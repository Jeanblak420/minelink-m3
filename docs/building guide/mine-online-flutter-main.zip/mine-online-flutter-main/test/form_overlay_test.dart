import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';
import 'package:mine_online/models/form_overlay.dart';

void main() {
  const f1 = FormFieldDef(
    key: 'extra_note',
    type: FormFieldType.text,
    label: 'Extra note',
    required: false,
  );
  const f2 = FormFieldDef(
    key: 'check_ok',
    type: FormFieldType.boolean,
    label: 'Checked OK',
    required: true,
  );

  group('FormOverlay', () {
    test('empty overlay has no content', () {
      const o = FormOverlay(
        addedFields: [],
        addedPages: [],
        fieldOverrides: {},
      );
      expect(o.hasContent, false);
    });

    test('round-trips added fields, pages, and overrides', () {
      const o = FormOverlay(
        addedFields: [f1],
        addedPages: [
          OverlayPage(id: 'p1', title: 'Extra checks', fields: [f2]),
        ],
        fieldOverrides: {
          'shiftBossName': FieldOverride(
            hidden: false,
            label: 'Supervisor',
            type: 'text',
            required: true,
          ),
        },
      );
      final back = FormOverlay.fromMap(o.toMap());
      expect(back.hasContent, true);
      expect(back.addedFields.single.key, 'extra_note');
      expect(back.addedPages.single.title, 'Extra checks');
      expect(back.addedPages.single.fields.single.key, 'check_ok');
      expect(back.fieldOverrides['shiftBossName']!.label, 'Supervisor');
    });

    test('fromMap tolerates an empty/missing map', () {
      expect(FormOverlay.fromMap(const {}).hasContent, false);
      expect(FormOverlay.fromMap(const {}).addedFields, isEmpty);
    });

    test('allOverlayFields flattens added fields + every page', () {
      const o = FormOverlay(
        addedFields: [f1],
        addedPages: [
          OverlayPage(id: 'p1', title: 'P', fields: [f2]),
        ],
        fieldOverrides: {},
      );
      final keys = allOverlayFields(o).map((f) => f.key).toList();
      expect(keys, containsAll(<String>['extra_note', 'check_ok']));
      expect(keys.length, 2);
    });

    test('overlayValuesFromPayload reads the namespaced map', () {
      final v = overlayValuesFromPayload({
        'name': 'x',
        'overlay': {'extra_note': 'hi'},
      });
      expect(v['extra_note'], 'hi');
      expect(overlayValuesFromPayload({'name': 'x'}), isEmpty);
    });
  });

  group('applyFieldOrder', () {
    const natural = ['a', 'b', 'c', 'd'];

    test('empty order keeps natural order', () {
      expect(applyFieldOrder(natural, const []), natural);
    });
    test('full permutation is honored', () {
      expect(applyFieldOrder(natural, ['d', 'c', 'b', 'a']), [
        'd',
        'c',
        'b',
        'a',
      ]);
    });
    test('partial order: named first, rest appended in natural order', () {
      expect(applyFieldOrder(natural, ['c', 'a']), ['c', 'a', 'b', 'd']);
    });
    test('unknown ids in order are ignored', () {
      expect(applyFieldOrder(natural, ['x', 'b', 'z']), ['b', 'a', 'c', 'd']);
    });
    test('idempotent', () {
      final once = applyFieldOrder(natural, ['c', 'a']);
      expect(applyFieldOrder(natural, once), once);
    });
  });
}
