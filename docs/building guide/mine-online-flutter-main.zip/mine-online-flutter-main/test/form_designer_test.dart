import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';

void main() {
  test('FormFieldDef round-trips legacy layout props + dynamicDropdown', () {
    const f = FormFieldDef(
      key: 'shaft',
      type: FormFieldType.dynamicDropdown,
      label: 'Shaft',
      required: true,
      section: 'Location',
      row: 'r1',
      rowOrder: 2,
      tabIndex: 3,
      dropdownSource: 'shafts',
    );
    final back = FormFieldDef.fromMap(f.toMap());
    expect(back.type, FormFieldType.dynamicDropdown);
    expect(back.section, 'Location');
    expect(back.row, 'r1');
    expect(back.rowOrder, 2);
    expect(back.tabIndex, 3);
    expect(back.dropdownSource, 'shafts');
  });

  test('legacy props absent → null (existing templates unaffected)', () {
    final back = FormFieldDef.fromMap(const {
      'key': 'a',
      'type': 'text',
      'label': 'A',
      'required': false,
    });
    expect(back.section, isNull);
    expect(back.rowOrder, isNull);
    expect(back.dropdownSource, isNull);
  });

  test(
    'groupBySection: no section → empty group first; sorted by row/order',
    () {
      const a = FormFieldDef(
        key: 'a',
        type: FormFieldType.text,
        label: 'A',
        required: false,
      );
      const b = FormFieldDef(
        key: 'b',
        type: FormFieldType.text,
        label: 'B',
        required: false,
        section: 'S',
        row: 'r1',
        rowOrder: 2,
      );
      const c = FormFieldDef(
        key: 'c',
        type: FormFieldType.text,
        label: 'C',
        required: false,
        section: 'S',
        row: 'r1',
        rowOrder: 1,
      );
      final g = groupBySection([a, b, c]);
      expect(g.first.key, '');
      final s = g.firstWhere((e) => e.key == 'S');
      expect(s.value.map((f) => f.key).toList(), ['c', 'b']);
    },
  );
}
