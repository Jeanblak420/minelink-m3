import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/form_metadata.dart';

void main() {
  group('groupFormsByCategory', () {
    test('preserves first-seen category order and within-category order', () {
      const forms = [
        FormMetadata(formType: 'a', title: 'A', route: '/a', category: 'X'),
        FormMetadata(formType: 'b', title: 'B', route: '/b', category: 'Y'),
        FormMetadata(formType: 'c', title: 'C', route: '/c', category: 'X'),
      ];
      final g = groupFormsByCategory(forms);
      expect(g.keys.toList(), ['X', 'Y']);
      expect(g['X']!.map((f) => f.formType).toList(), ['a', 'c']);
      expect(g['Y']!.map((f) => f.formType).toList(), ['b']);
    });

    test('empty input yields empty map', () {
      expect(groupFormsByCategory(const []), isEmpty);
    });

    test('real registry groups every form', () {
      final g = groupFormsByCategory(kFormMetadataRegistry);
      final total = g.values.fold<int>(0, (n, l) => n + l.length);
      expect(total, kFormMetadataRegistry.length);
    });
  });
}
