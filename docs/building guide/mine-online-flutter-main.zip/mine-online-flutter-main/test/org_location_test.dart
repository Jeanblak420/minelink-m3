import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/org_location.dart';

void main() {
  test('groupByParent groups sections by shaftId', () {
    final sections = [
      const Section(
        id: 's1',
        shaftId: 'a',
        name: 'X',
        description: null,
        isActive: true,
      ),
      const Section(
        id: 's2',
        shaftId: 'a',
        name: 'Y',
        description: null,
        isActive: true,
      ),
      const Section(
        id: 's3',
        shaftId: 'b',
        name: 'Z',
        description: null,
        isActive: true,
      ),
    ];
    final g = groupByParent(sections, (s) => s.shaftId);
    expect(g['a']!.length, 2);
    expect(g['b']!.length, 1);
    expect(g.containsKey('c'), isFalse);
  });

  test('Shaft.fromMap maps shaft_name -> name', () {
    final s = Shaft.fromMap({
      'id': '1',
      'shaft_name': 'North',
      'is_active': true,
    });
    expect(s.name, 'North');
    expect(s.isActive, isTrue);
  });

  test('Section/Area fromMap read parents + default isActive', () {
    final sec = Section.fromMap({
      'id': 's',
      'shaft_id': 'sh',
      'name': 'Sec',
      'is_active': false,
    });
    expect(sec.shaftId, 'sh');
    expect(sec.isActive, isFalse);

    final ar = Area.fromMap({'id': 'a', 'section_id': 's', 'name': 'Ar'});
    expect(ar.sectionId, 's');
    expect(ar.isActive, isTrue); // default when missing
  });
}
