import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/appointment.dart';

void main() {
  group('AppointmentStatus', () {
    test('wire/fromWire round-trip', () {
      for (final s in AppointmentStatus.values) {
        expect(AppointmentStatusX.fromWire(s.wire), s);
      }
    });
    test('fromWire falls back to pendingAcceptance on junk', () {
      expect(
        AppointmentStatusX.fromWire('nonsense'),
        AppointmentStatus.pendingAcceptance,
      );
    });
  });

  group('isLiveStatus', () {
    test('live for acceptance/signoff/active, not declined/resigned', () {
      expect(isLiveStatus(AppointmentStatus.pendingAcceptance), true);
      expect(isLiveStatus(AppointmentStatus.pendingSignoff), true);
      expect(isLiveStatus(AppointmentStatus.active), true);
      expect(isLiveStatus(AppointmentStatus.declined), false);
      expect(isLiveStatus(AppointmentStatus.resigned), false);
    });
  });

  group('mergeLetterValues', () {
    test('field keys take precedence over standard tokens', () {
      final out = mergeLetterValues({'section': 'Std'}, {'section': 'Field'});
      expect(out['section'], 'Field');
    });
    test('union of both maps', () {
      final out = mergeLetterValues({'full_name': 'Jane'}, {'area': 'A'});
      expect(out['full_name'], 'Jane');
      expect(out['area'], 'A');
    });
  });

  group('Appointment transitions', () {
    Appointment make(AppointmentStatus s) => Appointment.fromMap({
      'id': 'a',
      'role_code': 'R',
      'appointee_id': 'u',
      'effective_date': '2026-06-21',
      'status': s.wire,
      'payload': <String, dynamic>{},
      'issued_at': '2026-06-21T00:00:00Z',
    });
    test('canAccept/canDecline only when pending_acceptance', () {
      expect(make(AppointmentStatus.pendingAcceptance).canAccept, true);
      expect(make(AppointmentStatus.active).canAccept, false);
      expect(make(AppointmentStatus.pendingAcceptance).canDecline, true);
    });
    test('canResign when pending_signoff or active', () {
      expect(make(AppointmentStatus.active).canResign, true);
      expect(make(AppointmentStatus.pendingSignoff).canResign, true);
      expect(make(AppointmentStatus.declined).canResign, false);
    });
    test('round-trips effective_date and status through toMap', () {
      final a = make(AppointmentStatus.active);
      expect(a.toMap()['status'], 'active');
      expect(a.toMap()['effective_date'], '2026-06-21');
    });
  });
}
