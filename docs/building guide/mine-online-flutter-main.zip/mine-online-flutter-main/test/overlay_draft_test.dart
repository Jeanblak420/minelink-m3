import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/form_overlay_data.dart';
import 'package:mine_online/models/form_overlay.dart';

OverlayDraft d(String id, String base, String name, bool active) =>
    OverlayDraft(
      id: id,
      baseFormType: base,
      name: name,
      isActive: active,
      overlay: const FormOverlay(
        addedFields: [],
        addedPages: [],
        fieldOverrides: {},
      ),
    );

void main() {
  group('activeDraftName', () {
    final drafts = [
      d('1', 'shift_boss_appointment', 'Copy A', false),
      d('2', 'shift_boss_appointment', 'Copy B', true),
      d('3', 'miner_appointment', 'M', false),
    ];
    test('returns the active draft name for the form', () {
      expect(activeDraftName(drafts, 'shift_boss_appointment'), 'Copy B');
    });
    test('null when no active draft for the form', () {
      expect(activeDraftName(drafts, 'miner_appointment'), isNull);
      expect(activeDraftName(drafts, 'unknown'), isNull);
    });
  });
}
