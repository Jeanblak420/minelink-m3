import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/analytics_data.dart';

void main() {
  final now = DateTime.utc(2026, 6, 22, 12);
  String iso(int dAgo) => now.subtract(Duration(days: dAgo)).toIso8601String();

  test('forms: counts by type/status, per-day, % change', () {
    final summary = computeAnalytics(
      now: now,
      days: 7,
      priorSubmissionsCount: 2,
      submissions: [
        {
          'form_type': 'early_shift_record',
          'workflow_status': 'fully_signed',
          'created_at': iso(0),
        },
        {
          'form_type': 'early_shift_record',
          'workflow_status': 'submitted',
          'created_at': iso(1),
        },
        {
          'form_type': 'gassing_incident',
          'workflow_status': 'submitted',
          'created_at': iso(0),
        },
      ],
      appointments: const [],
      profiles: const [],
      devices: const [],
      signatureRequests: const [],
    );
    expect(summary.formsTotal, 3);
    expect(summary.formsByType['early_shift_record'], 2);
    expect(summary.formsByStatus['submitted'], 2);
    expect(summary.formsPerDay.length, 7);
    expect(summary.formsPerDay.last, 2); // today (dAgo 0): 2 submissions
    expect(summary.formsChangePct, 50); // (3-2)/2*100
  });

  test('appointments: status/role + acceptance rate', () {
    final s = computeAnalytics(
      now: now,
      days: 30,
      priorSubmissionsCount: 0,
      submissions: const [],
      appointments: [
        {'status': 'active', 'role_code': '2.13.1', 'accepted_at': iso(1)},
        {'status': 'declined', 'role_code': '2.13.1', 'accepted_at': null},
      ],
      profiles: const [],
      devices: const [],
      signatureRequests: const [],
    );
    expect(s.apptTotal, 2);
    expect(s.apptByRole['2.13.1'], 2);
    expect(s.apptAcceptanceRate, 0.5);
  });

  test('signatures completion + devices pending + profiles', () {
    final s = computeAnalytics(
      now: now,
      days: 30,
      priorSubmissionsCount: 0,
      submissions: const [],
      appointments: const [],
      profiles: [
        {'user_account_type': 'Shift Boss'},
        {'user_account_type': 'Shift Boss'},
      ],
      devices: [
        {'platform': 'windows', 'approved': false, 'is_active': true},
      ],
      signatureRequests: [
        {'requested_role': 'Mine Overseer', 'status': 'signed'},
        {'requested_role': 'Mine Overseer', 'status': 'pending'},
      ],
    );
    expect(s.profilesByAccountType['Shift Boss'], 2);
    expect(s.devicesPending, 1);
    expect(s.sigPendingByRole['Mine Overseer'], 1);
    expect(s.sigCompletionRate, 0.5);
  });

  test('sortedDesc', () {
    expect(sortedDesc({'a': 1, 'b': 3, 'c': 2}).map((e) => e.key).toList(), [
      'b',
      'c',
      'a',
    ]);
  });
}
