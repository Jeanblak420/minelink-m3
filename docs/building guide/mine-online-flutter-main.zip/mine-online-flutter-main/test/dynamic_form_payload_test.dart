import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';
import 'package:mine_online/utils/dynamic_form_payload.dart';

void main() {
  final fields = <FormFieldDef>[
    FormFieldDef(key: 'sec', type: FormFieldType.section, label: 'Section', required: false),
    FormFieldDef(key: 'name', type: FormFieldType.text, label: 'Name', required: true),
    FormFieldDef(key: 'note', type: FormFieldType.multiline, label: 'Note', required: false),
    FormFieldDef(key: 'ok', type: FormFieldType.boolean, label: 'OK?', required: true),
    FormFieldDef(key: 'rows', type: FormFieldType.table, label: 'Rows', required: false,
        columns: [FormFieldColumn(key: 'c', label: 'C', type: 'text')]),
  ];

  test('missingRequiredFields: required empty text is missing; section/optional ignored', () {
    final missing = missingRequiredFields(fields, {'ok': false});
    expect(missing, ['Name']);
  });

  test('missingRequiredFields: filled required passes', () {
    final missing = missingRequiredFields(fields, {'name': 'Al', 'ok': true});
    expect(missing, isEmpty);
  });

  test('missingRequiredFields: whitespace-only string is missing', () {
    final missing = missingRequiredFields(fields, {'name': '   ', 'ok': true});
    expect(missing, ['Name']);
  });

  test('buildSubmissionPayload omits section, defaults types', () {
    final payload = buildSubmissionPayload(fields, {'name': 'Al', 'ok': true});
    expect(payload.containsKey('sec'), isFalse);
    expect(payload['name'], 'Al');
    expect(payload['note'], '');
    expect(payload['ok'], true);
    expect(payload['rows'], isA<List>());
    expect(payload['rows'], isEmpty);
  });

  test('buildSubmissionPayload keeps table rows', () {
    final rows = [
      {'c': 'one'},
      {'c': 'two'},
    ];
    final payload = buildSubmissionPayload(fields, {'name': 'Al', 'ok': false, 'rows': rows});
    expect(payload['rows'], rows);
    expect(payload['ok'], false);
  });
}
