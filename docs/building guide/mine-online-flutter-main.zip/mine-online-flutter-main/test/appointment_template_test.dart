import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/appointment_template.dart';
import 'package:mine_online/models/custom_form_template.dart';

void main() {
  group('extractPlaceholders', () {
    test('returns distinct tokens in first-seen order', () {
      expect(
        extractPlaceholders(
          'Dear {{full_name}}, ref {{employee_number}} / {{full_name}}.',
        ),
        ['full_name', 'employee_number'],
      );
    });
    test('tolerates inner whitespace', () {
      expect(extractPlaceholders('{{ first_name }}'), ['first_name']);
    });
    test('empty when no tokens', () {
      expect(extractPlaceholders('plain text'), <String>[]);
    });
  });

  group('renderLetterBody', () {
    test('substitutes known tokens', () {
      expect(
        renderLetterBody('Hi {{full_name}}', {'full_name': 'Jane Doe'}),
        'Hi Jane Doe',
      );
    });
    test('leaves unknown tokens verbatim', () {
      expect(
        renderLetterBody('Hi {{missing}}', {'full_name': 'x'}),
        'Hi {{missing}}',
      );
    });
    test(
      'field token precedence is just map lookup (caller controls order)',
      () {
        expect(
          renderLetterBody('{{section}}', {'section': 'Section A'}),
          'Section A',
        );
      },
    );
  });

  group('validateAppointmentTemplate', () {
    test('flags empty name, missing role, and no fields', () {
      final errors = validateAppointmentTemplate(
        name: '  ',
        roleId: null,
        fields: const [],
      );
      expect(errors, contains('Template name is required.'));
      expect(errors, contains('Select an appointment role.'));
      expect(errors, contains('Add at least one field.'));
    });
    test('does not surface the form-builder name message', () {
      final errors = validateAppointmentTemplate(
        name: '  ',
        roleId: 'r1',
        fields: const [
          FormFieldDef(
            key: 'a',
            type: FormFieldType.text,
            label: 'A',
            required: false,
          ),
        ],
      );
      expect(errors, isNot(contains('Form name is required.')));
      expect(errors, contains('Template name is required.'));
    });
    test('passes a valid template', () {
      final errors = validateAppointmentTemplate(
        name: 'Shift Boss',
        roleId: 'role-1',
        fields: const [
          FormFieldDef(
            key: 'area',
            type: FormFieldType.text,
            label: 'Area',
            required: true,
          ),
        ],
      );
      expect(errors, isEmpty);
    });
  });

  group('AppointmentTemplate round-trip', () {
    test('toMap/fromMap preserves fields and letterBody', () {
      const t = AppointmentTemplate(
        id: 'id1',
        code: 'appt_x',
        name: 'X',
        description: null,
        roleId: 'r1',
        language: 'en',
        fields: [
          FormFieldDef(
            key: 'a',
            type: FormFieldType.text,
            label: 'A',
            required: false,
          ),
        ],
        letterBody: 'Hi {{a}}',
        requiredSigners: ['mine_overseer'],
        version: 2,
        isActive: true,
        createdBy: null,
      );
      final back = AppointmentTemplate.fromMap({...t.toMap(), 'id': 'id1'});
      expect(back.code, 'appt_x');
      expect(back.fields.single.key, 'a');
      expect(back.letterBody, 'Hi {{a}}');
      expect(back.requiredSigners, ['mine_overseer']);
      expect(back.version, 2);
    });
  });

  group('AppointmentRole', () {
    test('displayLabel uses code when present', () {
      const r = AppointmentRole(
        id: 'r',
        label: 'Mine Manager',
        code: '2.6.1',
        description: null,
        isMandatory: true,
        isActive: true,
        sortOrder: 10,
      );
      expect(r.displayLabel, '2.6.1 — Mine Manager');
    });
    test('displayLabel falls back to label without code', () {
      const r = AppointmentRole(
        id: 'r',
        label: 'Relieving Miner',
        code: null,
        description: null,
        isMandatory: false,
        isActive: true,
        sortOrder: 60,
      );
      expect(r.displayLabel, 'Relieving Miner');
    });
  });
}
