import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/widgets/admin/admin_sidebar.dart';

void main() {
  test('root only active on exact /', () {
    expect(isSidebarRouteActive('/', '/'), isTrue);
    expect(isSidebarRouteActive('/', '/profiles'), isFalse);
  });

  test('non-root active on exact match or sub-path', () {
    expect(isSidebarRouteActive('/profiles', '/profiles'), isTrue);
    expect(isSidebarRouteActive('/reports', '/reports/daily'), isTrue);
    expect(isSidebarRouteActive('/reports', '/reportsX'), isFalse);
    expect(isSidebarRouteActive('/appointments', '/'), isFalse);
  });
}
