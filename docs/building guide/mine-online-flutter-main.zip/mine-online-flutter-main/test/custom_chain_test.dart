import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/dynamic_form_payload.dart';

void main() {
  test('empty / unknown signers → false, no mutation', () {
    final p = <String, dynamic>{'name': 'Al'};
    expect(applyCustomChainSignatureFields(const [], p), isFalse);
    expect(applyCustomChainSignatureFields(['shift_boss'], p), isFalse);
    expect(p.containsKey('signatures'), isFalse);
  });

  test('mine_overseer adds blank recognized fields and returns true', () {
    final p = <String, dynamic>{};
    final added = applyCustomChainSignatureFields(['mine_overseer'], p);
    expect(added, isTrue);
    final sig = p['signatures'] as Map<String, dynamic>;
    expect(sig['mineOverseerSignature'], '');
    expect(sig['mineOverseerDate'], '');
    expect(sig.containsKey('mineManagerSignature'), isFalse);
  });

  test('both signers add both field sets', () {
    final p = <String, dynamic>{};
    applyCustomChainSignatureFields(['mine_overseer', 'mine_manager'], p);
    final sig = p['signatures'] as Map<String, dynamic>;
    expect(sig['mineOverseerSignature'], '');
    expect(sig['mineManagerSignature'], '');
  });

  test('existing signature values are preserved', () {
    final p = <String, dynamic>{
      'signatures': {'mineOverseerSignature': 'data:image/png;base64,xx'},
    };
    applyCustomChainSignatureFields(['mine_overseer', 'mine_manager'], p);
    final sig = p['signatures'] as Map<String, dynamic>;
    expect(sig['mineOverseerSignature'], 'data:image/png;base64,xx');
    expect(sig['mineManagerSignature'], '');
  });
}
