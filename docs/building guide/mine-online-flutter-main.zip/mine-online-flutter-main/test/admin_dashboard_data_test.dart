import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/admin_dashboard_data.dart';

void main() {
  final submissions = <Map<String, dynamic>>[
    {'id': 's1', 'user_id': 'u1', 'form_type': 'shift_boss_appointment', 'workflow_status': 'fully_signed', 'current_signature_role': null, 'created_at': '2026-06-10T08:00:00Z'},
    {'id': 's2', 'user_id': 'u2', 'form_type': 'miner_appointment', 'workflow_status': 'pending_signature', 'current_signature_role': 'Mine Overseer', 'created_at': '2026-06-12T08:00:00Z'},
    {'id': 's3', 'user_id': 'u1', 'form_type': 'gassing_incident', 'workflow_status': 'submitted', 'current_signature_role': null, 'created_at': '2026-06-11T08:00:00Z'},
    {'id': 's4', 'user_id': 'u3', 'form_type': 'shift_boss_daily_report', 'workflow_status': 'submitted', 'current_signature_role': null, 'created_at': '2026-06-09T08:00:00Z'},
  ];
  final profiles = <String, Map<String, dynamic>>{
    'u1': {'id': 'u1', 'full_name': 'Alice Stone', 'email': 'alice@x.co', 'occupation': 'Shift Boss', 'location': 'Shaft 1'},
    'u2': {'id': 'u2', 'full_name': '', 'email': 'bob@x.co', 'job_title': 'Miner', 'location': ''},
  };

  test('counts KPIs from submissions', () {
    final d = computeAdminDashboard(profileCount: 9, submissions: submissions, profiles: profiles);
    expect(d.totalEmployees, 9);
    expect(d.activeAppointments, 1); // s1 only (appt + fully_signed)
    expect(d.pendingForms, 3); // s2, s3, s4 (submitted/pending_signature)
    expect(d.safetyIncidents, 1); // s3
  });

  test('activity feed includes only appointment rows, newest-first order preserved', () {
    final d = computeAdminDashboard(profileCount: 9, submissions: submissions, profiles: profiles);
    expect(d.recentActivity.map((a) => a.submissionId), ['s1', 's2']);
  });

  test('activity item name/subtitle resolve from profile with fallbacks', () {
    final d = computeAdminDashboard(profileCount: 9, submissions: submissions, profiles: profiles);
    final a = d.recentActivity[0];
    expect(a.name, 'Alice Stone');
    expect(a.subtitle, 'Shift Boss • Shaft 1');
    final b = d.recentActivity[1];
    expect(b.name, 'bob@x.co'); // empty full_name -> email
    expect(b.subtitle, 'Miner'); // job_title used, empty location dropped
    expect(b.workflowStatus, 'pending_signature');
  });

  test('activityLimit caps the feed', () {
    final many = List.generate(10, (i) => {
      'id': 'a$i', 'user_id': 'u1', 'form_type': 'miner_appointment',
      'workflow_status': 'submitted', 'created_at': '2026-06-0${i}T08:00:00Z',
    });
    final d = computeAdminDashboard(profileCount: 0, submissions: many, profiles: const {}, activityLimit: 6);
    expect(d.recentActivity.length, 6);
  });
}
