import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/report_data.dart';

void main() {
  group('reportWindow', () {
    test('daily is one calendar day, end exclusive', () {
      final w = reportWindow(ReportPeriod.daily, DateTime(2026, 6, 24, 15, 30));
      expect(w.start, DateTime(2026, 6, 24));
      expect(w.end, DateTime(2026, 6, 25));
      expect(w.label, 'Wednesday, 24 June 2026');
    });

    test('weekly starts Monday and spans 7 days', () {
      // 2026-06-24 is a Wednesday; week is Mon 22 -> Mon 29.
      final w = reportWindow(ReportPeriod.weekly, DateTime(2026, 6, 24));
      expect(w.start, DateTime(2026, 6, 22));
      expect(w.end, DateTime(2026, 6, 29));
      expect(w.label, 'Week of 22–28 June 2026');
    });

    test('monthly is start-of-month to start-of-next-month', () {
      final w = reportWindow(ReportPeriod.monthly, DateTime(2026, 6, 15));
      expect(w.start, DateTime(2026, 6, 1));
      expect(w.end, DateTime(2026, 7, 1));
      expect(w.label, 'June 2026');
    });

    test('monthly rolls over December to next January', () {
      final w = reportWindow(ReportPeriod.monthly, DateTime(2026, 12, 9));
      expect(w.start, DateTime(2026, 12, 1));
      expect(w.end, DateTime(2027, 1, 1));
      expect(w.label, 'December 2026');
    });
  });

  group('computeReport', () {
    final window = reportWindow(ReportPeriod.monthly, DateTime(2026, 6, 15));
    Map<String, dynamic> sub(
      String type,
      String status,
      String day,
      String uid,
    ) => {
      'form_type': type,
      'workflow_status': status,
      'created_at': '2026-06-${day}T08:00:00Z',
      'user_id': uid,
    };

    test('counts KPIs, breakdowns, and orders register newest-first', () {
      final s = computeReport(
        period: ReportPeriod.monthly,
        window: window,
        submissions: [
          sub('weekly_sherq_meeting', 'fully_signed', '03', 'u1'),
          sub('gassing_incident', 'submitted', '10', 'u2'),
          sub('weekly_sherq_meeting', 'pending_signature', '07', 'u1'),
        ],
        appointments: [
          {'status': 'active', 'accepted_at': '2026-06-04T00:00:00Z'},
          {'status': 'pending_acceptance', 'accepted_at': null},
        ],
        signatureRequests: [
          {'status': 'signed'},
          {'status': 'signed'},
          {'status': 'pending'},
        ],
        profiles: {
          'u1': {'full_name': 'Alice Adams'},
          'u2': {'email': 'bob@mine.test'},
        },
      );

      expect(s.submissions, 3);
      expect(s.fullySigned, 1);
      expect(s.pendingInChain, 2); // 'submitted' + 'pending_signature'
      expect(s.incidents, 1); // gassing_incident
      expect(s.appointmentsIssued, 2);
      expect(s.appointmentsAccepted, 1);
      expect(s.signatureCompletionRate, closeTo(2 / 3, 1e-9));
      expect(s.byFormType['Weekly SHERQ Meeting'], 2);
      expect(s.byStatus['fully_signed'], 1);
      // newest-first: day 10, 07, 03
      expect(s.register.first.date, DateTime.parse('2026-06-10T08:00:00Z'));
      expect(s.register.first.submitter, 'bob@mine.test');
      expect(s.register.last.submitter, 'Alice Adams');
    });

    test('empty inputs yield zeros and empty register', () {
      final s = computeReport(
        period: ReportPeriod.daily,
        window: reportWindow(ReportPeriod.daily, DateTime(2026, 6, 24)),
        submissions: const [],
        appointments: const [],
        signatureRequests: const [],
        profiles: const {},
      );
      expect(s.submissions, 0);
      expect(s.signatureCompletionRate, 0.0);
      expect(s.register, isEmpty);
    });
  });
}
