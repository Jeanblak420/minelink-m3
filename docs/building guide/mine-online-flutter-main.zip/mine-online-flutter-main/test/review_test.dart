import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/review_data.dart';

void main() {
  group('reviewStatusLabel', () {
    test('pending for null / empty / pending', () {
      expect(reviewStatusLabel(null), 'Pending');
      expect(reviewStatusLabel(''), 'Pending');
      expect(reviewStatusLabel('pending'), 'Pending');
    });
    test('known statuses', () {
      expect(reviewStatusLabel('approved'), 'Approved');
      expect(reviewStatusLabel('rejected'), 'Rejected');
      expect(reviewStatusLabel('flagged'), 'Flagged');
    });
    test('unknown passes through', () {
      expect(reviewStatusLabel('weird'), 'weird');
    });
  });
}
