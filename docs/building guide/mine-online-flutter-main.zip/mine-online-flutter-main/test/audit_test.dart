import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/audit_data.dart';

AuditEntry e(
  String action, {
  Map<String, dynamic>? oldV,
  Map<String, dynamic>? newV,
}) => AuditEntry.fromMap({
  'id': '00000000-0000-0000-0000-000000000001',
  'user_id': 'actor-1',
  'action': action,
  'entity_type': 'user',
  'entity_id': 'target-1',
  'old_values': oldV,
  'new_values': newV,
  'created_at': '2026-06-25T10:00:00Z',
});

void main() {
  group('describeAuditEntry', () {
    const names = {'actor-1': 'Jean Burger', 'target-1': 'Bob Miner'};
    String d(AuditEntry entry) => describeAuditEntry(
      entry,
      actorName: names[entry.actorId],
      targetName: names[entry.entityId],
    );

    test('create', () {
      expect(
        d(e('user.create')),
        'Jean Burger created an account for Bob Miner',
      );
    });
    test('delete', () {
      expect(d(e('user.delete')), "Jean Burger deleted Bob Miner's account");
    });
    test('password', () {
      expect(
        d(e('user.update_password')),
        "Jean Burger reset Bob Miner's password",
      );
    });
    test('disable', () {
      expect(d(e('user.disable')), "Jean Burger disabled Bob Miner's account");
    });
    test('enable', () {
      expect(d(e('user.enable')), "Jean Burger re-enabled Bob Miner's account");
    });
    test('role_change reads old/new', () {
      final entry = e(
        'user.role_change',
        oldV: {'user_account_type': 'Miner'},
        newV: {'user_account_type': 'Shift Boss'},
      );
      expect(
        d(entry),
        "Jean Burger changed Bob Miner's role from Miner to Shift Boss",
      );
    });
    test('unknown action falls back', () {
      expect(
        d(e('widget.frobnicate')),
        'Jean Burger performed widget.frobnicate on user Bob Miner',
      );
    });
    test('missing names degrade', () {
      final entry = e('user.disable');
      expect(
        describeAuditEntry(entry),
        "An administrator disabled a user's account",
      );
    });
    test('submission.review reads status + title from new_values', () {
      final entry = AuditEntry.fromMap({
        'id': 'a',
        'user_id': 'actor-1',
        'action': 'submission.review',
        'entity_type': 'form_submission',
        'entity_id': 'sub-1',
        'old_values': {'review_status': 'pending'},
        'new_values': {
          'review_status': 'approved',
          'title': 'Weekly SHERQ Meeting',
        },
        'created_at': '2026-06-25T10:00:00Z',
      });
      expect(
        describeAuditEntry(entry, actorName: 'Jean Burger'),
        'Jean Burger approved the submission "Weekly SHERQ Meeting"',
      );
    });
    test('submission.review without title degrades', () {
      final entry = AuditEntry.fromMap({
        'id': 'a',
        'user_id': 'actor-1',
        'action': 'submission.review',
        'entity_type': 'form_submission',
        'entity_id': 'sub-1',
        'old_values': null,
        'new_values': {'review_status': 'flagged'},
        'created_at': '2026-06-25T10:00:00Z',
      });
      expect(
        describeAuditEntry(entry, actorName: 'Jean Burger'),
        'Jean Burger flagged a submission',
      );
    });

    AuditEntry ev(String action, Map<String, dynamic> newV, {String? actor}) =>
        AuditEntry.fromMap({
          'id': 'x',
          'user_id': actor,
          'action': action,
          'entity_type': action.split('.').first,
          'entity_id': 'e1',
          'old_values': null,
          'new_values': newV,
          'created_at': '2026-06-25T10:00:00Z',
        });

    test('appointment.issued names role + appointee', () {
      final e = ev('appointment.issued', {
        'role_code': 'Shift Boss',
        'appointee_name': 'Bob Miner',
      }, actor: 'actor-1');
      expect(
        describeAuditEntry(e, actorName: 'Jean Burger'),
        'Jean Burger issued a Shift Boss appointment to Bob Miner',
      );
    });
    test('appointment.issued without appointee degrades', () {
      final e = ev('appointment.issued', {'role_code': 'Shift Boss'});
      expect(
        describeAuditEntry(e),
        'An administrator issued a Shift Boss appointment to an appointee',
      );
    });
    test('appointment.activated has no actor', () {
      final e = ev('appointment.activated', {'role_code': 'Shift Boss'});
      expect(describeAuditEntry(e), 'A Shift Boss appointment became active');
    });
    test('appointment.resigned', () {
      final e = ev('appointment.resigned', {'role_code': 'Miner'});
      expect(
        describeAuditEntry(e, actorName: 'Bob Miner'),
        'Bob Miner resigned from a Miner appointment',
      );
    });
    test('device.approved names platform', () {
      final e = ev('device.approved', {'platform': 'windows'});
      expect(
        describeAuditEntry(e, actorName: 'Jean Burger'),
        'Jean Burger approved a device (windows)',
      );
    });
    test('device.revoked', () {
      final e = ev('device.revoked', {'platform': 'android'});
      expect(
        describeAuditEntry(e, actorName: 'Jean Burger'),
        'Jean Burger revoked a device (android)',
      );
    });
  });
}
