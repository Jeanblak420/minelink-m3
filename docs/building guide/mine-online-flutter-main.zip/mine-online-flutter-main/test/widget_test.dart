// Placeholder test: full app boot requires Supabase + dotenv initialisation,
// so we just verify the entry symbol resolves. Real widget tests will be added
// as forms ship with verifiable behaviour.

import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/app.dart';

void main() {
  test('MineOnlineApp class is exported', () {
    expect(MineOnlineApp, isNotNull);
  });
}
