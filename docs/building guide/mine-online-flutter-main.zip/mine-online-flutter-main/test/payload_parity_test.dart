// Payload-shape parity tests for the 11 signature-chain forms.
//
// For each form, build a deterministic input fixture and assert that
// `data.toMap()` produces the exact JSON shape the web app produces for the
// same input. The web app reads `form_submissions.payload` via the signature
// paths defined in `src/utils/formRegistry.ts`, so if Flutter's toMap output
// matches the shape the web app's interface declares, both apps will round-
// trip a submission through the signature workflow identically.
//
// The expected maps below are hand-written from `src/types/FormData.ts`
// interface definitions (verified field-by-field across audit rounds 2/5/6/7).
// If anyone renames a field in Flutter's form_data.dart without updating both
// sides of this test, the assertion will fail loudly.

import 'package:flutter_test/flutter_test.dart';

import 'package:mine_online/models/form_data.dart';

void main() {
  group('Payload parity — chain forms', () {
    test('shift_boss_appointment', () {
      final data = ShiftBossFormData(
        title: 'Mr',
        name: 'Jean Test',
        identityNumber: '0123456789012',
        companyNumber: '123456',
        shaft: 'North Shaft',
        workplaces: WorkplaceSet(
          stopes: 'Yes',
          developmentEnds: 'Yes',
          declines: 'No',
          loadAndHaul: 'Yes',
          travellingWay: 'Yes',
          refugeBay: 'Yes',
          store: 'No',
          waitingPlace: 'Yes',
          conveyorBelts: 'Yes',
          otherWorkplaces: 'Misc',
        ),
        effectiveDate: '16/08/2023',
        nextRevisionDate: '16/08/2026',
        signatures: ShiftBossSignatures(
          shiftBossSignature: 'data:image/png;base64,SB',
          shiftBossDate: '01/01/2026',
        ),
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'title': 'Mr',
        'name': 'Jean Test',
        'identityNumber': '0123456789012',
        'companyNumber': '123456',
        'shaft': 'North Shaft',
        'workplaces': <String, dynamic>{
          'stopes': 'Yes',
          'developmentEnds': 'Yes',
          'declines': 'No',
          'loadAndHaul': 'Yes',
          'travellingWay': 'Yes',
          'refugeBay': 'Yes',
          'store': 'No',
          'waitingPlace': 'Yes',
          'conveyorBelts': 'Yes',
          'otherWorkplaces': 'Misc',
        },
        'effectiveDate': '16/08/2023',
        'nextRevisionDate': '16/08/2026',
        'signatures': <String, dynamic>{
          'shiftBossSignature': 'data:image/png;base64,SB',
          'shiftBossDate': '01/01/2026',
          'mineOverseerSignature': '',
          'mineOverseerDate': '',
          'mineManagerSignature': '',
          'mineManagerDate': '',
        },
      }));
    });

    test('miner_appointment', () {
      final data = MinerAppointmentFormData(
        title: 'Mrs',
        name: 'Test Miner',
        identityNumber: '9876543210123',
        companyNumber: '654321',
        sectionShaft: 'South Shaft',
        workplaces: WorkplaceSet(
          stopes: 'Yes',
          developmentEnds: '',
          declines: '',
          loadAndHaul: 'Yes',
          travellingWay: '',
          refugeBay: '',
          store: '',
          waitingPlace: 'Yes',
          conveyorBelts: '',
          otherWorkplaces: '',
        ),
        signatures: MinerAppointmentSignatures(
          minerSignature: 'data:image/png;base64,M',
          minerDate: '02/02/2026',
        ),
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'title': 'Mrs',
        'name': 'Test Miner',
        'identityNumber': '9876543210123',
        'companyNumber': '654321',
        'sectionShaft': 'South Shaft',
        'workplaces': <String, dynamic>{
          'stopes': 'Yes',
          'developmentEnds': '',
          'declines': '',
          'loadAndHaul': 'Yes',
          'travellingWay': '',
          'refugeBay': '',
          'store': '',
          'waitingPlace': 'Yes',
          'conveyorBelts': '',
          'otherWorkplaces': '',
        },
        'signatures': <String, dynamic>{
          'minerSignature': 'data:image/png;base64,M',
          'minerDate': '02/02/2026',
          'shiftBossSignature': '',
          'shiftBossDate': '',
          'mineOverseerSignature': '',
          'mineOverseerDate': '',
          'mineManagerSignature': '',
          'mineManagerDate': '',
        },
      }));
    });

    test('relieving_miner_appointment', () {
      final data = RelievingMinerFormData(
        title: 'Mr',
        name: 'Test Relieving Miner',
        identityNumber: '5555566667777',
        companyNumber: '777888',
        sectionShaft: 'East Shaft',
        workplaces: WorkplaceSet(stopes: 'Yes', refugeBay: 'Yes'),
        signatures: RelievingMinerSignatures(
          relievingMinerSignature: 'data:image/png;base64,RM',
          relievingMinerDate: '03/03/2026',
        ),
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'title': 'Mr',
        'name': 'Test Relieving Miner',
        'identityNumber': '5555566667777',
        'companyNumber': '777888',
        'sectionShaft': 'East Shaft',
        'workplaces': <String, dynamic>{
          'stopes': 'Yes',
          'developmentEnds': '',
          'declines': '',
          'loadAndHaul': '',
          'travellingWay': '',
          'refugeBay': 'Yes',
          'store': '',
          'waitingPlace': '',
          'conveyorBelts': '',
          'otherWorkplaces': '',
        },
        'signatures': <String, dynamic>{
          'relievingMinerSignature': 'data:image/png;base64,RM',
          'relievingMinerDate': '03/03/2026',
          'shiftBossSignature': '',
          'shiftBossDate': '',
          'mineOverseerSignature': '',
          'mineOverseerDate': '',
          'mineManagerSignature': '',
          'mineManagerDate': '',
        },
      }));
    });

    test('gassing_incident', () {
      final data = GassingIncidentFormData(
        date: '04/04/2026',
        coyNoOfInjured: 'C42',
        time: '14:30',
        workingPlace: 'Stope 12',
        severity: 'Minor',
        description: 'Smoke from ventilation duct.',
        injuries: 'None',
        shiftBossSignature: 'data:image/png;base64,SB',
        mineOverseerSignature: '',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'date': '04/04/2026',
        'coyNoOfInjured': 'C42',
        'time': '14:30',
        'workingPlace': 'Stope 12',
        'severity': 'Minor',
        'description': 'Smoke from ventilation duct.',
        'injuries': 'None',
        'shiftBossSignature': 'data:image/png;base64,SB',
        'mineOverseerSignature': '',
      }));
    });

    test('weekly_sherq_meeting', () {
      final data = WeeklySherqMeetingFormData(
        date: '05/05/2026',
        time: '08:00',
        workplace: 'Crib Room',
        duration: '30 min',
        supervisorCoyNo: 'S100',
        sheRepCoyNo: 'R200',
        topics: WeeklySherqTopics(
          standards: true,
          incident: false,
          emergencyPreparedness: true,
          soReport: false,
          instruction: true,
          rockMechanicReport: false,
          ppe: true,
          sheRepReport: false,
          procedures: true,
          ventReport: false,
        ),
        mattersDiscussed: 'Lockout procedures.',
        feedbackFromCrew: 'All clear.',
        attendance: [
          AttendanceEntry(coyNo: 'A1', signature: 'sig1'),
          AttendanceEntry(coyNo: 'B2', signature: ''),
        ],
        supervisorSignature: 'data:image/png;base64,SUP',
        sheRepSignature: '',
        shiftBossSignature: 'data:image/png;base64,SB',
        mineOverseerSignature: '',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'date': '05/05/2026',
        'time': '08:00',
        'workplace': 'Crib Room',
        'duration': '30 min',
        'supervisorCoyNo': 'S100',
        'sheRepCoyNo': 'R200',
        'topics': <String, dynamic>{
          'standards': true,
          'incident': false,
          'emergencyPreparedness': true,
          'soReport': false,
          'instruction': true,
          'rockMechanicReport': false,
          'ppe': true,
          'sheRepReport': false,
          'procedures': true,
          'ventReport': false,
        },
        'mattersDiscussed': 'Lockout procedures.',
        'feedbackFromCrew': 'All clear.',
        'attendance': <Map<String, dynamic>>[
          {'coyNo': 'A1', 'signature': 'sig1'},
          {'coyNo': 'B2', 'signature': ''},
        ],
        'supervisorSignature': 'data:image/png;base64,SUP',
        'sheRepSignature': '',
        'shiftBossSignature': 'data:image/png;base64,SB',
        'mineOverseerSignature': '',
      }));
    });

    test('early_shift_record', () {
      final data = EarlyShiftRecordFormData(
        section: 'Sec A',
        strike: 'Strike 1',
        date: '06/06/2026',
        wentUndergroundAt: '06:00',
        arrivedAtWaitingPlace: '06:30',
        minerArrivedAt: '06:45',
        minerCoyNo: 'C99',
        waitingPlaceLocation: 'WP1',
        barricadeErected: 'Yes',
        barricadeDetails: '',
        minerFollowedProcedure: 'Yes',
        minerFollowedDetails: '',
        permissionToCompA: 'Yes',
        minerPossessionGDI: 'Yes',
        gdiNo: 'G12',
        blastingCableDisconnected: 'Yes',
        earlyEntryExamination: 'Yes',
        earlyEntryDetails: '',
        safeDeclarationBooklet: 'Yes',
        safeDeclarationDetails: '',
        flammableGasesTest: 'Yes',
        flammableGasesDetails: '',
        entryEquipmentAvailable: 'Yes',
        entryEquipmentDetails: '',
        hygrometerAndAnemo: 'Yes',
        hygrometerDetails: '',
        waterDownProperly: 'Yes',
        drinkingWaterAvailable: 'Yes',
        drinkingWaterDetails: '',
        specialInstruction: 'None',
        additionalRemarks: '',
        shiftBossSignature: 'data:image/png;base64,SB',
        shiftBossSignatureDate: '06/06/2026',
        minerOverseerSignature: '',
        minerOverseerSignatureDate: '',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'section': 'Sec A',
        'strike': 'Strike 1',
        'date': '06/06/2026',
        'wentUndergroundAt': '06:00',
        'arrivedAtWaitingPlace': '06:30',
        'minerArrivedAt': '06:45',
        'minerCoyNo': 'C99',
        'waitingPlaceLocation': 'WP1',
        'barricadeErected': 'Yes',
        'barricadeDetails': '',
        'minerFollowedProcedure': 'Yes',
        'minerFollowedDetails': '',
        'permissionToCompA': 'Yes',
        'minerPossessionGDI': 'Yes',
        'gdiNo': 'G12',
        'blastingCableDisconnected': 'Yes',
        'earlyEntryExamination': 'Yes',
        'earlyEntryDetails': '',
        'safeDeclarationBooklet': 'Yes',
        'safeDeclarationDetails': '',
        'flammableGasesTest': 'Yes',
        'flammableGasesDetails': '',
        'entryEquipmentAvailable': 'Yes',
        'entryEquipmentDetails': '',
        'hygrometerAndAnemo': 'Yes',
        'hygrometerDetails': '',
        'waterDownProperly': 'Yes',
        'drinkingWaterAvailable': 'Yes',
        'drinkingWaterDetails': '',
        'specialInstruction': 'None',
        'additionalRemarks': '',
        'shiftBossSignature': 'data:image/png;base64,SB',
        'shiftBossSignatureDate': '06/06/2026',
        'minerOverseerSignature': '',
        'minerOverseerSignatureDate': '',
      }));
    });

    test('late_shift_record', () {
      final data = LateShiftRecordFormData(
        section: 'Sec B',
        strike: 'Strike 2',
        date: '07/07/2026',
        minerInChargeCoyNo: 'C77',
        chargesCorrectlyPrepared: 'Yes',
        chargingUpDevEndNo: 'DE-1',
        explosiveCorrectlyTransported: 'Yes',
        testedForFlammableGas: 'Yes',
        gdiNo: 'G34',
        chargingUnderDirectSupervision: 'Yes',
        typeOfExplosivesUsed: 'ANFO',
        typeOfFuseUsed: 'Safety',
        fuseLength: '2m',
        amountOfFusesUsed: '5',
        holesDislodgedCorrectly: 'Yes',
        lengthOfDrillHoles: '2.5m',
        lengthOfBlowPipe: '1m',
        blastingCableToStandard: 'Yes',
        circuitTested: 'Yes',
        blastingCableConnectedToTerminalBox: 'Yes',
        distributionOfOldExplosivesObserved: 'Yes',
        distributionOfOldExplosivesDiscussed: 'Yes',
        workingPlaceBarricadeInPosition: 'Yes',
        explosiveBoxesLocked: 'Yes',
        idCardsCorrectlyIssued: 'Yes',
        airAndWaterHosesClosed: 'Yes',
        anyIncidentInjuriesReported: 'No',
        arrivedOnSurfaceAt: '18:00',
        specialInstructionsGiven: '',
        shiftBossSignature: 'data:image/png;base64,SB',
        shiftBossSignatureDate: '07/07/2026',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'section': 'Sec B',
        'strike': 'Strike 2',
        'date': '07/07/2026',
        'minerInChargeCoyNo': 'C77',
        'chargesCorrectlyPrepared': 'Yes',
        'chargesDetails': '',
        'chargingUpDevEndNo': 'DE-1',
        'ventHolingNo': '',
        'explosiveCorrectlyTransported': 'Yes',
        'testedForFlammableGas': 'Yes',
        'gdiNo': 'G34',
        'chargingUnderDirectSupervision': 'Yes',
        'typeOfExplosivesUsed': 'ANFO',
        'typeOfFuseUsed': 'Safety',
        'fuseLength': '2m',
        'amountOfFusesUsed': '5',
        'holesDislodgedCorrectly': 'Yes',
        'holesDislodgedDetails': '',
        'lengthOfDrillHoles': '2.5m',
        'lengthOfBlowPipe': '1m',
        'blastingCableToStandard': 'Yes',
        'blastingCableDetails': '',
        'circuitTested': 'Yes',
        'blastingCableConnectedToTerminalBox': 'Yes',
        'blastingCableTerminalDetails': '',
        'distributionOfOldExplosivesObserved': 'Yes',
        'distributionOfOldExplosivesDiscussed': 'Yes',
        'workingPlaceBarricadeInPosition': 'Yes',
        'explosiveBoxesLocked': 'Yes',
        'barricadeExplosiveDetails': '',
        'idCardsCorrectlyIssued': 'Yes',
        'airAndWaterHosesClosed': 'Yes',
        'anyIncidentInjuriesReported': 'No',
        'arrivedOnSurfaceAt': '18:00',
        'specialInstructionsGiven': '',
        'additionalRemarks': '',
        'shiftBossSignature': 'data:image/png;base64,SB',
        'shiftBossSignatureDate': '07/07/2026',
        'minerOverseerSignature': '',
        'minerOverseerSignatureDate': '',
      }));
    });

    test('explosive_control_record', () {
      final data = ExplosiveControlRecordFormData(
        section: 'Sec X',
        strike: 'Strike X',
        date: '08/08/2026',
        minerCoyNo: 'C55',
        entries: [
          ExplosiveControlEntry(
            description: 'Capped fuse',
            boxNo: 'B1',
            amountInControlBook: '10',
            amountObserved: '10',
            amountDelivered: '0',
          ),
          ExplosiveControlEntry(
            description: 'Detonator',
            boxNo: 'B2',
            amountInControlBook: '20',
            amountObserved: '19',
            amountDelivered: '1',
          ),
        ],
        deviationsObserved: 'No',
        oldBoxesMarked: 'Yes',
        oldBoxesLocked: 'Yes',
        typeOfExplosiveInBox: 'ANFO',
        totalInBox: '40',
        recordedCorrectly: 'Yes',
        specialInstructions: '',
        shiftBossSignature: 'data:image/png;base64,SB',
        shiftBossDate: '08/08/2026',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'section': 'Sec X',
        'strike': 'Strike X',
        'date': '08/08/2026',
        'minerCoyNo': 'C55',
        'entries': <Map<String, dynamic>>[
          {
            'description': 'Capped fuse',
            'boxNo': 'B1',
            'amountInControlBook': '10',
            'amountObserved': '10',
            'amountDelivered': '0',
          },
          {
            'description': 'Detonator',
            'boxNo': 'B2',
            'amountInControlBook': '20',
            'amountObserved': '19',
            'amountDelivered': '1',
          },
        ],
        'deviationsObserved': 'No',
        'deviationsDetails': '',
        'oldBoxesMarked': 'Yes',
        'oldBoxesMarkedDetails': '',
        'oldBoxesLocked': 'Yes',
        'oldBoxesLockedDetails': '',
        'typeOfExplosiveInBox': 'ANFO',
        'totalInBox': '40',
        'recordedCorrectly': 'Yes',
        'recordedDetails': '',
        'specialInstructions': '',
        'shiftBossSignature': 'data:image/png;base64,SB',
        'shiftBossDate': '08/08/2026',
        'mineOverseerSignature': '',
        'mineOverseerDate': '',
      }));
    });

    test('waiting_place_inspection', () {
      final data = WaitingPlaceInspectionFormData(
        section: 'Sec Y',
        miner: 'Test Miner',
        date: '09/09/2026',
        items: [
          WaitingPlaceCheckItem(yes: true, no: false, remarks: 'Posted'),
          WaitingPlaceCheckItem(yes: false, no: true, remarks: 'Missing'),
        ],
        specialInstructions: 'Refill water.',
        shiftBossSignature: 'data:image/png;base64,SB',
        shiftBossDate: '09/09/2026',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'section': 'Sec Y',
        'miner': 'Test Miner',
        'date': '09/09/2026',
        'items': <Map<String, dynamic>>[
          {'yes': true, 'no': false, 'remarks': 'Posted'},
          {'yes': false, 'no': true, 'remarks': 'Missing'},
        ],
        'specialInstructions': 'Refill water.',
        'shiftBossSignature': 'data:image/png;base64,SB',
        'shiftBossDate': '09/09/2026',
        'mineOverseerSignature': '',
        'mineOverseerDate': '',
      }));
    });

    test('trackless_machinery_inspection (lowercase shiftboss keys)', () {
      // Trackless uses non-standard lowercase b in shiftbossSignature /
      // shiftbossSignatureDate. The signature path in formRegistry.ts
      // references these exact keys, so any case drift would break the chain.
      final data = TracklessMachineryFormData(
        inspections: [
          TracklessMachineryEntry(
            dateOfInspection: '10/10/2026',
            operatorCoyNumber: 'O1',
            machineNumber: 'M1',
            operatorTrained: 'Yes',
            operatorLicence: 'Yes',
            preUseChecklistAvailable: 'Yes',
            preUseChecklistCompleted: 'Yes',
            correctPPE: 'Yes',
            safetyBelt: 'Yes',
          ),
        ],
        shiftbossSignature: 'data:image/png;base64,SB',
        shiftbossSignatureDate: '10/10/2026',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'inspections': <Map<String, dynamic>>[
          {
            'dateOfInspection': '10/10/2026',
            'operatorCoyNumber': 'O1',
            'machineNumber': 'M1',
            'operatorTrained': 'Yes',
            'operatorTrained_remedial': '',
            'operatorLicence': 'Yes',
            'operatorLicence_remedial': '',
            'preUseChecklistAvailable': 'Yes',
            'preUseChecklistAvailable_remedial': '',
            'preUseChecklistCompleted': 'Yes',
            'preUseChecklistCompleted_remedial': '',
            'correctPPE': 'Yes',
            'correctPPE_remedial': '',
            'safetyBelt': 'Yes',
            'safetyBelt_remedial': '',
          },
        ],
        'shiftbossSignature': 'data:image/png;base64,SB',
        'shiftbossSignatureDate': '10/10/2026',
        'mineOverseerSignature': '',
        'mineOverseerSignatureDate': '',
      }));
    });

    test('action_log_underground_visits', () {
      final data = ActionLogUndergroundVisitsFormData(
        date: '11/11/2026',
        workingPlaceVisited: 'Stope 5',
        nameOfSeniorOfficial: 'Mr Senior',
        designation: 'Mine Manager',
        deviations: [
          ActionLogDeviationEntry(
            deviationObserved: 'Cable hanging',
            remedialAction: 'Re-route',
            estimatedCompletionDate: '12/11/2026',
            dateCompleted: '',
            signature: 'sig1',
          ),
        ],
        shiftBossSignature: 'data:image/png;base64,SB',
        mineOverseerSignature: '',
        seniorOfficialSignature: '',
      );

      expect(data.toMap(), equals(<String, dynamic>{
        'date': '11/11/2026',
        'workingPlaceVisited': 'Stope 5',
        'nameOfSeniorOfficial': 'Mr Senior',
        'designation': 'Mine Manager',
        'deviations': <Map<String, dynamic>>[
          {
            'deviationObserved': 'Cable hanging',
            'remedialAction': 'Re-route',
            'estimatedCompletionDate': '12/11/2026',
            'dateCompleted': '',
            'signature': 'sig1',
          },
        ],
        'shiftBossSignature': 'data:image/png;base64,SB',
        'mineOverseerSignature': '',
        'seniorOfficialSignature': '',
      }));
    });
  });
}
