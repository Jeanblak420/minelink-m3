import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';
import 'package:mine_online/pdf/generate_custom_form_pdf.dart';

void main() {
  test('boolean renders Yes/No regardless of null', () {
    expect(customPdfValueString(true, FormFieldType.boolean), 'Yes');
    expect(customPdfValueString(false, FormFieldType.boolean), 'No');
    expect(customPdfValueString(null, FormFieldType.boolean), 'No');
  });

  test('null / blank string render as em dash', () {
    expect(customPdfValueString(null, FormFieldType.text), '—');
    expect(customPdfValueString('', FormFieldType.text), '—');
    expect(customPdfValueString('   ', FormFieldType.text), '—');
  });

  test('non-empty string passes through', () {
    expect(customPdfValueString('Hello', FormFieldType.text), 'Hello');
    expect(
      customPdfValueString('2026-06-17', FormFieldType.date),
      '2026-06-17',
    );
  });

  test('number renders via toString', () {
    expect(customPdfValueString(42, FormFieldType.number), '42');
    expect(customPdfValueString(3.5, FormFieldType.number), '3.5');
  });
}
