import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/device.dart';

void main() {
  Device d({bool approved = false, bool active = true}) => Device.fromMap({
    'id': 'x',
    'user_id': 'u',
    'device_name': 'PC',
    'platform': 'windows',
    'approved': approved,
    'is_active': active,
    'last_seen_at': '2026-06-22T00:00:00Z',
    'created_at': '2026-06-22T00:00:00Z',
  });

  test('status: pending / approved / revoked', () {
    expect(d().statusLabel, 'Pending');
    expect(d(approved: true).statusLabel, 'Approved');
    expect(d(approved: true, active: false).statusLabel, 'Revoked');
    expect(d(active: false).statusLabel, 'Revoked');
  });

  test('isPending only when active and not approved', () {
    expect(d().isPending, true);
    expect(d(approved: true).isPending, false);
    expect(d(active: false).isPending, false);
  });
}
