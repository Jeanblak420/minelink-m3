import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';

void main() {
  FormFieldDef text(String key) =>
      FormFieldDef(key: key, type: FormFieldType.text, label: key, required: false);

  CustomFormTemplate template(List<FormFieldDef> fields, {List<String> audience = const []}) =>
      CustomFormTemplate(
        id: 't1', code: 'custom_x', name: 'X', description: null, category: null,
        fields: fields, audience: audience, requiredSigners: const [],
        version: 1, isActive: true, createdBy: null,
      );

  test('toMap/fromMap round-trips fields and audience', () {
    final t = template([
      FormFieldDef(key: 'name', type: FormFieldType.text, label: 'Name', required: true),
      FormFieldDef(key: 'shift', type: FormFieldType.dropdown, label: 'Shift', required: true, options: ['A', 'B']),
      FormFieldDef(key: 'items', type: FormFieldType.table, label: 'Items', required: false,
          columns: [FormFieldColumn(key: 'item', label: 'Item', type: 'text')]),
    ], audience: ['Shift Boss']);
    final back = CustomFormTemplate.fromMap(t.toMap()..['id'] = 't1');
    expect(back.fields.length, 3);
    expect(back.fields[1].type, FormFieldType.dropdown);
    expect(back.fields[1].options, ['A', 'B']);
    expect(back.fields[2].columns!.first.key, 'item');
    expect(back.audience, ['Shift Boss']);
  });

  test('validateTemplate flags empty name', () {
    final errs = validateTemplate(name: '', fields: [text('a')]);
    expect(errs, contains('Form name is required.'));
  });

  test('validateTemplate flags no fields', () {
    final errs = validateTemplate(name: 'X', fields: const []);
    expect(errs.any((e) => e.contains('at least one field')), isTrue);
  });

  test('validateTemplate flags duplicate keys', () {
    final errs = validateTemplate(name: 'X', fields: [text('a'), text('a')]);
    expect(errs.any((e) => e.contains('Duplicate field key')), isTrue);
  });

  test('validateTemplate flags empty label and missing key', () {
    final errs = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: '', type: FormFieldType.text, label: '', required: false),
    ]);
    expect(errs.any((e) => e.contains('label')), isTrue);
    expect(errs.any((e) => e.contains('key')), isTrue);
  });

  test('validateTemplate flags dropdown without options', () {
    final errs = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: 'd', type: FormFieldType.dropdown, label: 'D', required: false, options: const []),
    ]);
    expect(errs.any((e) => e.contains('at least one option')), isTrue);
  });

  test('validateTemplate flags table without columns', () {
    final errs = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: 't', type: FormFieldType.table, label: 'T', required: false, columns: const []),
    ]);
    expect(errs.any((e) => e.contains('at least one column')), isTrue);
  });

  test('section field is exempt from key/label-as-input rules but needs a label', () {
    final ok = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: 'sec1', type: FormFieldType.section, label: 'Part A', required: false),
      text('a'),
    ]);
    expect(ok, isEmpty);
  });

  test('audienceAllows: empty audience = everyone', () {
    expect(audienceAllows(const [], 'Shift Boss'), isTrue);
    expect(audienceAllows(const [], null), isTrue);
  });

  test('audienceAllows: matches account type', () {
    expect(audienceAllows(['Admin', 'Shift Boss'], 'Shift Boss'), isTrue);
    expect(audienceAllows(['Admin'], 'Shift Boss'), isFalse);
    expect(audienceAllows(['Admin'], null), isFalse);
  });
}
