# Porting status

Tracks which web-app forms/screens are ported to Flutter. See `CLAUDE.md` → "How to port the next form" for the recipe.

## Foundation

- [x] Project scaffold (Windows + Android)
- [x] Supabase client + dotenv bootstrap
- [x] Auth provider + realtime profile subscription
- [x] Material 3 theming (light / dark / custom HCT seed)
- [x] Router with auth redirect
- [x] Role-access helpers
- [x] Signature workflow util (invokes the edge function)
- [x] Password security (HIBP k-anonymity)
- [x] PDF runtime (coordinate helpers, fonts, autoTable port)
- [x] Shared "inspection doc" header/footer frame
- [x] Login screen
- [x] Home screen (default-user grid; role-specific dashboards stubbed)

## Forms

| Route | Form | Screen | PDF | Submit workflow |
| --- | --- | --- | --- | --- |
| `/shift-boss` | Shift Boss Appointment | ✅ | ✅ (custom coords) | ✅ |
| `/miner-appointment` | Miner Appointment | ✅ | ✅ (grid) | ✅ |
| `/lockout-lock-scissor-checklist` | Lockout Checklist | ✅ | ✅ (grid + banner) | n/a (no signature chain) |
| `/relieving-miner` | Relieving Miner Appointment | ✅ | ✅ (grid) | ✅ |
| `/safety-health-rep` | SHE Rep Appointment | ✅ | ✅ (custom coords) | n/a (no signature chain) |
| `/machinery-operators` | Machinery Operators | ✅ | ✅ (grid, 18+ rows) | n/a (no signature chain) |
| `/shift-boss-daily-report` | Shift Boss Daily Report | ✅ | ✅ (2-page, spanning headers) | n/a (web has no chain — Flutter saves a logbook entry only) |
| `/gassing-incident` | Gassing Incident Report | ✅ | ✅ (dotted-underline) | ✅ |
| `/weekly-sherq-meeting` | Weekly SHERQ Meeting | ✅ | ✅ (grid + topics + attendance) | ✅ |
| `/early-shift-record` | Early Shift Record | ✅ | ✅ (2-page, dotted-underline) | ✅ |
| `/late-shift-record` | Late Shift Record | ✅ | ✅ (2-page, dotted-underline) | ✅ |
| `/explosive-control-record` | Explosive Control Record | ✅ | ✅ (grid + Q&A) | ✅ (Mine Overseer) |
| `/waiting-place-inspection` | Waiting Place Inspection | ✅ | ✅ (checklist + section divider) | ✅ (Mine Overseer) |
| `/refuge-bay-inspection` | Refuge Bay Inspection | ✅ | ✅ (28-row checklist + instructions) | n/a (no signature chain) |
| `/trackless-machinery-inspection` | Trackless Machinery | ✅ | ✅ (4 inspection blocks) | ✅ (Mine Overseer) |
| `/conveyor-belt-inspection` | Conveyor Belt Inspection | ✅ | ✅ (2-section table) | n/a (no signature chain) |
| `/rock-breaker-inspection` | Rock Breaker Inspection | ✅ | ✅ (checklist) | n/a (no signature chain) |
| `/belt-tip-area-inspection` | Belt Tip Area Inspection | ✅ | ✅ (checklist) | n/a (no signature chain) |
| `/action-log-underground-visits` | Action Log Underground Visits | ✅ | ✅ (grid) | ✅ (Mine Overseer) |
| `/special-instruction` | Special Instruction | ✅ | ✅ (dual section) | n/a (no signature chain) |
| `/inspection-control-sheet` | Inspection Control Sheet | ✅ | ✅ (landscape day-grid) | n/a (no signature chain) |
| `/planned-task-observation` | Planned Task Observation | ✅ | ✅ (landscape grid) | n/a (no signature chain) |
| `/special-brief-instruction-register` | Special Brief Instruction Register | ✅ | ✅ (register) | n/a (no signature chain) |
| `/verbal-emergency-drills` | Verbal Emergency Drills | ✅ | ✅ (shared) | n/a (no signature chain) |
| `/physical-emergency-drills` | Physical Emergency Drills | ✅ | ✅ (shared) | n/a (no signature chain) |
| `/emergency-drill-exercise` | Emergency Drill Exercise | ✅ | ✅ (stacked tables) | n/a (no signature chain) |
| `/monthly-fire-fighting-inspection` | Monthly Fire Fighting Inspection | ✅ | ✅ (9-col grid) | n/a (no signature chain) |

## Other screens

| Route | Screen | Status |
| --- | --- | --- |
| `/login` | Login | ✅ |
| `/` | Home (default + role dashboards) | ✅ (Super Admin / Admin / Mine Leadership / Shift Boss dashboards live) |
| `/profiles` | User Profiles list | ✅ (full admin CRUD via `admin-create-user` edge fn; presence; search; ComboBox) |
| `/my-profile` | My Profile | ✅ (ComboBox autocomplete for department / location / occupation / etc.) |
| `/settings` | Settings (incl. theme picker) | ✅ |
| `/notifications` | Notifications list + bell | ✅ (list + unread-count Badge on the bell) |
| `/signature-requests` | Pending signature requests | ✅ (list + sign + "View PDF" + "Open form in view-mode" via `buildFormView`) |
| `/current-logbook` | My Current Logbook | ✅ |
| `/completed-logbook-history` | Completed Logbook History | ✅ |
| `/admin` | Admin Panel | ✅ |
| `/appointment-history-logs` | Admin Appointment History | ✅ |
| `/active-individual-current-logbook` | Active Individual Current Logbook | ✅ |
| `/individual-completed-logbook-history` | Individual Completed History | ✅ |
| `/logbook-version-management` | Logbook Version Management | placeholder (web is also placeholder) |
| `/send-notifications-reminders` | Notification/reminder management | placeholder (web is also placeholder) |
