# CLAUDE.md — Mine Online (Flutter)

Guidance for Claude Code (claude.ai/code) when working in this repository.

## What this repo is

Flutter mirror of the React/TypeScript Mine Online app at
`C:\Users\Somebody Someone\Desktop\PrayforPlauge\plauge\Mine-Online_Best-Latest-29-03-2026-BOLT-VERSION`.

It targets **Windows + Android** (no iOS, no web). It connects to the **same Supabase project** (`hhrnkzznpadrmyverhyb`) as the web app — users, profiles, forms, signature workflow, and notifications are all shared. Both apps read and write the same `profiles`, `form_submissions`, `signature_requests`, and `notifications` tables.

## Operating rule: Supabase is your job, not the user's

Same rule as the React project. Schema changes, migrations, RLS edits, edge function deploys, secret rotation, log inspection, type generation, data backfills — **do it yourself** using:

- **Supabase MCP server** (project ref `hhrnkzznpadrmyverhyb`)
- **Supabase CLI** (`npx supabase`, project alias `Mine-Online-T1`)

Never ask the user to run `supabase db push`, paste SQL into the dashboard, or click around in Studio. The only exception is destructive operations (drops, wipes) which warrant a confirmation, but you still execute after the user confirms.

## Porting status (as of last edit)

**Foundation: complete.**
- Supabase + dotenv bootstrap, auth + realtime profile subscription, Material 3 theming (light/dark/custom HCT seed), router with redirect-when-unauthenticated, role-access helpers, login, home with role-specific dashboards.

**All 27 forms ported end-to-end** (UI + Supabase submission + visually-identical PDF). See `PORTING_STATUS.md` for the per-route table. Highlights:
- 11 forms with full signature-chain workflow — matches the web app's `requiredSigners ≠ []` set (Shift Boss, Miner, Relieving Miner, Gassing Incident, Weekly SHERQ, Early Shift Record, Late Shift Record, Explosive Control Record, Waiting Place Inspection, Trackless Machinery Inspection, Action Log Underground Visits). Each auto-stamps the submitter's profile signature into the Shift Boss slot at submit time (mirrors web `useFormApproval`).
- 16 forms generate PDF only (no signature chain). 14 of those also call `persistFormSubmission` in Flutter to write a `form_submissions` row with `workflow_status: NULL` — this is a Flutter-only deviation; the web never persists non-chain forms. Lockout Checklist and Shift Boss Daily Report follow web parity (Daily Report still calls `persistFormSubmission` for a logbook entry but does NOT enter the chain — web has no equivalent).
- Every form screen accepts an optional `FormViewArgs` parameter — used by `/signature-requests` to hydrate the form from a submitted payload and render in view mode. See `lib/utils/form_registry.dart`.

**All non-form screens ported.** `/profiles` now mirrors the React app's full admin CRUD (create / edit / delete via `admin-create-user` edge function; presence tracking via `user_presence`; in-memory ComboBox option lists). `/my-profile` uses ComboBox autocomplete for the same lists. `/signature-requests` shows a "View PDF" + "Open form (view mode)" pair instead of raw JSON. `/appointments` is a hub screen that cards out to every appointment form (Shift Boss, Miner, Relieving Miner, etc.) — mirrors the web app's appointment-form launcher. `/admin`, `/appointment-history-logs`, `/active-individual-current-logbook`, `/individual-completed-logbook-history`, `/completed-logbook-history`, `/current-logbook`, `/notifications`, `/settings` are all live. Two routes remain placeholders intentionally (the React app uses placeholders for them too): `/logbook-version-management`, `/send-notifications-reminders`.

**Route → screen sharing.** Two screens back multiple routes via a variant argument — worth knowing when tracing a route:
- `FormSubmissionHistoryScreen(title: ...)` backs both `/completed-logbook-history` and `/individual-completed-logbook-history`
- `AdminAppointmentsLogbookScreen(variant: AdminLogbookVariant.history | .active)` backs both `/appointment-history-logs` and `/active-individual-current-logbook`

## Reusable widgets

Shared widgets that screens hook into:

- `lib/widgets/account_badge.dart` — initials avatar + Sign Out / My Profile / Settings popup
- `lib/widgets/notification_bell.dart` — bell icon with unread-count `Badge`
- `lib/widgets/app_bar_actions.dart` — `commonAppBarActions()` returns `[NotificationBell, AccountBadge]`; spread into every screen's `AppBar.actions`
- `lib/widgets/combo_box_field.dart` — autocomplete dropdown with `onAddOption` callback (used by My Profile and User Profiles forms)
- `lib/widgets/user_presence_tracker.dart` — `ChangeNotifier` polling the `user_presence` table; exposes `isOnline(userId)`
- `lib/widgets/dashboards/` — `DashboardCard`, `DashboardGrid`, and the four role-specific dashboards used by `home_screen.dart`
- `lib/widgets/inspection_items_field.dart` — shared yes/no/remedial-action table widget used by rock-breaker / belt-tip / conveyor-belt screens (companion: `lib/pdf/inspection_items_table.dart` renders the same data to PDF)
- `lib/widgets/date_picker_field.dart`, `lib/widgets/signature_canvas.dart` — date and signature inputs
- `lib/widgets/submission_viewer_dialog.dart` — mirrors `SubmissionViewerModal.tsx`; opened from logbook rows, renders the form in view mode via `buildFormView` and exposes a "Download PDF" button

Shared constants:

- `lib/constants/profile_options.dart` — default lists for ComboBox seeding (departments, locations, companies, payroll IDs, etc.); mirrors `src/components/MyProfile.tsx` lines 10–40
- `lib/constants/occupations.dart` — mirrors `src/constants/occupations.ts`
- `lib/constants/account_types.dart` — mirrors `src/constants/accountTypes.ts` (`kUserAccountTypes`, `kNotificationEnabledAccountTypes`, `getAccountTypeFlags`)

Shared utilities:

- `lib/utils/form_registry.dart` — `buildFormView(formType, args)` returns the right form screen; `generatePdfForFormType(formType, payload)` regenerates the PDF document
- `lib/utils/form_approval.dart` — port of `useFormApproval.ts`; holds the per-form Shift Boss signature dot-paths and the helper that auto-stamps submitter signature + timestamp into the payload at submit time. Mirrors the web app's `signaturePaths.shiftBoss` map exactly.
- `lib/utils/admin_user.dart` — wraps the `admin-create-user` edge function (create / update_password / delete)
- `lib/utils/pdf_download.dart` — `savePdfBytes(...)` opens the system save-file dialog (`file_picker`) and writes PDF bytes to the chosen path; handles platform differences (Windows writes via `dart:io`, Android via SAF). Used by the submission viewer's "Download PDF" button.
- `lib/utils/presence_heartbeat.dart` — upserts `user_presence.last_seen_at` every 60 s while signed in; mirrors the web app's `usePresence` hook. `AuthProvider` starts/stops it on sign-in / sign-out.

Shared models:

- `lib/models/form_view_args.dart` — `FormViewArgs` carries `mode`, `initialPayload`, `currentSignerRole`, `submissionId`, and the pending-signature callback
- `lib/models/form_data_apply_map.dart` — inverse of every model's `toMap()`; called as `data.applyMap(payload)` to hydrate a form-data instance from a Supabase row
- `lib/models/app_notification.dart` — mirrors `useNotifications.ts → Notification`; consumed by `NotificationsProvider` and the bell/notifications screen
- `lib/models/signature_request.dart` — mirrors `signatureWorkflow.ts → SignatureRequest` + `ProfileSnapshot`; the shape edge functions read/write

Providers (registered in `app.dart` alongside `AuthProvider` / `ThemeProvider`):

- `lib/providers/notifications_provider.dart` — loads notifications, subscribes to realtime inserts, tracks unread count; the bell badge and `/notifications` screen both read from it

### Nested to-dos

`public.todos.parent_id` (self-referencing FK, `on delete cascade`) lets any todo own children. The current backlog runs three deep: 4 main tasks (`[T1]`…`[T4]`) → 29 phases (`[T1 · Phase 1]`…) → 116 sub-tasks (`[T1 · P1.1]`…). The `/todos` screen renders the result via:

- `lib/widgets/todos/todo_tree.dart` — `TodoNode` + `buildTodoForest()` + `pruneForestToLane()`. The pruner keeps a parent visible in any lane where it OR a descendant lives.
- `lib/widgets/todos/todo_lane.dart` — recursive `_TodoTreeView` (stateful). Parents render with an `_ExpandChevron` and **start collapsed**; tapping expands. Background tint cycles through a 5-colour palette by `(siblingIndex + depth) % 5` so adjacent siblings never share a colour and a child never inherits its parent's tint.
- `lib/widgets/todos/todo_card.dart` — `childCountInLane` / `childCountTotal` drive the "3 of 9 phases" pill on parent cards; `interactive: false` renders the checkbox but ignores taps.

**Eng todos are read-only on the user side.** The UPDATE policy on `public.todos` (`20260525150000_lock_eng_todos_to_service_role.sql`) requires `kind = 'user'` — only service_role can flip status on `kind='eng'` rows. The Flutter side enforces the same: `TodoCard.interactive=false` for eng rows, and `_StatusPillButton.onTap=null` inside `TodoDetailDialog` so the pills render but don't fire. User-request todos (`kind='user'`) stay collaborative as before.

## Build & run

| Task | Command |
| --- | --- |
| Get deps | `flutter pub get` |
| Static analysis | `flutter analyze` |
| Windows dev run | `flutter run -d windows` |
| Android dev run | `flutter run -d android` |
| Windows build | `flutter build windows --release` |
| Android APK | `flutter build apk --release` |

## Windows build path-with-spaces — patched in this repo

The project folder is named `NEW PROJECT HERE`, which contains spaces. Flutter's stock Windows scaffold gates the install-prefix override on `CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT`, but that flag is unreliable when the source path contains spaces — CMake then falls back to `C:\Program Files\<binary_name>`, the install step needs admin, and `flutter run -d windows` fails at `INSTALL.vcxproj` with MSB3073.

**Patched here**: `windows/CMakeLists.txt` removes the `if(CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)` guard and forces `CMAKE_INSTALL_PREFIX` to the build bundle dir unconditionally. `flutter run -d windows` and `flutter build windows --release` now work directly from the original `NEW PROJECT HERE\` path — no junction, no rename, no admin. **Do not re-add the guard** — it will re-break Windows builds on this folder.

Android builds were never affected by the original caveat.

## ⚠️ Flutter SDK template gap

This scaffold ran from `C:\FlutterDev\flutter` (Flutter 3.38.7), which is **missing the Windows template files** that older SDKs ship:
- `packages/flutter_tools/templates/app/windows.tmpl/flutter/CMakeLists.txt`
- `packages/flutter_tools/templates/app/windows.tmpl/runner/CMakeLists.txt`
- `packages/flutter_tools/templates/app/windows.tmpl/runner/flutter_window.h`
- `.../utils.h`
- `.../win32_window.h`

We restored those files manually in `windows/flutter/` and `windows/runner/` by copying from `Desktop\Flutter SDK\flutter_windows_3.29.2-stable\flutter` (which still has them). **Do not run `flutter create --overwrite` on this project** — it will revert custom code in `lib/main.dart`, `pubspec.yaml`, `.gitignore`, and `test/widget_test.dart`, and will not restore the missing template files because the active SDK doesn't have them.

If you need to regenerate Windows scaffolding, copy the missing files from the older SDK first.

## Project layout

Indicative tree — for the per-route screen/PDF list see `PORTING_STATUS.md`, and for the shared widgets / utils / models / providers catalog see the **Reusable widgets** section above.

```
lib/
  main.dart                       — bootstrap dotenv + Supabase + runApp
  app.dart                        — MaterialApp.router; registers AuthProvider, ThemeProvider, NotificationsProvider
  config/                         — env.dart, supabase_client.dart
  constants/                      — profile_options, occupations, account_types
  models/                         — user_profile, form_data (+ apply_map), form_view_args, app_notification, signature_request
  providers/                      — auth_provider, theme_provider, notifications_provider
  utils/                          — role_access, signature_workflow, form_approval, form_registry, admin_user,
                                    appointment_profile, password_security, presence_heartbeat, pdf_download
  routing/                        — router.dart (all web routes mirrored)
  screens/                        — one file per form (*_form_screen.dart) + login, home, my_profile, profiles,
                                    appointments (hub), admin, admin_appointments_logbook, form_submission_history,
                                    current_logbook, notifications, settings, signature_requests, placeholder
  widgets/                        — account_badge, notification_bell, app_bar_actions, combo_box_field,
                                    date_picker_field, signature_canvas, user_presence_tracker,
                                    inspection_items_field, submission_viewer_dialog
  widgets/dashboards/             — dashboard_card + 4 role-specific dashboards (super_admin, admin,
                                    mine_leadership, shift_boss)
  pdf/                            — pdf_runtime, inspection_doc_frame, inspection_items_table,
                                    one generate_*_pdf.dart per form
```

## How to port the next form

Pick the source by name from `src/components/<Name>Form.tsx` and the matching `generate<Name>PDF` block in `src/utils/pdfGenerator.ts`. Then:

1. **Add a Dart model** in `lib/models/form_data.dart` matching the TS interface name and field shape exactly. Field names must match the JSON payload the web app writes to `form_submissions.payload`, so both apps round-trip submissions.
2. **Write a PDF generator** in `lib/pdf/generate_<name>_pdf.dart`. Mirror the jsPDF code line-for-line. The runtime in `pdf_runtime.dart` provides `text()`, `rectFillStroke()`, `splitTextToSize()`, etc. that take the same mm coordinates the web code uses. For autoTable-style forms, use `drawAutoTable()` from `inspection_doc_frame.dart`. For absolute-coordinate forms (like Shift Boss), draw directly on the `PageCtx`.
3. **Build a screen** at `lib/screens/<name>_form_screen.dart`. Mirror the form layout from the React component. Use `SignatureCanvasField` for signature pads, `DatePickerField` for dates. Auto-fill identity fields from `getProfilePersonalDetails(profile)`. Wire the buttons:
   - "Generate PDF" → `Printing.layoutPdf(onLayout: (_) async => (await generate...Pdf(data)).save())`
   - "Submit for Approval" → `saveFormSubmissionAndStartWorkflow(formType, title, data.toMap())`
4. **Replace the placeholder route** in `lib/routing/router.dart`: remove the entry from the `_placeholders()` map and add a real `GoRoute` near the top.
5. **Run `flutter analyze`**; then `flutter run -d windows` (or `-d android`) to verify the form renders and the PDF preview opens.

## Web ↔ Flutter parity rules

- Field names in form data must match the web app exactly (it's the same JSON payload column).
- Form types (the `form_type` column) must match the web app's `FORM_REGISTRATIONS` entries.
- PDF coordinates use millimetres on `PdfPageFormat.letter`, matching jsPDF's `format: 'letter', unit: 'mm'`.
- Realtime channel names should mirror web: `profile:$id` etc.
- Use the existing role helpers in `role_access.dart`; **don't read `profile.isAdmin` etc. directly** — the occupation-substring fallback is load-bearing and the web app keeps this guarantee.

## Required env

`.env` (gitignored) at project root:
```
SUPABASE_URL=https://hhrnkzznpadrmyverhyb.supabase.co
SUPABASE_ANON_KEY=...   # same anon key the web app uses
```

Server-only secrets (SMTP, mailbox) live only in the web `.env` and Supabase edge function environment — never copy them here.

## Things NOT to do

- Do not migrate from / touch the vestigial Flutter scaffold in the React project's `lib/`, `ios/`, `android/`, `windows/`. That was the original starting point and is unrelated to this app.
- Do not run `flutter create --overwrite` on this project — it reverts customisations.
- Do not add UI/icon/theme libraries beyond `dynamic_color` without an explicit ask — Flutter Material 3 + Lucide-style icons via `Icons.*` is the same minimal-deps principle as the React app.
- Do not commit `.env`. The `.gitignore` already covers it.
