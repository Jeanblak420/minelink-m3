// Responsive 2-column row → 1-column column under [breakpoint] px.
// Use inside form screens to render side-by-side inputs that should stack on
// phones. Mirrors the UI kit's `useNarrow(640)` breakpoint by default.
//
//   ResponsiveFormRow(children: [
//     TextFormField(...),
//     TextFormField(...),
//   ])
//
// On wide screens you get a Row with each child given equal flex; on narrow
// screens you get a Column. Spacing is auto-handled.

import 'package:flutter/material.dart';

class ResponsiveFormRow extends StatelessWidget {
  const ResponsiveFormRow({
    super.key,
    required this.children,
    this.spacing = 12,
    this.breakpoint = 640,
  });

  final List<Widget> children;
  final double spacing;
  final double breakpoint;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final narrow = width < breakpoint;

    if (narrow) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) SizedBox(height: spacing),
            children[i],
          ],
        ],
      );
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (var i = 0; i < children.length; i++) ...[
          if (i > 0) SizedBox(width: spacing),
          Expanded(child: children[i]),
        ],
      ],
    );
  }
}
