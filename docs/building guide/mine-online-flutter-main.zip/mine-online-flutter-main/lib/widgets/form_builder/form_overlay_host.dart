// SP4.5: renders a form's edit overlay (admin-added fields + pages) at the bottom
// of a bespoke form screen. Loads the overlay for [formType]; when there is none
// (or it is empty) it renders nothing — so an un-edited form is byte-identical to
// the bespoke baseline. Added-field VALUES are reported via [onChanged] for the
// host screen to fold into payload['overlay'].

import 'package:flutter/material.dart';

import '../../models/form_overlay.dart';
import '../../utils/form_overlay_data.dart';
import 'dynamic_form_renderer.dart';

class FormOverlayHost extends StatefulWidget {
  const FormOverlayHost({
    super.key,
    required this.formType,
    required this.values,
    required this.onChanged,
    this.readOnly = false,
    this.overlayOverride,
  });

  final String formType;

  /// Seed values (e.g. payload['overlay'] in view mode).
  final Map<String, dynamic> values;

  /// Called with the full overlay-values map whenever a field changes.
  final ValueChanged<Map<String, dynamic>> onChanged;

  final bool readOnly;

  /// When set, render this overlay directly instead of loading the saved one
  /// (Form Builder live preview). Null in every normal flow.
  final FormOverlay? overlayOverride;

  @override
  State<FormOverlayHost> createState() => _FormOverlayHostState();
}

class _FormOverlayHostState extends State<FormOverlayHost> {
  FormOverlay? _overlay;
  bool _loaded = false;
  late final Map<String, dynamic> _values = {...widget.values};

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant FormOverlayHost old) {
    super.didUpdateWidget(old);
    if (old.overlayOverride != widget.overlayOverride) _load();
  }

  Future<void> _load() async {
    if (widget.overlayOverride != null) {
      setState(() {
        _overlay = widget.overlayOverride;
        _loaded = true;
      });
      return;
    }
    try {
      final o = await loadFormOverlay(widget.formType);
      if (!mounted) return;
      setState(() {
        _overlay = o;
        _loaded = true;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loaded = true); // safe degradation: render nothing
    }
  }

  void _set(String key, dynamic value) {
    _values[key] = value;
    widget.onChanged(_values);
  }

  @override
  Widget build(BuildContext context) {
    final o = _overlay;
    if (!_loaded || o == null || !o.hasContent) {
      return const SizedBox.shrink();
    }
    final theme = Theme.of(context);
    final blocks = <Widget>[];

    if (o.addedFields.isNotEmpty) {
      blocks.add(const SizedBox(height: 16));
      blocks.add(const Divider());
      blocks.add(
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 4),
          child: Text(
            'Additional information',
            style: theme.textTheme.titleMedium,
          ),
        ),
      );
      blocks.add(
        DynamicFormRenderer(
          fields: o.addedFields,
          values: _values,
          onChanged: _set,
        ),
      );
    }

    for (final page in o.addedPages) {
      blocks.add(const SizedBox(height: 16));
      blocks.add(const Divider());
      blocks.add(
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 4),
          child: Text(
            page.title.isEmpty ? 'Additional page' : page.title,
            style: theme.textTheme.titleMedium,
          ),
        ),
      );
      blocks.add(
        DynamicFormRenderer(
          fields: page.fields,
          values: _values,
          onChanged: _set,
        ),
      );
    }

    return AbsorbPointer(
      absorbing: widget.readOnly,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: blocks,
      ),
    );
  }
}
