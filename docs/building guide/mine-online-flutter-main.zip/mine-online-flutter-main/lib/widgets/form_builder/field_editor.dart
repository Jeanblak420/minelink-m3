// Reorderable list of field definitions for the form builder. Each row edits
// one FormFieldDef in place; the parent owns the list and is notified via
// onChanged with a fresh list on every mutation.

import 'package:flutter/material.dart';

import '../../models/custom_form_template.dart';

class FieldEditorList extends StatelessWidget {
  const FieldEditorList({
    super.key,
    required this.fields,
    required this.onChanged,
  });

  final List<FormFieldDef> fields;
  final ValueChanged<List<FormFieldDef>> onChanged;

  void _update(int i, FormFieldDef next) {
    final copy = [...fields];
    copy[i] = next;
    onChanged(copy);
  }

  void _remove(int i) {
    final copy = [...fields]..removeAt(i);
    onChanged(copy);
  }

  void _add(FormFieldType type) {
    final n = fields.length + 1;
    onChanged([
      ...fields,
      FormFieldDef(
        key: type == FormFieldType.section ? 'section_$n' : 'field_$n',
        type: type,
        label: type == FormFieldType.section ? 'Section' : 'Field $n',
        required: false,
        options: type == FormFieldType.dropdown ? const [] : null,
        columns: type == FormFieldType.table ? const [] : null,
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ReorderableListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          buildDefaultDragHandles: true,
          itemCount: fields.length,
          onReorder: (oldI, newI) {
            final copy = [...fields];
            if (newI > oldI) newI -= 1;
            copy.insert(newI, copy.removeAt(oldI));
            onChanged(copy);
          },
          itemBuilder: (context, i) => _FieldEditorRow(
            key: ValueKey('field_$i'),
            field: fields[i],
            onChanged: (f) => _update(i, f),
            onRemove: () => _remove(i),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            // dynamicDropdown is authored only in the SP4.6 designer (it needs a
            // data source picker), so it is excluded from this generic palette.
            for (final t in FormFieldType.values)
              if (t != FormFieldType.dynamicDropdown)
                OutlinedButton.icon(
                  icon: const Icon(Icons.add, size: 16),
                  label: Text(_typeLabel(t)),
                  onPressed: () => _add(t),
                ),
          ],
        ),
      ],
    );
  }
}

String _typeLabel(FormFieldType t) {
  switch (t) {
    case FormFieldType.text:
      return 'Text';
    case FormFieldType.multiline:
      return 'Paragraph';
    case FormFieldType.number:
      return 'Number';
    case FormFieldType.date:
      return 'Date';
    case FormFieldType.dropdown:
      return 'Dropdown';
    case FormFieldType.boolean:
      return 'Yes/No';
    case FormFieldType.signature:
      return 'Signature';
    case FormFieldType.section:
      return 'Section heading';
    case FormFieldType.table:
      return 'Table';
    case FormFieldType.dynamicDropdown:
      return 'Dynamic dropdown';
  }
}

class _FieldEditorRow extends StatelessWidget {
  const _FieldEditorRow({
    super.key,
    required this.field,
    required this.onChanged,
    required this.onRemove,
  });

  final FormFieldDef field;
  final ValueChanged<FormFieldDef> onChanged;
  final VoidCallback onRemove;

  FormFieldDef _copy({
    String? key,
    String? label,
    bool? required,
    List<String>? options,
    List<FormFieldColumn>? columns,
  }) => FormFieldDef(
    key: key ?? field.key,
    type: field.type,
    label: label ?? field.label,
    required: required ?? field.required,
    help: field.help,
    options: options ?? field.options,
    columns: columns ?? field.columns,
  );

  @override
  Widget build(BuildContext context) {
    final isSection = field.type == FormFieldType.section;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Chip(
                  label: Text(_typeLabel(field.type)),
                  visualDensity: VisualDensity.compact,
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  tooltip: 'Remove field',
                  onPressed: onRemove,
                ),
              ],
            ),
            TextFormField(
              initialValue: field.label,
              decoration: const InputDecoration(labelText: 'Label'),
              onChanged: (v) => onChanged(_copy(label: v)),
            ),
            if (!isSection) ...[
              const SizedBox(height: 8),
              TextFormField(
                initialValue: field.key,
                decoration: const InputDecoration(
                  labelText: 'Key (payload field name)',
                  helperText: 'lowercase, no spaces',
                ),
                onChanged: (v) => onChanged(_copy(key: v)),
              ),
              Row(
                children: [
                  Checkbox(
                    value: field.required,
                    onChanged: (v) => onChanged(_copy(required: v ?? false)),
                  ),
                  const Text('Required'),
                ],
              ),
            ],
            if (field.type == FormFieldType.dropdown)
              _OptionsEditor(
                options: field.options ?? const [],
                onChanged: (opts) => onChanged(_copy(options: opts)),
              ),
            if (field.type == FormFieldType.table)
              _ColumnsEditor(
                columns: field.columns ?? const [],
                onChanged: (cols) => onChanged(_copy(columns: cols)),
              ),
          ],
        ),
      ),
    );
  }
}

class _OptionsEditor extends StatelessWidget {
  const _OptionsEditor({required this.options, required this.onChanged});
  final List<String> options;
  final ValueChanged<List<String>> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        const Text('Options', style: TextStyle(fontWeight: FontWeight.w600)),
        for (var i = 0; i < options.length; i++)
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  initialValue: options[i],
                  decoration: const InputDecoration(isDense: true),
                  onChanged: (v) {
                    final copy = [...options];
                    copy[i] = v;
                    onChanged(copy);
                  },
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18),
                onPressed: () => onChanged([...options]..removeAt(i)),
              ),
            ],
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add option'),
            onPressed: () => onChanged([...options, '']),
          ),
        ),
      ],
    );
  }
}

class _ColumnsEditor extends StatelessWidget {
  const _ColumnsEditor({required this.columns, required this.onChanged});
  final List<FormFieldColumn> columns;
  final ValueChanged<List<FormFieldColumn>> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        const Text('Columns', style: TextStyle(fontWeight: FontWeight.w600)),
        for (var i = 0; i < columns.length; i++)
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  initialValue: columns[i].label,
                  decoration: const InputDecoration(
                    isDense: true,
                    labelText: 'Column label',
                  ),
                  onChanged: (v) {
                    final copy = [...columns];
                    copy[i] = FormFieldColumn(
                      key: v.toLowerCase().replaceAll(
                        RegExp(r'[^a-z0-9]+'),
                        '_',
                      ),
                      label: v,
                      type: columns[i].type,
                    );
                    onChanged(copy);
                  },
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18),
                onPressed: () => onChanged([...columns]..removeAt(i)),
              ),
            ],
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add column'),
            onPressed: () => onChanged([
              ...columns,
              const FormFieldColumn(key: '', label: '', type: 'text'),
            ]),
          ),
        ),
      ],
    );
  }
}
