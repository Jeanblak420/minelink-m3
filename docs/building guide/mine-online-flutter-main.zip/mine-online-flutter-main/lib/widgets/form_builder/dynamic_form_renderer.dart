// Renders a fillable form from a CustomFormTemplate. Stateless: the parent owns
// the values map and is notified of edits via onChanged(key, value). The table
// field edits the list value via onChanged with a fresh list.

import 'package:flutter/material.dart';

import '../../models/custom_form_template.dart';
import '../../utils/form_dropdown_data.dart';
import '../date_picker_field.dart';
import '../signature_canvas.dart';

class DynamicFormRenderer extends StatelessWidget {
  const DynamicFormRenderer({
    super.key,
    required this.fields,
    required this.values,
    required this.onChanged,
    this.grouped = false,
  });

  final List<FormFieldDef> fields;
  final Map<String, dynamic> values;
  final void Function(String key, dynamic value) onChanged;

  /// SP4.6: when true, render fields grouped by section → row → rowOrder (the
  /// legacy designer layout). Default false = today's linear rendering.
  final bool grouped;

  @override
  Widget build(BuildContext context) {
    if (!grouped) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final f in fields) ...[
            _field(context, f),
            const SizedBox(height: 16),
          ],
        ],
      );
    }
    final groups = groupBySection(fields);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final g in groups) ...[
          if (g.key.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 4),
              child: Text(
                g.key,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
          ],
          for (final f in g.value) ...[
            _field(context, f),
            const SizedBox(height: 16),
          ],
        ],
      ],
    );
  }

  Widget _field(BuildContext context, FormFieldDef f) {
    final label = f.required ? '${f.label} *' : f.label;
    switch (f.type) {
      case FormFieldType.section:
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(f.label, style: Theme.of(context).textTheme.titleMedium),
        );
      case FormFieldType.text:
        return TextFormField(
          initialValue: (values[f.key] as String?) ?? '',
          decoration: InputDecoration(labelText: label, helperText: f.help),
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.multiline:
        return TextFormField(
          initialValue: (values[f.key] as String?) ?? '',
          minLines: 3,
          maxLines: 6,
          decoration: InputDecoration(labelText: label, helperText: f.help),
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.number:
        return TextFormField(
          initialValue: values[f.key] == null ? '' : '${values[f.key]}',
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: label, helperText: f.help),
          onChanged: (v) => onChanged(
            f.key,
            v.trim().isEmpty ? null : num.tryParse(v.trim()),
          ),
        );
      case FormFieldType.date:
        return DatePickerField(
          label: label,
          value: (values[f.key] as String?) ?? '',
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.dropdown:
        final options = f.options ?? const [];
        final current = values[f.key] as String?;
        return DropdownButtonFormField<String>(
          initialValue: (current != null && options.contains(current))
              ? current
              : null,
          decoration: InputDecoration(labelText: label, helperText: f.help),
          items: [
            for (final o in options) DropdownMenuItem(value: o, child: Text(o)),
          ],
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.boolean:
        return SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(label),
          subtitle: f.help == null ? null : Text(f.help!),
          value: values[f.key] == true,
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.signature:
        return SignatureCanvasField(
          label: label,
          value: (values[f.key] as String?) ?? '',
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.table:
        return _TableField(
          field: f,
          value: values[f.key],
          onChanged: (rows) => onChanged(f.key, rows),
        );
      case FormFieldType.dynamicDropdown:
        return _DynamicDropdownField(
          field: f,
          label: label,
          value: values[f.key] as String?,
          onChanged: (value, optLabel) {
            onChanged(f.key, value);
            // Stash the resolved label so the PDF can show it without a lookup.
            onChanged('${f.key}__label', optLabel);
          },
        );
    }
  }
}

/// SP4.6: a dropdown whose options are loaded from a data-linked source
/// (form_dropdown_sources allowlist). While loading it renders disabled.
class _DynamicDropdownField extends StatefulWidget {
  const _DynamicDropdownField({
    required this.field,
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final FormFieldDef field;
  final String label;
  final String? value;
  final void Function(String? value, String? label) onChanged;

  @override
  State<_DynamicDropdownField> createState() => _DynamicDropdownFieldState();
}

class _DynamicDropdownFieldState extends State<_DynamicDropdownField> {
  List<({String value, String label})> _options = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final src = widget.field.dropdownSource;
    if (src == null || src.isEmpty) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final opts = await loadDropdownOptions(src);
      if (!mounted) return;
      setState(() {
        _options = opts;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final current = _options.any((o) => o.value == widget.value)
        ? widget.value
        : null;
    return DropdownButtonFormField<String>(
      initialValue: current,
      decoration: InputDecoration(
        labelText: widget.label,
        helperText: widget.field.help,
        suffixIcon: _loading
            ? const Padding(
                padding: EdgeInsets.all(12),
                child: SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              )
            : null,
      ),
      items: [
        for (final o in _options)
          DropdownMenuItem(value: o.value, child: Text(o.label)),
      ],
      onChanged: _loading
          ? null
          : (v) {
              final lbl = _options
                  .where((o) => o.value == v)
                  .map((o) => o.label)
                  .cast<String?>()
                  .firstWhere((_) => true, orElse: () => null);
              widget.onChanged(v, lbl);
            },
    );
  }
}

class _TableField extends StatelessWidget {
  const _TableField({
    required this.field,
    required this.value,
    required this.onChanged,
  });

  final FormFieldDef field;
  final dynamic value;
  final ValueChanged<List<Map<String, dynamic>>> onChanged;

  List<Map<String, dynamic>> get _rows => (value is List)
      ? (value as List).map((e) => (e as Map).cast<String, dynamic>()).toList()
      : <Map<String, dynamic>>[];

  @override
  Widget build(BuildContext context) {
    final cols = field.columns ?? const [];
    final rows = _rows;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          field.required ? '${field.label} *' : field.label,
          style: Theme.of(context).textTheme.titleSmall,
        ),
        for (var r = 0; r < rows.length; r++)
          Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                children: [
                  for (final c in cols)
                    TextFormField(
                      initialValue: (rows[r][c.key] as String?) ?? '',
                      keyboardType: c.type == 'number'
                          ? const TextInputType.numberWithOptions(decimal: true)
                          : TextInputType.text,
                      decoration: InputDecoration(
                        labelText: c.label,
                        isDense: true,
                      ),
                      onChanged: (v) {
                        final next = [
                          for (final row in rows) {...row},
                        ];
                        next[r][c.key] = v;
                        onChanged(next);
                      },
                    ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      icon: const Icon(Icons.close, size: 16),
                      label: const Text('Remove row'),
                      onPressed: () {
                        final next = [
                          for (final row in rows) {...row},
                        ]..removeAt(r);
                        onChanged(next);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add row'),
            onPressed: () {
              final next = [
                for (final row in rows) {...row},
                <String, dynamic>{},
              ];
              onChanged(next);
            },
          ),
        ),
      ],
    );
  }
}
