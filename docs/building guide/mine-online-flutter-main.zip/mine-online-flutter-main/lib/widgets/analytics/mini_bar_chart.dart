// SP7: a dependency-free horizontal bar breakdown. Renders the top [maxBars]
// entries (already sorted) as label + proportional bar + value.

import 'package:flutter/material.dart';

class MiniBarChart extends StatelessWidget {
  const MiniBarChart({
    super.key,
    required this.data,
    required this.color,
    this.maxBars = 6,
  });

  /// Entries sorted by value desc (e.g. sortedDesc(map)).
  final List<MapEntry<String, int>> data;
  final Color color;
  final int maxBars;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (data.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          'No data for this range.',
          style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
        ),
      );
    }
    final shown = data.take(maxBars).toList();
    final maxVal = shown.first.value == 0 ? 1 : shown.first.value;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final e in shown)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                SizedBox(
                  width: 130,
                  child: Text(
                    e.key,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Stack(
                      children: [
                        Container(
                          height: 14,
                          color: scheme.surfaceContainerHighest,
                        ),
                        FractionallySizedBox(
                          widthFactor: (e.value / maxVal).clamp(0.02, 1.0),
                          child: Container(height: 14, color: color),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 36,
                  child: Text(
                    '${e.value}',
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
