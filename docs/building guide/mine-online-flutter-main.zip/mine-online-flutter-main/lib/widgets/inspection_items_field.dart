import 'package:flutter/material.dart';

import '../models/form_data.dart';

/// Renders an inspection-checklist items table:
/// per row [#, item label, Yes/No dropdown, remedial action text field].
/// Mutates [items] in place; callers wrap with setState via [onChanged].
class InspectionItemsField extends StatelessWidget {
  const InspectionItemsField({
    super.key,
    required this.labels,
    required this.items,
    required this.onChanged,
    this.numbers,
  });

  final List<String> labels;
  final List<InspectionItem> items;
  final VoidCallback onChanged;

  /// Optional list of display row numbers (e.g. [1,2,3,...,10,12,13,...] when
  /// the source skips a number). Defaults to 1..labels.length.
  final List<int>? numbers;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < labels.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 28,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: Text('${numbers?[i] ?? (i + 1)}.'),
                  ),
                ),
                Expanded(
                  flex: 5,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 14, right: 8),
                    child: Text(labels[i]),
                  ),
                ),
                SizedBox(
                  width: 96,
                  child: DropdownButtonFormField<String>(
                    initialValue:
                        items[i].yesNo.isEmpty ? null : items[i].yesNo,
                    decoration: const InputDecoration(
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      border: OutlineInputBorder(),
                      hintText: 'Yes/No',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Yes', child: Text('Yes')),
                      DropdownMenuItem(value: 'No', child: Text('No')),
                    ],
                    onChanged: (v) {
                      items[i].yesNo = v ?? '';
                      onChanged();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 4,
                  child: TextFormField(
                    initialValue: items[i].remedialAction,
                    onChanged: (v) => items[i].remedialAction = v,
                    decoration: const InputDecoration(
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                      border: OutlineInputBorder(),
                      hintText: 'Remedial action',
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
