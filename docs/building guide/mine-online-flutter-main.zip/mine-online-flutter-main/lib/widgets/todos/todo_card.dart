import 'package:flutter/material.dart';

import '../../models/todo.dart';
import '../../theme/mol_tones.dart';
import '../../utils/todo_attachments.dart';

/// One swimlane card. Tinted by status, with a left accent stripe, a
/// red-when-checked checkbox, and a strikethrough/0.62-opacity treatment
/// when done — matches ui_kits/mine-online-app/TodosScreen.jsx → TodoCard.
class TodoCard extends StatefulWidget {
  const TodoCard({
    super.key,
    required this.todo,
    required this.onOpen,
    required this.onToggleDone,
    this.childCountInLane,
    this.childCountTotal,
    this.interactive = true,
  });

  final Todo todo;
  final VoidCallback onOpen;
  final VoidCallback onToggleDone;

  /// When this card represents a parent task, the number of its
  /// descendants in the current lane. Null for leaves (no badge).
  final int? childCountInLane;

  /// Total descendants across every lane. Used as the denominator on
  /// the badge (e.g. "3 of 9 phases").
  final int? childCountTotal;

  /// When false, the checkbox renders but ignores taps — eng todos
  /// (managed by the engineering system via service_role) are display-
  /// only on the user side. The dialog still opens on card tap so users
  /// can read the description.
  final bool interactive;

  @override
  State<TodoCard> createState() => _TodoCardState();
}

class _TodoCardState extends State<TodoCard> {
  bool _hover = false;

  MolTone _toneForStatus(MolTones tones, String status) {
    switch (status) {
      case 'done':
        return tones.success;
      case 'doing':
        return tones.warning;
      default:
        return tones.info;
    }
  }

  MolTone _toneForUrgency(MolTones tones, String urgency) {
    switch (urgency) {
      case 'asap':
        return tones.danger;
      case 'meeting':
        return tones.warning;
      default:
        return tones.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final t = widget.todo;
    final done = t.isDone;
    final statusTone = _toneForStatus(tones, t.status);
    final urgency = t.isUser ? todoUrgencyById(t.urgency) : null;

    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        transform: Matrix4.translationValues(0, _hover ? -1 : 0, 0),
        child: Material(
          color: statusTone.tint,
          borderRadius: BorderRadius.circular(12),
          elevation: _hover ? 2 : 1,
          shadowColor: Colors.black.withValues(alpha: 0.12),
          child: InkWell(
            onTap: widget.onOpen,
            borderRadius: BorderRadius.circular(12),
            child: Opacity(
              opacity: done ? 0.72 : 1.0,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 0),
                          child: _Checkbox(
                            checked: done,
                            onChanged: widget.interactive
                                ? widget.onToggleDone
                                : null,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            t.title,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: scheme.onSurface,
                              decoration: done
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                              decorationColor: tones.danger.accent,
                              decorationThickness: 2,
                              height: 1.35,
                            ),
                          ),
                          if (t.isUser &&
                              (t.submitterName ?? '').isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              'from ${t.submitterName}',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w400,
                                color: tones.fg3,
                                height: 1.3,
                              ),
                            ),
                          ],
                          if (t.imageStoragePath != null) ...[
                            const SizedBox(height: 6),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                todoAttachmentPublicUrl(t.imageStoragePath!),
                                height: 80,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (_, _, _) => Container(
                                  height: 80,
                                  color: tones.bgSunken,
                                  alignment: Alignment.center,
                                  child: Icon(
                                    Icons.broken_image_outlined,
                                    color: tones.fg4,
                                  ),
                                ),
                              ),
                            ),
                          ],
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 6,
                            runSpacing: 6,
                            children: [
                              if (urgency != null)
                                _Pill(
                                  text: urgency.short,
                                  tone: _toneForUrgency(tones, urgency.id),
                                ),
                              if (widget.childCountTotal != null &&
                                  widget.childCountTotal! > 0)
                                _Pill(
                                  text: widget.childCountInLane != null
                                      ? '${widget.childCountInLane} of ${widget.childCountTotal} items'
                                      : '${widget.childCountTotal} items',
                                  tone: tones.info,
                                ),
                              if (!t.isUser &&
                                  (t.description ?? '').isNotEmpty)
                                _DescPreview(
                                  text: t.description!,
                                  color: tones.fg3,
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Checkbox extends StatelessWidget {
  const _Checkbox({required this.checked, required this.onChanged});
  final bool checked;
  final VoidCallback? onChanged;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onChanged,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: 20,
        height: 20,
        margin: const EdgeInsets.only(top: 1),
        decoration: BoxDecoration(
          color: checked ? tones.danger.accent : scheme.surface,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: checked ? tones.danger.accent : tones.line,
            width: 2,
          ),
        ),
        alignment: Alignment.center,
        child: checked
            ? const Icon(Icons.check, size: 14, color: Colors.white)
            : null,
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.tone});
  final String text;
  final MolTone tone;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: tone.soft,
        borderRadius: BorderRadius.circular(9999),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: tone.fg,
          letterSpacing: 0.3,
        ),
      ),
    );
  }
}

class _DescPreview extends StatelessWidget {
  const _DescPreview({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final shown = text.length > 60 ? '${text.substring(0, 60)}…' : text;
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 240),
      child: Text(
        shown,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 11, color: color, height: 1.3),
      ),
    );
  }
}
