import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../models/todo.dart';
import '../../theme/mol_tones.dart';
import 'annotate_image_dialog.dart';

/// New User Request modal. Disables Submit until title, name, image, and
/// summary are all filled. Mirrors TodosScreen.jsx → CreateUserRequest.
/// Image annotation (drawing arrows / notes) is e-todos-6 — this dialog
/// only accepts a screenshot + caption.
class CreateUserRequestDialog extends StatefulWidget {
  const CreateUserRequestDialog({
    super.key,
    required this.initialName,
    required this.onSubmit,
  });

  final String initialName;
  final Future<bool> Function(UserRequestDraft draft) onSubmit;

  @override
  State<CreateUserRequestDialog> createState() =>
      _CreateUserRequestDialogState();
}

class _CreateUserRequestDialogState extends State<CreateUserRequestDialog> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _nameCtrl;
  final TextEditingController _imageNotesCtrl = TextEditingController();
  final TextEditingController _summaryCtrl = TextEditingController();
  String _urgency = 'whenever';
  Uint8List? _imageBytes;
  String _imageFilename = '';
  String _imageMime = 'image/png';
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController();
    _nameCtrl = TextEditingController(text: widget.initialName);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _nameCtrl.dispose();
    _imageNotesCtrl.dispose();
    _summaryCtrl.dispose();
    super.dispose();
  }

  bool get _valid =>
      _titleCtrl.text.trim().isNotEmpty &&
      _nameCtrl.text.trim().isNotEmpty &&
      _summaryCtrl.text.trim().isNotEmpty &&
      _imageBytes != null &&
      !_submitting;

  String _mimeForExtension(String filename) {
    final lower = filename.toLowerCase();
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    if (lower.endsWith('.webp')) return 'image/webp';
    if (lower.endsWith('.gif')) return 'image/gif';
    return 'image/png';
  }

  Future<void> _pickImage() async {
    final result = await FilePicker.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final f = result.files.single;
    if (f.bytes == null) return;
    setState(() {
      _imageBytes = f.bytes;
      _imageFilename = f.name;
      _imageMime = _mimeForExtension(f.name);
    });
    await _annotate();
  }

  Future<void> _annotate() async {
    final bytes = _imageBytes;
    if (bytes == null || !mounted) return;
    final annotated = await AnnotateImageDialog.show(context, bytes);
    if (annotated == null || !mounted) return;
    setState(() {
      _imageBytes = annotated;
      _imageMime = 'image/png';
      if (!_imageFilename.toLowerCase().endsWith('.png')) {
        final stem = _imageFilename.contains('.')
            ? _imageFilename.substring(0, _imageFilename.lastIndexOf('.'))
            : _imageFilename;
        _imageFilename =
            '${stem.isEmpty ? 'screenshot' : stem}-annotated.png';
      }
    });
  }

  Future<void> _submit() async {
    if (!_valid) return;
    setState(() => _submitting = true);
    final ok = await widget.onSubmit(UserRequestDraft(
      title: _titleCtrl.text.trim(),
      submitterName: _nameCtrl.text.trim(),
      urgency: _urgency,
      summary: _summaryCtrl.text.trim(),
      imageBytes: _imageBytes!,
      imageFilename: _imageFilename.isEmpty ? 'screenshot.png' : _imageFilename,
      imageMime: _imageMime,
      imageNotes: _imageNotesCtrl.text.trim(),
    ));
    if (!mounted) return;
    setState(() => _submitting = false);
    if (ok && mounted) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 680),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 8, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'New user request',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: scheme.onSurface,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    tooltip: 'Close',
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
            Divider(color: tones.lineFaint, height: 1),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextField(
                      controller: _titleCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Task name',
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _nameCtrl,
                      decoration: const InputDecoration(
                        labelText: 'First and last name',
                      ),
                      autofillHints: const [AutofillHints.name],
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 18),
                    _RequiredLabel(
                      label: 'Screenshot or image with notes',
                    ),
                    const SizedBox(height: 8),
                    if (_imageBytes == null)
                      InkWell(
                        onTap: _pickImage,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: tones.bgSunken,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: tones.line,
                              width: 2,
                              style: BorderStyle.solid,
                            ),
                          ),
                          child: Column(
                            children: [
                              Icon(
                                Icons.add_photo_alternate_outlined,
                                size: 28,
                                color: tones.fg3,
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Click to upload a screenshot',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  color: tones.fg3,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'PNG / JPG · annotate it first if you can',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: tones.fg4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.memory(
                              _imageBytes!,
                              fit: BoxFit.contain,
                              height: 280,
                              width: double.infinity,
                            ),
                          ),
                          Positioned(
                            top: 8,
                            right: 8,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _ImagePreviewButton(
                                  icon: Icons.edit_outlined,
                                  label: 'Annotate',
                                  onTap: _annotate,
                                ),
                                const SizedBox(width: 6),
                                _ImagePreviewButton(
                                  icon: Icons.close,
                                  label: 'Replace',
                                  onTap: () => setState(() {
                                    _imageBytes = null;
                                    _imageFilename = '';
                                  }),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    if (_imageBytes != null) ...[
                      const SizedBox(height: 10),
                      TextField(
                        controller: _imageNotesCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Notes about the image (optional)',
                        ),
                      ),
                    ],
                    const SizedBox(height: 18),
                    _RequiredLabel(label: 'Urgency'),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      initialValue: _urgency,
                      items: [
                        for (final u in todoUrgencies)
                          DropdownMenuItem(value: u.id, child: Text(u.label)),
                      ],
                      onChanged: (v) {
                        if (v != null) setState(() => _urgency = v);
                      },
                    ),
                    const SizedBox(height: 18),
                    _RequiredLabel(label: 'Summary'),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _summaryCtrl,
                      minLines: 5,
                      maxLines: 10,
                      decoration: const InputDecoration(
                        hintText:
                            "Please explain/elaborate in as much detail as possible with steps starting from step 1 as to what you'd like this change or addition to do once it has been fully implemented please.",
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed:
                        _submitting ? null : () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    icon: _submitting
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.send),
                    label: const Text('Submit request'),
                    onPressed: _valid ? _submit : null,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RequiredLabel extends StatelessWidget {
  const _RequiredLabel({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return RichText(
      text: TextSpan(
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w500,
          color: tones.fg3,
          letterSpacing: 0.4,
        ),
        children: [
          TextSpan(text: label.toUpperCase()),
          const TextSpan(text: ' '),
          TextSpan(
            text: '*',
            style: TextStyle(color: tones.danger.accent),
          ),
        ],
      ),
    );
  }
}

class _ImagePreviewButton extends StatelessWidget {
  const _ImagePreviewButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(9999),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9999),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14, color: tones.fg3),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: tones.fg3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class UserRequestDraft {
  UserRequestDraft({
    required this.title,
    required this.submitterName,
    required this.urgency,
    required this.summary,
    required this.imageBytes,
    required this.imageFilename,
    required this.imageMime,
    required this.imageNotes,
  });

  final String title;
  final String submitterName;
  final String urgency;
  final String summary;
  final Uint8List imageBytes;
  final String imageFilename;
  final String imageMime;
  final String imageNotes;
}
