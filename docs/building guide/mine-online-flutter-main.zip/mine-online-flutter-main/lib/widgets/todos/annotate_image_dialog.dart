import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_painter/image_painter.dart';

/// Lets a user draw arrows / circles / freeform / text on a screenshot
/// before submission. The returned bytes are the rendered PNG with all
/// annotations baked in. Returns `null` if the user cancels.
class AnnotateImageDialog extends StatefulWidget {
  const AnnotateImageDialog({
    super.key,
    required this.bytes,
  });

  final Uint8List bytes;

  static Future<Uint8List?> show(BuildContext context, Uint8List bytes) {
    return showDialog<Uint8List?>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AnnotateImageDialog(bytes: bytes),
    );
  }

  @override
  State<AnnotateImageDialog> createState() => _AnnotateImageDialogState();
}

class _AnnotateImageDialogState extends State<AnnotateImageDialog> {
  late final ImagePainterController _controller;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _controller = ImagePainterController(
      color: Colors.red,
      strokeWidth: 4,
      mode: PaintMode.freeStyle,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      final bytes = await _controller.exportImage();
      if (!mounted) return;
      Navigator.of(context).pop(bytes ?? widget.bytes);
    } catch (_) {
      if (!mounted) return;
      Navigator.of(context).pop(widget.bytes);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900, maxHeight: 720),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 8, 12),
              child: Row(
                children: [
                  Icon(Icons.edit_outlined, color: scheme.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Annotate screenshot',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: scheme.onSurface,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    tooltip: 'Cancel',
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Flexible(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: ImagePainter.memory(
                  widget.bytes,
                  controller: _controller,
                  scalable: true,
                  controlsAtTop: true,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed:
                        _saving ? null : () => Navigator.of(context).pop(),
                    child: const Text('Skip annotation'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    icon: _saving
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.check),
                    label: const Text('Use annotated image'),
                    onPressed: _saving ? null : _save,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
