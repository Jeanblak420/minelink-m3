import 'package:flutter/material.dart';

import '../../models/todo.dart';
import '../../theme/mol_tones.dart';
import '../mol_chips.dart';
import 'todo_card.dart';
import 'todo_tree.dart';

/// One column of a section (Planned / In Progress / Completed).
///
/// Takes a pruned forest of [TodoNode]s — every node has at least one
/// descendant (or itself) in [status]. Parents render as expandable
/// containers (collapsed by default) so the lane stays readable when
/// there are many phases / sub-tasks. Each sibling gets a cycled tint
/// so neighbouring groups never share a colour.
class TodoLane extends StatelessWidget {
  const TodoLane({
    super.key,
    required this.status,
    required this.nodes,
    required this.onOpen,
    required this.onToggleDone,
  });

  final TodoStatus status;
  final List<TodoNode> nodes;
  final ValueChanged<Todo> onOpen;
  final ValueChanged<Todo> onToggleDone;

  int _countInLane(List<TodoNode> ns) {
    var n = 0;
    for (final node in ns) {
      if (node.todo.status == status.id) n += 1;
      n += _countInLane(node.children);
    }
    return n;
  }

  IconData get _icon {
    switch (status.id) {
      case 'doing':
        return Icons.play_circle_outline;
      case 'done':
        return Icons.check_circle_outline;
      default:
        return Icons.pending_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final count = _countInLane(nodes);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tones.bgMuted,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 4),
            child: Row(
              children: [
                StatusChip(
                  kind: status.id == 'doing'
                      ? StatusChipKind.doing
                      : status.id == 'done'
                          ? StatusChipKind.done
                          : StatusChipKind.planned,
                  label: status.label,
                  icon: _icon,
                ),
                const SizedBox(width: 8),
                Text(
                  '$count',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: tones.fg3,
                  ),
                ),
              ],
            ),
          ),
          if (nodes.isEmpty)
            Container(
              constraints: const BoxConstraints(minHeight: 60),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: tones.line),
              ),
              alignment: Alignment.center,
              padding: const EdgeInsets.all(12),
              child: Text(
                'No items',
                style: TextStyle(fontSize: 12, color: tones.fg4),
                textAlign: TextAlign.center,
              ),
            )
          else
            Column(
              children: [
                for (var i = 0; i < nodes.length; i++) ...[
                  if (i > 0) const SizedBox(height: 10),
                  _TodoTreeView(
                    node: nodes[i],
                    laneStatus: status.id,
                    depth: 0,
                    siblingIndex: i,
                    onOpen: onOpen,
                    onToggleDone: onToggleDone,
                  ),
                ],
              ],
            ),
        ],
      ),
    );
  }
}

/// Recursive renderer. Each parent renders an expand/collapse chevron;
/// children are hidden until the user expands the group. Background tint
/// rotates per (sibling + depth) so adjacent nodes never share a colour.
class _TodoTreeView extends StatefulWidget {
  const _TodoTreeView({
    required this.node,
    required this.laneStatus,
    required this.depth,
    required this.siblingIndex,
    required this.onOpen,
    required this.onToggleDone,
  });

  final TodoNode node;
  final String laneStatus;
  final int depth;
  final int siblingIndex;
  final ValueChanged<Todo> onOpen;
  final ValueChanged<Todo> onToggleDone;

  @override
  State<_TodoTreeView> createState() => _TodoTreeViewState();
}

class _TodoTreeViewState extends State<_TodoTreeView> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final selfInLane = widget.node.todo.status == widget.laneStatus;
    final hasChildren = widget.node.children.isNotEmpty;
    final isEng = widget.node.todo.isEng;

    final header = selfInLane
        ? TodoCard(
            todo: widget.node.todo,
            childCountInLane: hasChildren
                ? widget.node.descendantCountIn(widget.laneStatus)
                : null,
            childCountTotal:
                hasChildren ? widget.node.descendantCount : null,
            interactive: !isEng,
            onOpen: () => widget.onOpen(widget.node.todo),
            onToggleDone: () => widget.onToggleDone(widget.node.todo),
          )
        : _ContextHeader(
            todo: widget.node.todo,
            laneStatus: widget.laneStatus,
            shownChildCount:
                widget.node.descendantCountIn(widget.laneStatus),
            totalChildCount: widget.node.descendantCount,
            onOpen: () => widget.onOpen(widget.node.todo),
          );

    if (!hasChildren) return header;

    final bg = _siblingTint(scheme, widget.depth, widget.siblingIndex);
    return Container(
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: tones.lineFaint, width: 0.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(child: header),
              const SizedBox(width: 4),
              _ExpandChevron(
                expanded: _expanded,
                onTap: () => setState(() => _expanded = !_expanded),
              ),
            ],
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
            alignment: Alignment.topCenter,
            child: _expanded
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(14, 10, 0, 2),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        for (var i = 0; i < widget.node.children.length; i++) ...[
                          if (i > 0) const SizedBox(height: 8),
                          _TodoTreeView(
                            node: widget.node.children[i],
                            laneStatus: widget.laneStatus,
                            depth: widget.depth + 1,
                            siblingIndex: i,
                            onOpen: widget.onOpen,
                            onToggleDone: widget.onToggleDone,
                          ),
                        ],
                      ],
                    ),
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

/// Cycle through Material 3's neutral surface ladder per sibling index.
/// The depth offset rotates by one slot per level so a child container
/// never inherits its parent's tone and adjacent siblings always differ.
/// Uses M3 surface tones (not coloured pastels) for a calmer, more
/// premium grouping — colour stays on the cards themselves, where it
/// signals status.
Color _siblingTint(ColorScheme scheme, int depth, int siblingIndex) {
  final palette = <Color>[
    scheme.surfaceContainerLowest,
    scheme.surfaceContainerHigh,
    scheme.surfaceContainerLow,
    scheme.surfaceContainerHighest,
    scheme.surfaceContainer,
  ];
  final idx = (siblingIndex + depth) % palette.length;
  return palette[idx];
}

class _ExpandChevron extends StatelessWidget {
  const _ExpandChevron({required this.expanded, required this.onTap});
  final bool expanded;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return InkResponse(
      onTap: onTap,
      radius: 18,
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: AnimatedRotation(
          duration: const Duration(milliseconds: 180),
          turns: expanded ? 0.5 : 0.0,
          child: Icon(
            Icons.expand_more,
            size: 22,
            color: tones.fg3,
          ),
        ),
      ),
    );
  }
}

/// Non-checkable header that appears in a lane only because a descendant
/// is in this lane. Communicates the parent's actual status with a small
/// pill so the user knows where the parent itself lives.
class _ContextHeader extends StatelessWidget {
  const _ContextHeader({
    required this.todo,
    required this.laneStatus,
    required this.shownChildCount,
    required this.totalChildCount,
    required this.onOpen,
  });

  final Todo todo;
  final String laneStatus;
  final int shownChildCount;
  final int totalChildCount;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final actualStatus = todoStatusById(todo.status);
    final actualLabel = actualStatus?.label ?? todo.status;
    final pillKind = todo.status == 'doing'
        ? StatusChipKind.doing
        : todo.status == 'done'
            ? StatusChipKind.done
            : StatusChipKind.planned;

    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(10),
      elevation: 0,
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Row(
            children: [
              Icon(Icons.folder_outlined, size: 16, color: tones.fg3),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  todo.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: tones.fg3,
                    height: 1.3,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: tones.bgMuted,
                  borderRadius: BorderRadius.circular(9999),
                ),
                child: Text(
                  '$shownChildCount of $totalChildCount',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: tones.fg3,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              StatusChip(kind: pillKind, label: actualLabel),
            ],
          ),
        ),
      ),
    );
  }
}

TodoStatus? todoStatusById(String id) {
  for (final s in todoStatuses) {
    if (s.id == id) return s;
  }
  return null;
}
