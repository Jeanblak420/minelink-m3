import '../../models/todo.dart';

/// One node in the todo hierarchy. A node is "in this lane" when its own
/// status matches the lane; it's "visible in this lane" when it OR any
/// descendant is in this lane (so a parent appears as a context header
/// for any of its phases that are currently in that lane, even if the
/// parent's own status is elsewhere).
class TodoNode {
  TodoNode(this.todo, this.children);

  final Todo todo;
  final List<TodoNode> children;

  int get descendantCount {
    var n = 0;
    for (final c in children) {
      n += 1 + c.descendantCount;
    }
    return n;
  }

  int descendantCountIn(String laneStatus) {
    var n = 0;
    for (final c in children) {
      if (c.todo.status == laneStatus) n += 1;
      n += c.descendantCountIn(laneStatus);
    }
    return n;
  }

  int descendantCountAny() {
    var n = 0;
    for (final c in children) {
      n += 1 + c.descendantCountAny();
    }
    return n;
  }

  /// Counts split by status for the badge on a parent card.
  ({int planned, int doing, int done}) descendantStatusCounts() {
    var planned = 0, doing = 0, done = 0;
    for (final c in children) {
      switch (c.todo.status) {
        case 'planned':
          planned++;
          break;
        case 'doing':
          doing++;
          break;
        case 'done':
          done++;
          break;
      }
      final sub = c.descendantStatusCounts();
      planned += sub.planned;
      doing += sub.doing;
      done += sub.done;
    }
    return (planned: planned, doing: doing, done: done);
  }
}

/// Builds a forest from a flat todo list. A node is "rooted" when its
/// parent_id is null OR its parent isn't in the supplied list (orphaned
/// children are surfaced at the top level so they don't disappear).
List<TodoNode> buildTodoForest(List<Todo> all) {
  final byId = {for (final t in all) t.id: t};
  final childrenOf = <String, List<Todo>>{};
  for (final t in all) {
    if (t.parentId != null && byId.containsKey(t.parentId)) {
      (childrenOf[t.parentId!] ??= []).add(t);
    }
  }

  TodoNode build(Todo t) {
    final kids = childrenOf[t.id] ?? const <Todo>[];
    // Sort children oldest first so phase 1 → phase N reads top to bottom.
    final sortedKids = [...kids]
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return TodoNode(t, sortedKids.map(build).toList(growable: false));
  }

  final roots = all
      .where((t) => t.parentId == null || !byId.containsKey(t.parentId))
      .toList()
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  return roots.map(build).toList(growable: false);
}

/// Returns the subtree rooted at [node] but pruned so only branches that
/// contain at least one item in [laneStatus] (including the node itself)
/// remain. Returns null when nothing in the subtree matches the lane.
TodoNode? pruneToLane(TodoNode node, String laneStatus) {
  final keptChildren = <TodoNode>[];
  for (final c in node.children) {
    final pruned = pruneToLane(c, laneStatus);
    if (pruned != null) keptChildren.add(pruned);
  }
  final selfMatches = node.todo.status == laneStatus;
  if (!selfMatches && keptChildren.isEmpty) return null;
  return TodoNode(node.todo, keptChildren);
}

/// Filters a forest down to only nodes (and their descendants) that have
/// something in [laneStatus]. Parents whose own status is elsewhere still
/// render — as context headers above their matching descendants.
List<TodoNode> pruneForestToLane(List<TodoNode> forest, String laneStatus) {
  final out = <TodoNode>[];
  for (final n in forest) {
    final p = pruneToLane(n, laneStatus);
    if (p != null) out.add(p);
  }
  return out;
}
