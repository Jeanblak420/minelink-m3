import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/todo.dart';
import '../../providers/auth_provider.dart';
import '../../theme/mol_tones.dart';
import '../../utils/role_access.dart';
import '../../utils/todo_attachments.dart';

/// Tap-a-card detail dialog. Three pill buttons cycle the status; Delete is
/// danger-coloured; Close confirms. Matches TodosScreen.jsx → TodoDetail.
class TodoDetailDialog extends StatelessWidget {
  const TodoDetailDialog({
    super.key,
    required this.todo,
    required this.onSetStatus,
    required this.onDelete,
  });

  final Todo todo;
  final ValueChanged<String> onSetStatus;
  final VoidCallback onDelete;

  IconData _iconFor(String id) {
    switch (id) {
      case 'doing':
        return Icons.play_circle_outline;
      case 'done':
        return Icons.check_circle_outline;
      default:
        return Icons.pending_outlined;
    }
  }

  MolTone _toneFor(MolTones tones, String id) {
    switch (id) {
      case 'doing':
        return tones.warning;
      case 'done':
        return tones.success;
      default:
        return tones.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final isUser = todo.isUser;
    final urgency = isUser ? todoUrgencyById(todo.urgency) : null;
    // Deletion is locked to admins by RLS — every user-submitted request
    // must stay on the shared list permanently so everyone can see what's
    // been suggested. Hide the button for non-admins so it isn't confusing.
    final canDelete = isAdminProfile(context.watch<AuthProvider>().profile);
    final urgencyTone = urgency == null
        ? null
        : (urgency.id == 'asap'
            ? tones.danger
            : urgency.id == 'meeting'
                ? tones.warning
                : tones.info);

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 620),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 8, 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      todo.title,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: scheme.onSurface,
                        height: 1.3,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    tooltip: 'Close',
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
            Divider(color: tones.lineFaint, height: 1),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Status pill switcher. Eng todos are managed by the
                    // engineering system via service_role — render the pills
                    // for visual reference but don't let the user re-tap
                    // them. A small hint sits below.
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final s in todoStatuses)
                          _StatusPillButton(
                            label: s.label,
                            icon: _iconFor(s.id),
                            active: todo.status == s.id,
                            tone: _toneFor(tones, s.id),
                            onTap: isUser ? () => onSetStatus(s.id) : null,
                          ),
                      ],
                    ),
                    if (!isUser) ...[
                      const SizedBox(height: 6),
                      Text(
                        'Engineering tasks update automatically as work ships — status is read-only here.',
                        style: TextStyle(
                          fontSize: 11,
                          color: tones.fg3,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                    const SizedBox(height: 18),
                    if (isUser) ...[
                      if ((todo.submitterName ?? '').isNotEmpty)
                        _LabeledRow(
                          label: 'Submitted by',
                          value: todo.submitterName!,
                        ),
                      if (urgency != null && urgencyTone != null) ...[
                        const SizedBox(height: 12),
                        _Label('Urgency'),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: urgencyTone.soft,
                            borderRadius: BorderRadius.circular(9999),
                          ),
                          child: Text(
                            urgency.short,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: urgencyTone.fg,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          urgency.label,
                          style: TextStyle(
                            fontSize: 12,
                            color: tones.fg3,
                            height: 1.5,
                          ),
                        ),
                      ],
                      if (todo.imageStoragePath != null) ...[
                        const SizedBox(height: 14),
                        _Label('Attached screenshot'),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            todoAttachmentPublicUrl(todo.imageStoragePath!),
                            fit: BoxFit.contain,
                            errorBuilder: (_, _, _) => Container(
                              height: 120,
                              color: tones.bgSunken,
                              alignment: Alignment.center,
                              child: Text(
                                'Image failed to load',
                                style: TextStyle(color: tones.fg3),
                              ),
                            ),
                          ),
                        ),
                        if ((todo.imageNotes ?? '').isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text(
                            '"${todo.imageNotes}"',
                            style: TextStyle(
                              fontStyle: FontStyle.italic,
                              fontSize: 12,
                              color: scheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ],
                      if ((todo.summary ?? '').isNotEmpty) ...[
                        const SizedBox(height: 14),
                        _Label('Summary'),
                        const SizedBox(height: 6),
                        Text(
                          todo.summary!,
                          style: TextStyle(
                            fontSize: 14,
                            color: scheme.onSurface,
                            height: 1.55,
                          ),
                        ),
                      ],
                    ] else ...[
                      _Label('Details'),
                      const SizedBox(height: 6),
                      Text(
                        (todo.description ?? '').isEmpty
                            ? 'No description provided.'
                            : todo.description!,
                        style: TextStyle(
                          fontSize: 14,
                          color: scheme.onSurface,
                          height: 1.55,
                        ),
                      ),
                      if ((todo.authorName ?? '').isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Text(
                          'Added by ${todo.authorName!}',
                          style: TextStyle(fontSize: 11, color: tones.fg3),
                        ),
                      ],
                    ],
                  ],
                ),
              ),
            ),
            // Footer actions
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Row(
                children: [
                  if (canDelete)
                    TextButton.icon(
                      icon: const Icon(Icons.delete_outline),
                      label: const Text('Delete'),
                      style: TextButton.styleFrom(
                        foregroundColor: tones.danger.accent,
                      ),
                      onPressed: onDelete,
                    ),
                  const Spacer(),
                  FilledButton.icon(
                    icon: const Icon(Icons.check),
                    label: const Text('Close'),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusPillButton extends StatelessWidget {
  const _StatusPillButton({
    required this.label,
    required this.icon,
    required this.active,
    required this.tone,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool active;
  final MolTone tone;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final disabled = onTap == null;
    final fg = active ? tone.fg : tones.fg3;
    return InkWell(
      borderRadius: BorderRadius.circular(9999),
      onTap: onTap,
      child: Opacity(
        opacity: disabled && !active ? 0.55 : 1.0,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: active ? tone.soft : scheme.surface,
            borderRadius: BorderRadius.circular(9999),
            border: Border.all(
              color: active ? tone.accent : tones.line,
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14, color: fg),
              const SizedBox(width: 6),
              Text(
                label.toUpperCase(),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: fg,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LabeledRow extends StatelessWidget {
  const _LabeledRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Label(label),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: scheme.onSurface,
          ),
        ),
      ],
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return Text(
      text.toUpperCase(),
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: tones.fg3,
        letterSpacing: 0.4,
      ),
    );
  }
}
