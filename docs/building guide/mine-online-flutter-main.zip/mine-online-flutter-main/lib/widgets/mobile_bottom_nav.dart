// Mobile bottom navigation. Renders only when MediaQuery.size.width < 720
// (matches the UI kit's `useNarrow(720)` breakpoint). On desktop the
// top-bar role-switcher + actions row carries the same navigation, so this
// returns SizedBox.shrink() above the breakpoint.
//
// Tabs:
//   Home           → /
//   Appointments   → /appointments
//   Inbox          → /notifications  (M3 Badge with unread count)
//   Profile        → /my-profile
//
// e-nav-1 (this widget) + e-nav-2 (back-arrow behaviour on tab roots, see
// home_screen + AppRouter) + e-nav-3 (SafeArea wrap, below) all live here.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../providers/notifications_provider.dart';

class MobileBottomNav extends StatelessWidget {
  const MobileBottomNav({super.key, required this.location});

  /// The current route location (typically `GoRouterState.of(context).uri.path`
  /// or hard-coded in screens that don't have access to the router state).
  final String location;

  static const _breakpoint = 720.0;

  static const _tabs = <_NavTab>[
    _NavTab(
      route: '/',
      label: 'Home',
      icon: Icons.home_outlined,
      activeIcon: Icons.home,
    ),
    _NavTab(
      route: '/appointments',
      label: 'Appointments',
      icon: Icons.assignment_outlined,
      activeIcon: Icons.assignment,
    ),
    _NavTab(
      route: '/notifications',
      label: 'Inbox',
      icon: Icons.notifications_none_outlined,
      activeIcon: Icons.notifications,
      isInbox: true,
    ),
    _NavTab(
      route: '/my-profile',
      label: 'Profile',
      icon: Icons.person_outline,
      activeIcon: Icons.person,
    ),
  ];

  int _indexFor(String location) {
    for (var i = 0; i < _tabs.length; i++) {
      final t = _tabs[i];
      if (t.route == '/' ? location == '/' : location.startsWith(t.route)) {
        return i;
      }
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= _breakpoint) return const SizedBox.shrink();
    final unread = context.watch<NotificationsProvider>().unreadCount;
    final idx = _indexFor(location);

    return SafeArea(
      top: false,
      child: NavigationBar(
        selectedIndex: idx,
        destinations: [
          for (final t in _tabs)
            NavigationDestination(
              icon: t.isInbox && unread > 0
                  ? Badge(
                      label: Text(unread > 9 ? '9+' : '$unread'),
                      child: Icon(t.icon),
                    )
                  : Icon(t.icon),
              selectedIcon: t.isInbox && unread > 0
                  ? Badge(
                      label: Text(unread > 9 ? '9+' : '$unread'),
                      child: Icon(t.activeIcon),
                    )
                  : Icon(t.activeIcon),
              label: t.label,
            ),
        ],
        onDestinationSelected: (i) {
          final target = _tabs[i].route;
          if (target == location) return;
          context.go(target);
        },
      ),
    );
  }
}

class _NavTab {
  const _NavTab({
    required this.route,
    required this.label,
    required this.icon,
    required this.activeIcon,
    this.isInbox = false,
  });

  final String route;
  final String label;
  final IconData icon;
  final IconData activeIcon;
  final bool isInbox;
}
