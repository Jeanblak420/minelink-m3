// Returns the standard AppBar trailing actions:
// TodosChecklistButton + NotificationBell + AccountBadge.
// Use via:
//
//   AppBar(
//     title: const Text('...'),
//     actions: commonAppBarActions(),
//   )
//
// Screen-specific actions can be prepended:
//
//   actions: [
//     IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh)),
//     ...commonAppBarActions(),
//   ],

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'account_badge.dart';
import 'notification_bell.dart';

List<Widget> commonAppBarActions() => const [
      TodosChecklistButton(),
      NotificationBell(),
      AccountBadge(),
    ];

/// Same trio used by home_screen.dart's _Header (which builds its own row
/// instead of using the AppBar). Keeps the To-Do checklist icon present on
/// every dashboard / main view, not just AppBar-bearing screens.
List<Widget> homeHeaderActions() => const [
      TodosChecklistButton(),
      NotificationBell(),
      SizedBox(width: 4),
      AccountBadge(),
    ];

class TodosChecklistButton extends StatelessWidget {
  const TodosChecklistButton({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: 'To-Do List',
      icon: const Icon(Icons.checklist_outlined),
      onPressed: () => context.go('/todos'),
    );
  }
}
