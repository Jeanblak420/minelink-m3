// Mirrors src/components/AccountBadge.tsx. Shows the user's initials in a
// CircleAvatar; tapping opens a PopupMenu with the profile header up top,
// then My Profile / Settings / Sign out (danger). Sign-out → /login.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';

class AccountBadge extends StatelessWidget {
  const AccountBadge({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    final auth = context.watch<AuthProvider>();
    final profile = auth.profile;
    final realProfile = auth.realProfile;
    final user = auth.user;
    final isSuperAdmin = realProfile?.isSuperAdmin ?? false;
    final initialsSource = (profile?.fullName.isNotEmpty == true)
        ? profile!.fullName
        : (profile?.firstName.isNotEmpty == true)
            ? profile!.firstName
            : (user?.email ?? 'Account');
    final displayName = (profile?.fullName.isNotEmpty == true)
        ? profile!.fullName
        : (profile?.firstName.isNotEmpty == true)
            ? profile!.firstName
            : 'Signed-in user';
    final email = user?.email ?? '';

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: PopupMenuButton<String>(
        tooltip: 'Account',
        onSelected: (value) async {
          switch (value) {
            case 'profile':
              if (context.mounted) context.go('/my-profile');
              break;
            case 'settings':
              if (context.mounted) context.go('/settings');
              break;
            case 'signout':
              await context.read<AuthProvider>().signOut();
              if (context.mounted) context.go('/login');
              break;
            default:
              if (value.startsWith('view-as:')) {
                final role = value.substring('view-as:'.length);
                context
                    .read<AuthProvider>()
                    .setViewAs(role.isEmpty ? null : role);
              }
              break;
          }
        },
        itemBuilder: (_) => [
          PopupMenuItem(
            enabled: false,
            padding: EdgeInsets.zero,
            child: Container(
              width: 260,
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 20,
                    backgroundColor: scheme.primary,
                    child: Text(
                      _initials(initialsSource),
                      style: TextStyle(
                        color: scheme.onPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: scheme.onSurface,
                          ),
                        ),
                        if (email.isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            email,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              color: tones.fg3,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const PopupMenuDivider(),
          if (isSuperAdmin) ...[
            PopupMenuItem(
              enabled: false,
              padding: EdgeInsets.zero,
              child: Container(
                width: 260,
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'VIEW AS',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: tones.fg3,
                        letterSpacing: 0.6,
                      ),
                    ),
                    const SizedBox(height: 6),
                    DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: auth.viewAsAccountType ?? '',
                        isDense: true,
                        isExpanded: true,
                        items: const [
                          DropdownMenuItem(
                            value: '',
                            child: Text('Super Admin (your role)'),
                          ),
                          DropdownMenuItem(
                            value: 'Shift Boss',
                            child: Text('Shift Boss'),
                          ),
                          DropdownMenuItem(
                            value: 'Mine Overseer',
                            child: Text('Mine Overseer'),
                          ),
                          DropdownMenuItem(
                            value: 'Mine Manager',
                            child: Text('Mine Manager'),
                          ),
                          DropdownMenuItem(
                            value: 'Admin',
                            child: Text('Admin'),
                          ),
                        ],
                        onChanged: (val) {
                          // The PopupMenu intercepts our taps if we use
                          // `value:` on the item — so do the switch directly
                          // here and close the menu ourselves.
                          context.read<AuthProvider>().setViewAs(
                                (val == null || val.isEmpty) ? null : val,
                              );
                          if (context.mounted) Navigator.of(context).pop();
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const PopupMenuDivider(),
          ],
          PopupMenuItem(
            value: 'profile',
            child: Row(
              children: const [
                Icon(Icons.person_outline, size: 18),
                SizedBox(width: 12),
                Text('My Profile'),
              ],
            ),
          ),
          PopupMenuItem(
            value: 'settings',
            child: Row(
              children: const [
                Icon(Icons.settings_outlined, size: 18),
                SizedBox(width: 12),
                Text('Settings'),
              ],
            ),
          ),
          const PopupMenuDivider(),
          PopupMenuItem(
            value: 'signout',
            child: Row(
              children: [
                Icon(Icons.logout, size: 18, color: scheme.error),
                const SizedBox(width: 12),
                Text('Sign out', style: TextStyle(color: scheme.error)),
              ],
            ),
          ),
        ],
        child: CircleAvatar(
          radius: 18,
          backgroundColor: scheme.primary,
          child: Text(
            _initials(initialsSource),
            style: TextStyle(
              color: scheme.onPrimary,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}

String _initials(String source) {
  // Mirrors web src/components/AccountBadge.tsx lines 22-27:
  //   displayName.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
  // Single space split (not whitespace regex) so an email like 'jean@x.com'
  // produces 'J', and 'John Smith' produces 'JS'.
  final parts = source.split(' ').take(2).toList();
  final buf = StringBuffer();
  for (final p in parts) {
    if (p.isNotEmpty) buf.write(p[0]);
  }
  final out = buf.toString().toUpperCase();
  return out.isEmpty ? '?' : out;
}
