import 'package:flutter/material.dart';

/// Explains that this IS the Mine Online app and where to get the Android build.
/// (The "Download Mobile App" sidebar item / Quick Action open this.)
Future<void> showMobileAppInfo(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: const Icon(Icons.smartphone_outlined),
      title: const Text('Mine Online Mobile'),
      content: const Text(
        "You're already using the Mine Online app. The Android build (APK) is "
        'distributed to field tablets through your administrator. Ask your '
        'administrator for the latest release if you need to install it on '
        'another device.',
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: const Text('Got it'),
        ),
      ],
    ),
  );
}
