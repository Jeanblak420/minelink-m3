import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../theme/mol_tones.dart';
import '../../utils/admin_dashboard_data.dart';
import '../empty_state.dart';
import '../mol_chips.dart';

/// "Appointment Activity" card: header + "View All", then recent appointment
/// rows (name, subtitle, status pill, date) or an empty state.
class AppointmentActivityFeed extends StatelessWidget {
  const AppointmentActivityFeed({
    super.key,
    required this.items,
    required this.loading,
    required this.onViewAll,
    required this.onOpen,
  });

  final List<AppointmentActivityItem> items;
  final bool loading;
  final VoidCallback onViewAll;

  /// Called with the tapped activity item so the screen can open the
  /// submission viewer for the real underlying submission.
  final ValueChanged<AppointmentActivityItem> onOpen;

  static final _fmt = DateFormat('d MMM yyyy');

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Appointment Activity',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                TextButton(
                  onPressed: onViewAll,
                  child: const Text('View All →'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            if (loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (items.isEmpty)
              const EmptyState(
                icon: Icons.assignment_outlined,
                title: 'No appointment activity yet',
                body: 'Submitted appointment forms will appear here.',
              )
            else
              for (var i = 0; i < items.length; i++) ...[
                if (i > 0) Divider(color: tones.lineFaint, height: 1),
                _ActivityRow(
                  item: items[i],
                  dateLabel: _label(items[i].date),
                  onTap: () => onOpen(items[i]),
                ),
              ],
          ],
        ),
      ),
    );
  }

  String _label(DateTime? d) => d == null ? '—' : _fmt.format(d.toLocal());
}

class _ActivityRow extends StatelessWidget {
  const _ActivityRow({
    required this.item,
    required this.dateLabel,
    required this.onTap,
  });
  final AppointmentActivityItem item;
  final String dateLabel;
  final VoidCallback onTap;

  StatusChip _statusChip() {
    switch (item.workflowStatus) {
      case 'fully_signed':
        return const StatusChip(kind: StatusChipKind.complete, dense: true);
      case 'pending_signature':
        return StatusChip(
          kind: StatusChipKind.pending,
          label: item.currentSignatureRole != null
              ? 'Pending • ${item.currentSignatureRole}'
              : 'Pending',
          dense: true,
        );
      default:
        return const StatusChip(
          kind: StatusChipKind.doing,
          label: 'Submitted',
          dense: true,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.name,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  if (item.subtitle.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        item.subtitle,
                        style: TextStyle(
                          fontSize: 12,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  const SizedBox(height: 6),
                  _statusChip(),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  dateLabel,
                  style: TextStyle(
                    fontSize: 12,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 6),
                Icon(
                  Icons.chevron_right,
                  size: 18,
                  color: scheme.onSurfaceVariant,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
