import 'package:flutter/foundation.dart';

/// Session-scoped collapse state for the admin sidebar rail. Survives
/// navigation between admin-native screens (which rebuild AdminShell), so the
/// rail stays collapsed/expanded as the user moves around. Not persisted —
/// resets to expanded on app restart.
final ValueNotifier<bool> sidebarCollapsed = ValueNotifier<bool>(false);
