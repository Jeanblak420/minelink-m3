import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../theme/mol_tones.dart';
import 'mobile_app_info_dialog.dart';
import 'sidebar_state.dart';

/// True when [currentLocation] should highlight the item for [itemRoute].
bool isSidebarRouteActive(String itemRoute, String currentLocation) {
  if (itemRoute == '/') return currentLocation == '/';
  return currentLocation == itemRoute ||
      currentLocation.startsWith('$itemRoute/');
}

class SidebarLeaf {
  const SidebarLeaf(this.label, this.icon, this.route, {this.accent = 0});
  final String label;
  final IconData icon;
  final String route;
  final int accent;
}

class SidebarSection {
  const SidebarSection(this.label, this.icon, this.children, {this.accent = 0});
  final String label;
  final IconData icon;
  final List<SidebarLeaf> children;
  final int accent;
}

const _navItems = <Object>[
  SidebarLeaf('Dashboard', Icons.dashboard_outlined, '/', accent: 0),
  SidebarSection('Shiftboss Logbook', Icons.menu_book_outlined, [
    SidebarLeaf(
      'Combined View',
      Icons.dashboard_customize_outlined,
      '/current-logbook',
      accent: 1,
    ),
    SidebarLeaf(
      'Appointments',
      Icons.assignment_outlined,
      '/appointments',
      accent: 2,
    ),
    SidebarLeaf(
      'Daily Reports',
      Icons.today_outlined,
      '/reports/daily',
      accent: 3,
    ),
    SidebarLeaf(
      'Weekly Reports',
      Icons.date_range_outlined,
      '/reports/weekly',
      accent: 4,
    ),
    SidebarLeaf(
      'Monthly Reports',
      Icons.calendar_month_outlined,
      '/reports/monthly',
      accent: 5,
    ),
  ], accent: 1),
  SidebarSection('Templates', Icons.build_outlined, [
    SidebarLeaf(
      'Form Studio',
      Icons.auto_awesome_motion_outlined,
      '/templates/studio',
      accent: 6,
    ),
    SidebarLeaf(
      'Form Builder',
      Icons.dynamic_form_outlined,
      '/form-builder',
      accent: 6,
    ),
    SidebarLeaf(
      'Appointment Builder',
      Icons.settings_suggest_outlined,
      '/appointment-builder',
      accent: 7,
    ),
    SidebarLeaf(
      'Form Designer',
      Icons.design_services_outlined,
      '/form-designer',
      accent: 8,
    ),
  ], accent: 4),
  SidebarLeaf(
    'Report History',
    Icons.history_outlined,
    '/completed-logbook-history',
    accent: 8,
  ),
  SidebarLeaf(
    'Custom Forms',
    Icons.list_alt_outlined,
    '/custom-forms',
    accent: 9,
  ),
  SidebarLeaf(
    'My Appointments',
    Icons.how_to_reg_outlined,
    '/my-appointments',
    accent: 7,
  ),
  SidebarSection('Setup', Icons.tune_outlined, [
    SidebarLeaf(
      'User Management',
      Icons.group_outlined,
      '/profiles',
      accent: 10,
    ),
    SidebarLeaf(
      'Locations',
      Icons.place_outlined,
      '/setup/locations',
      accent: 11,
    ),
    SidebarLeaf('Gangs', Icons.groups_2_outlined, '/setup/gangs', accent: 0),
    SidebarLeaf(
      'Appointments',
      Icons.assignment_ind_outlined,
      '/setup/appointments',
      accent: 2,
    ),
    SidebarLeaf('Devices', Icons.devices_outlined, '/setup/devices', accent: 1),
    SidebarLeaf(
      'Audit Log',
      Icons.fact_check_outlined,
      '/setup/audit-log',
      accent: 3,
    ),
    SidebarLeaf(
      'Submission Review',
      Icons.rate_review_outlined,
      '/setup/submission-review',
      accent: 0,
    ),
    SidebarLeaf('Analytics', Icons.insights_outlined, '/analytics', accent: 2),
    SidebarLeaf(
      'Notifications',
      Icons.notifications_outlined,
      '/notifications',
      accent: 3,
    ),
    SidebarLeaf('Settings', Icons.settings_outlined, '/settings', accent: 4),
    SidebarLeaf('Admin Workspace', Icons.shield_outlined, '/admin', accent: 5),
  ], accent: 6),
];

/// Flattens the nav tree into an ordered list of leaves (used by the collapsed
/// rail, which shows every destination as an icon).
List<SidebarLeaf> _flatLeaves() {
  final out = <SidebarLeaf>[];
  for (final item in _navItems) {
    if (item is SidebarLeaf) {
      out.add(item);
    } else if (item is SidebarSection) {
      out.addAll(item.children);
    }
  }
  return out;
}

/// The sidebar's distinct, theme-aware background: a subtle primary tint over
/// the surface so it reads as a separate panel in light, dark, and custom.
Color sidebarBackground(ColorScheme scheme) =>
    Color.alphaBlend(scheme.primary.withValues(alpha: 0.07), scheme.surface);

class AdminSidebar extends StatelessWidget {
  const AdminSidebar({
    super.key,
    required this.location,
    this.collapsed = false,
    this.canCollapse = false,
  });

  final String location;

  /// When true the rail shows icons only (labels hidden). Only honoured on wide
  /// layouts; the mobile drawer is always expanded.
  final bool collapsed;

  /// Whether to show the collapse toggle (wide layout only).
  final bool canCollapse;

  void _go(BuildContext context, String route) {
    final nav = Navigator.of(context);
    if (nav.canPop()) nav.pop(); // close the drawer if we're in one
    if (route != location) context.go(route);
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;

    return Container(
      color: sidebarBackground(scheme),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header: brand label + collapse toggle.
          Padding(
            padding: EdgeInsets.fromLTRB(
              collapsed ? 8 : 20,
              16,
              collapsed ? 8 : 12,
              8,
            ),
            child: Row(
              mainAxisAlignment: collapsed
                  ? MainAxisAlignment.center
                  : MainAxisAlignment.spaceBetween,
              children: [
                if (!collapsed)
                  Text(
                    'Admin',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                if (canCollapse)
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    tooltip: collapsed ? 'Expand sidebar' : 'Collapse sidebar',
                    icon: Icon(
                      collapsed ? Icons.chevron_right : Icons.chevron_left,
                    ),
                    onPressed: () =>
                        sidebarCollapsed.value = !sidebarCollapsed.value,
                  ),
              ],
            ),
          ),
          Expanded(
            child: collapsed
                ? _CollapsedRail(
                    location: location,
                    onTap: (r) => _go(context, r),
                  )
                : ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    children: [
                      for (final item in _navItems)
                        if (item is SidebarLeaf)
                          _LeafTile(
                            leaf: item,
                            active: isSidebarRouteActive(item.route, location),
                            onTap: () => _go(context, item.route),
                          )
                        else if (item is SidebarSection)
                          _SectionTile(
                            section: item,
                            location: location,
                            onTapLeaf: (r) => _go(context, r),
                          ),
                      const SizedBox(height: 8),
                      Divider(color: tones.lineFaint, height: 1),
                      _LeafActionTile(
                        icon: Icons.download_outlined,
                        label: 'Download Mobile App',
                        color: scheme.primary,
                        onTap: () {
                          final nav = Navigator.of(context);
                          if (nav.canPop()) nav.pop();
                          showMobileAppInfo(context);
                        },
                      ),
                      _LeafActionTile(
                        icon: Icons.logout,
                        label: 'Logout',
                        color: scheme.error,
                        onTap: () => context.read<AuthProvider>().signOut(),
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
          ),
          if (collapsed) ...[
            Divider(color: tones.lineFaint, height: 1),
            _RailIconButton(
              icon: Icons.download_outlined,
              label: 'Download Mobile App',
              color: scheme.primary,
              active: false,
              onTap: () => showMobileAppInfo(context),
            ),
            _RailIconButton(
              icon: Icons.logout,
              label: 'Logout',
              color: scheme.error,
              active: false,
              onTap: () => context.read<AuthProvider>().signOut(),
            ),
            const SizedBox(height: 8),
          ],
        ],
      ),
    );
  }
}

class _CollapsedRail extends StatelessWidget {
  const _CollapsedRail({required this.location, required this.onTap});
  final String location;
  final void Function(String route) onTap;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final leaves = _flatLeaves();
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      children: [
        for (final leaf in leaves)
          _RailIconButton(
            icon: leaf.icon,
            label: leaf.label,
            color: primary,
            active: isSidebarRouteActive(leaf.route, location),
            onTap: () => onTap(leaf.route),
          ),
      ],
    );
  }
}

class _RailIconButton extends StatelessWidget {
  const _RailIconButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.active,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final Color color;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Tooltip(
        message: label,
        child: Material(
          color: active ? scheme.primaryContainer : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onTap,
            child: SizedBox(
              height: 48,
              child: Icon(
                icon,
                size: 22,
                color: active ? scheme.onPrimaryContainer : color,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LeafTile extends StatelessWidget {
  const _LeafTile({
    required this.leaf,
    required this.active,
    required this.onTap,
  });
  final SidebarLeaf leaf;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: active ? scheme.primaryContainer : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                Icon(
                  leaf.icon,
                  size: 20,
                  color: active ? scheme.onPrimaryContainer : scheme.primary,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    leaf.label,
                    style: TextStyle(
                      fontWeight: active ? FontWeight.w600 : FontWeight.w500,
                      color: active
                          ? scheme.onPrimaryContainer
                          : scheme.onSurface,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LeafActionTile extends StatelessWidget {
  const _LeafActionTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final iconColor = color ?? scheme.onSurface;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                Icon(icon, size: 20, color: iconColor),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: scheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionTile extends StatefulWidget {
  const _SectionTile({
    required this.section,
    required this.location,
    required this.onTapLeaf,
  });
  final SidebarSection section;
  final String location;
  final void Function(String route) onTapLeaf;

  @override
  State<_SectionTile> createState() => _SectionTileState();
}

class _SectionTileState extends State<_SectionTile> {
  late bool _open = widget.section.children.any(
    (l) => isSidebarRouteActive(l.route, widget.location),
  );

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => setState(() => _open = !_open),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 11,
                ),
                child: Row(
                  children: [
                    Icon(widget.section.icon, size: 20, color: scheme.primary),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        widget.section.label,
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                    Icon(
                      _open ? Icons.expand_less : Icons.expand_more,
                      size: 20,
                      color: scheme.onSurfaceVariant,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (_open)
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Column(
              children: [
                for (final leaf in widget.section.children)
                  _LeafTile(
                    leaf: leaf,
                    active: isSidebarRouteActive(leaf.route, widget.location),
                    onTap: () => widget.onTapLeaf(leaf.route),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
