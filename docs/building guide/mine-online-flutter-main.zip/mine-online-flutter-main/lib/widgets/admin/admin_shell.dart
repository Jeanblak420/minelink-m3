import 'package:flutter/material.dart';

import '../../theme/mol_tones.dart';
import '../app_bar_actions.dart';
import '../mobile_bottom_nav.dart';
import 'admin_sidebar.dart';
import 'sidebar_state.dart';

/// Responsive admin layout: a permanent sidebar on wide screens (≥1000 px),
/// a hamburger Drawer on narrow screens (keeping the app-wide bottom nav).
/// `child` is the page content; it manages its own scrolling.
class AdminShell extends StatelessWidget {
  const AdminShell({
    super.key,
    required this.location,
    required this.child,
    this.title = 'Mine Online',
  });

  final String location;
  final Widget child;
  final String title;

  static const sidebarBreakpoint = 1000.0;
  static const sidebarWidth = 260.0;
  static const sidebarRailWidth = 72.0;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    final wide = MediaQuery.of(context).size.width >= sidebarBreakpoint;

    if (wide) {
      return Scaffold(
        backgroundColor: scheme.surface,
        body: SafeArea(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ValueListenableBuilder<bool>(
                valueListenable: sidebarCollapsed,
                builder: (context, collapsed, _) {
                  final targetWidth = collapsed
                      ? sidebarRailWidth
                      : sidebarWidth;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeInOut,
                    width: targetWidth,
                    // Lay the sidebar out at its target width and clip while the
                    // container animates — otherwise full-width content is
                    // briefly squeezed into the narrow intermediate width during
                    // the expand animation and RenderFlex overflows.
                    child: ClipRect(
                      child: OverflowBox(
                        minWidth: targetWidth,
                        maxWidth: targetWidth,
                        alignment: Alignment.centerLeft,
                        child: AdminSidebar(
                          location: location,
                          collapsed: collapsed,
                          canCollapse: true,
                        ),
                      ),
                    ),
                  );
                },
              ),
              VerticalDivider(width: 1, color: tones.line),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: homeHeaderActions(),
                      ),
                    ),
                    Expanded(child: child),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: scheme.surface,
      appBar: AppBar(title: Text(title), actions: commonAppBarActions()),
      drawer: Drawer(
        child: SafeArea(child: AdminSidebar(location: location)),
      ),
      bottomNavigationBar: MobileBottomNav(location: location),
      body: SafeArea(child: child),
    );
  }
}
