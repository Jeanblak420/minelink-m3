// Inline approve/send-back bar rendered at the bottom of a chain form when
// it is opened in view mode AND the caller is the next pending signer.
//
// Wire it into every chain form with one line:
//
//   if (widget.viewArgs?.canSign ?? false)
//     FormSignActions(
//       viewArgs: widget.viewArgs!,
//       collectSignature: () => _padController.toPngBytes(),
//       onActionDone: (status) => Navigator.of(context).pop(status),
//     ),
//
// The form supplies a `collectSignature` closure that returns the bytes of
// the signer's signature (typically the form's own signature pad). The
// widget handles confirmation dialog, error surface, and snackbar.

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/form_view_args.dart';
import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/signature_workflow.dart';

class FormSignActions extends StatefulWidget {
  const FormSignActions({
    super.key,
    required this.viewArgs,
    this.collectSignature,
    this.onActionDone,
  });

  final FormViewArgs viewArgs;

  /// Returns the PNG bytes of the signature the caller wants applied. If
  /// null or returns null, the saved profile signature is used.
  final Future<Uint8List?> Function()? collectSignature;

  /// Called after a successful Approve or Send back with the resulting
  /// status ('approved' | 'sent_back'). Hosts typically pop the screen.
  final ValueChanged<String>? onActionDone;

  @override
  State<FormSignActions> createState() => _FormSignActionsState();
}

class _FormSignActionsState extends State<FormSignActions> {
  bool _busy = false;

  Future<void> _approve() async {
    final messenger = ScaffoldMessenger.of(context);
    final auth = context.read<AuthProvider>();
    final requestId = widget.viewArgs.requestId;
    if (requestId == null) return;

    setState(() => _busy = true);
    try {
      String signature = auth.profile?.signatureData ?? '';
      final bytes = await widget.collectSignature?.call();
      if (bytes != null && bytes.isNotEmpty) {
        signature = 'data:image/png;base64,${base64Encode(bytes)}';
      }
      if (signature.trim().isEmpty) {
        throw Exception(
          'Save a signature in My Profile or draw one before approving.',
        );
      }
      await signSignatureRequest(requestId, signature);
      messenger.showSnackBar(const SnackBar(
        content: Text('Approved. Forwarded to the next signer.'),
      ));
      widget.onActionDone?.call('approved');
    } catch (err) {
      if (!mounted) return;
      messenger.showSnackBar(SnackBar(content: Text('Approve failed: $err')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendBack() async {
    final messenger = ScaffoldMessenger.of(context);
    final requestId = widget.viewArgs.requestId;
    if (requestId == null) return;

    final reason = await _askForReason();
    if (reason == null) return;

    setState(() => _busy = true);
    try {
      await sendBackSignatureRequest(requestId, reason: reason);
      messenger.showSnackBar(const SnackBar(
        content: Text('Sent back to the previous signer.'),
      ));
      widget.onActionDone?.call('sent_back');
    } catch (err) {
      if (!mounted) return;
      messenger.showSnackBar(SnackBar(content: Text('Send back failed: $err')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _askForReason() async {
    final controller = TextEditingController();
    final tones = MolTones.of(context);
    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Send back for changes'),
          content: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Tell the previous signer what needs to change. The '
                  'submitter and the previous signer will both be notified.',
                  style: TextStyle(color: tones.fg3),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: controller,
                  autofocus: true,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    hintText: 'Reason (optional)',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton.icon(
              icon: const Icon(Icons.undo),
              label: const Text('Send back'),
              style: FilledButton.styleFrom(
                backgroundColor: tones.danger.accent,
                foregroundColor: Colors.white,
              ),
              onPressed: () =>
                  Navigator.of(dialogContext).pop(controller.text),
            ),
          ],
        );
      },
    );
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final role = widget.viewArgs.currentSignerRole ?? 'You';

    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: tones.warning.tint,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: tones.warning.accent.withValues(alpha: 0.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.draw_outlined, color: tones.warning.accent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '$role signature required',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: scheme.onSurface,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            "Tap Approve & forward to apply your signature and move the document "
            "to the next step, or Send back to bounce it to the previous "
            "signer with a note.",
            style: TextStyle(fontSize: 13, color: tones.fg3, height: 1.4),
          ),
          const SizedBox(height: 12),
          Wrap(
            alignment: WrapAlignment.end,
            spacing: 12,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: _busy ? null : _sendBack,
                icon: const Icon(Icons.undo_outlined),
                label: const Text('Send back'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: tones.danger.accent,
                  side: BorderSide(color: tones.danger.accent),
                ),
              ),
              FilledButton.icon(
                onPressed: _busy ? null : _approve,
                icon: _busy
                    ? const SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.check),
                label: const Text('Approve & forward'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
