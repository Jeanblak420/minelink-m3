// Tracks online presence by polling the `user_presence` Supabase table.
// Mirrors the logic in src/components/UserProfiles.tsx lines 36 + 221-234:
// a user is "online" if `last_seen_at` is within 2 minutes of now.

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../config/supabase_client.dart';

class UserPresenceTracker extends ChangeNotifier {
  UserPresenceTracker();

  static const Duration onlineThreshold = Duration(minutes: 2);

  Map<String, DateTime> _lastSeen = const {};
  Timer? _ticker;

  Map<String, DateTime> get lastSeen => _lastSeen;

  bool isOnline(String userId) {
    final ts = _lastSeen[userId];
    if (ts == null) return false;
    return DateTime.now().difference(ts) < onlineThreshold;
  }

  Future<void> start() async {
    await _refresh();
    _ticker ??= Timer.periodic(const Duration(seconds: 30), (_) => _refresh());
  }

  Future<void> _refresh() async {
    try {
      final rows = await supabase
          .from('user_presence')
          .select('user_id, last_seen_at');
      final map = <String, DateTime>{};
      for (final row in (rows as List).cast<Map<String, dynamic>>()) {
        final id = row['user_id'] as String?;
        final lastStr = row['last_seen_at'] as String?;
        if (id == null || lastStr == null) continue;
        final parsed = DateTime.tryParse(lastStr);
        if (parsed != null) map[id] = parsed;
      }
      _lastSeen = map;
      notifyListeners();
    } catch (_) {
      // Swallow — table may not exist on first deploy.
    }
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
