// Center page content with a sensible max-width on wide screens so the
// Windows full-screen build doesn't feel left-aligned. Mobile is unaffected
// because narrow screens never reach the cap.
//
// Use the right preset for the kind of screen:
//   PageBody.list(...)     — 1080 px (home, appointments, current logbook,
//                            notifications, profiles, signature requests,
//                            completed logbook, admin, etc.)
//   PageBody.form(...)     — 720 px (settings, every form screen, my profile)
//   PageBody.auth(...)     — 440 px (login)
//   PageBody.wide(...)     — 1180 px (todos screen, anything that wants a
//                            roomier grid)
//
// Mirrors mine-online-design-system/README.md "Layout rules":
//   "Max content width 1080 px on home / list screens.
//    Max card width 720 px on settings / single-form screens.
//    Max auth card width 440 px on login."

import 'package:flutter/material.dart';

class PageBody extends StatelessWidget {
  const PageBody({
    super.key,
    required this.child,
    this.maxWidth = 1080,
    this.padding,
    this.scrollable = false,
  });

  factory PageBody.list({
    Key? key,
    required Widget child,
    EdgeInsetsGeometry? padding,
    bool scrollable = false,
  }) => PageBody(
    key: key,
    maxWidth: 1080,
    padding: padding,
    scrollable: scrollable,
    child: child,
  );

  factory PageBody.form({
    Key? key,
    required Widget child,
    EdgeInsetsGeometry? padding,
    bool scrollable = false,
  }) => PageBody(
    key: key,
    maxWidth: 720,
    padding: padding,
    scrollable: scrollable,
    child: child,
  );

  factory PageBody.auth({
    Key? key,
    required Widget child,
    EdgeInsetsGeometry? padding,
    bool scrollable = false,
  }) => PageBody(
    key: key,
    maxWidth: 440,
    padding: padding,
    scrollable: scrollable,
    child: child,
  );

  factory PageBody.wide({
    Key? key,
    required Widget child,
    EdgeInsetsGeometry? padding,
    bool scrollable = false,
  }) => PageBody(
    key: key,
    maxWidth: 1180,
    padding: padding,
    scrollable: scrollable,
    child: child,
  );

  final Widget child;
  final double maxWidth;
  final EdgeInsetsGeometry? padding;

  /// When true, the content scrolls vertically (for screens whose body is a
  /// non-scrolling Column of intrinsic-height content). PageBody otherwise only
  /// constrains width + centres, so a tall non-scrolling child would overflow.
  final bool scrollable;

  @override
  Widget build(BuildContext context) {
    if (scrollable) {
      return SingleChildScrollView(
        padding: padding,
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxWidth),
            child: child,
          ),
        ),
      );
    }
    Widget content = Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
    if (padding != null) {
      content = Padding(padding: padding!, child: content);
    }
    return content;
  }
}
