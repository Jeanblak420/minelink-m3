// Three reusable pill components. All share the same soft-tone bg + dark-fg
// shape (Container with 9999 radius, 0.4 letter-spacing, uppercase text).
// Centralised so logbook rows, notification cards, todos and the profiles
// table all draw from the same source.

import 'package:flutter/material.dart';

import '../theme/mol_tones.dart';

enum StatusChipKind { planned, doing, done, complete, pending }

class StatusChip extends StatelessWidget {
  const StatusChip({
    super.key,
    required this.kind,
    this.label,
    this.icon,
    this.dense = false,
  });

  final StatusChipKind kind;
  final String? label;
  final IconData? icon;
  final bool dense;

  ({MolTone tone, IconData icon, String label}) _resolve(MolTones tones) {
    switch (kind) {
      case StatusChipKind.planned:
      case StatusChipKind.pending:
        return (
          tone: tones.info,
          icon: icon ?? Icons.pending_outlined,
          label: label ?? 'Planned',
        );
      case StatusChipKind.doing:
        return (
          tone: tones.warning,
          icon: icon ?? Icons.play_circle_outline,
          label: label ?? 'In Progress',
        );
      case StatusChipKind.done:
      case StatusChipKind.complete:
        return (
          tone: tones.success,
          icon: icon ?? Icons.check_circle_outline,
          label: label ?? (kind == StatusChipKind.complete ? 'Complete' : 'Done'),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final r = _resolve(tones);
    return _Pill(
      tone: r.tone,
      icon: r.icon,
      label: r.label,
      dense: dense,
    );
  }
}

enum UrgencyChipKind { asap, whenever, meeting }

class UrgencyChip extends StatelessWidget {
  const UrgencyChip({super.key, required this.kind, this.dense = false});

  final UrgencyChipKind kind;
  final bool dense;

  ({MolTone tone, String label}) _resolve(MolTones tones) {
    switch (kind) {
      case UrgencyChipKind.asap:
        return (tone: tones.danger, label: 'ASAP');
      case UrgencyChipKind.whenever:
        return (tone: tones.info, label: 'WHEN READY');
      case UrgencyChipKind.meeting:
        return (tone: tones.warning, label: 'NEXT MEETING');
    }
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final r = _resolve(tones);
    return _Pill(tone: r.tone, label: r.label, dense: dense);
  }
}

class RolePill extends StatelessWidget {
  const RolePill({super.key, required this.role, this.dense = false});

  final String role;
  final bool dense;

  MolTone _toneFor(MolTones tones) {
    final r = role.toLowerCase();
    if (r.contains('super')) return tones.danger;
    if (r.contains('admin')) return tones.info;
    if (r.contains('manager')) return tones.warning;
    if (r.contains('overseer')) return tones.warning;
    if (r.contains('shift boss')) return tones.success;
    return tones.info;
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return _Pill(tone: _toneFor(tones), label: role, dense: dense);
  }
}

class _Pill extends StatelessWidget {
  const _Pill({
    required this.tone,
    required this.label,
    this.icon,
    this.dense = false,
  });

  final MolTone tone;
  final String label;
  final IconData? icon;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: dense ? 8 : 10,
        vertical: dense ? 3 : 4,
      ),
      decoration: BoxDecoration(
        color: tone.soft,
        borderRadius: BorderRadius.circular(9999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: dense ? 12 : 14, color: tone.fg),
            SizedBox(width: dense ? 4 : 6),
          ],
          Text(
            label.toUpperCase(),
            style: TextStyle(
              fontSize: dense ? 10 : 11,
              fontWeight: FontWeight.w600,
              color: tone.fg,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
    );
  }
}
