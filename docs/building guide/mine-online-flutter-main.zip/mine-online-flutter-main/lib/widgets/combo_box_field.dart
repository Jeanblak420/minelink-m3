// Combo-box / autocomplete field. Mirrors src/components/ui/ComboBox.tsx:
// case-insensitive substring match, prefix-match priority, "Add: <value>"
// affordance when the typed text doesn't match an existing option and
// `allowCustom` is true. `onAddOption` is called once when the user actually
// adds a new value (so the parent can push it into its in-memory options list).
//
// The component is "committed" in two ways: every keystroke updates the value
// via `onChanged`, AND tapping an option (or the Add tile) also commits.

import 'package:flutter/material.dart';

class ComboBoxField extends StatefulWidget {
  const ComboBoxField({
    super.key,
    required this.label,
    required this.value,
    required this.options,
    required this.onChanged,
    this.hintText,
    this.allowCustom = true,
    this.onAddOption,
    this.enabled = true,
  });

  final String label;
  final String? hintText;
  final String value;
  final List<String> options;
  final bool allowCustom;
  final ValueChanged<String> onChanged;
  final ValueChanged<String>? onAddOption;
  final bool enabled;

  @override
  State<ComboBoxField> createState() => _ComboBoxFieldState();
}

class _ComboBoxFieldState extends State<ComboBoxField> {
  final FocusNode _focusNode = FocusNode();
  late final TextEditingController _controller;
  final LayerLink _link = LayerLink();
  OverlayEntry? _overlay;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.value);
    _focusNode.addListener(_onFocusChange);
  }

  @override
  void didUpdateWidget(covariant ComboBoxField old) {
    super.didUpdateWidget(old);
    if (old.value != widget.value && _controller.text != widget.value) {
      _controller.text = widget.value;
    }
  }

  @override
  void dispose() {
    _hide();
    _focusNode.removeListener(_onFocusChange);
    _focusNode.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _onFocusChange() {
    if (_focusNode.hasFocus) {
      _show();
    } else {
      _hide();
    }
  }

  void _show() {
    if (!widget.enabled) return;
    _hide();
    final overlay = Overlay.of(context, rootOverlay: true);
    _overlay = OverlayEntry(
      builder: (ctx) {
        final renderBox = context.findRenderObject() as RenderBox?;
        final size = renderBox?.size ?? const Size(280, 56);
        return Positioned(
          width: size.width,
          child: CompositedTransformFollower(
            link: _link,
            showWhenUnlinked: false,
            offset: Offset(0, size.height + 2),
            child: Material(
              elevation: 4,
              borderRadius: BorderRadius.circular(12),
              clipBehavior: Clip.antiAlias,
              child: _OptionsList(
                controller: _controller,
                allOptions: widget.options,
                allowCustom: widget.allowCustom,
                onSelect: (value, isNew) {
                  _controller.value = TextEditingValue(
                    text: value,
                    selection: TextSelection.collapsed(offset: value.length),
                  );
                  widget.onChanged(value);
                  if (isNew && widget.onAddOption != null) {
                    widget.onAddOption!(value);
                  }
                  _focusNode.unfocus();
                },
              ),
            ),
          ),
        );
      },
    );
    overlay.insert(_overlay!);
  }

  void _hide() {
    _overlay?.remove();
    _overlay = null;
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _link,
      child: TextField(
        controller: _controller,
        focusNode: _focusNode,
        enabled: widget.enabled,
        decoration: InputDecoration(
          labelText: widget.label,
          hintText: widget.hintText,
          suffixIcon: const Icon(Icons.arrow_drop_down),
        ),
        onChanged: (v) {
          widget.onChanged(v);
          _overlay?.markNeedsBuild();
        },
        onSubmitted: (v) {
          final trimmed = v.trim();
          if (trimmed.isEmpty) return;
          final match = _firstMatch(widget.options, trimmed);
          if (match != null) {
            _controller.text = match;
            widget.onChanged(match);
          } else if (widget.allowCustom) {
            widget.onChanged(trimmed);
            widget.onAddOption?.call(trimmed);
          }
          _focusNode.unfocus();
        },
      ),
    );
  }
}

class _OptionsList extends StatefulWidget {
  const _OptionsList({
    required this.controller,
    required this.allOptions,
    required this.allowCustom,
    required this.onSelect,
  });

  final TextEditingController controller;
  final List<String> allOptions;
  final bool allowCustom;
  final void Function(String value, bool isNew) onSelect;

  @override
  State<_OptionsList> createState() => _OptionsListState();
}

class _OptionsListState extends State<_OptionsList> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_listen);
  }

  void _listen() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    widget.controller.removeListener(_listen);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = widget.controller.text.trim().toLowerCase();
    final filtered = _filter(widget.allOptions, query);
    final exactMatch =
        filtered.any((o) => o.toLowerCase() == query) || query.isEmpty;
    final showAdd = widget.allowCustom && !exactMatch && query.isNotEmpty;

    if (filtered.isEmpty && !showAdd) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Text('No matches',
            style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant)),
      );
    }
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 240),
      child: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        children: [
          for (final opt in filtered.take(50))
            InkWell(
              onTap: () => widget.onSelect(opt, false),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                child: Text(opt),
              ),
            ),
          if (showAdd)
            InkWell(
              onTap: () =>
                  widget.onSelect(widget.controller.text.trim(), true),
              child: Container(
                color: Theme.of(context).colorScheme.surfaceContainerHigh,
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                child: Row(
                  children: [
                    const Icon(Icons.add, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Text(
                            'Add: ${widget.controller.text.trim()}',
                            overflow: TextOverflow.ellipsis)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

List<String> _filter(List<String> options, String query) {
  if (query.isEmpty) return options;
  final prefix = <String>[];
  final substring = <String>[];
  for (final o in options) {
    final lower = o.toLowerCase();
    if (lower.startsWith(query)) {
      prefix.add(o);
    } else if (lower.contains(query)) {
      substring.add(o);
    }
  }
  return [...prefix, ...substring];
}

String? _firstMatch(List<String> options, String query) {
  final q = query.toLowerCase();
  for (final o in options) {
    if (o.toLowerCase() == q) return o;
  }
  for (final o in options) {
    if (o.toLowerCase().startsWith(q)) return o;
  }
  return null;
}
