// Mirrors src/components/NotificationBell.tsx — bell IconButton with a Badge
// over it showing the unread count (capped at "9+"). Routes to /notifications
// on tap. Hidden when the user's account_type is not in the
// notification-enabled set, matching the web behaviour.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../constants/account_types.dart';
import '../providers/auth_provider.dart';
import '../providers/notifications_provider.dart';
import '../utils/role_access.dart';

class NotificationBell extends StatelessWidget {
  const NotificationBell({super.key});

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<AuthProvider>().profile;
    final accountType = profile?.userAccountType;
    final enabled = (accountType != null &&
            kNotificationEnabledAccountTypes.contains(accountType)) ||
        isAdminProfile(profile) ||
        isShiftBossProfile(profile) ||
        isMineOverseerProfile(profile) ||
        isMineManagerProfile(profile);
    if (!enabled) return const SizedBox.shrink();

    final unread = context.watch<NotificationsProvider>().unreadCount;
    final label = unread > 9 ? '9+' : '$unread';

    return IconButton(
      tooltip: 'Notifications',
      onPressed: () => context.go('/notifications'),
      icon: unread > 0
          ? Badge(
              label: Text(label),
              backgroundColor: Theme.of(context).colorScheme.error,
              textColor: Theme.of(context).colorScheme.onError,
              child: const Icon(Icons.notifications_outlined),
            )
          : const Icon(Icons.notifications_none_outlined),
    );
  }
}
