import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:signature/signature.dart';

/// Captured-stroke export pixel ratio. The `signature` package's default
/// `toPngBytes()` renders at the stroke bounding-box's logical size (~400 ×
/// 80 px for a typical signature), which looks acceptable on screen but
/// becomes blurry when stretched into a PDF signature cell. We re-render
/// the captured strokes onto a `pixelRatio`-larger canvas so the embedded
/// PNG holds detail even after the PDF stretches it.
const double _signatureExportPixelRatio = 4.0;

/// Re-renders `controller.points` onto a canvas scaled by [pixelRatio] and
/// returns the resulting PNG. Mirrors the `signature` package's internal
/// `_SignaturePainter` using only public APIs (`pointsToStrokes`,
/// `penStrokeWidth`, `strokeCap`, `strokeJoin`, `penColor`, `minXValue`,
/// `minYValue`, `defaultWidth`, `defaultHeight`).
Future<Uint8List?> exportHighResSignaturePng(
  SignatureController controller, {
  double pixelRatio = _signatureExportPixelRatio,
}) async {
  if (controller.isEmpty) return null;
  final logicalWidth = controller.defaultWidth;
  final logicalHeight = controller.defaultHeight;
  if (logicalWidth == null ||
      logicalHeight == null ||
      logicalWidth <= 0 ||
      logicalHeight <= 0) {
    return null;
  }

  final pixelWidth = (logicalWidth * pixelRatio).ceil();
  final pixelHeight = (logicalHeight * pixelRatio).ceil();
  final recorder = ui.PictureRecorder();
  final canvas = ui.Canvas(
    recorder,
    Rect.fromLTWH(0, 0, pixelWidth.toDouble(), pixelHeight.toDouble()),
  );

  // Opaque white background — matches `exportBackgroundColor: Colors.white`.
  canvas.drawRect(
    Rect.fromLTWH(0, 0, pixelWidth.toDouble(), pixelHeight.toDouble()),
    Paint()..color = Colors.white,
  );

  // Scale up by `pixelRatio`, then translate so the stroke bounding box
  // starts at (penStrokeWidth, penStrokeWidth) in logical pixels. This
  // matches the translation the package applies in `toImage`.
  canvas.scale(pixelRatio);
  canvas.translate(
    -(controller.minXValue! - controller.penStrokeWidth),
    -(controller.minYValue! - controller.penStrokeWidth),
  );

  final strokePaint = Paint()
    ..color = controller.penColor
    ..strokeCap = controller.strokeCap
    ..strokeJoin = controller.strokeJoin
    ..isAntiAlias = true
    ..style = PaintingStyle.stroke;
  final dotPaint = Paint()
    ..color = controller.penColor
    ..isAntiAlias = true
    ..style = PaintingStyle.fill;

  final strokes = controller.pointsToStrokes(3);
  for (final stroke in strokes) {
    if (stroke.length > 1) {
      for (var i = 0; i < stroke.length - 1; i++) {
        strokePaint.strokeWidth =
            controller.penStrokeWidth * stroke[i].pressure;
        canvas.drawLine(stroke[i].offset, stroke[i + 1].offset, strokePaint);
      }
    } else {
      final p = stroke.first;
      canvas.drawCircle(
        p.offset,
        (controller.penStrokeWidth / 2) * p.pressure,
        dotPaint,
      );
    }
  }

  final picture = recorder.endRecording();
  final image = await picture.toImage(pixelWidth, pixelHeight);
  final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
  picture.dispose();
  image.dispose();
  return byteData?.buffer.asUint8List();
}

/// Wraps the `signature` package to produce a PNG data URL identical in shape
/// to the web app's `SignatureCanvas` (`data:image/png;base64,...`).
class SignatureCanvasField extends StatefulWidget {
  const SignatureCanvasField({
    super.key,
    required this.value,
    required this.onChanged,
    this.label = 'Signature',
    this.readOnly = false,
  });

  final String value;
  final ValueChanged<String> onChanged;
  final String label;
  final bool readOnly;

  @override
  State<SignatureCanvasField> createState() => _SignatureCanvasFieldState();
}

class _SignatureCanvasFieldState extends State<SignatureCanvasField> {
  late final SignatureController _controller;

  @override
  void initState() {
    super.initState();
    _controller = SignatureController(
      penStrokeWidth: 2,
      penColor: Colors.black,
      exportBackgroundColor: Colors.white,
    );
    _controller.addListener(_emit);
  }

  Future<void> _emit() async {
    if (widget.readOnly) return;
    if (_controller.isEmpty) {
      widget.onChanged('');
      return;
    }
    final Uint8List? bytes = await exportHighResSignaturePng(_controller);
    if (bytes == null) return;
    widget.onChanged('data:image/png;base64,${base64Encode(bytes)}');
  }

  @override
  void dispose() {
    _controller.removeListener(_emit);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hasSignature = widget.value.isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.label.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(
              widget.label,
              style: Theme.of(context).textTheme.labelLarge,
            ),
          ),
        Container(
          height: 130,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: scheme.outlineVariant),
            borderRadius: BorderRadius.circular(8),
          ),
          clipBehavior: Clip.antiAlias,
          child: widget.readOnly && hasSignature
              ? _RenderedSignature(dataUrl: widget.value)
              : widget.readOnly
                  ? Center(
                      child: Text(
                        'Signature not yet captured',
                        style: TextStyle(color: scheme.onSurfaceVariant),
                      ),
                    )
                  : Signature(
                      controller: _controller,
                      backgroundColor: Colors.white,
                    ),
        ),
        if (!widget.readOnly)
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () {
                _controller.clear();
                widget.onChanged('');
              },
              icon: const Icon(Icons.refresh, size: 18),
              label: const Text('Clear'),
            ),
          ),
      ],
    );
  }
}

class _RenderedSignature extends StatelessWidget {
  const _RenderedSignature({required this.dataUrl});
  final String dataUrl;

  @override
  Widget build(BuildContext context) {
    if (!dataUrl.startsWith('data:image')) {
      return Center(child: Text(dataUrl));
    }
    final base64Part = dataUrl.split(',').last;
    final bytes = base64Decode(base64Part);
    return Image.memory(bytes, fit: BoxFit.contain);
  }
}
