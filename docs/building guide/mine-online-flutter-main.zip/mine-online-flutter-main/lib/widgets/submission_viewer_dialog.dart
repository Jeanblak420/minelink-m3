// Mirrors src/components/SubmissionViewerModal.tsx — a dialog that opens when
// a user taps a row in their current logbook or an admin taps a row in the
// admin logbook. Renders the form in view mode and exposes a "Download PDF"
// button. Falls back to a raw-JSON pane if the form_type is unknown.
//
// We rely on each form screen to handle its own view-mode rendering (disable
// inputs, hide action buttons) so the dialog can let the form's own
// SingleChildScrollView take scroll gestures normally — wrapping the form in
// AbsorbPointer here would kill the scroll.

import 'dart:convert';

import 'package:flutter/material.dart';

import '../models/form_view_args.dart';
import '../utils/form_registry.dart';
import '../utils/pdf_download.dart';

class SubmissionViewerDialog extends StatefulWidget {
  const SubmissionViewerDialog({super.key, required this.row});

  final Map<String, dynamic> row;

  @override
  State<SubmissionViewerDialog> createState() => _SubmissionViewerDialogState();
}

class _SubmissionViewerDialogState extends State<SubmissionViewerDialog> {
  bool _downloading = false;
  String? _downloadError;
  String? _downloadSuccess;

  String get _formType => widget.row['form_type'] as String? ?? '';
  String get _title => widget.row['title'] as String? ?? 'Submission';
  Map<String, dynamic> get _payload =>
      (widget.row['payload'] as Map<String, dynamic>?) ?? const {};

  String _statusLabel() {
    final status = widget.row['workflow_status'] as String?;
    final role = widget.row['current_signature_role'] as String?;
    if (status == 'fully_signed') return 'Fully signed';
    if (status == 'pending_signature' && role != null && role.isNotEmpty) {
      return 'Pending: $role';
    }
    if (status == null || status.isEmpty) return 'Saved';
    return 'Submitted';
  }

  Future<void> _download() async {
    setState(() {
      _downloading = true;
      _downloadError = null;
      _downloadSuccess = null;
    });
    try {
      final doc = await generatePdfForFormType(_formType, _payload);
      if (doc == null) {
        setState(() =>
            _downloadError = 'PDF generator not available for this form.');
        return;
      }
      final bytes = await doc.save();
      if (!mounted) return;
      final result = await savePdfBytes(bytes: bytes, suggestedName: _title);
      if (!mounted) return;
      if (result.error != null) {
        setState(() => _downloadError = result.error);
      } else if (result.saved) {
        setState(() => _downloadSuccess = 'Saved to ${result.path}');
      }
    } catch (err) {
      if (mounted) setState(() => _downloadError = err.toString());
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final formWidget = buildFormView(
      _formType,
      FormViewArgs(mode: FormMode.view, initialPayload: _payload),
    );
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1080, maxHeight: 800),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 12, 16),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: scheme.outlineVariant),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_title,
                            style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 4),
                        Text('$_formType · ${_statusLabel()}',
                            style: TextStyle(
                                color: scheme.onSurfaceVariant, fontSize: 12)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  if (formWidget != null)
                    FilledButton.icon(
                      onPressed: _downloading ? null : _download,
                      icon: const Icon(Icons.download_outlined),
                      label: Text(_downloading ? 'Preparing...' : 'Download PDF'),
                    ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                    tooltip: 'Close',
                  ),
                ],
              ),
            ),
            if (_downloadError != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                child: Text(_downloadError!,
                    style: TextStyle(color: scheme.error)),
              ),
            if (_downloadSuccess != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                child: Text(_downloadSuccess!,
                    style: TextStyle(color: scheme.primary)),
              ),
            Expanded(
              child: formWidget ??
                  Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "The visual form for this submission isn't "
                            'registered in-app yet — payload shown below.',
                            style:
                                TextStyle(color: scheme.onSurfaceVariant),
                          ),
                          const SizedBox(height: 12),
                          Expanded(
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: scheme.surfaceContainerHigh,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: SingleChildScrollView(
                                child: SelectableText(
                                  const JsonEncoder.withIndent('  ')
                                      .convert(_payload),
                                  style: const TextStyle(
                                      fontFamily: 'monospace', fontSize: 12),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
