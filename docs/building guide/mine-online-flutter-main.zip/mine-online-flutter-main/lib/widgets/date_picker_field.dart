import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// Mirrors src/components/ui/DatePicker.tsx — value stored as DD/MM/YYYY.
class DatePickerField extends StatelessWidget {
  const DatePickerField({
    super.key,
    required this.value,
    required this.onChanged,
    this.label,
    this.disabled = false,
  });

  final String value;
  final ValueChanged<String> onChanged;
  final String? label;
  final bool disabled;

  static final _format = DateFormat('dd/MM/yyyy');

  DateTime? get _parsed {
    if (value.isEmpty) return null;
    try {
      return _format.parseStrict(value);
    } catch (_) {
      return null;
    }
  }

  Future<void> _pick(BuildContext context) async {
    final now = DateTime.now();
    final initial = _parsed ?? now;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
    );
    if (picked != null) {
      onChanged(_format.format(picked));
    }
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      readOnly: true,
      enabled: !disabled,
      controller: TextEditingController(text: value),
      decoration: InputDecoration(
        labelText: label ?? 'Date',
        hintText: 'DD/MM/YYYY',
        suffixIcon: const Icon(Icons.calendar_today_outlined),
      ),
      onTap: disabled ? null : () => _pick(context),
    );
  }
}
