import 'package:flutter/material.dart';

import '../theme/mol_tones.dart';

/// Status of one step in the signature chain.
enum SignatureStepStatus {
  /// Signed (filled check icon, success tone).
  signed,

  /// Currently active — this is the signer the workflow is waiting on
  /// (edit icon, warning tone).
  active,

  /// Not yet reached (outline pending icon, muted tone).
  pending,
}

class SignatureStep {
  const SignatureStep({
    required this.label,
    required this.status,
    this.subtitle,
  });

  final String label;
  final String? subtitle;
  final SignatureStepStatus status;
}

/// Compact 3-step pill chain — Shift Boss → Mine Overseer → Mine Manager.
/// Drop into Current Logbook rows + the form view-mode header to give a
/// one-glance read of who has signed and who's next.
class SignatureChain extends StatelessWidget {
  const SignatureChain({
    super.key,
    required this.steps,
    this.dense = false,
  });

  final List<SignatureStep> steps;

  /// When true, hides subtitles and reduces padding — fits inside a logbook
  /// row. When false, more breathing room for the form-view header.
  final bool dense;

  /// Convenience: build a 3-step chain from a form_submissions row.
  /// `workflowStatus` is one of (production): 'pending_signature',
  /// 'fully_signed', null. `currentSignatureRole` (set when status is
  /// 'pending_signature') is one of 'Mine Overseer' / 'Mine Manager'.
  /// Anything else falls back to all-pending.
  static SignatureChain fromWorkflowStatus(
    String? workflowStatus, {
    String? currentSignatureRole,
    bool dense = false,
  }) {
    final s = workflowStatus ?? '';
    final role = currentSignatureRole ?? '';
    SignatureStepStatus shiftBoss;
    SignatureStepStatus mineOverseer;
    SignatureStepStatus mineManager;
    if (s == 'fully_signed' ||
        s == 'complete' ||
        s == 'mine_manager_signed') {
      shiftBoss = SignatureStepStatus.signed;
      mineOverseer = SignatureStepStatus.signed;
      mineManager = SignatureStepStatus.signed;
    } else if (s == 'pending_signature') {
      shiftBoss = SignatureStepStatus.signed;
      if (role.contains('Manager') ||
          s == 'awaiting_manager' ||
          s == 'pending_mine_manager') {
        mineOverseer = SignatureStepStatus.signed;
        mineManager = SignatureStepStatus.active;
      } else {
        mineOverseer = SignatureStepStatus.active;
        mineManager = SignatureStepStatus.pending;
      }
    } else if (s == 'mine_overseer_signed' ||
        s == 'awaiting_manager' ||
        s == 'pending_mine_manager') {
      shiftBoss = SignatureStepStatus.signed;
      mineOverseer = SignatureStepStatus.signed;
      mineManager = SignatureStepStatus.active;
    } else if (s == 'shift_boss_signed' || s == 'pending_mine_overseer') {
      shiftBoss = SignatureStepStatus.signed;
      mineOverseer = SignatureStepStatus.active;
      mineManager = SignatureStepStatus.pending;
    } else {
      shiftBoss = SignatureStepStatus.pending;
      mineOverseer = SignatureStepStatus.pending;
      mineManager = SignatureStepStatus.pending;
    }
    return SignatureChain(
      dense: dense,
      steps: [
        SignatureStep(label: 'Shift Boss', status: shiftBoss),
        SignatureStep(label: 'Mine Overseer', status: mineOverseer),
        SignatureStep(label: 'Mine Manager', status: mineManager),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < steps.length; i++) ...[
          if (i > 0) _Connector(dense: dense, tones: tones),
          _StepPill(step: steps[i], tones: tones, dense: dense),
        ],
      ],
    );
  }
}

class _StepPill extends StatelessWidget {
  const _StepPill({
    required this.step,
    required this.tones,
    required this.dense,
  });

  final SignatureStep step;
  final MolTones tones;
  final bool dense;

  ({IconData icon, MolTone tone}) _iconAndTone() {
    switch (step.status) {
      case SignatureStepStatus.signed:
        return (icon: Icons.check_circle, tone: tones.success);
      case SignatureStepStatus.active:
        return (icon: Icons.edit_outlined, tone: tones.warning);
      case SignatureStepStatus.pending:
        return (icon: Icons.radio_button_unchecked, tone: tones.info);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final it = _iconAndTone();
    final muted = step.status == SignatureStepStatus.pending;
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: dense ? 8 : 10,
        vertical: dense ? 4 : 6,
      ),
      decoration: BoxDecoration(
        color: muted ? tones.bgSunken : it.tone.soft,
        borderRadius: BorderRadius.circular(9999),
        border: Border.all(
          color: muted ? tones.line : it.tone.accent.withValues(alpha: 0.4),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(it.icon, size: dense ? 12 : 14, color: it.tone.accent),
          SizedBox(width: dense ? 4 : 6),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                step.label,
                style: TextStyle(
                  fontSize: dense ? 10 : 11,
                  fontWeight: FontWeight.w600,
                  color: muted ? tones.fg3 : it.tone.fg,
                  letterSpacing: 0.3,
                ),
              ),
              if (!dense && (step.subtitle ?? '').isNotEmpty)
                Text(
                  step.subtitle!,
                  style: TextStyle(
                    fontSize: 10,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Connector extends StatelessWidget {
  const _Connector({required this.dense, required this.tones});
  final bool dense;
  final MolTones tones;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: dense ? 4 : 6),
      child: Container(
        width: dense ? 12 : 18,
        height: 1.5,
        color: tones.line,
      ),
    );
  }
}
