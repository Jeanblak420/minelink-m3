// Mirrors src/components/AdminDashboard.tsx — 10 cards.

import 'package:flutter/material.dart';

import 'dashboard_card.dart';

const _cards = <DashboardCardData>[
  DashboardCardData(
      route: '/appointment-history-logs',
      icon: Icons.assignment_outlined,
      title: 'Appointment History Logs',
      description: 'View individual Shift Boss appointment history'),
  DashboardCardData(
      route: '/active-individual-current-logbook',
      icon: Icons.checklist_outlined,
      title: 'Active Individual Current Logbook',
      description:
          "View the active current logbook an individual Shift Boss is busy with, including live progress."),
  DashboardCardData(
      route: '/individual-completed-logbook-history',
      icon: Icons.history_outlined,
      title: "Individuals' Past Completed Logbook History",
      description:
          "View individual Shift Boss's logbook history, trace incomplete required sections, and discover repeating patterns."),
  DashboardCardData(
      route: '/logbook-version-management',
      icon: Icons.edit_outlined,
      title: 'Logbook Version Management',
      description:
          'Review, edit, add, change, and update logbook versions, version history, and logbook sections.'),
  DashboardCardData(
      route: '/send-notifications-reminders',
      icon: Icons.send_outlined,
      title: 'Send Notifications and Reminders',
      description:
          'Prepare and send notifications or reminders to users when notification rules are connected.'),
  DashboardCardData(
      route: '/profiles',
      icon: Icons.group_outlined,
      title: 'User Management',
      description: 'Manage employee profiles and account types.'),
  DashboardCardData(
      route: '/notifications',
      icon: Icons.notifications_outlined,
      title: 'Notifications',
      description: 'View notification history and unread items.'),
  DashboardCardData(
      route: '/my-profile',
      icon: Icons.person_outline,
      title: 'My Profile',
      description: 'Manage your own details and signature.'),
  DashboardCardData(
      route: '/settings',
      icon: Icons.settings_outlined,
      title: 'Settings',
      description: 'Theme and user preference settings.'),
  DashboardCardData(
      route: '/admin',
      icon: Icons.shield_outlined,
      title: 'Admin Workspace',
      description: 'Operational admin tools and review workflows.'),
];

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) => const DashboardGrid(cards: _cards);
}
