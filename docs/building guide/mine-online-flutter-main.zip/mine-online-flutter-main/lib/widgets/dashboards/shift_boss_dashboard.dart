// Mirrors src/components/ShiftBossDashboard.tsx — 5 cards.

import 'package:flutter/material.dart';

import 'dashboard_card.dart';

const _cards = <DashboardCardData>[
  DashboardCardData(
      route: '/custom-forms',
      icon: Icons.list_alt_outlined,
      title: 'Custom Forms',
      description: 'Fill out forms published for your role.'),
  DashboardCardData(
      route: '/appointments',
      icon: Icons.assignment_outlined,
      title: 'Appointments',
      description: 'Create and manage appointment forms.'),
  DashboardCardData(
      route: '/current-logbook',
      icon: Icons.description_outlined,
      title: 'Current Logbook',
      description:
          'Documents you submitted, updating live as Mine Overseer and Mine Manager sign each one.'),
  DashboardCardData(
      route: '/completed-logbook-history',
      icon: Icons.task_alt_outlined,
      title: 'Completed Logbook History',
      description: 'Saved logbook and appointment form submissions.'),
  DashboardCardData(
      route: '/my-profile',
      icon: Icons.person_outline,
      title: 'My Profile',
      description: 'Manage your own details and signature.'),
  DashboardCardData(
      route: '/settings',
      icon: Icons.settings_outlined,
      title: 'Settings',
      description: 'Theme and user preference settings.'),
];

class ShiftBossDashboard extends StatelessWidget {
  const ShiftBossDashboard({super.key});

  @override
  Widget build(BuildContext context) => const DashboardGrid(cards: _cards);
}
