// Shared dashboard tile used by SuperAdmin/Admin/MineLeadership/ShiftBoss
// dashboards and the default fallback grid on /. Extracted from the original
// inline `_NavCard` in home_screen.dart.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DashboardCardData {
  const DashboardCardData({
    required this.route,
    required this.icon,
    required this.title,
    required this.description,
  });

  final String route;
  final IconData icon;
  final String title;
  final String description;
}

class DashboardCard extends StatelessWidget {
  const DashboardCard({super.key, required this.data});
  final DashboardCardData data;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.go(data.route),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: scheme.primaryContainer,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  data.icon,
                  size: 32,
                  color: scheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                data.title,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 6),
              Text(
                data.description,
                textAlign: TextAlign.center,
                style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DashboardGrid extends StatelessWidget {
  const DashboardGrid({super.key, required this.cards});
  final List<DashboardCardData> cards;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final cols = width >= 1100
            ? 4
            : width >= 820
            ? 3
            : width >= 540
            ? 2
            : 1;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: cols,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: cols == 1 ? 2.4 : 1.05,
          ),
          itemCount: cards.length,
          itemBuilder: (_, i) => DashboardCard(data: cards[i]),
        );
      },
    );
  }
}
