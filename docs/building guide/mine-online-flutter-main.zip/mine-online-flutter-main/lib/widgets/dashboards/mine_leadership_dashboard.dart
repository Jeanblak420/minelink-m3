// Mirrors src/components/MineLeadershipDashboard.tsx — 8 cards.
// Shown to Mine Overseer / Mine Manager accounts.

import 'package:flutter/material.dart';

import 'dashboard_card.dart';

const _cards = <DashboardCardData>[
  DashboardCardData(
      route: '/custom-forms',
      icon: Icons.list_alt_outlined,
      title: 'Custom Forms',
      description: 'Fill out forms published for your role.'),
  DashboardCardData(
      route: '/appointment-history-logs',
      icon: Icons.assignment_outlined,
      title: 'Appointment History Logs',
      description: 'View individual Shift Boss appointment history.'),
  DashboardCardData(
      route: '/active-individual-current-logbook',
      icon: Icons.checklist_outlined,
      title: 'Active Individual Current Logbook',
      description:
          "View the active current logbook an individual Shift Boss is busy with, including live progress."),
  DashboardCardData(
      route: '/individual-completed-logbook-history',
      icon: Icons.history_outlined,
      title: "Individuals' Past Completed Logbook History",
      description:
          "Review past completed submissions and patterns over time."),
  DashboardCardData(
      route: '/signature-requests',
      icon: Icons.draw_outlined,
      title: 'Signature Requests',
      description: 'Review submitted documents and add your signature.'),
  DashboardCardData(
      route: '/profiles',
      icon: Icons.group_outlined,
      title: 'User Profiles',
      description: 'View employee profiles (read-only).'),
  DashboardCardData(
      route: '/notifications',
      icon: Icons.notifications_outlined,
      title: 'Notifications',
      description: 'View notification history and unread items.'),
  DashboardCardData(
      route: '/my-profile',
      icon: Icons.person_outline,
      title: 'My Profile',
      description: 'Manage your own details and signature.'),
  DashboardCardData(
      route: '/settings',
      icon: Icons.settings_outlined,
      title: 'Settings',
      description: 'Theme and user preference settings.'),
];

class MineLeadershipDashboard extends StatelessWidget {
  const MineLeadershipDashboard({super.key});

  @override
  Widget build(BuildContext context) => const DashboardGrid(cards: _cards);
}
