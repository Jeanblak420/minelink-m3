import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_planned_task_observation_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';

class PlannedTaskObservationFormScreen extends StatefulWidget {
  const PlannedTaskObservationFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<PlannedTaskObservationFormScreen> createState() =>
      _PlannedTaskObservationFormScreenState();
}

class _PlannedTaskObservationFormScreenState
    extends State<PlannedTaskObservationFormScreen> {
  final _data = PlannedTaskObservationFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('planned_task_observation');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'planned_task_observation',
        'Planned Task Observation',
        payload,
      );
      final doc = await generatePlannedTaskObservationPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Planned_Task_Observation.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Widget _cell(
    String value,
    ValueChanged<String> onChanged, {
    double width = 80,
    String? hint,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return SizedBox(
      width: width,
      child: TextFormField(
        initialValue: value,
        onChanged: onChanged,
        decoration: InputDecoration(
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 8,
          ),
          border: const OutlineInputBorder(),
          hintText: ov?.label ?? hint,
        ),
      ),
    );
  }

  Widget _rowFields(PlannedTaskObservationRow r) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _cell(r.task, (v) => r.task = v, width: 200, hint: 'Task'),
            const SizedBox(width: 6),
            _cell(r.annual, (v) => r.annual = v, hint: 'Annual'),
            const SizedBox(width: 6),
            _cell(r.semester, (v) => r.semester = v, hint: 'Semester'),
            const SizedBox(width: 6),
            _cell(r.quarterly, (v) => r.quarterly = v, hint: 'Quarterly'),
            const SizedBox(width: 6),
            _cell(r.monthly, (v) => r.monthly = v, hint: 'Monthly'),
            const SizedBox(width: 6),
            _cell(r.biWeekly, (v) => r.biWeekly = v, hint: 'Bi-weekly'),
            const SizedBox(width: 6),
            _cell(r.weekly, (v) => r.weekly = v, hint: 'Weekly'),
            const SizedBox(width: 6),
            _cell(r.daily, (v) => r.daily = v, hint: 'Daily'),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Planned Task Observation'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: PageBody.form(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Control Sheet - Planned Task Observation',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            'Shift Boss should record all the planned task observations done in this PTO control sheet',
                          ),
                          const SizedBox(height: 16),
                          for (final r in _data.rows) _rowFields(r),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: OutlinedButton.icon(
                                onPressed: () => setState(
                                  () => _data.rows.add(
                                    PlannedTaskObservationRow(),
                                  ),
                                ),
                                icon: const Icon(Icons.add),
                                label: const Text('Add Row'),
                              ),
                            ),
                          FormOverlayHost(
                            formType: 'planned_task_observation',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
