// SP4 Appointments lifecycle — appointee inbox. Lists the appointments issued to
// the signed-in user and lets them accept-and-sign, decline, resign, and view the
// letter. Dynamic (SP3 template) appointments are signed with a signature pad;
// built-in appointment forms open the existing form screen to be completed.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../config/supabase_client.dart';
import '../models/appointment.dart';
import '../models/appointment_template.dart';
import '../providers/auth_provider.dart';
import '../utils/appointable_forms.dart';
import '../utils/appointment_data.dart';
import '../utils/appointment_template_data.dart';
import '../utils/form_registry.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/signature_canvas.dart';

final _dateFmt = DateFormat('dd MMM yyyy');

class MyAppointmentsScreen extends StatefulWidget {
  const MyAppointmentsScreen({super.key});

  @override
  State<MyAppointmentsScreen> createState() => _MyAppointmentsScreenState();
}

class _MyAppointmentsScreenState extends State<MyAppointmentsScreen> {
  bool _loading = true;
  String? _error;
  List<Appointment> _appointments = const [];
  final Map<String, AppointmentTemplate> _templatesById = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final appts = await loadMyAppointments();
      final templates = await loadAppointmentTemplates(includeArchived: true);
      if (!mounted) return;
      setState(() {
        _appointments = appts;
        _templatesById
          ..clear()
          ..addEntries(templates.map((t) => MapEntry(t.id, t)));
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  bool _isDynamic(Appointment a) =>
      (a.formType ?? '').startsWith('appt_') || a.templateId != null;

  Future<AppointmentTemplate?> _templateFor(Appointment a) async {
    if (a.templateId != null && _templatesById.containsKey(a.templateId)) {
      return _templatesById[a.templateId];
    }
    final code = a.formType;
    if (code != null) return loadAppointmentTemplateByCode(code);
    return null;
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _acceptDynamic(Appointment a) async {
    final me = context.read<AuthProvider>().profile;
    if (me == null) return;
    final template = await _templateFor(a);
    if (template == null) {
      _snack('Could not load the appointment template.');
      return;
    }
    final signature = await _captureSignature(me.signatureData ?? '');
    if (signature == null) return;
    if (signature.trim().isEmpty) {
      _snack('A signature is required to accept.');
      return;
    }
    try {
      await acceptAppointment(
        appt: a,
        template: template,
        me: me,
        signature: signature,
      );
      _load();
    } catch (err) {
      _snack('Accept failed: $err');
    }
  }

  Future<void> _acceptBuiltIn(Appointment a) async {
    final form = appointableFormByCode(a.formType ?? '');
    if (form == null) {
      _snack('Unknown appointment form.');
      return;
    }
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => form.builder(
          onSubmitted: (submissionId) => linkAppointmentSubmission(
            a,
            submissionId,
            hasChain: form.hasChain,
          ),
        ),
      ),
    );
    if (mounted) _load();
  }

  Future<String?> _captureSignature(String initial) async {
    var sig = initial;
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Accept & sign'),
        content: SizedBox(
          width: 420,
          child: SignatureCanvasField(
            value: initial,
            label: 'Your signature',
            onChanged: (v) => sig = v,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, sig),
            child: const Text('Accept'),
          ),
        ],
      ),
    );
  }

  Future<void> _decline(Appointment a) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Decline appointment'),
        content: const Text('Decline this appointment? This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Decline'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await declineAppointment(a);
    _load();
  }

  Future<void> _resign(Appointment a) async {
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Resign appointment'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(labelText: 'Reason'),
          minLines: 1,
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: const Text('Resign'),
          ),
        ],
      ),
    );
    if (reason == null || reason.isEmpty) return;
    await resignAppointment(a, reason);
    _load();
  }

  Future<void> _viewPdf(Appointment a) async {
    final formType = a.formType;
    if (formType == null || formType.isEmpty) {
      _snack('Nothing to preview yet.');
      return;
    }
    var payload = a.payload;
    if (a.submissionId != null) {
      final row = await supabase
          .from('form_submissions')
          .select('payload')
          .eq('id', a.submissionId!)
          .maybeSingle();
      if (row != null && row['payload'] is Map) {
        payload = (row['payload'] as Map).cast<String, dynamic>();
      }
    }
    final doc = await generatePdfForFormType(formType, payload);
    if (doc == null) {
      _snack('Could not render this appointment.');
      return;
    }
    await Printing.layoutPdf(onLayout: (_) async => doc.save());
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Appointments'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(16),
                child: _appointments.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'You have no appointments yet.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView.separated(
                        shrinkWrap: true,
                        itemCount: _appointments.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (_, i) => _card(_appointments[i]),
                      ),
              ),
      ),
    );
  }

  Widget _card(Appointment a) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(a.roleCode, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              '${a.status.label} • effective ${_dateFmt.format(a.effectiveDate)}'
              '${a.section != null && a.section!.isNotEmpty ? ' • ${a.section}' : ''}',
              style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
            ),
            if (a.status == AppointmentStatus.pendingSignoff) ...[
              const SizedBox(height: 8),
              Text(
                'Awaiting Mine Overseer / Mine Manager sign-off.',
                style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 4, children: _actions(a)),
          ],
        ),
      ),
    );
  }

  List<Widget> _actions(Appointment a) {
    final widgets = <Widget>[];
    if (a.canAccept) {
      widgets.add(
        FilledButton.icon(
          onPressed: () =>
              _isDynamic(a) ? _acceptDynamic(a) : _acceptBuiltIn(a),
          icon: const Icon(Icons.check),
          label: Text(
            _isDynamic(a) ? 'Accept & sign' : 'Accept & complete form',
          ),
        ),
      );
      widgets.add(
        OutlinedButton.icon(
          onPressed: () => _decline(a),
          icon: const Icon(Icons.close),
          label: const Text('Decline'),
        ),
      );
    }
    if (a.status == AppointmentStatus.pendingSignoff) {
      widgets.add(
        OutlinedButton.icon(
          onPressed: () => context.go('/signature-requests'),
          icon: const Icon(Icons.fact_check_outlined),
          label: const Text('Track sign-off'),
        ),
      );
    }
    if (a.status == AppointmentStatus.active ||
        a.status == AppointmentStatus.pendingSignoff) {
      widgets.add(
        OutlinedButton.icon(
          onPressed: () => _viewPdf(a),
          icon: const Icon(Icons.picture_as_pdf_outlined),
          label: const Text('View letter'),
        ),
      );
    }
    if (a.canResign) {
      widgets.add(
        TextButton.icon(
          onPressed: () => _resign(a),
          icon: const Icon(Icons.logout),
          label: const Text('Resign'),
        ),
      );
    }
    return widgets;
  }
}
