import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/app_notification.dart';
import '../providers/notifications_provider.dart';
import '../theme/mol_tones.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/empty_state.dart';
import '../widgets/mobile_bottom_nav.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return Scaffold(
      backgroundColor: tones.bgMuted,
      bottomNavigationBar:
          const MobileBottomNav(location: '/notifications'),
      appBar: AppBar(
        title: const Text('Notifications'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          Consumer<NotificationsProvider>(
            builder: (innerContext, p, _) => TextButton(
              onPressed: p.notifications.any((n) => !n.read)
                  ? () async {
                      await p.markAllAsRead();
                      if (!innerContext.mounted) return;
                      ScaffoldMessenger.of(innerContext).showSnackBar(
                        const SnackBar(
                          content: Text('All notifications marked as read'),
                        ),
                      );
                    }
                  : null,
              child: const Text('Mark all as read'),
            ),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: PageBody.list(
          child: Consumer<NotificationsProvider>(
          builder: (context, provider, _) {
            if (provider.loading) {
              return const Center(child: CircularProgressIndicator());
            }
            if (provider.notifications.isEmpty) {
              return const EmptyState(
                icon: Icons.notifications_none_outlined,
                title: 'No notifications yet',
                body: 'Future app events will appear here.',
              );
            }
            return RefreshIndicator(
              onRefresh: provider.reload,
              child: ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 16),
                itemCount: provider.notifications.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (_, i) =>
                    _NotificationCard(provider.notifications[i]),
              ),
            );
          },
        ),
        ),
      ),
    );
  }
}

class _NotificationCategory {
  const _NotificationCategory({
    required this.id,
    required this.label,
    required this.icon,
    required this.tone,
    required this.defaultRoute,
  });
  final String id;
  final String label;
  final IconData icon;
  final MolTone tone;
  final String defaultRoute;
}

_NotificationCategory _categoryFor(
  AppNotification item,
  MolTones tones,
) {
  // Web parity: notifications.metadata.category drives this. Fall back to
  // `type` (legacy) so older rows still render with a sensible tone.
  final raw = (item.category ?? item.type).toUpperCase();
  switch (raw) {
    case 'SIGNATURE':
      return _NotificationCategory(
        id: 'SIGNATURE',
        label: 'Signature',
        icon: Icons.draw_outlined,
        tone: tones.warning,
        defaultRoute: '/signature-requests',
      );
    case 'WORKFLOW':
    case 'SUCCESS':
      return _NotificationCategory(
        id: 'WORKFLOW',
        label: 'Workflow',
        icon: Icons.assignment_turned_in_outlined,
        tone: tones.success,
        defaultRoute: '/current-logbook',
      );
    case 'ADMIN':
    case 'WARNING':
      return _NotificationCategory(
        id: 'ADMIN',
        label: 'Admin',
        icon: Icons.shield_outlined,
        tone: tones.info,
        defaultRoute: '/admin',
      );
    default:
      return _NotificationCategory(
        id: raw,
        label: raw.isEmpty ? 'System' : raw.toLowerCase(),
        icon: Icons.notifications_outlined,
        tone: tones.info,
        defaultRoute: '/',
      );
  }
}

class _NotificationCard extends StatelessWidget {
  const _NotificationCard(this.item);
  final AppNotification item;

  static final _formatter = DateFormat('d MMM, HH:mm');

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    final category = _categoryFor(item, tones);
    final read = item.read;
    final documentTitle = item.metadata?['documentTitle'] as String?;

    return Material(
      color: category.tone.tint,
      borderRadius: BorderRadius.circular(16),
      elevation: 1,
      shadowColor: Colors.black.withValues(alpha: 0.08),
      child: InkWell(
        onTap: () => _onTap(context, category),
        borderRadius: BorderRadius.circular(16),
        child: Opacity(
          opacity: read ? 0.72 : 1.0,
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 12,
                bottom: 12,
                child: Container(
                  width: 4,
                  decoration: BoxDecoration(
                    color: category.tone.accent,
                    borderRadius: BorderRadius.circular(9999),
                  ),
                ),
              ),
              if (!read)
                Positioned(
                  top: 10,
                  right: 12,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: category.tone.accent,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: category.tone.soft,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      alignment: Alignment.center,
                      child: Icon(category.icon,
                          size: 20, color: category.tone.accent),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: scheme.onSurface,
                              decoration: read
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                              decorationColor: tones.fg4,
                              decorationThickness: 1.5,
                            ),
                          ),
                          if (item.body.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              item.body,
                              style: TextStyle(
                                fontSize: 13,
                                color: scheme.onSurfaceVariant,
                                height: 1.4,
                              ),
                            ),
                          ],
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 4,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              if (documentTitle != null &&
                                  documentTitle.isNotEmpty)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: scheme.surface,
                                    borderRadius: BorderRadius.circular(9999),
                                    border: Border.all(
                                      color: tones.line,
                                      width: 0.5,
                                    ),
                                  ),
                                  child: Text(
                                    documentTitle,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w500,
                                      color: tones.fg3,
                                    ),
                                  ),
                                ),
                              Text(
                                category.label.toUpperCase(),
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  color: category.tone.fg,
                                  letterSpacing: 0.6,
                                ),
                              ),
                              Text(
                                _formatter.format(item.createdAt.toLocal()),
                                style: TextStyle(
                                  fontSize: 11,
                                  color: tones.fg3,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onTap(BuildContext context, _NotificationCategory category) {
    final provider = context.read<NotificationsProvider>();
    provider.markAsRead(item.id);
    final url = item.actionUrl;
    if (url != null && url.isNotEmpty) {
      context.go(url);
      return;
    }
    // e-notif-3: route by category when no explicit action_url is set.
    if (category.id == 'ADMIN') {
      final docId = item.metadata?['documentId'] as String? ??
          item.metadata?['form_instance_id'] as String?;
      if (docId != null && docId.isNotEmpty) {
        context.go('${category.defaultRoute}?id=$docId');
        return;
      }
    }
    context.go(category.defaultRoute);
  }
}