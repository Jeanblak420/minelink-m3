// SP8 Reports — one screen backing /reports/daily|weekly|monthly via a period
// variant. KPI summary + breakdowns + submission register, with PDF export.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../pdf/generate_report_pdf.dart';
import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/analytics_data.dart' show sortedDesc;
import '../utils/report_data.dart';
import '../utils/role_access.dart';
import '../widgets/admin/kpi_stat_card.dart';
import '../widgets/analytics/mini_bar_chart.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';

const _titles = {
  ReportPeriod.daily: 'Daily Reports',
  ReportPeriod.weekly: 'Weekly Reports',
  ReportPeriod.monthly: 'Monthly Reports',
};

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key, required this.period});

  final ReportPeriod period;

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  DateTime _anchor = DateTime.now();
  bool _loading = true;
  String? _error;
  ReportSummary? _summary;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = await loadReport(widget.period, _anchor);
      if (!mounted) return;
      setState(() {
        _summary = s;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _pickAnchor() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _anchor,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _anchor = picked);
      _load();
    }
  }

  Future<void> _exportPdf() async {
    final s = _summary;
    if (s == null) return;
    await Printing.layoutPdf(
      onLayout: (_) async => (await generateReportPdf(s)).save(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    final title = _titles[widget.period]!;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: Text(title),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Reports are available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Export PDF',
            onPressed: (_loading || _summary == null) ? null : _exportPdf,
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : _body(context),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final s = _summary!;
    final tones = MolTones.of(context);
    return PageBody.list(
      scrollable: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  s.window.label,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              OutlinedButton.icon(
                onPressed: _pickAnchor,
                icon: const Icon(Icons.calendar_today_outlined, size: 18),
                label: const Text('Change period'),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // KPIs
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _kpi(
                'Submissions',
                s.submissions,
                Icons.description_outlined,
                tones.info,
              ),
              _kpi(
                'Fully signed',
                s.fullySigned,
                Icons.verified_outlined,
                tones.success,
              ),
              _kpi(
                'Pending in chain',
                s.pendingInChain,
                Icons.pending_outlined,
                tones.warning,
              ),
              _kpi(
                'Safety incidents',
                s.incidents,
                Icons.warning_amber_outlined,
                tones.danger,
              ),
              _kpi(
                'Appointments issued',
                s.appointmentsIssued,
                Icons.assignment_ind_outlined,
                tones.info,
              ),
              _kpi(
                'Appointments accepted',
                s.appointmentsAccepted,
                Icons.how_to_reg_outlined,
                tones.success,
              ),
            ],
          ),
          const SizedBox(height: 8),
          _statTile(
            'Signature completion',
            '${(s.signatureCompletionRate * 100).round()}%',
            tones.success,
          ),
          const SizedBox(height: 16),

          // Breakdowns
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _label('By form'),
                  MiniBarChart(
                    data: sortedDesc(s.byFormType),
                    color: tones.info.accent,
                  ),
                  const SizedBox(height: 12),
                  _label('By workflow status'),
                  MiniBarChart(
                    data: sortedDesc(s.byStatus),
                    color: tones.warning.accent,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Register
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _label('Submission register (${s.register.length})'),
                  const SizedBox(height: 8),
                  if (s.register.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text(
                        'No submissions in this period.',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    )
                  else
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text('Date')),
                          DataColumn(label: Text('Form')),
                          DataColumn(label: Text('Submitter')),
                          DataColumn(label: Text('Status')),
                        ],
                        rows: [
                          for (final r in s.register)
                            DataRow(
                              cells: [
                                DataCell(Text(_fmtDate(r.date))),
                                DataCell(Text(r.formLabel)),
                                DataCell(Text(r.submitter)),
                                DataCell(Text(r.status)),
                              ],
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  static String _fmtDate(DateTime? d) {
    if (d == null) return '—';
    final l = d.toLocal();
    return '${l.year}-${l.month.toString().padLeft(2, '0')}-${l.day.toString().padLeft(2, '0')}';
  }

  Widget _kpi(String label, int value, IconData icon, MolTone tone) => SizedBox(
    width: 220,
    child: KpiStatCard(
      label: label,
      value: value,
      icon: icon,
      tone: tone,
      loading: false,
    ),
  );

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(
      t,
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
      ),
    ),
  );

  Widget _statTile(String label, String value, MolTone tone) => Container(
    width: 220,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: tone.tint,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: tone.fg, fontSize: 12)),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: tone.accent,
            fontSize: 24,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
}
