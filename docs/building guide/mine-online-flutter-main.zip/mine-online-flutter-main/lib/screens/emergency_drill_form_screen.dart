import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import '../pdf/generate_emergency_drill_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';

class EmergencyDrillFormScreen extends StatefulWidget {
  const EmergencyDrillFormScreen({
    super.key,
    required this.title,
    required this.formType,
    required this.pageNum,
    this.viewArgs,
  });

  final String title;
  final String formType;
  final String pageNum;
  final FormViewArgs? viewArgs;

  @override
  State<EmergencyDrillFormScreen> createState() =>
      _EmergencyDrillFormScreenState();
}

class _EmergencyDrillFormScreenState extends State<EmergencyDrillFormScreen> {
  final _data = EmergencyDrillFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides(widget.formType);
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(widget.formType, widget.title, payload);
      final doc = await generateEmergencyDrillPdf(
        _data,
        title: widget.title,
        pageNum: widget.pageNum,
        subject: widget.title,
      );
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: '${widget.title.replaceAll(' ', '_')}.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: Text(widget.title),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 980,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      widget.title,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Refuge Bay No.',
                            _data.refugeBayNo,
                            (v) => _data.refugeBayNo = v,
                            id: 'refugeBayNo',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Working place',
                            _data.workingPlace,
                            (v) => _data.workingPlace = v,
                            id: 'workingPlace',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Emergency Drill performed',
                            _data.emergencyDrillPerformed,
                            (v) => _data.emergencyDrillPerformed = v,
                            maxLines: 3,
                            id: 'emergencyDrillPerformed',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Deficiencies observed',
                            _data.deficienciesObserved,
                            (v) => _data.deficienciesObserved = v,
                            maxLines: 3,
                            id: 'deficienciesObserved',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Recommended Improvements',
                            _data.recommendedImprovements,
                            (v) => _data.recommendedImprovements = v,
                            maxLines: 3,
                            id: 'recommendedImprovements',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Refuge Bay situated at',
                            _data.refugeBaySituatedAt,
                            (v) => _data.refugeBaySituatedAt = v,
                            id: 'refugeBaySituatedAt',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Employees who attended the Drill Meeting',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          for (var i = 0; i < _data.employees.length; i++)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      initialValue: _data.employees[i].col1,
                                      onChanged: (v) =>
                                          _data.employees[i].col1 = v,
                                      decoration: const InputDecoration(
                                        isDense: true,
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 12,
                                        ),
                                        border: OutlineInputBorder(),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: TextFormField(
                                      initialValue: _data.employees[i].col2,
                                      onChanged: (v) =>
                                          _data.employees[i].col2 = v,
                                      decoration: const InputDecoration(
                                        isDense: true,
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 12,
                                        ),
                                        border: OutlineInputBorder(),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: TextFormField(
                                      initialValue: _data.employees[i].col3,
                                      onChanged: (v) =>
                                          _data.employees[i].col3 = v,
                                      decoration: const InputDecoration(
                                        isDense: true,
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 12,
                                        ),
                                        border: OutlineInputBorder(),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          if (!_isViewMode)
                            OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.employees.add(
                                  EmergencyDrillEmployee(),
                                ),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add Employee'),
                            ),
                          FormOverlayHost(
                            formType: widget.formType,
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
