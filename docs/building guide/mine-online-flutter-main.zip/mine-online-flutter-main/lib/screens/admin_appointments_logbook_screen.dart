// Mirrors src/components/AdminAppointmentsLogbook.tsx — used by
// /appointment-history-logs (variant=history) and
// /active-individual-current-logbook (variant=active).

// ignore_for_file: unnecessary_underscores

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../models/user_profile.dart';
import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/empty_state.dart';
import '../widgets/mol_chips.dart';
import '../widgets/page_body.dart';
import '../widgets/submission_viewer_dialog.dart';

bool _canAccessLogbook(UserProfile? profile) =>
    isAdminProfile(profile) ||
    isMineOverseerProfile(profile) ||
    isMineManagerProfile(profile);

enum AdminLogbookVariant { history, active }

class AdminAppointmentsLogbookScreen extends StatefulWidget {
  const AdminAppointmentsLogbookScreen({super.key, required this.variant});

  final AdminLogbookVariant variant;

  @override
  State<AdminAppointmentsLogbookScreen> createState() =>
      _AdminAppointmentsLogbookScreenState();
}

class _AdminAppointmentsLogbookScreenState
    extends State<AdminAppointmentsLogbookScreen> {
  static final _formatter = DateFormat('d MMM yyyy, HH:mm');

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _submissions = const [];
  Map<String, Map<String, dynamic>> _profiles = const {};
  final Set<String> _expanded = {};
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      var query = supabase
          .from('form_submissions')
          .select(
              'id,user_id,form_type,title,payload,workflow_status,current_signature_role,completed_at,created_at,updated_at');
      if (widget.variant == AdminLogbookVariant.active) {
        query = query.inFilter('workflow_status',
            ['submitted', 'pending_signature']);
      }
      final rows = await query
          .order('updated_at', ascending: false, nullsFirst: false)
          .order('created_at', ascending: false)
          .limit(500);
      final submissionRows = (rows as List).cast<Map<String, dynamic>>();
      Map<String, Map<String, dynamic>> profileMap = {};
      final userIds = submissionRows
          .map((r) => r['user_id'] as String?)
          .whereType<String>()
          .toSet()
          .toList();
      if (userIds.isNotEmpty) {
        final profileRows = await supabase
            .from('profiles')
            .select(
                'id,full_name,email,phone,occupation,job_title,company,department,cost_centre,location,company_number')
            .inFilter('id', userIds);
        for (final row in (profileRows as List).cast<Map<String, dynamic>>()) {
          profileMap[row['id'] as String] = row;
        }
      }
      if (!mounted) return;
      setState(() {
        _submissions = submissionRows;
        _profiles = profileMap;
        _loading = false;
      });
      _resubscribe();
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _submissions = const [];
        _profiles = const {};
        _loading = false;
      });
    }
  }

  void _resubscribe() {
    if (_channel != null) return;
    _channel = supabase
        .channel('admin-logbook:${widget.variant.name}')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'form_submissions',
          callback: (_) => _load(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'signature_requests',
          callback: (_) => _load(),
        )
        .subscribe();
  }

  Map<String, List<Map<String, dynamic>>> _grouped() {
    final groups = <String, List<Map<String, dynamic>>>{};
    for (final row in _submissions) {
      final uid = row['user_id'] as String? ?? '';
      groups.putIfAbsent(uid, () => []).add(row);
    }
    return groups;
  }

  List<String> _sortedUserIds(Map<String, List<Map<String, dynamic>>> grouped) {
    final ids = grouped.keys.toList();
    ids.sort((a, b) {
      final na = (_profiles[a]?['full_name'] as String?) ??
          (_profiles[a]?['email'] as String?) ??
          '';
      final nb = (_profiles[b]?['full_name'] as String?) ??
          (_profiles[b]?['email'] as String?) ??
          '';
      return na.toLowerCase().compareTo(nb.toLowerCase());
    });
    return ids;
  }

  String _formatDate(String? s) {
    if (s == null || s.isEmpty) return '—';
    final d = DateTime.tryParse(s);
    return d == null ? s : _formatter.format(d.toLocal());
  }

  Widget _statusBadge(Map<String, dynamic> row) {
    final status = row['workflow_status'] as String?;
    final role = row['current_signature_role'] as String?;
    if (status == 'fully_signed') {
      return const StatusChip(kind: StatusChipKind.complete, dense: true);
    }
    if (status == 'pending_signature') {
      return StatusChip(
        kind: StatusChipKind.pending,
        label: role != null ? 'Pending • $role' : 'Pending',
        dense: true,
      );
    }
    return const StatusChip(
        kind: StatusChipKind.doing, label: 'Submitted', dense: true);
  }

  Widget _countChip(int count) {
    final tones = MolTones.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: tones.info.soft,
        borderRadius: BorderRadius.circular(9999),
      ),
      child: Text('$count form${count == 1 ? '' : 's'}',
          style: TextStyle(
              color: tones.info.fg,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4)),
    );
  }

  String get _title => widget.variant == AdminLogbookVariant.history
      ? 'Appointments History Logs'
      : 'Active Individual Current Logbook';

  String get _subtitle => widget.variant == AdminLogbookVariant.history
      ? 'Every user who has ever submitted a form, grouped by submitter. Tap a user to view their submissions.'
      : 'Users with submissions still moving through the signature workflow. Live updates as Mine Overseer and Mine Manager sign.';

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!_canAccessLogbook(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: Text(_title),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.shield_outlined,
                    size: 48, color: scheme.error),
                const SizedBox(height: 12),
                Text('Admin access required',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                    'This view is only available to Admin, Mine Overseer, and Mine Manager accounts.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: scheme.onSurfaceVariant)),
              ],
            ),
          ),
        ),
      );
    }

    final grouped = _grouped();
    final userIds = _sortedUserIds(grouped);

    return Scaffold(
      appBar: AppBar(
        title: Text(_title),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: PageBody.list(
          child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(_error!,
                        style: TextStyle(color: scheme.error)),
                  )
                : ListView(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                        child: Text(_subtitle,
                            style: TextStyle(color: scheme.onSurfaceVariant)),
                      ),
                      if (userIds.isEmpty)
                        EmptyState(
                          icon: widget.variant == AdminLogbookVariant.active
                              ? Icons.checklist_outlined
                              : Icons.history_outlined,
                          title: widget.variant == AdminLogbookVariant.active
                              ? 'No active submissions'
                              : 'No submissions yet',
                          body: widget.variant == AdminLogbookVariant.active
                              ? 'Submissions still moving through the signature workflow will appear here.'
                              : 'Forms submitted by any user will appear here, grouped by submitter.',
                        )
                      else
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                          child: Card(
                            elevation: 1,
                            clipBehavior: Clip.antiAlias,
                            child: Column(
                              children: [
                                for (var i = 0; i < userIds.length; i++) ...[
                                  if (i > 0)
                                    Divider(
                                        height: 1,
                                        color:
                                            MolTones.of(context).lineFaint),
                                  _userTile(
                                      userIds[i],
                                      grouped[userIds[i]]!,
                                      scheme),
                                ],
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
      ),
      ),
    );
  }

  Widget _userTile(
      String uid, List<Map<String, dynamic>> rows, ColorScheme scheme) {
    final profile = _profiles[uid];
    final name = (profile?['full_name'] as String?) ??
        (profile?['email'] as String?) ??
        'Unknown user';
    final occ = (profile?['occupation'] as String?) ??
        (profile?['job_title'] as String?) ??
        '';
    final isOpen = _expanded.contains(uid);
    final tones = MolTones.of(context);
    return _HoverWrap(
      idleColor: Colors.transparent,
      hoverColor: tones.bgMuted,
      child: Column(
        children: [
          InkWell(
            onTap: () => setState(() {
              if (isOpen) {
                _expanded.remove(uid);
              } else {
                _expanded.add(uid);
              }
            }),
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              child: Row(
                children: [
                  Icon(
                    isOpen
                        ? Icons.keyboard_arrow_down
                        : Icons.keyboard_arrow_right,
                    size: 22,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name,
                            style: Theme.of(context).textTheme.titleSmall),
                        if (occ.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: RolePill(role: occ, dense: true),
                          ),
                      ],
                    ),
                  ),
                  _countChip(rows.length),
                ],
              ),
            ),
          ),
          if (isOpen)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Column(
                children: [
                  for (final row in rows)
                    _SubmissionMiniCard(
                      row: row,
                      dateLabel: _formatDate(row['created_at'] as String?),
                      statusChip: _statusBadge(row),
                      onTap: () => _openPayload(row),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _openPayload(Map<String, dynamic> row) {
    return showDialog(
      context: context,
      builder: (_) => SubmissionViewerDialog(row: row),
    );
  }
}

class _HoverWrap extends StatefulWidget {
  const _HoverWrap({
    required this.child,
    required this.idleColor,
    required this.hoverColor,
  });

  final Widget child;
  final Color idleColor;
  final Color hoverColor;

  @override
  State<_HoverWrap> createState() => _HoverWrapState();
}

class _HoverWrapState extends State<_HoverWrap> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        color: _hover ? widget.hoverColor : widget.idleColor,
        child: widget.child,
      ),
    );
  }
}

class _SubmissionMiniCard extends StatelessWidget {
  const _SubmissionMiniCard({
    required this.row,
    required this.dateLabel,
    required this.statusChip,
    required this.onTap,
  });

  final Map<String, dynamic> row;
  final String dateLabel;
  final Widget statusChip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: tones.bgMuted,
        borderRadius: BorderRadius.circular(12),
        elevation: 0,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(row['title'] as String? ?? '—',
                          style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 4),
                      Text(row['form_type'] as String? ?? '',
                          style: TextStyle(color: scheme.onSurfaceVariant)),
                      const SizedBox(height: 6),
                      statusChip,
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Submitted',
                        style: TextStyle(
                            color: scheme.onSurfaceVariant, fontSize: 10)),
                    Text(dateLabel, style: const TextStyle(fontSize: 11)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}