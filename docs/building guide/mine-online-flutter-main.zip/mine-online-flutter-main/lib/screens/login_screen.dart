import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/supabase_client.dart';
import '../providers/auth_provider.dart';
import '../utils/password_security.dart';
import '../widgets/page_body.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtl = TextEditingController();
  final _passwordCtl = TextEditingController();
  bool _showPassword = false;
  bool _isSignUp = false;
  bool _loading = false;
  String? _error;
  String? _success;

  @override
  void dispose() {
    _emailCtl.dispose();
    _passwordCtl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      _loading = true;
      _error = null;
      _success = null;
    });
    final auth = context.read<AuthProvider>();
    final email = _emailCtl.text.trim();
    final password = _passwordCtl.text;
    try {
      if (_isSignUp) {
        await assertPasswordNotCompromised(password);
        final res = await auth.signUp(email, password);
        if (res.user != null) {
          try {
            await supabase.from('profiles').insert({
              'id': res.user!.id,
              'email': email,
              'full_name': email.split('@').first,
              'first_name': email.split('@').first,
              'title': 'Mr',
              'job_title': 'User',
              'cost_centre': 'General',
              'is_admin': false,
              'is_super_admin': false,
            });
          } catch (err) {
            // Duplicate inserts are fine; surface other issues quietly.
            if (!err.toString().toLowerCase().contains('duplicate')) {
              // ignore: avoid_print
              print('Profile creation warning: $err');
            }
          }
          setState(() {
            _success = 'Account created! You can now sign in.';
            _isSignUp = false;
          });
        }
      } else {
        await auth.signIn(email, password);
      }
    } catch (err) {
      setState(() {
        _error = _humanError(err);
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _humanError(Object err) {
    final msg = err.toString();
    if (msg.toLowerCase().contains('invalid login credentials')) {
      return 'Invalid email or password. Please try again.';
    }
    return msg.replaceFirst('Exception: ', '');
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final auth = context.watch<AuthProvider>();

    if (auth.loading) {
      return Scaffold(
        backgroundColor: scheme.surface,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: scheme.surface,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: PageBody(
              maxWidth: 440,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(
                      'assets/images/assmang-logo.png',
                      height: 96,
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Black Rock Mine',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Shift Boss Management System',
                      style: TextStyle(color: scheme.onSurfaceVariant),
                    ),
                    const SizedBox(height: 32),
                    Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        children: [
                          Container(
                            width: double.infinity,
                            color: scheme.primaryContainer,
                            padding: const EdgeInsets.fromLTRB(28, 22, 28, 22),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _isSignUp ? 'Create Account' : 'Sign In',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleLarge
                                      ?.copyWith(
                                        color: scheme.onPrimaryContainer,
                                      ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  _isSignUp
                                      ? 'Create a new account to get started'
                                      : 'Enter your credentials to access the system',
                                  style: TextStyle(
                                    color: scheme.onPrimaryContainer,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(28, 24, 28, 24),
                            child: Form(
                              autovalidateMode: AutovalidateMode.onUserInteraction,
                              child: Column(
                                children: [
                                  if (_success != null)
                                    _Banner(
                                      icon: Icons.person_add_alt_1_outlined,
                                      text: _success!,
                                      background: scheme.tertiaryContainer,
                                      foreground: scheme.onTertiaryContainer,
                                    ),
                                  if (_error != null)
                                    _Banner(
                                      icon: Icons.error_outline,
                                      text: _error!,
                                      background: scheme.errorContainer,
                                      foreground: scheme.onErrorContainer,
                                    ),
                                  TextFormField(
                                    controller: _emailCtl,
                                    keyboardType: TextInputType.emailAddress,
                                    autofillHints: const [
                                      AutofillHints.email,
                                    ],
                                    decoration: const InputDecoration(
                                      labelText: 'Email Address',
                                      hintText: 'your@email.com',
                                    ),
                                  ),
                                  const SizedBox(height: 16),
                                  TextFormField(
                                    controller: _passwordCtl,
                                    obscureText: !_showPassword,
                                    autofillHints: const [
                                      AutofillHints.password,
                                    ],
                                    decoration: InputDecoration(
                                      labelText: 'Password',
                                      hintText: 'Enter your password',
                                      suffixIcon: IconButton(
                                        icon: Icon(
                                          _showPassword
                                              ? Icons.visibility_off_outlined
                                              : Icons.visibility_outlined,
                                        ),
                                        onPressed: () => setState(
                                          () => _showPassword = !_showPassword,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 22),
                                  SizedBox(
                                    width: double.infinity,
                                    child: FilledButton.icon(
                                      onPressed: _loading ? null : _submit,
                                      icon: _loading
                                          ? const SizedBox(
                                              width: 18,
                                              height: 18,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                              ),
                                            )
                                          : Icon(
                                              _isSignUp
                                                  ? Icons.person_add_alt_1
                                                  : Icons.login,
                                            ),
                                      label: Text(
                                        _isSignUp
                                            ? (_loading
                                                ? 'Creating account...'
                                                : 'Create Account')
                                            : (_loading
                                                ? 'Signing in...'
                                                : 'Sign In'),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  TextButton(
                                    onPressed: () => setState(() {
                                      _isSignUp = !_isSignUp;
                                      _error = null;
                                      _success = null;
                                    }),
                                    child: Text(
                                      _isSignUp
                                          ? 'Already have an account? Sign In'
                                          : "Don't have an account? Create one",
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Assmang (PTY) Limited — Black Rock Mine Operations',
                      style: TextStyle(
                        color: scheme.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.icon,
    required this.text,
    required this.background,
    required this.foreground,
  });
  final IconData icon;
  final String text;
  final Color background;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: foreground, size: 20),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: TextStyle(color: foreground))),
        ],
      ),
    );
  }
}
