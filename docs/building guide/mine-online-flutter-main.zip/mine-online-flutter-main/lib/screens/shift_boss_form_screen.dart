import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_shift_boss_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/appointment_profile.dart';
import '../utils/form_overlay_data.dart';
import '../utils/role_access.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class ShiftBossFormScreen extends StatefulWidget {
  const ShiftBossFormScreen({super.key, this.viewArgs, this.onSubmitted});

  final FormViewArgs? viewArgs;

  /// When set (appointment-accept flow), called with the new submission id after
  /// a successful submit instead of navigating to the logbook.
  final ValueChanged<String>? onSubmitted;

  @override
  State<ShiftBossFormScreen> createState() => _ShiftBossFormScreenState();
}

class _ShiftBossFormScreenState extends State<ShiftBossFormScreen> {
  final _data = ShiftBossFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _submitting = false;
  String? _submitError;
  bool _initialised = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('shift_boss_appointment');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  /// Override-aware text field. Returns an empty box when hidden and applies a
  /// relabel when present; otherwise renders identically to a bare [_TF].
  Widget _tf(
    String id,
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? hint,
  }) {
    final ov = _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return _TF(ov?.label ?? label, value, onChanged, hint: hint);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final details = getProfilePersonalDetails(profile);
      _data.title = _data.title.isEmpty ? details.title : _data.title;
      _data.name = _data.name.isEmpty ? details.name : _data.name;
      _data.identityNumber = _data.identityNumber.isEmpty
          ? details.identityNumber
          : _data.identityNumber;
      _data.companyNumber = _data.companyNumber.isEmpty
          ? details.companyNumber
          : _data.companyNumber;
      _data.shaft = _data.shaft.isEmpty ? details.shaft : _data.shaft;
      if (isShiftBossProfile(profile)) {
        _data.signatures.shiftBossSignature =
            _data.signatures.shiftBossSignature.isEmpty
            ? details.signature
            : _data.signatures.shiftBossSignature;
        _data.signatures.shiftBossDate = _data.signatures.shiftBossDate.isEmpty
            ? _today
            : _data.signatures.shiftBossDate;
      }
    }
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateShiftBossPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Shift_Boss_Appointment_${_safeName(_data.name)}.pdf',
      );
    } catch (err) {
      _showSnack('Error generating PDF: $err');
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'shift_boss_appointment',
        _data.name.isNotEmpty
            ? 'Shift Boss Appointment — ${_data.name}'
            : 'Shift Boss Appointment',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        if (widget.onSubmitted != null) {
          widget.onSubmitted!(id);
          if (mounted) context.pop();
        } else {
          context.go('/current-logbook?submitted=$id');
        }
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  String _safeName(String s) {
    final cleaned = s.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
    return cleaned.isEmpty ? 'form' : cleaned;
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    // In view mode the form is being shown read-only for review/sign by the
    // next signer (Mine Overseer/Manager) — they're authorised by RLS and the
    // edge function's role check, so the Shift-Boss occupation gate doesn't
    // apply.
    final canAccess = _isViewMode || canAccessShiftBossDocuments(profile);
    final isShiftBossOnly =
        isShiftBossProfile(profile) && !isAdminProfile(profile);

    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Shift Boss Appointment'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: !canAccess
          ? _AccessDeniedCard()
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: PageBody(
                  maxWidth: 880,
                  child: AbsorbPointer(
                    absorbing: _isViewMode,
                    child: Card(
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                            color: scheme.primaryContainer,
                            child: Row(
                              children: [
                                Icon(
                                  Icons.description_outlined,
                                  color: scheme.onPrimaryContainer,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Shift Boss Appointment Form',
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleLarge
                                            ?.copyWith(
                                              color: scheme.onPrimaryContainer,
                                            ),
                                      ),
                                      Text(
                                        'ASSMANG (PTY) LIMITED — Black Rock Mine Operations',
                                        style: TextStyle(
                                          color: scheme.onPrimaryContainer,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              children: [
                                _SectionHeader(title: 'Personal Information'),
                                _Grid2(
                                  children: [
                                    _tf(
                                      'title',
                                      'Title (Mr/Mrs/Miss)',
                                      _data.title,
                                      (v) => _data.title = v,
                                    ),
                                    _tf(
                                      'name',
                                      'Full Name',
                                      _data.name,
                                      (v) => _data.name = v,
                                    ),
                                    _tf(
                                      'identityNumber',
                                      'Identity Number',
                                      _data.identityNumber,
                                      (v) => _data.identityNumber = v,
                                    ),
                                    _tf(
                                      'companyNumber',
                                      'Company Number',
                                      _data.companyNumber,
                                      (v) => _data.companyNumber = v,
                                    ),
                                    _tf(
                                      'shaft',
                                      'Shaft',
                                      _data.shaft,
                                      (v) => _data.shaft = v,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 24),
                                _SectionHeader(
                                  title: 'Areas of Responsibility',
                                ),
                                _WorkplaceRow(
                                  'Stopes/Working places',
                                  _data.workplaces.stopes,
                                  (v) => _data.workplaces.stopes = v,
                                  fieldOverride: _overrides['stopes'],
                                ),
                                _WorkplaceRow(
                                  'Development ends / Vent Holings',
                                  _data.workplaces.developmentEnds,
                                  (v) => _data.workplaces.developmentEnds = v,
                                  fieldOverride: _overrides['developmentEnds'],
                                ),
                                _WorkplaceRow(
                                  'Declines',
                                  _data.workplaces.declines,
                                  (v) => _data.workplaces.declines = v,
                                  fieldOverride: _overrides['declines'],
                                ),
                                _WorkplaceRow(
                                  'Load and Haul / Roadway',
                                  _data.workplaces.loadAndHaul,
                                  (v) => _data.workplaces.loadAndHaul = v,
                                  fieldOverride: _overrides['loadAndHaul'],
                                ),
                                _WorkplaceRow(
                                  'Travelling way',
                                  _data.workplaces.travellingWay,
                                  (v) => _data.workplaces.travellingWay = v,
                                  fieldOverride: _overrides['travellingWay'],
                                ),
                                _WorkplaceRow(
                                  'Refuge Bay',
                                  _data.workplaces.refugeBay,
                                  (v) => _data.workplaces.refugeBay = v,
                                  fieldOverride: _overrides['refugeBay'],
                                ),
                                _WorkplaceRow(
                                  'Store',
                                  _data.workplaces.store,
                                  (v) => _data.workplaces.store = v,
                                  fieldOverride: _overrides['store'],
                                ),
                                _WorkplaceRow(
                                  'Waiting place',
                                  _data.workplaces.waitingPlace,
                                  (v) => _data.workplaces.waitingPlace = v,
                                  fieldOverride: _overrides['waitingPlace'],
                                ),
                                _WorkplaceRow(
                                  'Conveyor belts / Tipping area',
                                  _data.workplaces.conveyorBelts,
                                  (v) => _data.workplaces.conveyorBelts = v,
                                  fieldOverride: _overrides['conveyorBelts'],
                                ),
                                const SizedBox(height: 12),
                                _tf(
                                  'otherWorkplaces',
                                  'Any other workplaces specified',
                                  _data.workplaces.otherWorkplaces,
                                  (v) => _data.workplaces.otherWorkplaces = v,
                                ),
                                const SizedBox(height: 24),
                                _SectionHeader(title: 'Signatures'),
                                _SignatureBlock(
                                  title: 'Shift Boss',
                                  signature:
                                      _data.signatures.shiftBossSignature,
                                  onSignatureChanged: (v) => setState(
                                    () =>
                                        _data.signatures.shiftBossSignature = v,
                                  ),
                                  date: _data.signatures.shiftBossDate,
                                  onDateChanged: (v) => setState(
                                    () => _data.signatures.shiftBossDate = v,
                                  ),
                                  dateDisabled: isShiftBossOnly,
                                  signatureReadOnly:
                                      profile?.signatureData?.isNotEmpty ==
                                      true,
                                ),
                                const SizedBox(height: 16),
                                _SignatureBlock(
                                  title: 'Mine Overseer',
                                  signature:
                                      _data.signatures.mineOverseerSignature,
                                  onSignatureChanged: (v) => setState(
                                    () =>
                                        _data.signatures.mineOverseerSignature =
                                            v,
                                  ),
                                  date: _data.signatures.mineOverseerDate,
                                  onDateChanged: (v) => setState(
                                    () => _data.signatures.mineOverseerDate = v,
                                  ),
                                  dateDisabled: isShiftBossOnly,
                                  signatureReadOnly: isShiftBossOnly,
                                ),
                                const SizedBox(height: 16),
                                _SignatureBlock(
                                  title: 'Mine Manager',
                                  signature:
                                      _data.signatures.mineManagerSignature,
                                  onSignatureChanged: (v) => setState(
                                    () =>
                                        _data.signatures.mineManagerSignature =
                                            v,
                                  ),
                                  date: _data.signatures.mineManagerDate,
                                  onDateChanged: (v) => setState(
                                    () => _data.signatures.mineManagerDate = v,
                                  ),
                                  dateDisabled: isShiftBossOnly,
                                  signatureReadOnly: isShiftBossOnly,
                                ),
                                const SizedBox(height: 24),
                                FormOverlayHost(
                                  formType: 'shift_boss_appointment',
                                  values:
                                      widget
                                              .viewArgs
                                              ?.initialPayload?['overlay']
                                          as Map<String, dynamic>? ??
                                      const {},
                                  readOnly: _isViewMode,
                                  overlayOverride:
                                      widget.viewArgs?.overlayOverride,
                                  onChanged: (v) => _overlayValues = v,
                                ),
                                if (_submitError != null)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 12),
                                    child: Text(
                                      _submitError!,
                                      style: TextStyle(color: scheme.error),
                                    ),
                                  ),
                                if (!_isViewMode)
                                  Wrap(
                                    alignment: WrapAlignment.end,
                                    spacing: 12,
                                    runSpacing: 12,
                                    children: [
                                      OutlinedButton.icon(
                                        onPressed: _generatePdf,
                                        icon: const Icon(
                                          Icons.picture_as_pdf_outlined,
                                        ),
                                        label: const Text('Generate PDF'),
                                      ),
                                      FilledButton.icon(
                                        onPressed: _submitting ? null : _submit,
                                        icon: const Icon(Icons.send_outlined),
                                        label: Text(
                                          _submitting
                                              ? 'Submitting...'
                                              : 'Submit for Approval',
                                        ),
                                      ),
                                    ],
                                  ),
                                if (widget.viewArgs?.canSign ?? false)
                                  FormSignActions(
                                    viewArgs: widget.viewArgs!,
                                    onActionDone: (status) {
                                      if (context.mounted) {
                                        Navigator.of(context).pop(status);
                                      }
                                    },
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});
  final String title;
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.only(bottom: 8),
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: scheme.outlineVariant)),
      ),
      child: Text(title, style: Theme.of(context).textTheme.titleMedium),
    );
  }
}

class _Grid2 extends StatelessWidget {
  const _Grid2({required this.children});
  final List<Widget> children;
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, c) {
        final columns = c.maxWidth > 640 ? 2 : 1;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            for (final child in children)
              SizedBox(
                width: (c.maxWidth - (columns - 1) * 12) / columns,
                child: child,
              ),
          ],
        );
      },
    );
  }
}

class _TF extends StatelessWidget {
  const _TF(this.label, this.value, this.onChanged, {this.hint});
  final String label;
  final String value;
  final ValueChanged<String> onChanged;
  final String? hint;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      decoration: InputDecoration(labelText: label, hintText: hint),
    );
  }
}

class _WorkplaceRow extends StatelessWidget {
  const _WorkplaceRow(
    this.label,
    this.value,
    this.onChanged, {
    this.fieldOverride,
  });
  final String label;
  final String value;
  final ValueChanged<String> onChanged;
  final FieldOverride? fieldOverride;
  @override
  Widget build(BuildContext context) {
    if (fieldOverride?.hidden == true) return const SizedBox.shrink();
    final effectiveLabel = fieldOverride?.label ?? label;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: LayoutBuilder(
        builder: (_, c) {
          if (c.maxWidth > 720) {
            return Row(
              children: [
                SizedBox(
                  width: 240,
                  child: Text(
                    effectiveLabel,
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                ),
                Expanded(
                  child: _TF('', value, onChanged, hint: effectiveLabel),
                ),
              ],
            );
          }
          return _TF(effectiveLabel, value, onChanged);
        },
      ),
    );
  }
}

class _SignatureBlock extends StatelessWidget {
  const _SignatureBlock({
    required this.title,
    required this.signature,
    required this.onSignatureChanged,
    required this.date,
    required this.onDateChanged,
    this.dateDisabled = false,
    this.signatureReadOnly = false,
  });
  final String title;
  final String signature;
  final ValueChanged<String> onSignatureChanged;
  final String date;
  final ValueChanged<String> onDateChanged;
  final bool dateDisabled;
  final bool signatureReadOnly;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        SignatureCanvasField(
          value: signature,
          onChanged: onSignatureChanged,
          readOnly: signatureReadOnly,
        ),
        const SizedBox(height: 12),
        DatePickerField(
          value: date,
          onChanged: onDateChanged,
          disabled: dateDisabled,
        ),
      ],
    );
  }
}

class _AccessDeniedCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: PageBody(
        maxWidth: 480,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Shift Boss access required',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Your profile occupation must contain "Shift Boss" to open and sign this document.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () => context.go('/my-profile'),
                    child: const Text('Update My Profile'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
