import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../pdf/generate_special_brief_instruction_register_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';

class SpecialBriefInstructionRegisterFormScreen extends StatefulWidget {
  const SpecialBriefInstructionRegisterFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<SpecialBriefInstructionRegisterFormScreen> createState() =>
      _SpecialBriefInstructionRegisterFormScreenState();
}

class _SpecialBriefInstructionRegisterFormScreenState
    extends State<SpecialBriefInstructionRegisterFormScreen> {
  final _data = SpecialBriefInstructionRegisterFormData(
    entries: List.generate(25, (_) => SpecialBriefEntry()),
  );

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('special_brief_instruction_register');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'special_brief_instruction_register',
        'Special Brief Instruction Register',
        payload,
      );
      final doc = await generateSpecialBriefInstructionRegisterPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Special_Brief_Instruction_Register.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  /// Override-aware wrapper for a standalone display/static field.
  /// Returns null when the field is hidden via a saved override.
  Widget? _overridable(String id, Widget Function(String? label) build) {
    final ov = _overrides[id];
    if (ov?.hidden == true) return null;
    return build(ov?.label);
  }

  Widget _entryRow(int i) {
    final e = _data.entries[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 28,
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text('${i + 1}.'),
            ),
          ),
          Expanded(
            child: TextFormField(
              initialValue: e.title,
              onChanged: (v) => e.title = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Title',
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              initialValue: e.communicatedTo,
              onChanged: (v) => e.communicatedTo = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Communicated to',
              ),
            ),
          ),
          IconButton(
            onPressed: _data.entries.length <= 1
                ? null
                : () => setState(() => _data.entries.removeAt(i)),
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Remove row',
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Special Brief / Instruction Register'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Special Brief / Instruction Register',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ?_overridable(
                            'intro',
                            (label) => Text(
                              label ??
                                  'Any management brief, message or instruction must be communicated to employees. A proper register must be kept in this regard.',
                            ),
                          ),
                          const SizedBox(height: 16),
                          for (var i = 0; i < _data.entries.length; i++)
                            _entryRow(i),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: OutlinedButton.icon(
                                onPressed: () => setState(
                                  () => _data.entries.add(SpecialBriefEntry()),
                                ),
                                icon: const Icon(Icons.add),
                                label: const Text('Add Entry'),
                              ),
                            ),
                          FormOverlayHost(
                            formType: 'special_brief_instruction_register',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
