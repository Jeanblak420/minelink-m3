import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_emergency_drill_exercise_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/signature_canvas.dart';

class EmergencyDrillExerciseFormScreen extends StatefulWidget {
  const EmergencyDrillExerciseFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<EmergencyDrillExerciseFormScreen> createState() =>
      _EmergencyDrillExerciseFormScreenState();
}

class _EmergencyDrillExerciseFormScreenState
    extends State<EmergencyDrillExerciseFormScreen> {
  final _data = EmergencyDrillExerciseFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('emergency_drill_exercise');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'emergency_drill_exercise',
        'Emergency Drill Exercise',
        payload,
      );
      final doc = await generateEmergencyDrillExercisePdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Emergency_Drill_Exercise.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _yn(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return Row(
      children: [
        Expanded(child: Text(ov?.label ?? label)),
        SizedBox(
          width: 110,
          child: DropdownButtonFormField<String>(
            initialValue: value.isEmpty ? null : value,
            decoration: const InputDecoration(
              isDense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'Yes', child: Text('Yes')),
              DropdownMenuItem(value: 'No', child: Text('No')),
            ],
            onChanged: (v) => onChanged(v ?? ''),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Emergency Drill Exercise'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Emergency Drill Exercise (Fire or Event)',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _tf(
                            'Shift Boss',
                            _data.shiftBoss,
                            (v) => _data.shiftBoss = v,
                            id: 'shiftBoss',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Working Place',
                            _data.workingPlace,
                            (v) => _data.workingPlace = v,
                            id: 'workingPlace',
                          ),
                          const SizedBox(height: 12),
                          DatePickerField(
                            value: _data.dateOfExercise,
                            onChanged: (v) =>
                                setState(() => _data.dateOfExercise = v),
                            label: 'Date of Exercise',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Type of Emergency (Fire / Seismic Event)',
                            _data.typeOfEmergency,
                            (v) => _data.typeOfEmergency = v,
                            id: 'typeOfEmergency',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            '1. Alarm made at (time)',
                            _data.alarmMadeAt,
                            (v) => _data.alarmMadeAt = v,
                            id: 'alarmMadeAt',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            '2. All persons evacuated by (time)',
                            _data.allPersonsEvacuatedBy,
                            (v) => _data.allPersonsEvacuatedBy = v,
                            id: 'allPersonsEvacuatedBy',
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            '3. Routes taken to the Refuge Bay/s',
                            _data.routesTaken,
                            (v) => _data.routesTaken = v,
                            maxLines: 3,
                            id: 'routesTaken',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            '4. Procedure followed in the refuge chamber/s',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          _yn(
                            'a. Compressed air and water valves opened',
                            _data.procedureA,
                            (v) => setState(() => _data.procedureA = v),
                            id: 'procedureA',
                          ),
                          const SizedBox(height: 4),
                          _yn(
                            'b. Door closed',
                            _data.procedureB,
                            (v) => setState(() => _data.procedureB = v),
                            id: 'procedureB',
                          ),
                          const SizedBox(height: 4),
                          _yn(
                            'c. Outside siren operated',
                            _data.procedureC,
                            (v) => setState(() => _data.procedureC = v),
                            id: 'procedureC',
                          ),
                          const SizedBox(height: 4),
                          _yn(
                            'd. Gang cards checked',
                            _data.procedureD,
                            (v) => setState(() => _data.procedureD = v),
                            id: 'procedureD',
                          ),
                          const SizedBox(height: 4),
                          _yn(
                            'e. Phoned to report emergency',
                            _data.procedureE,
                            (v) => setState(() => _data.procedureE = v),
                            id: 'procedureE',
                          ),
                          const SizedBox(height: 4),
                          _yn(
                            'f. Persons instructed in the waiting place',
                            _data.procedureF,
                            (v) => setState(() => _data.procedureF = v),
                            id: 'procedureF',
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            '5.1 Rescuing of injured / trapped workers',
                            _data.rescuingInjuredWorkers,
                            (v) => _data.rescuingInjuredWorkers = v,
                            maxLines: 3,
                            id: 'rescuingInjuredWorkers',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            '5.2 Extinguishing a fire which has just started',
                            _data.extinguishingFire,
                            (v) => _data.extinguishingFire = v,
                            maxLines: 3,
                            id: 'extinguishingFire',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            '5.3 A major fire or explosion',
                            _data.majorFireOrExplosion,
                            (v) => _data.majorFireOrExplosion = v,
                            maxLines: 3,
                            id: 'majorFireOrExplosion',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            '6. General remarks',
                            _data.generalRemarks,
                            (v) => _data.generalRemarks = v,
                            maxLines: 3,
                            id: 'generalRemarks',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.shiftBossSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'emergency_drill_exercise',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
