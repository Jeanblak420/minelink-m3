import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../providers/theme_provider.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';

/// Top-level theme modes shown as chips. 'custom' carries a separate
/// light/dark base toggle that maps to 'custom' / 'custom_dark'.
const _modeChips = <(String, String, IconData)>[
  ('light', 'Light', Icons.light_mode_outlined),
  ('dark', 'Dark', Icons.dark_mode_outlined),
  ('custom', 'Custom', Icons.palette_outlined),
];

const _presets = <String>[
  '#6750A4',
  '#1B6AC9',
  '#0E7C7B',
  '#388E3C',
  '#D81B60',
  '#F57C00',
  '#5D4037',
  '#455A64',
];

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _mode = 'light';
  String _color = '#6750A4';
  final TextEditingController _hexController = TextEditingController();
  bool _initialised = false;
  bool _saving = false;
  bool _saved = false;
  String? _error;

  bool get _isCustom => _mode == 'custom' || _mode == 'custom_dark';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    final theme = context.read<ThemeProvider>();
    _mode = theme.themeMode;
    _color = theme.customThemeColor;
    _hexController.text = _color;
  }

  @override
  void dispose() {
    _hexController.dispose();
    // Revert the live preview if the user leaves without saving.
    try {
      context.read<ThemeProvider>().clearPreview();
    } catch (_) {
      /* provider already disposed */
    }
    super.dispose();
  }

  void _applyMode(String mode) {
    setState(() => _mode = mode);
    context.read<ThemeProvider>().preview(mode: mode);
  }

  void _selectModeChip(String chip) {
    if (chip == 'custom') {
      // Keep the current custom base if already custom, else default to light.
      _applyMode(_mode == 'custom_dark' ? 'custom_dark' : 'custom');
    } else {
      _applyMode(chip);
    }
  }

  /// Called while the user types in the hex field — updates state + preview but
  /// must NOT write back to the controller (that would move the caret).
  void _applyColor(String color) {
    setState(() => _color = color);
    if (RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(color)) {
      context.read<ThemeProvider>().preview(color: color);
    }
  }

  /// Called by sliders / presets — also syncs the hex field text.
  void _setColorAndField(String color) {
    _hexController.text = color;
    _applyColor(color);
  }

  Future<void> _save() async {
    setState(() {
      _saving = true;
      _saved = false;
      _error = null;
    });
    try {
      await context.read<ThemeProvider>().commit(_mode, _color);
      if (!mounted) return;
      setState(() => _saved = true);
      Future.delayed(const Duration(milliseconds: 2500), () {
        if (mounted) setState(() => _saved = false);
      });
    } catch (err) {
      if (!mounted) return;
      setState(() => _error = err.toString());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  (int, int, int) _rgb() {
    final hex = RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(_color)
        ? _color
        : '#6750A4';
    final v = int.parse(hex.substring(1), radix: 16);
    return ((v >> 16) & 0xff, (v >> 8) & 0xff, v & 0xff);
  }

  void _setChannel({int? r, int? g, int? b}) {
    final (cr, cg, cb) = _rgb();
    final nr = r ?? cr, ng = g ?? cg, nb = b ?? cb;
    final hex =
        '#${nr.toRadixString(16).padLeft(2, '0')}${ng.toRadixString(16).padLeft(2, '0')}${nb.toRadixString(16).padLeft(2, '0')}';
    _setColorAndField(hex.toUpperCase());
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: commonAppBarActions(),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 720,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Appearance',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  'Saved to your profile — your theme follows you on every device '
                  'and the next time you sign in.',
                  style: TextStyle(color: scheme.onSurfaceVariant),
                ),
                const SizedBox(height: 16),
                Card(
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _label(context, 'Theme mode'),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final option in _modeChips)
                              ChoiceChip(
                                label: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(option.$3, size: 18),
                                    const SizedBox(width: 6),
                                    Text(option.$2),
                                  ],
                                ),
                                selected: option.$1 == 'custom'
                                    ? _isCustom
                                    : _mode == option.$1,
                                onSelected: (_) => _selectModeChip(option.$1),
                              ),
                          ],
                        ),
                        if (_isCustom) ...[
                          const SizedBox(height: 20),
                          _label(context, 'Base'),
                          const SizedBox(height: 8),
                          SegmentedButton<String>(
                            segments: const [
                              ButtonSegment(
                                value: 'custom',
                                label: Text('Light'),
                                icon: Icon(Icons.light_mode_outlined),
                              ),
                              ButtonSegment(
                                value: 'custom_dark',
                                label: Text('Dark'),
                                icon: Icon(Icons.dark_mode_outlined),
                              ),
                            ],
                            selected: {_mode},
                            onSelectionChanged: (s) => _applyMode(s.first),
                          ),
                          const SizedBox(height: 20),
                          _label(context, 'Accent colour'),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: _swatchColor(_color),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: scheme.outlineVariant,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: TextField(
                                  controller: _hexController,
                                  decoration: const InputDecoration(
                                    labelText: 'Hex',
                                    hintText: '#6750A4',
                                  ),
                                  onChanged: _applyColor,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          _rgbSliders(context),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              for (final preset in _presets)
                                _SwatchButton(
                                  hex: preset,
                                  selected:
                                      preset.toLowerCase() ==
                                      _color.toLowerCase(),
                                  onTap: () => _setColorAndField(preset),
                                ),
                            ],
                          ),
                        ],
                        const SizedBox(height: 20),
                        _label(context, 'Preview'),
                        const SizedBox(height: 10),
                        const _ThemePreview(),
                        if (_error != null) ...[
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: scheme.errorContainer.withValues(
                                alpha: 0.6,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _error!,
                              style: TextStyle(color: scheme.onErrorContainer),
                            ),
                          ),
                        ],
                        const SizedBox(height: 20),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: FilledButton.icon(
                            onPressed: _saving ? null : _save,
                            icon: Icon(
                              _saved
                                  ? Icons.check_circle_outline
                                  : Icons.save_outlined,
                            ),
                            label: Text(
                              _saved
                                  ? 'Saved'
                                  : (_saving ? 'Saving...' : 'Save settings'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(BuildContext context, String text) => Text(
    text,
    style: Theme.of(
      context,
    ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
  );

  Widget _rgbSliders(BuildContext context) {
    final (r, g, b) = _rgb();
    Widget slider(String name, int value, Color color, ValueChanged<int> onCh) {
      return Row(
        children: [
          SizedBox(
            width: 16,
            child: Text(
              name,
              style: TextStyle(fontWeight: FontWeight.w700, color: color),
            ),
          ),
          Expanded(
            child: Slider(
              value: value.toDouble(),
              min: 0,
              max: 255,
              activeColor: color,
              onChanged: (v) => onCh(v.round()),
            ),
          ),
          SizedBox(width: 32, child: Text('$value', textAlign: TextAlign.end)),
        ],
      );
    }

    return Column(
      children: [
        slider('R', r, Colors.red.shade600, (v) => _setChannel(r: v)),
        slider('G', g, Colors.green.shade600, (v) => _setChannel(g: v)),
        slider('B', b, Colors.blue.shade600, (v) => _setChannel(b: v)),
      ],
    );
  }
}

Color _swatchColor(String hex) {
  final h = RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(hex) ? hex : '#6750A4';
  return Color(0xFF000000 | int.parse(h.substring(1), radix: 16));
}

/// A small labelled sample of the live theme so the user sees how surfaces,
/// cards, buttons, chips, and the sidebar will look before saving.
class _ThemePreview extends StatelessWidget {
  const _ThemePreview();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final sidebarBg = Color.alphaBlend(
      scheme.primary.withValues(alpha: 0.07),
      scheme.surface,
    );
    return Container(
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: scheme.outlineVariant),
      ),
      clipBehavior: Clip.antiAlias,
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Mini sidebar strip.
            Container(
              width: 56,
              color: sidebarBg,
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Column(
                children: [
                  Icon(
                    Icons.dashboard_outlined,
                    size: 20,
                    color: scheme.primary,
                  ),
                  const SizedBox(height: 14),
                  Icon(
                    Icons.assignment_outlined,
                    size: 20,
                    color: scheme.primary,
                  ),
                  const SizedBox(height: 14),
                  Icon(
                    Icons.settings_outlined,
                    size: 20,
                    color: scheme.primary,
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Card(
                      margin: EdgeInsets.zero,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Sample card',
                              style: Theme.of(context).textTheme.titleSmall,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Body text on a surface',
                              style: TextStyle(
                                fontSize: 12,
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        FilledButton(
                          onPressed: () {},
                          child: const Text('Primary'),
                        ),
                        OutlinedButton(
                          onPressed: () {},
                          child: const Text('Outline'),
                        ),
                        Chip(
                          label: const Text('Chip'),
                          backgroundColor: scheme.primaryContainer,
                          labelStyle: TextStyle(
                            color: scheme.onPrimaryContainer,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SwatchButton extends StatelessWidget {
  const _SwatchButton({
    required this.hex,
    required this.selected,
    required this.onTap,
  });

  final String hex;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = Color(0xFF000000 | int.parse(hex.substring(1), radix: 16));
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? scheme.primary : scheme.outlineVariant,
            width: selected ? 2.5 : 1,
          ),
        ),
        child: selected
            ? const Icon(Icons.check, size: 18, color: Colors.white)
            : null,
      ),
    );
  }
}
