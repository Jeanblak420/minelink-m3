import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_late_shift_record_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class LateShiftRecordFormScreen extends StatefulWidget {
  const LateShiftRecordFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<LateShiftRecordFormScreen> createState() =>
      _LateShiftRecordFormScreenState();
}

class _LateShiftRecordFormScreenState extends State<LateShiftRecordFormScreen> {
  final _data = LateShiftRecordFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};
  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('late_shift_record');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
        if (_data.shiftBossSignatureDate.trim().isEmpty) {
          _data.shiftBossSignatureDate = _today;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateLateShiftRecordPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Late_Shift_Record.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'late_shift_record',
        _data.date.isNotEmpty
            ? 'Late Shift Record — ${_data.date}'
            : 'Late Shift Record',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _yn(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? detailsValue,
    ValueChanged<String>? onDetailsChanged,
    String detailsLabel = 'If "No" give details and remedial action:',
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: Text(ov?.label ?? label)),
              SizedBox(
                width: 110,
                child: DropdownButtonFormField<String>(
                  initialValue: value.isEmpty ? null : value,
                  decoration: const InputDecoration(
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 8,
                    ),
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'Yes', child: Text('Yes')),
                    DropdownMenuItem(value: 'No', child: Text('No')),
                  ],
                  onChanged: (v) => onChanged(v ?? ''),
                ),
              ),
            ],
          ),
          if (onDetailsChanged != null && value == 'No') ...[
            const SizedBox(height: 8),
            TextFormField(
              initialValue: detailsValue,
              onChanged: onDetailsChanged,
              maxLines: 2,
              decoration: InputDecoration(labelText: detailsLabel),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Late Shift Record'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Late Shift Record',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _tf(
                            'Section',
                            _data.section,
                            (v) => _data.section = v,
                            id: 'section',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Strike',
                            _data.strike,
                            (v) => _data.strike = v,
                            id: 'strike',
                          ),
                          const SizedBox(height: 12),
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Miner in charge Coy No.',
                            _data.minerInChargeCoyNo,
                            (v) => _data.minerInChargeCoyNo = v,
                            id: 'minerInChargeCoyNo',
                          ),
                          const SizedBox(height: 16),
                          const Divider(),
                          const SizedBox(height: 8),
                          _yn(
                            'Charges correctly prepared?',
                            _data.chargesCorrectlyPrepared,
                            (v) => setState(
                              () => _data.chargesCorrectlyPrepared = v,
                            ),
                            detailsValue: _data.chargesDetails,
                            onDetailsChanged: (v) => _data.chargesDetails = v,
                            id: 'chargesCorrectlyPrepared',
                          ),
                          _tf(
                            'Charging up development end no.',
                            _data.chargingUpDevEndNo,
                            (v) => _data.chargingUpDevEndNo = v,
                            id: 'chargingUpDevEndNo',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Vent holing no.',
                            _data.ventHolingNo,
                            (v) => _data.ventHolingNo = v,
                            id: 'ventHolingNo',
                          ),
                          _yn(
                            'Explosive correctly transported to the face?',
                            _data.explosiveCorrectlyTransported,
                            (v) => setState(
                              () => _data.explosiveCorrectlyTransported = v,
                            ),
                            id: 'explosiveCorrectlyTransported',
                          ),
                          _yn(
                            'Tested for flammable gas and CO gas with a GDI?',
                            _data.testedForFlammableGas,
                            (v) =>
                                setState(() => _data.testedForFlammableGas = v),
                            id: 'testedForFlammableGas',
                          ),
                          _tf(
                            'GDI No.',
                            _data.gdiNo,
                            (v) => _data.gdiNo = v,
                            id: 'gdiNo',
                          ),
                          _yn(
                            'Was charging done under direct supervision of Miner?',
                            _data.chargingUnderDirectSupervision,
                            (v) => setState(
                              () => _data.chargingUnderDirectSupervision = v,
                            ),
                            id: 'chargingUnderDirectSupervision',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Type of explosives used',
                            _data.typeOfExplosivesUsed,
                            (v) => _data.typeOfExplosivesUsed = v,
                            id: 'typeOfExplosivesUsed',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Type of fuse used',
                            _data.typeOfFuseUsed,
                            (v) => _data.typeOfFuseUsed = v,
                            id: 'typeOfFuseUsed',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Fuse length',
                            _data.fuseLength,
                            (v) => _data.fuseLength = v,
                            id: 'fuseLength',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Amount of fuses used',
                            _data.amountOfFusesUsed,
                            (v) => _data.amountOfFusesUsed = v,
                            id: 'amountOfFusesUsed',
                          ),
                          _yn(
                            'Where holes dislodged correctly?',
                            _data.holesDislodgedCorrectly,
                            (v) => setState(
                              () => _data.holesDislodgedCorrectly = v,
                            ),
                            detailsValue: _data.holesDislodgedDetails,
                            onDetailsChanged: (v) =>
                                _data.holesDislodgedDetails = v,
                            id: 'holesDislodgedCorrectly',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Length of drill holes',
                            _data.lengthOfDrillHoles,
                            (v) => _data.lengthOfDrillHoles = v,
                            id: 'lengthOfDrillHoles',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Length of blow pipe',
                            _data.lengthOfBlowPipe,
                            (v) => _data.lengthOfBlowPipe = v,
                            id: 'lengthOfBlowPipe',
                          ),
                          _yn(
                            'Blasting cable installed to standard?',
                            _data.blastingCableToStandard,
                            (v) => setState(
                              () => _data.blastingCableToStandard = v,
                            ),
                            detailsValue: _data.blastingCableDetails,
                            onDetailsChanged: (v) =>
                                _data.blastingCableDetails = v,
                            id: 'blastingCableToStandard',
                          ),
                          _yn(
                            'Circuit tested?',
                            _data.circuitTested,
                            (v) => setState(() => _data.circuitTested = v),
                            id: 'circuitTested',
                          ),
                          _yn(
                            'Blasting cable connected correctly to terminal box?',
                            _data.blastingCableConnectedToTerminalBox,
                            (v) => setState(
                              () =>
                                  _data.blastingCableConnectedToTerminalBox = v,
                            ),
                            detailsValue: _data.blastingCableTerminalDetails,
                            onDetailsChanged: (v) =>
                                _data.blastingCableTerminalDetails = v,
                            id: 'blastingCableConnectedToTerminalBox',
                          ),
                          _yn(
                            'Distribution of old explosives observed?',
                            _data.distributionOfOldExplosivesObserved,
                            (v) => setState(
                              () =>
                                  _data.distributionOfOldExplosivesObserved = v,
                            ),
                            id: 'distributionOfOldExplosivesObserved',
                          ),
                          _yn(
                            'Distribution of old explosives discussed?',
                            _data.distributionOfOldExplosivesDiscussed,
                            (v) => setState(
                              () => _data.distributionOfOldExplosivesDiscussed =
                                  v,
                            ),
                            id: 'distributionOfOldExplosivesDiscussed',
                          ),
                          _yn(
                            'Working place barricade in position?',
                            _data.workingPlaceBarricadeInPosition,
                            (v) => setState(
                              () => _data.workingPlaceBarricadeInPosition = v,
                            ),
                            id: 'workingPlaceBarricadeInPosition',
                          ),
                          _yn(
                            'Explosive boxes locked?',
                            _data.explosiveBoxesLocked,
                            (v) =>
                                setState(() => _data.explosiveBoxesLocked = v),
                            detailsValue: _data.barricadeExplosiveDetails,
                            onDetailsChanged: (v) =>
                                _data.barricadeExplosiveDetails = v,
                            id: 'explosiveBoxesLocked',
                          ),
                          _yn(
                            'Were ID cards correctly issued?',
                            _data.idCardsCorrectlyIssued,
                            (v) => setState(
                              () => _data.idCardsCorrectlyIssued = v,
                            ),
                            id: 'idCardsCorrectlyIssued',
                          ),
                          _yn(
                            'Air and water hoses closed?',
                            _data.airAndWaterHosesClosed,
                            (v) => setState(
                              () => _data.airAndWaterHosesClosed = v,
                            ),
                            id: 'airAndWaterHosesClosed',
                          ),
                          _yn(
                            'Any incident /injuries reported?',
                            _data.anyIncidentInjuriesReported,
                            (v) => setState(
                              () => _data.anyIncidentInjuriesReported = v,
                            ),
                            id: 'anyIncidentInjuriesReported',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Arrived on surface at (am/pm)',
                            _data.arrivedOnSurfaceAt,
                            (v) => _data.arrivedOnSurfaceAt = v,
                            id: 'arrivedOnSurfaceAt',
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            'Special instructions given',
                            _data.specialInstructionsGiven,
                            (v) => _data.specialInstructionsGiven = v,
                            maxLines: 3,
                            id: 'specialInstructionsGiven',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Additional remarks',
                            _data.additionalRemarks,
                            (v) => _data.additionalRemarks = v,
                            maxLines: 3,
                            id: 'additionalRemarks',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.shiftBossSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Miner Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.minerOverseerSignature,
                            onChanged: (v) => setState(
                              () => _data.minerOverseerSignature = v,
                            ),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.minerOverseerSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.minerOverseerSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'late_shift_record',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: const Text('Generate PDF'),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
