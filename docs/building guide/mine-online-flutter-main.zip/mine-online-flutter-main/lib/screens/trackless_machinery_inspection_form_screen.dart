import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_trackless_machinery_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

const List<String> _itemLabels = [
  'Operator trained?',
  'Operator licence available?',
  'Pre-use checklist available?',
  'Pre-use checklist completed according to requirements?',
  'Operator wearing correct PPE?',
  'Operator wearing safety belt?',
];

class TracklessMachineryInspectionFormScreen extends StatefulWidget {
  const TracklessMachineryInspectionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<TracklessMachineryInspectionFormScreen> createState() =>
      _TracklessMachineryInspectionFormScreenState();
}

class _TracklessMachineryInspectionFormScreenState
    extends State<TracklessMachineryInspectionFormScreen> {
  final _data = TracklessMachineryFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _generating = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};
  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('trackless_machinery_inspection');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftbossSignature.trim().isEmpty) {
          _data.shiftbossSignature = savedSig;
        }
        if (_data.shiftbossSignatureDate.trim().isEmpty) {
          _data.shiftbossSignatureDate = _today;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final doc = await generateTracklessMachineryPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Trackless_Machinery_Inspection.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final first = _data.inspections.isNotEmpty
          ? _data.inspections.first.dateOfInspection
          : '';
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'trackless_machinery_inspection',
        first.isNotEmpty
            ? 'Trackless Machinery Inspection — $first'
            : 'Trackless Machinery Inspection',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _yn(String value, ValueChanged<String> onChanged, {String? id}) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return SizedBox(
      width: 90,
      child: DropdownButtonFormField<String>(
        initialValue: value.isEmpty ? null : value,
        decoration: InputDecoration(
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 8,
          ),
          border: const OutlineInputBorder(),
          hintText: ov?.label ?? 'Yes/No',
        ),
        items: const [
          DropdownMenuItem(value: 'Yes', child: Text('Yes')),
          DropdownMenuItem(value: 'No', child: Text('No')),
        ],
        onChanged: (v) => onChanged(v ?? ''),
      ),
    );
  }

  Widget _entryBlock(int index, TracklessMachineryEntry e) {
    final pairs =
        <
          (String, String, void Function(String), String, void Function(String))
        >[
          (
            _itemLabels[0],
            e.operatorTrained,
            (v) => e.operatorTrained = v,
            e.operatorTrained_remedial,
            (v) => e.operatorTrained_remedial = v,
          ),
          (
            _itemLabels[1],
            e.operatorLicence,
            (v) => e.operatorLicence = v,
            e.operatorLicence_remedial,
            (v) => e.operatorLicence_remedial = v,
          ),
          (
            _itemLabels[2],
            e.preUseChecklistAvailable,
            (v) => e.preUseChecklistAvailable = v,
            e.preUseChecklistAvailable_remedial,
            (v) => e.preUseChecklistAvailable_remedial = v,
          ),
          (
            _itemLabels[3],
            e.preUseChecklistCompleted,
            (v) => e.preUseChecklistCompleted = v,
            e.preUseChecklistCompleted_remedial,
            (v) => e.preUseChecklistCompleted_remedial = v,
          ),
          (
            _itemLabels[4],
            e.correctPPE,
            (v) => e.correctPPE = v,
            e.correctPPE_remedial,
            (v) => e.correctPPE_remedial = v,
          ),
          (
            _itemLabels[5],
            e.safetyBelt,
            (v) => e.safetyBelt = v,
            e.safetyBelt_remedial,
            (v) => e.safetyBelt_remedial = v,
          ),
        ];

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Inspection ${index + 1}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 12),
            DatePickerField(
              value: e.dateOfInspection,
              onChanged: (v) => setState(() => e.dateOfInspection = v),
              label: 'Date of inspection',
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    initialValue: e.operatorCoyNumber,
                    onChanged: (v) => e.operatorCoyNumber = v,
                    decoration: const InputDecoration(
                      labelText: 'Operator Coy Number',
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    initialValue: e.machineNumber,
                    onChanged: (v) => e.machineNumber = v,
                    decoration: const InputDecoration(
                      labelText: 'Machine Number',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            for (var i = 0; i < pairs.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 28,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 14),
                        child: Text('${i + 1}.'),
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 14, right: 8),
                        child: Text(pairs[i].$1),
                      ),
                    ),
                    _yn(pairs[i].$2, (v) => setState(() => pairs[i].$3(v))),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 4,
                      child: TextFormField(
                        initialValue: pairs[i].$4,
                        onChanged: pairs[i].$5,
                        decoration: const InputDecoration(
                          isDense: true,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 12,
                          ),
                          border: OutlineInputBorder(),
                          hintText: 'Remedial action',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Trackless Machinery Inspection'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 1080,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Weekly Trackless Mobile Machinery Over-Inspection',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          for (var i = 0; i < _data.inspections.length; i++)
                            _entryBlock(i, _data.inspections[i]),
                          const SizedBox(height: 24),
                          Text(
                            'Shiftboss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftbossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftbossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftbossSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.shiftbossSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineOverseerSignature,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.mineOverseerSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.mineOverseerSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'trackless_machinery_inspection',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generating ? null : _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: Text(
                                    _generating
                                        ? 'Generating...'
                                        : 'Generate PDF',
                                  ),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
