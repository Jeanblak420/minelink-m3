import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/empty_state.dart';
import '../widgets/mobile_bottom_nav.dart';
import '../widgets/page_body.dart';

class _Card {
  const _Card({
    required this.route,
    required this.icon,
    required this.title,
    required this.description,
    this.requiresShiftBoss = false,
  });

  final String route;
  final IconData icon;
  final String title;
  final String description;
  final bool requiresShiftBoss;
}

const _cards = <_Card>[
  _Card(
    route: '/my-appointments',
    icon: Icons.how_to_reg_outlined,
    title: 'My Appointments',
    description: 'View and accept appointments issued to you',
  ),
  _Card(
    route: '/shift-boss',
    icon: Icons.description_outlined,
    title: 'Shift Boss Appointment Form',
    description: 'Create shift boss appointment forms',
    requiresShiftBoss: true,
  ),
  _Card(
    route: '/miner-appointment',
    icon: Icons.description_outlined,
    title: 'Miner Appointment Form',
    description: 'Create miner appointment forms',
  ),
  _Card(
    route: '/relieving-miner',
    icon: Icons.description_outlined,
    title: 'Relieving Miner Appointment Form',
    description: 'Create relieving miner appointment forms',
  ),
  _Card(
    route: '/safety-health-rep',
    icon: Icons.shield_outlined,
    title: 'Safety & Health Representative Appointment',
    description: 'Create safety & health representative forms',
  ),
  _Card(
    route: '/machinery-operators',
    icon: Icons.handyman_outlined,
    title: 'Machinery Operators Appointments',
    description: 'Create machinery operators appointment forms',
  ),
  _Card(
    route: '/shift-boss-daily-report',
    icon: Icons.assignment_outlined,
    title: 'Shift Boss Daily Report',
    description: 'Create shift boss daily report forms',
  ),
  _Card(
    route: '/gassing-incident',
    icon: Icons.warning_amber_outlined,
    title: 'Gassing / Smoke / Dust / Incident Record',
    description: 'Gassing / Smoke / Dust / Incident Record',
  ),
  _Card(
    route: '/weekly-sherq-meeting',
    icon: Icons.groups_outlined,
    title: 'Weekly SHERQ Meeting',
    description: 'Create weekly SHERQ meeting forms',
  ),
  _Card(
    route: '/early-shift-record',
    icon: Icons.schedule_outlined,
    title: 'Early Shift Record',
    description: 'Early shift inspection record form',
  ),
  _Card(
    route: '/late-shift-record',
    icon: Icons.nightlight_outlined,
    title: 'Late Shift Record',
    description: 'Late shift blasting inspection record form',
  ),
  _Card(
    route: '/explosive-control-record',
    icon: Icons.inventory_2_outlined,
    title: 'Explosive Control Record',
    description: 'Explosive box inspection and control record form',
  ),
  _Card(
    route: '/waiting-place-inspection',
    icon: Icons.assignment_turned_in_outlined,
    title: 'Waiting Place Inspection Record',
    description: 'Waiting place & underground portable toilet inspection',
  ),
  _Card(
    route: '/refuge-bay-inspection',
    icon: Icons.shield_outlined,
    title: 'Refuge Bay Inspection Record',
    description: 'Refuge bay life sustainability inspection record',
  ),
  _Card(
    route: '/trackless-machinery-inspection',
    icon: Icons.local_shipping_outlined,
    title: 'Weekly Trackless Mobile Machinery Over-Inspection',
    description: 'Weekly trackless mobile machinery over-inspection',
  ),
  _Card(
    route: '/conveyor-belt-inspection',
    icon: Icons.settings_outlined,
    title: 'Weekly Strike Conveyor Belt Inspection',
    description: 'Weekly strike conveyor belt walkways & belt condition',
  ),
  _Card(
    route: '/rock-breaker-inspection',
    icon: Icons.gavel_outlined,
    title: 'Weekly Rock Breaker Inspection',
    description: 'Weekly rock breaker equipment inspection checklist',
  ),
  _Card(
    route: '/belt-tip-area-inspection',
    icon: Icons.layers_outlined,
    title: 'Weekly Belt Tip Area Inspection',
    description: 'Weekly belt tip area condition inspection checklist',
  ),
  _Card(
    route: '/action-log-underground-visits',
    icon: Icons.menu_book_outlined,
    title: "Action Log of Senior Official's Underground Visits",
    description:
        'Log deviations and remedial actions from senior official underground visits',
  ),
  _Card(
    route: '/special-instruction',
    icon: Icons.report_problem_outlined,
    title: 'Special Instruction',
    description:
        'Issue special instructions for worker safety and health compliance',
  ),
  _Card(
    route: '/inspection-control-sheet',
    icon: Icons.grid_view_outlined,
    title: 'Inspection Control Sheet',
    description: 'Monthly workplace inspection schedule and control sheet',
  ),
  _Card(
    route: '/planned-task-observation',
    icon: Icons.checklist_outlined,
    title: 'Control Sheet - Planned Task Observation',
    description: 'Planned task observation frequency tracking control sheet',
  ),
  _Card(
    route: '/special-brief-instruction-register',
    icon: Icons.chat_bubble_outline,
    title: 'Special Brief / Instruction Register',
    description:
        'Register of special briefs and instructions communicated to crew',
  ),
  _Card(
    route: '/verbal-emergency-drills',
    icon: Icons.mic_none_outlined,
    title: 'Verbal Emergency Drills',
    description: 'Monthly verbal emergency drill attendance record',
  ),
  _Card(
    route: '/physical-emergency-drills',
    icon: Icons.directions_run_outlined,
    title: 'Physical Emergency Drills',
    description: 'Quarterly physical emergency drill attendance record',
  ),
  _Card(
    route: '/emergency-drill-exercise',
    icon: Icons.local_fire_department_outlined,
    title: 'Emergency Drill Exercise (Fire or Event)',
    description: 'Emergency evacuation drill exercise record',
  ),
  _Card(
    route: '/monthly-fire-fighting-inspection',
    icon: Icons.fire_extinguisher,
    title: 'Monthly Fire Fighting Equipment Inspection Report',
    description: 'Monthly fire fighting equipment inspection',
  ),
  _Card(
    route: '/lockout-lock-scissor-checklist',
    icon: Icons.lock_outline,
    title: 'Monthly Lock-out Lock and Scissor Checklist',
    description: 'Monthly lock-out equipment availability and training',
  ),
];

class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});

  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  bool _matches(_Card c, String query) {
    if (query.isEmpty) return true;
    final q = query.toLowerCase();
    return c.title.toLowerCase().contains(q) ||
        c.description.toLowerCase().contains(q);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    final accessible = _cards
        .where(
          (c) => !c.requiresShiftBoss || canAccessShiftBossDocuments(profile),
        )
        .toList(growable: false);
    final visible = accessible
        .where((c) => _matches(c, _query))
        .toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Appointments'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: commonAppBarActions(),
      ),
      bottomNavigationBar: const MobileBottomNav(location: '/appointments'),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: PageBody.list(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    'Select a form to create an appointment',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: scheme.onSurfaceVariant),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: (v) => setState(() => _query = v),
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: 'Search forms by name or description',
                      suffixIcon: _query.isEmpty
                          ? null
                          : IconButton(
                              tooltip: 'Clear',
                              icon: const Icon(Icons.close),
                              onPressed: () {
                                _searchCtrl.clear();
                                setState(() => _query = '');
                              },
                            ),
                    ),
                  ),
                ),
                if (visible.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: EmptyState(
                      icon: Icons.search_off,
                      title: 'No forms match',
                      body: 'Try a different search term.',
                    ),
                  )
                else
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final width = constraints.maxWidth;
                      final cols = width >= 1100
                          ? 4
                          : width >= 820
                          ? 3
                          : width >= 540
                          ? 2
                          : 1;
                      return GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: cols,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 16,
                          childAspectRatio: cols == 1 ? 2.4 : 1.05,
                        ),
                        itemCount: visible.length,
                        itemBuilder: (_, i) => _CardTile(visible[i]),
                      );
                    },
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CardTile extends StatefulWidget {
  const _CardTile(this.card);

  final _Card card;

  @override
  State<_CardTile> createState() => _CardTileState();
}

class _CardTileState extends State<_CardTile> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      cursor: SystemMouseCursors.click,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        decoration: BoxDecoration(
          color: _hover ? tones.navySoft : scheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _hover ? tones.navy.withValues(alpha: 0.35) : tones.line,
            width: _hover ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: _hover ? 0.06 : 0.02),
              blurRadius: _hover ? 10 : 4,
              offset: Offset(0, _hover ? 4 : 2),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => context.go(widget.card.route),
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: tones.navySoft,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(widget.card.icon, size: 30, color: tones.navy),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    widget.card.title,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    widget.card.description,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: scheme.onSurfaceVariant,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
