import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_gassing_incident_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class GassingIncidentFormScreen extends StatefulWidget {
  const GassingIncidentFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<GassingIncidentFormScreen> createState() =>
      _GassingIncidentFormScreenState();
}

class _GassingIncidentFormScreenState extends State<GassingIncidentFormScreen> {
  final _data = GassingIncidentFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('gassing_incident');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateGassingIncidentPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Gassing_Smoke_Dust_Incident_Record.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'gassing_incident',
        _data.date.isNotEmpty
            ? 'Gassing Incident Record — ${_data.date}'
            : 'Gassing Incident Record',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Gassing / Smoke / Dust / Incident'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Gassing / Smoke / Dust / Incident Record',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                            label: 'Date',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Coy No. of Injured',
                            _data.coyNoOfInjured,
                            (v) => _data.coyNoOfInjured = v,
                            id: 'coyNoOfInjured',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Time',
                            _data.time,
                            (v) => _data.time = v,
                            id: 'time',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Working Place',
                            _data.workingPlace,
                            (v) => _data.workingPlace = v,
                            id: 'workingPlace',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Severity',
                            _data.severity,
                            (v) => _data.severity = v,
                            id: 'severity',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Description',
                            _data.description,
                            (v) => _data.description = v,
                            maxLines: 5,
                            id: 'description',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Injuries',
                            _data.injuries,
                            (v) => _data.injuries = v,
                            maxLines: 2,
                            id: 'injuries',
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineOverseerSignature,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerSignature = v),
                          ),
                          FormOverlayHost(
                            formType: 'gassing_incident',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: const Text('Generate PDF'),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
