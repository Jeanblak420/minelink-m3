import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../pdf/generate_lockout_checklist_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/signature_canvas.dart';

class LockoutLockScissorChecklistFormScreen extends StatefulWidget {
  const LockoutLockScissorChecklistFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<LockoutLockScissorChecklistFormScreen> createState() =>
      _LockoutLockScissorChecklistFormScreenState();
}

class _LockoutLockScissorChecklistFormScreenState
    extends State<LockoutLockScissorChecklistFormScreen> {
  final _data = LockoutLockScissorChecklistFormData(
    entries: List.generate(20, (_) => LockoutChecklistEntry()),
  );

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  // ignore: unused_field
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('lockout_lock_scissor_checklist');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final doc = await generateLockoutChecklistPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'lockout-lock-scissor-checklist.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  void _addRow() {
    setState(() => _data.entries.add(LockoutChecklistEntry()));
  }

  void _removeRow(int i) {
    if (_data.entries.length <= 1) return;
    setState(() => _data.entries.removeAt(i));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Lockout Lock & Scissor Checklist'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => context.canPop()
                    ? context.pop()
                    : context.go('/appointments'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: PageBody.form(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: AbsorbPointer(
              absorbing: _isViewMode,
              child: Column(
                children: [
                  Card(
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      children: [
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            columnSpacing: 12,
                            columns: const [
                              DataColumn(label: Text('#')),
                              DataColumn(label: Text('Name & Surname')),
                              DataColumn(label: Text('Operator / Assistant')),
                              DataColumn(label: Text('Workplace')),
                              DataColumn(label: Text('Trained on\nLock Out')),
                              DataColumn(label: Text('Lock\nAvailable')),
                              DataColumn(label: Text('Scissor\nAvailable')),
                              DataColumn(label: Text('Date')),
                              DataColumn(label: Text('Signature')),
                              DataColumn(label: Text('')),
                            ],
                            rows: [
                              for (var i = 0; i < _data.entries.length; i++)
                                DataRow(
                                  cells: [
                                    DataCell(Text('${i + 1}')),
                                    DataCell(
                                      _cellInput(
                                        _data.entries[i].nameSurname,
                                        (v) => _data.entries[i].nameSurname = v,
                                      ),
                                    ),
                                    DataCell(
                                      _cellInput(
                                        _data.entries[i].operatorAssistant,
                                        (v) =>
                                            _data.entries[i].operatorAssistant =
                                                v,
                                      ),
                                    ),
                                    DataCell(
                                      _cellInput(
                                        _data.entries[i].workplace,
                                        (v) => _data.entries[i].workplace = v,
                                      ),
                                    ),
                                    DataCell(
                                      _yesNo(
                                        _data.entries[i].trainedOnLockOut,
                                        (v) => setState(
                                          () =>
                                              _data
                                                      .entries[i]
                                                      .trainedOnLockOut =
                                                  v,
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      _yesNo(
                                        _data.entries[i].lockAvailable,
                                        (v) => setState(
                                          () => _data.entries[i].lockAvailable =
                                              v,
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      _yesNo(
                                        _data.entries[i].scissorAvailable,
                                        (v) => setState(
                                          () =>
                                              _data
                                                      .entries[i]
                                                      .scissorAvailable =
                                                  v,
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      SizedBox(
                                        width: 130,
                                        child: DatePickerField(
                                          value: _data.entries[i].date,
                                          onChanged: (v) => setState(
                                            () => _data.entries[i].date = v,
                                          ),
                                        ),
                                      ),
                                    ),
                                    DataCell(
                                      _cellInput(
                                        _data.entries[i].signature,
                                        (v) => _data.entries[i].signature = v,
                                      ),
                                    ),
                                    DataCell(
                                      IconButton(
                                        icon: const Icon(
                                          Icons.delete_outline,
                                          size: 18,
                                        ),
                                        onPressed: _data.entries.length <= 1
                                            ? null
                                            : () => _removeRow(i),
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                        if (!_isViewMode)
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: TextButton.icon(
                                onPressed: _addRow,
                                icon: const Icon(Icons.add),
                                label: const Text('Add row'),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: scheme.errorContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'UNDER NO CIRCUMSTANCES may an Operator / Assistant perform work without lock-out equipment!!',
                      style: TextStyle(
                        color: scheme.onErrorContainer,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: SignatureCanvasField(
                        value: _data.shiftBossSignature,
                        onChanged: (v) =>
                            setState(() => _data.shiftBossSignature = v),
                        label: 'Shift Boss Signature',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FormOverlayHost(
                    formType: 'lockout_lock_scissor_checklist',
                    values:
                        widget.viewArgs?.initialPayload?['overlay']
                            as Map<String, dynamic>? ??
                        const {},
                    readOnly: _isViewMode,
                    overlayOverride: widget.viewArgs?.overlayOverride,
                    onChanged: (v) => _overlayValues = v,
                  ),
                  if (!_isViewMode)
                    Align(
                      alignment: Alignment.centerRight,
                      child: FilledButton.icon(
                        onPressed: _generating ? null : _generatePdf,
                        icon: const Icon(Icons.picture_as_pdf_outlined),
                        label: Text(
                          _generating ? 'Generating PDF...' : 'Generate PDF',
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _cellInput(
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return SizedBox(
      width: 140,
      child: TextFormField(
        initialValue: value,
        onChanged: onChanged,
        decoration: InputDecoration(
          isDense: true,
          labelText: ov?.label,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 6,
          ),
        ),
      ),
    );
  }

  Widget _yesNo(String value, ValueChanged<String> onChanged, {String? id}) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    final v = value.isEmpty ? null : value;
    return SizedBox(
      width: 80,
      child: DropdownButtonFormField<String>(
        initialValue: v,
        decoration: InputDecoration(
          isDense: true,
          labelText: ov?.label,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 6,
          ),
        ),
        items: const [
          DropdownMenuItem(value: 'YES', child: Text('YES')),
          DropdownMenuItem(value: 'NO', child: Text('NO')),
        ],
        onChanged: (val) => onChanged(val ?? ''),
      ),
    );
  }
}
