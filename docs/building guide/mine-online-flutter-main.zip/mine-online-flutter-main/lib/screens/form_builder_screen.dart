// Admin/super-admin screen to list, create, edit, archive, and restore custom
// form templates. Filling them lives in CustomFormsScreen (SP2.1b).

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../constants/account_types.dart';
import '../models/custom_form_template.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../providers/auth_provider.dart';
import '../utils/custom_form_data.dart';
import '../utils/dynamic_form_payload.dart' show kChainSignerLabels;
import '../utils/form_field_catalog.dart';
import '../utils/form_overlay_data.dart';
import '../utils/form_registry.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/form_builder/field_editor.dart';
import '../widgets/page_body.dart';

class FormBuilderScreen extends StatefulWidget {
  const FormBuilderScreen({super.key});

  @override
  State<FormBuilderScreen> createState() => _FormBuilderScreenState();
}

class _FormBuilderScreenState extends State<FormBuilderScreen> {
  bool _loading = true;
  String? _error;
  List<CustomFormTemplate> _templates = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final list = await loadTemplates(includeArchived: true);
      if (!mounted) return;
      setState(() {
        _templates = list;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _openEditor([CustomFormTemplate? existing]) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => _TemplateEditorScreen(existing: existing),
      ),
    );
    if (saved == true) _load();
  }

  Future<void> _toggleActive(CustomFormTemplate t) async {
    await setTemplateActive(t.id, !t.isActive);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Form Builder'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Form Builder is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Form Builder'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('New form'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Custom forms',
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 8),
                      if (_templates.isEmpty)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          child: Text(
                            'No custom forms yet. Tap "New form" to build one.',
                            style: TextStyle(color: scheme.onSurfaceVariant),
                          ),
                        )
                      else
                        for (final t in _templates)
                          Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              title: Text(t.name),
                              subtitle: Text(
                                '${t.fields.where((f) => f.type != FormFieldType.section).length} fields'
                                '${t.category != null && t.category!.isNotEmpty ? ' • ${t.category}' : ''}'
                                '${t.isActive ? '' : ' • archived'}',
                              ),
                              onTap: () => _openEditor(t),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'edit') _openEditor(t);
                                  if (v == 'toggle') _toggleActive(t);
                                },
                                itemBuilder: (_) => [
                                  const PopupMenuItem(
                                    value: 'edit',
                                    child: Text('Edit'),
                                  ),
                                  PopupMenuItem(
                                    value: 'toggle',
                                    child: Text(
                                      t.isActive ? 'Archive' : 'Restore',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class _TemplateEditorScreen extends StatefulWidget {
  const _TemplateEditorScreen({this.existing});
  final CustomFormTemplate? existing;

  @override
  State<_TemplateEditorScreen> createState() => _TemplateEditorScreenState();
}

class _TemplateEditorScreenState extends State<_TemplateEditorScreen> {
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _category;
  late List<FormFieldDef> _fields;
  late List<String> _audience;
  late List<String> _requiredSigners;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _description = TextEditingController(text: e?.description ?? '');
    _category = TextEditingController(text: e?.category ?? '');
    _fields = e == null ? [] : [...e.fields];
    _audience = e == null ? [] : [...e.audience];
    _requiredSigners = e == null ? [] : [...e.requiredSigners];
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _category.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final errors = validateTemplate(name: _name.text, fields: _fields);
    if (errors.isNotEmpty) {
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Fix these first'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [for (final e in errors) Text('• $e')],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      final e = widget.existing;
      final code =
          e?.code ??
          slugifyCode(
            _name.text,
            DateTime.now().microsecondsSinceEpoch.toRadixString(36),
          );
      await saveTemplate(
        id: e?.id,
        code: code,
        name: _name.text.trim(),
        description: _description.text.trim().isEmpty
            ? null
            : _description.text.trim(),
        category: _category.text.trim().isEmpty ? null : _category.text.trim(),
        fields: _fields,
        audience: _audience,
        requiredSigners: _requiredSigners,
        version: e?.version ?? 1,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'New form' : 'Edit form'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Save'),
          ),
        ],
      ),
      body: SafeArea(
        child: PageBody.form(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              TextField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Form name'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _description,
                decoration: const InputDecoration(
                  labelText: 'Description (optional)',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _category,
                decoration: const InputDecoration(
                  labelText: 'Category (optional)',
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Who can fill this form',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const Text(
                'Leave all unchecked = everyone',
                style: TextStyle(fontSize: 12),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final at in kUserAccountTypes)
                    FilterChip(
                      label: Text(at),
                      selected: _audience.contains(at),
                      onSelected: (sel) => setState(() {
                        if (sel) {
                          _audience = [..._audience, at];
                        } else {
                          _audience = _audience.where((a) => a != at).toList();
                        }
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Signature workflow',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const Text(
                'Required sign-off after submit (Shift Boss is the submitter). '
                'Leave both off for no signature chain.',
                style: TextStyle(fontSize: 12),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final entry in kChainSignerLabels.entries)
                    FilterChip(
                      label: Text(entry.value),
                      selected: _requiredSigners.contains(entry.key),
                      onSelected: (sel) => setState(() {
                        if (sel) {
                          _requiredSigners = [..._requiredSigners, entry.key];
                        } else {
                          _requiredSigners = _requiredSigners
                              .where((s) => s != entry.key)
                              .toList();
                        }
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Fields',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
              ),
              const SizedBox(height: 8),
              FieldEditorList(
                fields: _fields,
                onChanged: (f) => setState(() => _fields = f),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Edits one overlay DRAFT (an editable copy of a built-in form). The original
/// form is never modified; the draft is saved separately and only drives the
/// real form once an admin sets it active (FS1 Form Studio).
class OverlayEditorScreen extends StatefulWidget {
  const OverlayEditorScreen({
    super.key,
    required this.draftId,
    required this.baseFormType,
  });
  final String draftId;
  final String baseFormType;

  @override
  State<OverlayEditorScreen> createState() => _OverlayEditorScreenState();
}

class _OverlayEditorScreenState extends State<OverlayEditorScreen> {
  bool _loading = true;
  bool _saving = false;
  String _name = '';
  List<FormFieldDef> _addedFields = [];
  List<OverlayPage> _pages = [];
  Map<String, FieldOverride> _overrides = {};
  List<String> _order = const [];

  // Live-preview debounce: the heavy form preview only rebuilds ~350 ms after
  // the last edit, so typing a relabel stays smooth.
  FormOverlay? _previewOverlay;
  String _previewKey = '';
  Timer? _previewDebounce;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _previewDebounce?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final draft = await loadOverlayDraft(widget.draftId);
    final overlay = draft?.overlay;
    if (!mounted) return;
    setState(() {
      _name = draft?.name ?? '';
      _addedFields = overlay == null ? [] : [...overlay.addedFields];
      _pages = overlay == null ? [] : [...overlay.addedPages];
      _overrides = overlay == null ? {} : {...overlay.fieldOverrides};
      final blockIds = reorderableBlockFor(
        widget.baseFormType,
      ).map((r) => r.id).toList();
      _order = blockIds.isEmpty
          ? const []
          : applyFieldOrder(blockIds, overlay?.order ?? const []);
      _loading = false;
    });
  }

  FormOverlay _build() => FormOverlay(
    addedFields: _addedFields,
    addedPages: _pages,
    fieldOverrides: _overrides,
    order: reorderableBlockFor(widget.baseFormType).isEmpty ? const [] : _order,
  );

  FieldOverride _ovFor(String id) => _overrides[id] ?? const FieldOverride();

  void _setOverride(String id, FieldOverride next) {
    setState(() {
      // Drop entries that carry no change to keep the overlay clean.
      if (!next.hidden && (next.label == null || next.label!.isEmpty)) {
        _overrides = {..._overrides}..remove(id);
      } else {
        _overrides = {..._overrides, id: next};
      }
    });
  }

  Future<void> _save() async {
    // Validate every added field (added + pages) by reusing the SP2 validator,
    // but allow a fully empty overlay (which clears the form's additions).
    final all = allOverlayFields(_build());
    if (all.isNotEmpty) {
      final errors = validateTemplate(
        name: _name.isEmpty ? 'Untitled' : _name,
        fields: all,
      );
      if (errors.isNotEmpty) {
        showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Fix these first'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [for (final e in errors) Text('• $e')],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        return;
      }
    }
    setState(() => _saving = true);
    try {
      await saveOverlayDraft(
        widget.draftId,
        name: _name.isEmpty ? 'Untitled' : _name,
        overlay: _build(),
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  void _preview() {
    final view = buildFormView(widget.baseFormType, const FormViewArgs());
    if (view == null) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => view));
  }

  void _addPage() {
    setState(() {
      _pages = [
        ..._pages,
        OverlayPage(
          id: 'p${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}',
          title: 'New page',
          fields: const [],
        ),
      ];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit form'),
        actions: [
          IconButton(
            tooltip: 'Preview',
            onPressed: _preview,
            icon: const Icon(Icons.visibility_outlined),
          ),
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Save'),
          ),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : LayoutBuilder(
                builder: (context, c) {
                  final editor = PageBody.form(
                    padding: const EdgeInsets.all(16),
                    child: ListView(
                      children: [
                        TextFormField(
                          initialValue: _name,
                          decoration: const InputDecoration(
                            labelText: 'Name this edited form',
                            isDense: true,
                          ),
                          onChanged: (v) => _name = v,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          "The original form is never changed. Fields you add here "
                          "appear in an 'Additional information' section at the "
                          "bottom of the form and its PDF.",
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        if (catalogFor(widget.baseFormType).isNotEmpty) ...[
                          const SizedBox(height: 16),
                          const Text(
                            'Existing fields',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const Text(
                            'Hide or rename existing fields. Untouched fields are '
                            'unchanged.',
                            style: TextStyle(fontSize: 12),
                          ),
                          const SizedBox(height: 8),
                          for (final ref in catalogFor(widget.baseFormType))
                            _existingFieldRow(ref),
                        ],
                        if (reorderableBlockFor(
                          widget.baseFormType,
                        ).isNotEmpty) ...[
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              const Expanded(
                                child: Text(
                                  'Reorder fields',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () => setState(
                                  () => _order = reorderableBlockFor(
                                    widget.baseFormType,
                                  ).map((r) => r.id).toList(),
                                ),
                                child: const Text('Reset order'),
                              ),
                            ],
                          ),
                          const Text(
                            'Drag to change the order these fields appear in when '
                            'filling the form. The PDF layout is unchanged.',
                            style: TextStyle(fontSize: 12),
                          ),
                          const SizedBox(height: 8),
                          ReorderableListView(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            onReorder: (oldIndex, newIndex) {
                              setState(() {
                                final ids = [..._order];
                                if (newIndex > oldIndex) newIndex -= 1;
                                final moved = ids.removeAt(oldIndex);
                                ids.insert(newIndex, moved);
                                _order = ids;
                              });
                            },
                            children: [
                              for (final id in _order)
                                ListTile(
                                  key: ValueKey('reorder_$id'),
                                  dense: true,
                                  leading: const Icon(Icons.drag_handle),
                                  title: Text(
                                    reorderableBlockFor(
                                      widget.baseFormType,
                                    ).firstWhere((r) => r.id == id).label,
                                  ),
                                ),
                            ],
                          ),
                        ],
                        const SizedBox(height: 16),
                        const Text(
                          'Added fields',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 8),
                        FieldEditorList(
                          fields: _addedFields,
                          onChanged: (f) => setState(() => _addedFields = f),
                        ),
                        const SizedBox(height: 24),
                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Added pages',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                            TextButton.icon(
                              onPressed: _addPage,
                              icon: const Icon(Icons.add),
                              label: const Text('Add page'),
                            ),
                          ],
                        ),
                        for (var i = 0; i < _pages.length; i++) _pageEditor(i),
                      ],
                    ),
                  );
                  final wide = c.maxWidth >= 900;
                  if (wide) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(child: editor),
                        const VerticalDivider(width: 1),
                        Expanded(child: _previewPane(context)),
                      ],
                    );
                  }
                  return DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        const TabBar(
                          tabs: [
                            Tab(text: 'Edit'),
                            Tab(text: 'Preview'),
                          ],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [editor, _previewPane(context)],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }

  Widget _previewPane(BuildContext context) {
    // Debounce: only refresh the (heavy) form preview once editing settles.
    final liveSig = _build().toMap().toString();
    if (liveSig != _previewKey) {
      _previewDebounce?.cancel();
      _previewDebounce = Timer(const Duration(milliseconds: 350), () {
        if (!mounted) return;
        setState(() {
          _previewOverlay = _build();
          _previewKey = liveSig;
        });
      });
    }
    final overlay = _previewOverlay ?? _build();
    final view = buildFormView(
      widget.baseFormType,
      FormViewArgs(
        mode: FormMode.view,
        embedded: true,
        overlayOverride: overlay,
      ),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          alignment: Alignment.centerLeft,
          child: Text(
            'Live preview',
            style: Theme.of(context).textTheme.titleSmall,
          ),
        ),
        const Divider(height: 1),
        Expanded(
          // The preview is read-only; absorb all pointer input so nothing in
          // the embedded form can be tapped (e.g. accidental navigation).
          child: AbsorbPointer(
            child: KeyedSubtree(
              key: ValueKey(_previewKey),
              child:
                  view ??
                  const Center(child: Text('No preview for this form.')),
            ),
          ),
        ),
      ],
    );
  }

  Widget _existingFieldRow(FormFieldRef ref) {
    final ov = _ovFor(ref.id);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: TextFormField(
              initialValue: ov.label ?? '',
              enabled: !ov.hidden,
              decoration: InputDecoration(
                labelText: ref.label,
                hintText: 'Rename (optional)',
                isDense: true,
              ),
              onChanged: (v) => _setOverride(
                ref.id,
                FieldOverride(
                  hidden: ov.hidden,
                  label: v.trim().isEmpty ? null : v.trim(),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Hide', style: TextStyle(fontSize: 11)),
              Switch(
                value: ov.hidden,
                onChanged: (h) => _setOverride(
                  ref.id,
                  FieldOverride(hidden: h, label: ov.label),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _pageEditor(int i) {
    final page = _pages[i];
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    initialValue: page.title,
                    decoration: const InputDecoration(labelText: 'Page title'),
                    onChanged: (v) {
                      _pages[i] = OverlayPage(
                        id: page.id,
                        title: v,
                        fields: page.fields,
                      );
                    },
                  ),
                ),
                IconButton(
                  tooltip: 'Remove page',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () =>
                      setState(() => _pages = [..._pages]..removeAt(i)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            FieldEditorList(
              fields: page.fields,
              onChanged: (f) => setState(() {
                _pages[i] = OverlayPage(
                  id: page.id,
                  title: page.title,
                  fields: f,
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
