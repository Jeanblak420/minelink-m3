import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_early_shift_record_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_field_catalog.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class EarlyShiftRecordFormScreen extends StatefulWidget {
  const EarlyShiftRecordFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<EarlyShiftRecordFormScreen> createState() =>
      _EarlyShiftRecordFormScreenState();
}

class _EarlyShiftRecordFormScreenState
    extends State<EarlyShiftRecordFormScreen> {
  final _data = EarlyShiftRecordFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};
  List<String> _order = const [];
  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() {
        _overrides = override.fieldOverrides;
        _order = override.order;
      });
      return;
    }
    final overlay = await loadFormOverlay('early_shift_record');
    if (!mounted || overlay == null) return;
    setState(() {
      _overrides = overlay.fieldOverrides;
      _order = overlay.order;
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
        if (_data.shiftBossSignatureDate.trim().isEmpty) {
          _data.shiftBossSignatureDate = _today;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateEarlyShiftRecordPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Early_Shift_Record.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'early_shift_record',
        _data.date.isNotEmpty
            ? 'Early Shift Record — ${_data.date}'
            : 'Early Shift Record',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _yn(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? detailsValue,
    ValueChanged<String>? onDetailsChanged,
    String detailsLabel = 'If "No" give details and remedial action:',
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: Text(ov?.label ?? label)),
              SizedBox(
                width: 110,
                child: DropdownButtonFormField<String>(
                  initialValue: value.isEmpty ? null : value,
                  decoration: const InputDecoration(
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 8,
                    ),
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'Yes', child: Text('Yes')),
                    DropdownMenuItem(value: 'No', child: Text('No')),
                  ],
                  onChanged: (v) => onChanged(v ?? ''),
                ),
              ),
            ],
          ),
          if (onDetailsChanged != null && value == 'No') ...[
            const SizedBox(height: 8),
            TextFormField(
              initialValue: detailsValue,
              onChanged: onDetailsChanged,
              maxLines: 2,
              decoration: InputDecoration(labelText: detailsLabel),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Early Shift Record'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Early Shift Record',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ...(() {
                            final blockBuilders = <String, Widget>{
                              'section': _tf(
                                'Section',
                                _data.section,
                                (v) => _data.section = v,
                                id: 'section',
                              ),
                              'strike': _tf(
                                'Strike',
                                _data.strike,
                                (v) => _data.strike = v,
                                id: 'strike',
                              ),
                              'date': DatePickerField(
                                value: _data.date,
                                onChanged: (v) =>
                                    setState(() => _data.date = v),
                              ),
                              'wentUndergroundAt': _tf(
                                'Went underground at (am/pm)',
                                _data.wentUndergroundAt,
                                (v) => _data.wentUndergroundAt = v,
                                id: 'wentUndergroundAt',
                              ),
                              'arrivedAtWaitingPlace': _tf(
                                'Arrived at waiting place at (am/pm)',
                                _data.arrivedAtWaitingPlace,
                                (v) => _data.arrivedAtWaitingPlace = v,
                                id: 'arrivedAtWaitingPlace',
                              ),
                              'minerArrivedAt': _tf(
                                'Miner arrived at (am/pm)',
                                _data.minerArrivedAt,
                                (v) => _data.minerArrivedAt = v,
                                id: 'minerArrivedAt',
                              ),
                              'minerCoyNo': _tf(
                                'Miner Coy No.',
                                _data.minerCoyNo,
                                (v) => _data.minerCoyNo = v,
                                id: 'minerCoyNo',
                              ),
                              'waitingPlaceLocation': _tf(
                                'Waiting place location',
                                _data.waitingPlaceLocation,
                                (v) => _data.waitingPlaceLocation = v,
                                id: 'waitingPlaceLocation',
                              ),
                            };
                            final blockIds = reorderableBlockFor(
                              'early_shift_record',
                            ).map((r) => r.id).toList();
                            final ordered = applyFieldOrder(blockIds, _order);
                            return <Widget>[
                              for (var i = 0; i < ordered.length; i++) ...[
                                blockBuilders[ordered[i]]!,
                                if (i < ordered.length - 1)
                                  const SizedBox(height: 12),
                              ],
                            ];
                          })(),
                          const SizedBox(height: 16),
                          const Divider(),
                          const SizedBox(height: 8),
                          _yn(
                            'Is the barricade erected at the entrance to the working place?',
                            _data.barricadeErected,
                            (v) => setState(() => _data.barricadeErected = v),
                            detailsValue: _data.barricadeDetails,
                            onDetailsChanged: (v) => _data.barricadeDetails = v,
                          ),
                          _yn(
                            'Did the Miner follow the waiting place procedure?',
                            _data.minerFollowedProcedure,
                            (v) => setState(
                              () => _data.minerFollowedProcedure = v,
                            ),
                            detailsValue: _data.minerFollowedDetails,
                            onDetailsChanged: (v) =>
                                _data.minerFollowedDetails = v,
                          ),
                          _yn(
                            'Did the Miner give permission to the COMP A to enter the workings?',
                            _data.permissionToCompA,
                            (v) => setState(() => _data.permissionToCompA = v),
                          ),
                          _yn(
                            'Was the Miner in possession of a GDI?',
                            _data.minerPossessionGDI,
                            (v) => setState(() => _data.minerPossessionGDI = v),
                          ),
                          if (_data.minerPossessionGDI == 'Yes')
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: _tf(
                                'GDI No.',
                                _data.gdiNo,
                                (v) => _data.gdiNo = v,
                              ),
                            ),
                          _yn(
                            'Was the blasting cable disconnected at the terminal box?',
                            _data.blastingCableDisconnected,
                            (v) => setState(
                              () => _data.blastingCableDisconnected = v,
                            ),
                          ),
                          _yn(
                            'Did the Miner conduct the early entry examination according to the procedure?',
                            _data.earlyEntryExamination,
                            (v) =>
                                setState(() => _data.earlyEntryExamination = v),
                            detailsValue: _data.earlyEntryDetails,
                            onDetailsChanged: (v) =>
                                _data.earlyEntryDetails = v,
                          ),
                          _yn(
                            'Did the miner complete the safe declaration booklet according to the requirements?',
                            _data.safeDeclarationBooklet,
                            (v) => setState(
                              () => _data.safeDeclarationBooklet = v,
                            ),
                            detailsValue: _data.safeDeclarationDetails,
                            onDetailsChanged: (v) =>
                                _data.safeDeclarationDetails = v,
                          ),
                          _yn(
                            'Did the Miner test for flammable gases and CO according to the procedure?',
                            _data.flammableGasesTest,
                            (v) => setState(() => _data.flammableGasesTest = v),
                            detailsValue: _data.flammableGasesDetails,
                            onDetailsChanged: (v) =>
                                _data.flammableGasesDetails = v,
                          ),
                          _yn(
                            'Was entry examination equipment available and in order?',
                            _data.entryEquipmentAvailable,
                            (v) => setState(
                              () => _data.entryEquipmentAvailable = v,
                            ),
                            detailsValue: _data.entryEquipmentDetails,
                            onDetailsChanged: (v) =>
                                _data.entryEquipmentDetails = v,
                          ),
                          _yn(
                            'Does the Miner have a whirling hygrometer and Anemo meter?',
                            _data.hygrometerAndAnemo,
                            (v) => setState(() => _data.hygrometerAndAnemo = v),
                            detailsValue: _data.hygrometerDetails,
                            onDetailsChanged: (v) =>
                                _data.hygrometerDetails = v,
                          ),
                          _yn(
                            'Were the working places water down properly?',
                            _data.waterDownProperly,
                            (v) => setState(() => _data.waterDownProperly = v),
                          ),
                          _yn(
                            'Is drinking water available in close proximity to the working places?',
                            _data.drinkingWaterAvailable,
                            (v) => setState(
                              () => _data.drinkingWaterAvailable = v,
                            ),
                            detailsValue: _data.drinkingWaterDetails,
                            onDetailsChanged: (v) =>
                                _data.drinkingWaterDetails = v,
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            'Special instruction given',
                            _data.specialInstruction,
                            (v) => _data.specialInstruction = v,
                            maxLines: 3,
                            id: 'specialInstruction',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Additional remarks',
                            _data.additionalRemarks,
                            (v) => _data.additionalRemarks = v,
                            maxLines: 3,
                            id: 'additionalRemarks',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.shiftBossSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Miner Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.minerOverseerSignature,
                            onChanged: (v) => setState(
                              () => _data.minerOverseerSignature = v,
                            ),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.minerOverseerSignatureDate,
                            onChanged: (v) => setState(
                              () => _data.minerOverseerSignatureDate = v,
                            ),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'early_shift_record',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: const Text('Generate PDF'),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
