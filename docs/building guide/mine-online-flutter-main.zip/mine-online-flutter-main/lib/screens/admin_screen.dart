import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';

class _Card {
  const _Card({
    required this.route,
    required this.icon,
    required this.title,
    required this.description,
  });

  final String route;
  final IconData icon;
  final String title;
  final String description;
}

const _items = <_Card>[
  _Card(
      route: '/appointment-history-logs',
      icon: Icons.assignment_outlined,
      title: 'Appointment History Logs',
      description: 'View individual Shift Boss appointment history'),
  _Card(
      route: '/active-individual-current-logbook',
      icon: Icons.checklist_outlined,
      title: 'Active Individual Current Logbook',
      description:
          'View the active current logbook an individual Shift Boss is busy with, including live progress.'),
  _Card(
      route: '/individual-completed-logbook-history',
      icon: Icons.history_outlined,
      title: "Individuals' Past Completed Logbook History",
      description:
          "View individual Shift Boss's logbook history and trace incomplete required sections."),
  _Card(
      route: '/logbook-version-management',
      icon: Icons.edit_outlined,
      title: 'Logbook Version Management',
      description:
          'Review, edit, add, change, and update logbook versions and sections.'),
  _Card(
      route: '/send-notifications-reminders',
      icon: Icons.send_outlined,
      title: 'Send Notifications and Reminders',
      description:
          'Prepare and send notifications or reminders to users.'),
  _Card(
      route: '/profiles',
      icon: Icons.group_outlined,
      title: 'User Management',
      description: 'Manage employee profiles and account types.'),
  _Card(
      route: '/notifications',
      icon: Icons.notifications_outlined,
      title: 'Notifications',
      description: 'View notification history and unread items.'),
  _Card(
      route: '/my-profile',
      icon: Icons.person_outline,
      title: 'My Profile',
      description: 'Manage your own details and signature.'),
  _Card(
      route: '/settings',
      icon: Icons.settings_outlined,
      title: 'Settings',
      description: 'Theme and user preference settings.'),
];

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Workspace'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: commonAppBarActions(),
      ),
      body: SafeArea(
        child: PageBody.list(
          child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              final cols = width >= 1100
                  ? 4
                  : width >= 820
                      ? 3
                      : width >= 540
                          ? 2
                          : 1;
              return GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: cols,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: cols == 1 ? 2.4 : 1.1,
                ),
                itemCount: _items.length,
                itemBuilder: (_, i) {
                  final item = _items[i];
                  return Card(
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () => context.go(item.route),
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: scheme.primaryContainer,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(item.icon,
                                  size: 28,
                                  color: scheme.onPrimaryContainer),
                            ),
                            const SizedBox(height: 10),
                            Text(item.title,
                                textAlign: TextAlign.center,
                                style:
                                    Theme.of(context).textTheme.titleSmall),
                            const SizedBox(height: 4),
                            Text(item.description,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: scheme.onSurfaceVariant,
                                    fontSize: 12)),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        ),
      ),
    );
  }
}