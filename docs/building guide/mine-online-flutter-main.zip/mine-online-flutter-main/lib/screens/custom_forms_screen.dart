// Audience-facing list of fillable custom forms + the fill screen. Submits into
// form_submissions via persistFormSubmission (non-chain; SP2.1b).

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/custom_form_template.dart';
import '../pdf/generate_custom_form_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/custom_form_data.dart';
import '../utils/dynamic_form_payload.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/form_builder/dynamic_form_renderer.dart';
import '../widgets/page_body.dart';

class CustomFormsScreen extends StatefulWidget {
  const CustomFormsScreen({super.key});

  @override
  State<CustomFormsScreen> createState() => _CustomFormsScreenState();
}

class _CustomFormsScreenState extends State<CustomFormsScreen> {
  bool _loading = true;
  String? _error;
  List<CustomFormTemplate> _forms = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final accountType = context.read<AuthProvider>().profile?.userAccountType;
      final all = await loadTemplates(includeArchived: false);
      final visible = all
          .where((t) => audienceAllows(t.audience, accountType))
          .toList();
      if (!mounted) return;
      setState(() {
        _forms = visible;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom Forms'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(16),
                child: _forms.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'No forms are available for you to fill right now.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView.separated(
                        shrinkWrap: true,
                        itemCount: _forms.length,
                        separatorBuilder: (_, index) =>
                            const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final t = _forms[i];
                          return Card(
                            child: ListTile(
                              leading: const Icon(Icons.assignment_outlined),
                              title: Text(t.name),
                              subtitle:
                                  (t.description != null &&
                                      t.description!.isNotEmpty)
                                  ? Text(t.description!)
                                  : (t.category != null &&
                                            t.category!.isNotEmpty
                                        ? Text(t.category!)
                                        : null),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => _FillFormScreen(template: t),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
      ),
    );
  }
}

class _FillFormScreen extends StatefulWidget {
  const _FillFormScreen({required this.template});
  final CustomFormTemplate template;

  @override
  State<_FillFormScreen> createState() => _FillFormScreenState();
}

class _FillFormScreenState extends State<_FillFormScreen> {
  final Map<String, dynamic> _values = {};
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    for (final f in widget.template.fields) {
      if (f.type == FormFieldType.boolean) {
        _values[f.key] = false;
      } else if (f.type == FormFieldType.table) {
        _values[f.key] = <Map<String, dynamic>>[];
      }
    }
  }

  Future<void> _previewPdf() async {
    final payload = buildSubmissionPayload(widget.template.fields, _values);
    await Printing.layoutPdf(
      onLayout: (_) async =>
          (await generateCustomFormPdf(widget.template, payload)).save(),
    );
  }

  Future<void> _submit() async {
    final missing = missingRequiredFields(widget.template.fields, _values);
    if (missing.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please complete: ${missing.join(', ')}')),
      );
      return;
    }
    final profile = context.read<AuthProvider>().profile;
    setState(() => _submitting = true);
    try {
      final payload = buildSubmissionPayload(widget.template.fields, _values);
      // Chain templates: inject the recognized blank signature fields and start
      // the signature workflow; otherwise persist as a plain (non-chain) form.
      final isChain = applyCustomChainSignatureFields(
        widget.template.requiredSigners,
        payload,
      );
      final id = isChain
          ? await saveFormSubmissionAndStartWorkflow(
              widget.template.code,
              widget.template.name,
              payload,
              profile: profile,
            )
          : await persistFormSubmission(
              widget.template.code,
              widget.template.name,
              payload,
            );
      if (!mounted) return;
      if (id == null) {
        setState(() => _submitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not submit. Please try again.')),
        );
        return;
      }
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${widget.template.name} '
            '${isChain ? 'submitted for sign-off' : 'submitted'}.',
          ),
        ),
      );
    } catch (err) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Submit failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.template.name),
        actions: [
          IconButton(
            tooltip: 'Generate PDF',
            icon: const Icon(Icons.picture_as_pdf_outlined),
            onPressed: _submitting ? null : _previewPdf,
          ),
          TextButton(
            onPressed: _submitting ? null : _submit,
            child: _submitting
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Submit'),
          ),
        ],
      ),
      body: SafeArea(
        child: PageBody.form(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              DynamicFormRenderer(
                fields: widget.template.fields,
                values: _values,
                onChanged: (key, value) => setState(() => _values[key] = value),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
