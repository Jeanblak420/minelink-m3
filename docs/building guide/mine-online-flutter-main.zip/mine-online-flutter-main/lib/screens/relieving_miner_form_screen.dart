import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_relieving_miner_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/appointment_profile.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class RelievingMinerFormScreen extends StatefulWidget {
  const RelievingMinerFormScreen({super.key, this.viewArgs, this.onSubmitted});

  final FormViewArgs? viewArgs;

  /// When set (appointment-accept flow), called with the new submission id after
  /// a successful submit instead of navigating to the logbook.
  final ValueChanged<String>? onSubmitted;

  @override
  State<RelievingMinerFormScreen> createState() =>
      _RelievingMinerFormScreenState();
}

class _RelievingMinerFormScreenState extends State<RelievingMinerFormScreen> {
  final _data = RelievingMinerFormData();
  bool _initialised = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};
  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  @override
  void initState() {
    super.initState();
    _loadOverrides();
  }

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('relieving_miner_appointment');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) {
      _data.applyMap(payload);
    }
    if (_isViewMode) return;
    _data.signatures.relievingMinerDate = _today;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final d = getProfilePersonalDetails(profile);
      _data.title = d.title;
      _data.name = d.name;
      _data.identityNumber = d.identityNumber;
      _data.companyNumber = d.companyNumber;
      _data.sectionShaft = d.sectionShaft;
      _data.signatures.relievingMinerSignature = d.signature;
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.signatures.shiftBossSignature.trim().isEmpty) {
          _data.signatures.shiftBossSignature = savedSig;
        }
        if (_data.signatures.shiftBossDate.trim().isEmpty) {
          _data.signatures.shiftBossDate = _today;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateRelievingMinerPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Relieving_Miner_Appointment_${_safeName(_data.name)}.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'relieving_miner_appointment',
        _data.name.isNotEmpty
            ? 'Relieving Miner Appointment — ${_data.name}'
            : 'Relieving Miner Appointment',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        if (widget.onSubmitted != null) {
          widget.onSubmitted!(id);
          if (mounted) context.pop();
        } else {
          context.go('/current-logbook?submitted=$id');
        }
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  String _safeName(String s) {
    final cleaned = s.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
    return cleaned.isEmpty ? 'form' : cleaned;
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Relieving Miner Appointment'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Relieving Miner Appointment Form',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        children: [
                          _tf(
                            'Title',
                            _data.title,
                            (v) => _data.title = v,
                            id: 'title',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Full Name',
                            _data.name,
                            (v) => _data.name = v,
                            id: 'name',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Identity Number',
                            _data.identityNumber,
                            (v) => _data.identityNumber = v,
                            id: 'identityNumber',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Company Number',
                            _data.companyNumber,
                            (v) => _data.companyNumber = v,
                            id: 'companyNumber',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Section/Shaft',
                            _data.sectionShaft,
                            (v) => _data.sectionShaft = v,
                            id: 'sectionShaft',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Areas of Responsibility',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Stopes/Working places',
                            _data.workplaces.stopes,
                            (v) => _data.workplaces.stopes = v,
                            id: 'workplaces_stopes',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Development ends / Vent Holings',
                            _data.workplaces.developmentEnds,
                            (v) => _data.workplaces.developmentEnds = v,
                            id: 'workplaces_developmentEnds',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Declines',
                            _data.workplaces.declines,
                            (v) => _data.workplaces.declines = v,
                            id: 'workplaces_declines',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Load and Haul / Roadway',
                            _data.workplaces.loadAndHaul,
                            (v) => _data.workplaces.loadAndHaul = v,
                            id: 'workplaces_loadAndHaul',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Travelling way',
                            _data.workplaces.travellingWay,
                            (v) => _data.workplaces.travellingWay = v,
                            id: 'workplaces_travellingWay',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Refuge Bay',
                            _data.workplaces.refugeBay,
                            (v) => _data.workplaces.refugeBay = v,
                            id: 'workplaces_refugeBay',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Store',
                            _data.workplaces.store,
                            (v) => _data.workplaces.store = v,
                            id: 'workplaces_store',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Waiting place',
                            _data.workplaces.waitingPlace,
                            (v) => _data.workplaces.waitingPlace = v,
                            id: 'workplaces_waitingPlace',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Conveyor belts / Tipping area',
                            _data.workplaces.conveyorBelts,
                            (v) => _data.workplaces.conveyorBelts = v,
                            id: 'workplaces_conveyorBelts',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Any other workplaces specified',
                            _data.workplaces.otherWorkplaces,
                            (v) => _data.workplaces.otherWorkplaces = v,
                            id: 'workplaces_otherWorkplaces',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Signatures',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          for (final entry in [
                            (
                              'Relieving Miner',
                              () => _data.signatures.relievingMinerSignature,
                              (String v) =>
                                  _data.signatures.relievingMinerSignature = v,
                              () => _data.signatures.relievingMinerDate,
                              (String v) =>
                                  _data.signatures.relievingMinerDate = v,
                            ),
                            (
                              'Shift Boss',
                              () => _data.signatures.shiftBossSignature,
                              (String v) =>
                                  _data.signatures.shiftBossSignature = v,
                              () => _data.signatures.shiftBossDate,
                              (String v) => _data.signatures.shiftBossDate = v,
                            ),
                            (
                              'Mine Overseer',
                              () => _data.signatures.mineOverseerSignature,
                              (String v) =>
                                  _data.signatures.mineOverseerSignature = v,
                              () => _data.signatures.mineOverseerDate,
                              (String v) =>
                                  _data.signatures.mineOverseerDate = v,
                            ),
                            (
                              'Mine Manager',
                              () => _data.signatures.mineManagerSignature,
                              (String v) =>
                                  _data.signatures.mineManagerSignature = v,
                              () => _data.signatures.mineManagerDate,
                              (String v) =>
                                  _data.signatures.mineManagerDate = v,
                            ),
                          ])
                            Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    entry.$1,
                                    style: Theme.of(
                                      context,
                                    ).textTheme.titleSmall,
                                  ),
                                  const SizedBox(height: 8),
                                  SignatureCanvasField(
                                    value: entry.$2(),
                                    onChanged: (v) =>
                                        setState(() => entry.$3(v)),
                                  ),
                                  const SizedBox(height: 8),
                                  DatePickerField(
                                    value: entry.$4(),
                                    onChanged: (v) =>
                                        setState(() => entry.$5(v)),
                                  ),
                                ],
                              ),
                            ),
                          FormOverlayHost(
                            formType: 'relieving_miner_appointment',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                            const SizedBox(height: 12),
                          ],
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: const Text('Generate PDF'),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            )
                          else
                            Align(
                              alignment: Alignment.centerRight,
                              child: OutlinedButton.icon(
                                onPressed: _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: const Text('View PDF'),
                              ),
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
