// SP4.6 Builder 1 — a faithful re-implementation of the old Mine-On-Line app's
// form designer: a manager (Active/Archived) + a three-column designer (Form
// Fields | Live Preview | Edit Field). Authors into the existing
// custom_form_templates (general) and appointment_templates (appointment) — no
// duplicate storage. Adds the legacy data-linked "dynamic dropdown" capability.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/appointment_template.dart';
import '../models/custom_form_template.dart';
import '../providers/auth_provider.dart';
import '../utils/appointment_template_data.dart';
import '../utils/custom_form_data.dart';
import '../utils/form_dropdown_data.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/form_builder/dynamic_form_renderer.dart';
import '../widgets/page_body.dart';

enum DesignerKind { general, appointment }

const Map<FormFieldType, String> _kTypeLabels = {
  FormFieldType.text: 'Text',
  FormFieldType.multiline: 'Multi-line Text',
  FormFieldType.number: 'Number',
  FormFieldType.date: 'Date',
  FormFieldType.dropdown: 'Dropdown (Static)',
  FormFieldType.dynamicDropdown: 'Dropdown (Dynamic)',
  FormFieldType.boolean: 'Checkbox',
  FormFieldType.signature: 'Signature',
  FormFieldType.section: 'Section heading',
  FormFieldType.table: 'Table',
};

const List<String> _kLanguages = ['en', 'af', 'zu', 'xh', 'st', 'tn'];

class _Row {
  const _Row({
    required this.kind,
    required this.existing,
    required this.name,
    required this.version,
    required this.isActive,
  });
  final DesignerKind kind;
  final dynamic existing; // CustomFormTemplate | AppointmentTemplate
  final String name;
  final String version;
  final bool isActive;
}

class FormDesignerScreen extends StatefulWidget {
  const FormDesignerScreen({super.key});

  @override
  State<FormDesignerScreen> createState() => _FormDesignerScreenState();
}

class _FormDesignerScreenState extends State<FormDesignerScreen> {
  DesignerKind _kind = DesignerKind.general;
  bool _loading = true;
  String? _error;
  List<_Row> _rows = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = <_Row>[];
      if (_kind == DesignerKind.general) {
        for (final t in await loadTemplates(includeArchived: true)) {
          rows.add(
            _Row(
              kind: DesignerKind.general,
              existing: t,
              name: t.name,
              version: 'v${t.version}',
              isActive: t.isActive,
            ),
          );
        }
      } else {
        for (final t in await loadAppointmentTemplates(includeArchived: true)) {
          rows.add(
            _Row(
              kind: DesignerKind.appointment,
              existing: t,
              name: t.name,
              version: 'v${t.version}',
              isActive: t.isActive,
            ),
          );
        }
      }
      if (!mounted) return;
      setState(() {
        _rows = rows;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _openDesigner([dynamic existing]) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => _DesignerScreen(kind: _kind, existing: existing),
      ),
    );
    if (saved == true) _load();
  }

  Future<void> _toggleActive(_Row r) async {
    if (r.kind == DesignerKind.general) {
      final t = r.existing as CustomFormTemplate;
      await setTemplateActive(t.id, !t.isActive);
    } else {
      final t = r.existing as AppointmentTemplate;
      await setAppointmentTemplateActive(t.id, !t.isActive);
    }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Form Designer'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Form Designer is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    final active = _rows.where((r) => r.isActive).toList();
    final archived = _rows.where((r) => !r.isActive).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Form Designer'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openDesigner(),
        icon: const Icon(Icons.add),
        label: const Text('Create New Form'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SegmentedButton<DesignerKind>(
                      segments: const [
                        ButtonSegment(
                          value: DesignerKind.general,
                          label: Text('General Forms'),
                        ),
                        ButtonSegment(
                          value: DesignerKind.appointment,
                          label: Text('Appointment Forms'),
                        ),
                      ],
                      selected: {_kind},
                      onSelectionChanged: (s) {
                        setState(() => _kind = s.first);
                        _load();
                      },
                    ),
                    const SizedBox(height: 16),
                    _sectionHeader('Active Templates'),
                    if (active.isEmpty)
                      _emptyHint('No active templates.')
                    else
                      for (final r in active) _row(r),
                    const SizedBox(height: 16),
                    _sectionHeader('Archived Templates'),
                    if (archived.isEmpty)
                      _emptyHint('No archived templates.')
                    else
                      for (final r in archived) _row(r),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _sectionHeader(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      t,
      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
    ),
  );

  Widget _emptyHint(String t) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Text(
      t,
      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
    ),
  );

  Widget _row(_Row r) {
    final fieldCount = (r.existing.fields as List<FormFieldDef>)
        .where((f) => f.type != FormFieldType.section)
        .length;
    return Card(
      child: ListTile(
        title: Text(r.name),
        subtitle: Text('${r.version} • $fieldCount fields'),
        onTap: () => _openDesigner(r.existing),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') _openDesigner(r.existing);
            if (v == 'toggle') _toggleActive(r);
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'edit', child: Text('Edit')),
            PopupMenuItem(
              value: 'toggle',
              child: Text(r.isActive ? 'Archive' : 'Restore'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Designer (three columns)
// ---------------------------------------------------------------------------

class _DesignerScreen extends StatefulWidget {
  const _DesignerScreen({required this.kind, this.existing});
  final DesignerKind kind;
  final dynamic existing;

  @override
  State<_DesignerScreen> createState() => _DesignerScreenState();
}

class _DesignerScreenState extends State<_DesignerScreen> {
  late final TextEditingController _name;
  late final TextEditingController _version;
  late final TextEditingController _category;
  late final TextEditingController _description;
  String _language = 'en';
  String? _roleId;
  late List<FormFieldDef> _fields;
  int? _selected;
  bool _saving = false;

  List<DropdownSource> _sources = const [];
  List<AppointmentRole> _roles = const [];

  bool get _isAppt => widget.kind == DesignerKind.appointment;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _version = TextEditingController(text: e == null ? 'v1' : 'v${e.version}');
    _category = TextEditingController(
      text: e is CustomFormTemplate ? (e.category ?? '') : '',
    );
    _description = TextEditingController(text: e?.description ?? '');
    if (e is AppointmentTemplate) {
      _language = e.language;
      _roleId = e.roleId;
    }
    _fields = e == null ? [] : [...(e.fields as List<FormFieldDef>)];
    _loadAux();
  }

  Future<void> _loadAux() async {
    final sources = await loadDropdownSources();
    final roles = _isAppt
        ? await loadAppointmentRoles(includeArchived: true)
        : <AppointmentRole>[];
    if (!mounted) return;
    setState(() {
      _sources = sources;
      _roles = roles;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _version.dispose();
    _category.dispose();
    _description.dispose();
    super.dispose();
  }

  void _addField() {
    final n = _fields.length + 1;
    setState(() {
      _fields = [
        ..._fields,
        FormFieldDef(
          key: 'field_$n',
          type: FormFieldType.text,
          label: 'Field $n',
          required: false,
        ),
      ];
      _selected = _fields.length - 1;
    });
  }

  void _replaceSelected(FormFieldDef next) {
    final i = _selected;
    if (i == null) return;
    setState(() => _fields = [..._fields]..[i] = next);
  }

  void _removeSelected() {
    final i = _selected;
    if (i == null) return;
    setState(() {
      _fields = [..._fields]..removeAt(i);
      _selected = null;
    });
  }

  Future<void> _save() async {
    final errors = validateTemplate(name: _name.text, fields: _fields);
    for (final f in _fields) {
      if (f.type == FormFieldType.dynamicDropdown &&
          (f.dropdownSource == null || f.dropdownSource!.isEmpty)) {
        errors.add('Dynamic dropdown "${f.label}" needs a data source.');
      }
    }
    if (_isAppt && (_roleId == null || _roleId!.isEmpty)) {
      errors.add('Select an appointment role.');
    }
    if (errors.isNotEmpty) {
      _showErrors(errors.toSet().toList());
      return;
    }
    setState(() => _saving = true);
    try {
      final e = widget.existing;
      if (_isAppt) {
        final code =
            (e as AppointmentTemplate?)?.code ??
            appointmentTemplateCode(
              _name.text,
              DateTime.now().microsecondsSinceEpoch.toRadixString(36),
            );
        await saveAppointmentTemplate(
          id: e?.id,
          code: code,
          name: _name.text.trim(),
          description: _description.text.trim().isEmpty
              ? null
              : _description.text.trim(),
          roleId: _roleId,
          language: _language,
          fields: _fields,
          letterBody: e?.letterBody ?? '',
          requiredSigners: e?.requiredSigners ?? const [],
          version: e?.version ?? 1,
        );
      } else {
        final t = e as CustomFormTemplate?;
        final code =
            t?.code ??
            slugifyCode(
              _name.text,
              DateTime.now().microsecondsSinceEpoch.toRadixString(36),
            );
        await saveTemplate(
          id: t?.id,
          code: code,
          name: _name.text.trim(),
          description: _description.text.trim().isEmpty
              ? null
              : _description.text.trim(),
          category: _category.text.trim().isEmpty
              ? null
              : _category.text.trim(),
          fields: _fields,
          audience: t?.audience ?? const [],
          requiredSigners: t?.requiredSigners ?? const [],
          version: t?.version ?? 1,
        );
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  void _showErrors(List<String> errors) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Fix these first'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [for (final e in errors) Text('• $e')],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'New form' : 'Edit form'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Save'),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _metadataHeader(),
            const Divider(height: 1),
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  if (c.maxWidth >= 1000) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(width: 260, child: _fieldListPanel()),
                        const VerticalDivider(width: 1),
                        Expanded(child: _previewPanel()),
                        const VerticalDivider(width: 1),
                        SizedBox(width: 320, child: _editFieldPanel()),
                      ],
                    );
                  }
                  return DefaultTabController(
                    length: 3,
                    child: Column(
                      children: [
                        const TabBar(
                          tabs: [
                            Tab(text: 'Fields'),
                            Tab(text: 'Preview'),
                            Tab(text: 'Edit'),
                          ],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              _fieldListPanel(),
                              _previewPanel(),
                              _editFieldPanel(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _metadataHeader() {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      color: scheme.surfaceContainerHighest,
      padding: const EdgeInsets.all(12),
      child: Wrap(
        spacing: 12,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          SizedBox(
            width: 220,
            child: TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Form Name'),
            ),
          ),
          SizedBox(
            width: 110,
            child: TextField(
              controller: _version,
              decoration: const InputDecoration(labelText: 'Version'),
            ),
          ),
          SizedBox(
            width: 130,
            child: DropdownButtonFormField<String>(
              initialValue: _language,
              decoration: const InputDecoration(labelText: 'Language'),
              items: [
                for (final l in _kLanguages)
                  DropdownMenuItem(value: l, child: Text(l)),
              ],
              onChanged: (v) => setState(() => _language = v ?? 'en'),
            ),
          ),
          if (_isAppt)
            SizedBox(
              width: 240,
              child: DropdownButtonFormField<String>(
                initialValue: _roleId,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Appointment Role',
                ),
                items: [
                  for (final r in _roles)
                    DropdownMenuItem(value: r.id, child: Text(r.displayLabel)),
                ],
                onChanged: (v) => setState(() => _roleId = v),
              ),
            )
          else ...[
            SizedBox(
              width: 160,
              child: TextField(
                controller: _category,
                decoration: const InputDecoration(labelText: 'Category'),
              ),
            ),
            SizedBox(
              width: 220,
              child: TextField(
                controller: _description,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _fieldListPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Padding(
          padding: EdgeInsets.all(12),
          child: Text(
            'Form Fields',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _fields.length,
            itemBuilder: (_, i) {
              final f = _fields[i];
              final sel = _selected == i;
              return ListTile(
                selected: sel,
                selectedTileColor: Theme.of(
                  context,
                ).colorScheme.primaryContainer.withValues(alpha: 0.4),
                title: Text(f.label.isEmpty ? '(no label)' : f.label),
                subtitle: Text(_kTypeLabels[f.type] ?? f.type.name),
                onTap: () => setState(() => _selected = i),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(
            onPressed: _addField,
            icon: const Icon(Icons.add),
            label: const Text('Add Field'),
          ),
        ),
      ],
    );
  }

  Widget _previewPanel() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Live Preview',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
          ),
          const SizedBox(height: 12),
          if (_fields.isEmpty)
            const Text('Add fields to see the preview.')
          else
            AbsorbPointer(
              child: DynamicFormRenderer(
                fields: _fields,
                values: const {},
                onChanged: (_, _) {},
                grouped: true,
              ),
            ),
        ],
      ),
    );
  }

  Widget _editFieldPanel() {
    final i = _selected;
    if (i == null || i >= _fields.length) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text('Select a field to edit.'),
        ),
      );
    }
    final f = _fields[i];
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Edit Field',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              IconButton(
                tooltip: 'Remove Field',
                icon: const Icon(Icons.delete_outline),
                onPressed: _removeSelected,
              ),
            ],
          ),
          _tf('Label', f.label, (v) => _replaceSelected(_with(f, label: v))),
          _tf('Name', f.key, (v) => _replaceSelected(_with(f, key: v))),
          DropdownButtonFormField<FormFieldType>(
            initialValue: f.type,
            decoration: const InputDecoration(labelText: 'Field Type'),
            items: [
              for (final entry in _kTypeLabels.entries)
                DropdownMenuItem(value: entry.key, child: Text(entry.value)),
            ],
            onChanged: (t) => _replaceSelected(_with(f, type: t ?? f.type)),
          ),
          _tf(
            'Section',
            f.section ?? '',
            (v) => _replaceSelected(_with(f, section: v)),
          ),
          _tf('Row', f.row ?? '', (v) => _replaceSelected(_with(f, row: v))),
          _numTf(
            'Row Order',
            f.rowOrder,
            (v) => _replaceSelected(_with(f, rowOrder: v)),
          ),
          _numTf(
            'Tab Index',
            f.tabIndex,
            (v) => _replaceSelected(_with(f, tabIndex: v)),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Required'),
            value: f.required,
            onChanged: (v) => _replaceSelected(_with(f, required: v)),
          ),
          if (f.type == FormFieldType.dropdown)
            _tf(
              'Static Options (comma-separated)',
              (f.options ?? const []).join(', '),
              (v) => _replaceSelected(
                _with(
                  f,
                  options: v
                      .split(',')
                      .map((s) => s.trim())
                      .where((s) => s.isNotEmpty)
                      .toList(),
                ),
              ),
            ),
          if (f.type == FormFieldType.dynamicDropdown)
            DropdownButtonFormField<String>(
              initialValue: f.dropdownSource,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Dynamic Source'),
              items: [
                for (final s in _sources)
                  DropdownMenuItem(value: s.key, child: Text(s.displayName)),
              ],
              onChanged: (v) => _replaceSelected(_with(f, dropdownSource: v)),
            ),
        ],
      ),
    );
  }

  Widget _tf(String label, String value, ValueChanged<String> onChanged) =>
      Padding(
        padding: const EdgeInsets.only(top: 8),
        child: TextFormField(
          key: ValueKey('$label$_selected'),
          initialValue: value,
          decoration: InputDecoration(labelText: label),
          onChanged: onChanged,
        ),
      );

  Widget _numTf(String label, int? value, ValueChanged<int?> onChanged) =>
      Padding(
        padding: const EdgeInsets.only(top: 8),
        child: TextFormField(
          key: ValueKey('$label$_selected'),
          initialValue: value?.toString() ?? '',
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: label),
          onChanged: (v) =>
              onChanged(v.trim().isEmpty ? null : int.tryParse(v.trim())),
        ),
      );

  // Immutable update preserving all other props.
  FormFieldDef _with(
    FormFieldDef f, {
    String? key,
    FormFieldType? type,
    String? label,
    bool? required,
    List<String>? options,
    String? section,
    String? row,
    int? rowOrder,
    int? tabIndex,
    String? dropdownSource,
    bool clearRowOrder = false,
    bool clearTabIndex = false,
  }) {
    return FormFieldDef(
      key: key ?? f.key,
      type: type ?? f.type,
      label: label ?? f.label,
      required: required ?? f.required,
      help: f.help,
      options: options ?? f.options,
      columns: f.columns,
      section: section ?? f.section,
      row: row ?? f.row,
      rowOrder: clearRowOrder ? null : (rowOrder ?? f.rowOrder),
      tabIndex: clearTabIndex ? null : (tabIndex ?? f.tabIndex),
      dropdownSource: dropdownSource ?? f.dropdownSource,
    );
  }
}
