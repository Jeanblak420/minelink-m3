import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_refuge_bay_inspection_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';

const List<String> _itemLabels = [
  'Route Demarcated',
  'Refuge Bay Numbered',
  'Green Indication Light',
  'Door opens to inside & seal',
  'Back Wall Sealed',
  'Compressed Air Available',
  'Compressed Air Valve with 50mm steel column in Chamber',
  'Compressed Air Silencer',
  'Refuge Bay Ventilated',
  'Refuge Bay Pressurising',
  'Air Whistle',
  'Activator in the refuge bay',
  'Drinking Water Inside',
  'First Aid Box',
  'Emergency Procedures displayed inside Chamber',
  'Telephone Working',
  'Number Indicated on Phone List',
  'Radio Comms (transmittance between Control Room and Refuge Bay)',
  'Benches',
  'Toilet Facilities',
  'Illumination',
  'Free from Other Material',
  'Size of the refuge bay',
  'Ambient Temperature',
  'Emergency Escape Route Plan',
  'Oxygen Candles',
  'Entrance free from obstructions and combustible material',
  'Are the electrical cable well routed?',
];

const Map<int, String> _extraFieldMap = {
  16: 'Tel No.',
  18: 'Qty. seating available',
  25: 'Qty.',
};

const List<int> _displayNumbers = [
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
  21,
  22,
  23,
  24,
  25,
  26,
  27,
  28,
  29,
];

class RefugeBayInspectionFormScreen extends StatefulWidget {
  const RefugeBayInspectionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<RefugeBayInspectionFormScreen> createState() =>
      _RefugeBayInspectionFormScreenState();
}

class _RefugeBayInspectionFormScreenState
    extends State<RefugeBayInspectionFormScreen> {
  final _data = RefugeBayInspectionFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('refuge_bay_inspection');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'refuge_bay_inspection',
        'Refuge Bay Inspection',
        payload,
      );
      final doc = await generateRefugeBayInspectionPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Refuge_Bay_Inspection.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Widget _itemRow(int i) {
    final item = _data.items[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 32,
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text('${_displayNumbers[i]}.'),
            ),
          ),
          Expanded(
            flex: 5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 14, right: 8),
                  child: Text(_itemLabels[i]),
                ),
                if (_extraFieldMap.containsKey(i))
                  Padding(
                    padding: const EdgeInsets.only(top: 4, right: 8),
                    child: TextFormField(
                      initialValue: item.extraField,
                      onChanged: (v) => item.extraField = v,
                      decoration: InputDecoration(
                        isDense: true,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 8,
                        ),
                        border: const OutlineInputBorder(),
                        labelText: _extraFieldMap[i],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SizedBox(
            width: 70,
            child: DropdownButtonFormField<String>(
              initialValue: item.consequenceClassification.isEmpty
                  ? null
                  : item.consequenceClassification,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 6,
                  vertical: 8,
                ),
                border: OutlineInputBorder(),
                hintText: 'C/C',
              ),
              items: const [
                DropdownMenuItem(value: '2', child: Text('2')),
                DropdownMenuItem(value: '3', child: Text('3')),
                DropdownMenuItem(value: '4', child: Text('4')),
                DropdownMenuItem(value: '5', child: Text('5')),
              ],
              onChanged: (v) =>
                  setState(() => item.consequenceClassification = v ?? ''),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Checkbox(
              value: item.yes,
              onChanged: (v) => setState(() {
                item.yes = v ?? false;
                if (item.yes) item.no = false;
              }),
            ),
          ),
          const Padding(padding: EdgeInsets.only(top: 14), child: Text('Yes')),
          const SizedBox(width: 8),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Checkbox(
              value: item.no,
              onChanged: (v) => setState(() {
                item.no = v ?? false;
                if (item.no) item.yes = false;
              }),
            ),
          ),
          const Padding(padding: EdgeInsets.only(top: 14), child: Text('No')),
          const SizedBox(width: 8),
          Expanded(
            flex: 3,
            child: TextFormField(
              initialValue: item.remarks,
              onChanged: (v) => item.remarks = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Remarks',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Refuge Bay Inspection'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 1180,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Refuge Bay Inspection Record',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _tf(
                            'Shaft',
                            _data.shaft,
                            (v) => _data.shaft = v,
                            id: 'shaft',
                          ),
                          const SizedBox(height: 12),
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Observer',
                            _data.observer,
                            (v) => _data.observer = v,
                            id: 'observer',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Refuge Bay No.',
                            _data.refugeBayNo,
                            (v) => _data.refugeBayNo = v,
                            id: 'refugeBayNo',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Mine Overseer',
                            _data.mineOverseer,
                            (v) => _data.mineOverseer = v,
                            id: 'mineOverseer',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Section',
                            _data.section,
                            (v) => _data.section = v,
                            id: 'section',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Inspection items',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          for (var i = 0; i < _data.items.length; i++)
                            _itemRow(i),
                          const SizedBox(height: 16),
                          if (_overrides['isLifeSustainable']?.hidden != true)
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    _overrides['isLifeSustainable']?.label ??
                                        'Is this Refuge Bay life sustainable?',
                                  ),
                                ),
                                SizedBox(
                                  width: 130,
                                  child: DropdownButtonFormField<String>(
                                    initialValue:
                                        _data.isLifeSustainable.isEmpty
                                        ? null
                                        : _data.isLifeSustainable,
                                    decoration: const InputDecoration(
                                      isDense: true,
                                      contentPadding: EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 8,
                                      ),
                                      border: OutlineInputBorder(),
                                    ),
                                    items: const [
                                      DropdownMenuItem(
                                        value: 'Yes',
                                        child: Text('Yes'),
                                      ),
                                      DropdownMenuItem(
                                        value: 'No',
                                        child: Text('No'),
                                      ),
                                    ],
                                    onChanged: (v) => setState(
                                      () => _data.isLifeSustainable = v ?? '',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          const SizedBox(height: 24),
                          Text(
                            'Instructions',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (var i = 0; i < _data.instructions.length; i++)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      initialValue:
                                          _data.instructions[i].instruction,
                                      onChanged: (v) =>
                                          _data.instructions[i].instruction = v,
                                      decoration: const InputDecoration(
                                        isDense: true,
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 12,
                                        ),
                                        border: OutlineInputBorder(),
                                        hintText: 'Instruction',
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  SizedBox(
                                    width: 160,
                                    child: DatePickerField(
                                      value:
                                          _data.instructions[i].completionDate,
                                      onChanged: (v) => setState(
                                        () =>
                                            _data
                                                    .instructions[i]
                                                    .completionDate =
                                                v,
                                      ),
                                      label: 'Completion',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: OutlinedButton.icon(
                                onPressed: () => setState(
                                  () => _data.instructions.add(
                                    RefugeBayInstruction(),
                                  ),
                                ),
                                icon: const Icon(Icons.add),
                                label: const Text('Add Instruction'),
                              ),
                            ),
                          const SizedBox(height: 24),
                          DatePickerField(
                            value: _data.observerDate,
                            onChanged: (v) =>
                                setState(() => _data.observerDate = v),
                            label: 'Observer date',
                          ),
                          const SizedBox(height: 12),
                          DatePickerField(
                            value: _data.mineOverseerDate,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerDate = v),
                            label: 'Mine Overseer date',
                          ),
                          FormOverlayHost(
                            formType: 'refuge_bay_inspection',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
