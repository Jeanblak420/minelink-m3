// ignore_for_file: unnecessary_underscores

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../models/form_view_args.dart';
import '../models/signature_request.dart';
import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/form_registry.dart';
import '../utils/pdf_download.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';

class SignatureRequestsScreen extends StatefulWidget {
  const SignatureRequestsScreen({super.key, this.requestId});

  final String? requestId;

  @override
  State<SignatureRequestsScreen> createState() =>
      _SignatureRequestsScreenState();
}

class _SignatureRequestsScreenState extends State<SignatureRequestsScreen> {
  static final _formatter = DateFormat('d MMM, HH:mm');

  bool _loading = true;
  bool _saving = false;
  bool _downloadingPdf = false;
  String? _error;
  String? _success;
  List<SignatureRequest> _pending = const [];
  List<SignatureRequest> _signed = const [];
  String? _selectedId;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _load();
    _subscribe();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    super.dispose();
  }

  void _subscribe() {
    if (_channel != null) return;
    _channel = supabase
        .channel('signature-requests-realtime')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'signature_requests',
          callback: (_) {
            if (mounted) _load();
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'form_submissions',
          callback: (_) {
            if (mounted) _load();
          },
        )
        .subscribe();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final pendingRaw = await listSignatureRequests(status: 'pending');
      final signedRaw = await listSignatureRequests(status: 'signed');
      final pending = pendingRaw.map(SignatureRequest.fromMap).toList();
      final signed = signedRaw.map(SignatureRequest.fromMap).toList();
      final all = [...pending, ...signed];
      String? next;
      if (widget.requestId != null &&
          all.any((r) => r.id == widget.requestId)) {
        next = widget.requestId;
      } else if (pending.isNotEmpty) {
        next = pending.first.id;
      } else if (signed.isNotEmpty) {
        next = signed.first.id;
      }
      if (!mounted) return;
      setState(() {
        _pending = pending;
        _signed = signed;
        _selectedId = next;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _pending = const [];
        _signed = const [];
        _loading = false;
      });
    }
  }

  SignatureRequest? get _selected {
    if (_selectedId == null) return null;
    for (final r in _pending) {
      if (r.id == _selectedId) return r;
    }
    for (final r in _signed) {
      if (r.id == _selectedId) return r;
    }
    return null;
  }

  Future<void> _sign() async {
    final selected = _selected;
    if (selected == null) return;
    final signature = context.read<AuthProvider>().profile?.signatureData ?? '';
    if (signature.isEmpty) {
      setState(() {
        _error = 'Save a signature under My Profile before signing.';
      });
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
      _success = null;
    });
    try {
      await signSignatureRequest(selected.id, signature);
      if (!mounted) return;
      setState(() {
        _success =
            'Signature submitted. The document has moved to the next step.';
      });
      await _load();
    } catch (err) {
      if (!mounted) return;
      setState(() => _error = err.toString());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  String _formatDate(DateTime? d) =>
      d == null ? 'Not signed yet' : _formatter.format(d.toLocal());

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isWide = MediaQuery.of(context).size.width > 880;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Signature Requests'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: PageBody(
          maxWidth: 1240,
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : isWide
                  ? Row(
                      children: [
                        SizedBox(width: 360, child: _listColumn(scheme)),
                        const VerticalDivider(width: 1),
                        Expanded(child: _detailColumn(scheme)),
                      ],
                    )
                  : _selected == null
                      ? _listColumn(scheme)
                      : _detailColumn(scheme),
        ),
      ),
    );
  }

  Widget _listColumn(ColorScheme scheme) {
    final isWide = MediaQuery.of(context).size.width > 880;
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Pending',
                  style: Theme.of(context).textTheme.titleMedium),
              Text(
                  '${_pending.length} request${_pending.length == 1 ? '' : 's'} awaiting signature',
                  style: TextStyle(color: scheme.onSurfaceVariant)),
            ],
          ),
        ),
        if (_pending.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Text('No pending requests',
                style: TextStyle(color: scheme.onSurfaceVariant)),
          )
        else
          for (final r in _pending)
            _requestTile(r, isPending: true, scheme: scheme, mobileNav: !isWide),
        if (_signed.isNotEmpty) ...[
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Text('Signed recently',
                style: Theme.of(context).textTheme.titleSmall),
          ),
          for (final r in _signed.take(5))
            _requestTile(r,
                isPending: false, scheme: scheme, mobileNav: !isWide),
        ],
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _requestTile(SignatureRequest r,
      {required bool isPending,
      required ColorScheme scheme,
      required bool mobileNav}) {
    final selected = _selectedId == r.id;
    final tones = MolTones.of(context);
    final tone = isPending ? tones.warning : tones.success;
    final bg = selected ? tone.soft : tone.tint;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        elevation: selected ? 1.5 : 0.5,
        shadowColor: Colors.black.withValues(alpha: 0.08),
        child: InkWell(
          onTap: () => setState(() => _selectedId = r.id),
          borderRadius: BorderRadius.circular(14),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 10,
                bottom: 10,
                child: Container(
                  width: 4,
                  decoration: BoxDecoration(
                    color: tone.accent,
                    borderRadius: BorderRadius.circular(9999),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      r.submission?.title.isNotEmpty == true
                          ? r.submission!.title
                          : 'Submitted document',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(color: tone.fg),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isPending
                          ? '${r.requestedRole} signature requested by ${r.submitterProfile?.fullName.isNotEmpty == true ? r.submitterProfile!.fullName : (r.submitterProfile?.email ?? 'Shift Boss')}'
                          : 'Signed ${_formatDate(r.signedAt)}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: tone.fg.withValues(alpha: 0.85),
                          fontSize: 12.5),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _formatDate(r.createdAt),
                      style: TextStyle(
                        color: tone.accent,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailColumn(ColorScheme scheme) {
    final selected = _selected;
    if (selected == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.description_outlined,
                  size: 48,
                  color: scheme.onSurfaceVariant.withValues(alpha: 0.6)),
              const SizedBox(height: 12),
              Text('No document selected',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text('Incoming requests will appear here.',
                  style: TextStyle(color: scheme.onSurfaceVariant)),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_error != null) ...[
          _Banner(
            color: scheme.error,
            background: scheme.errorContainer,
            child: Text(_error!),
          ),
          const SizedBox(height: 12),
        ],
        if (_success != null) ...[
          _Banner(
            color: scheme.primary,
            background: scheme.primaryContainer,
            child: Text(_success!),
          ),
          const SizedBox(height: 12),
        ],
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        selected.submission?.title.isNotEmpty == true
                            ? selected.submission!.title
                            : 'Submitted document',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                    ),
                    Chip(
                      avatar:
                          const Icon(Icons.check_circle_outline, size: 16),
                      label: Text(selected.status),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                    '${selected.submission?.formType ?? 'form'} • submitted ${_formatDate(selected.submission?.createdAt)}',
                    style: TextStyle(color: scheme.onSurfaceVariant)),
                const SizedBox(height: 16),
                if (selected.submitterProfile != null)
                  _profileCard(scheme, selected.submitterProfile!),
                if (selected.status == 'pending') ...[
                  const SizedBox(height: 16),
                  Card(
                    color: scheme.surfaceContainerHighest,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${selected.requestedRole} signature required',
                              style: Theme.of(context).textTheme.titleSmall),
                          const SizedBox(height: 8),
                          Text(
                              'Your saved profile signature will be applied. Update it under My Profile if you want a different mark.',
                              style:
                                  TextStyle(color: scheme.onSurfaceVariant)),
                          const SizedBox(height: 12),
                          FilledButton.icon(
                            onPressed: _saving ? null : _sign,
                            icon: const Icon(Icons.edit_outlined),
                            label: Text(_saving
                                ? 'Submitting...'
                                : 'Sign and Submit'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Review the submitted document',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 6),
                Text(
                    'Inspect the form as it was submitted — either in its original PDF layout or by opening the form in read-only view mode.',
                    style: TextStyle(color: scheme.onSurfaceVariant)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    FilledButton.icon(
                      onPressed:
                          _downloadingPdf ? null : () => _downloadPdf(selected),
                      icon: const Icon(Icons.download_outlined),
                      label: Text(
                          _downloadingPdf ? 'Preparing...' : 'Download PDF'),
                    ),
                    OutlinedButton.icon(
                      onPressed: buildFormView(
                                  selected.submission?.formType ?? '',
                                  FormViewArgs(mode: FormMode.view)) ==
                              null
                          ? null
                          : () => _viewAsForm(selected),
                      icon: const Icon(Icons.description_outlined),
                      label: const Text('Open form (view mode)'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  childrenPadding: EdgeInsets.zero,
                  title: const Text('Raw payload (JSON)'),
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerHigh,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: SelectableText(
                        const JsonEncoder.withIndent('  ')
                            .convert(selected.submission?.payload ?? const {}),
                        style: const TextStyle(
                            fontFamily: 'monospace', fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _downloadPdf(SignatureRequest request) async {
    final formType = request.submission?.formType ?? '';
    final payload = request.submission?.payload ?? const <String, dynamic>{};
    setState(() {
      _downloadingPdf = true;
      _error = null;
      _success = null;
    });
    try {
      final doc = await generatePdfForFormType(formType, payload);
      if (!mounted) return;
      if (doc == null) {
        setState(() =>
            _error = 'No PDF generator registered for $formType.');
        return;
      }
      final bytes = await doc.save();
      if (!mounted) return;
      final result = await savePdfBytes(
        bytes: bytes,
        suggestedName: request.submission?.title ?? 'submission',
      );
      if (!mounted) return;
      if (result.error != null) {
        setState(() => _error = result.error);
      } else if (result.saved) {
        setState(() => _success = 'PDF saved to ${result.path}');
      }
    } catch (err) {
      if (mounted) setState(() => _error = err.toString());
    } finally {
      if (mounted) setState(() => _downloadingPdf = false);
    }
  }

  void _viewAsForm(SignatureRequest request) {
    final formType = request.submission?.formType ?? '';
    final args = FormViewArgs(
      mode: FormMode.view,
      initialPayload: request.submission?.payload,
      currentSignerRole:
          request.status == 'pending' ? request.requestedRole : null,
      submissionId: request.submissionId,
      requestId: request.status == 'pending' ? request.id : null,
    );
    final widget = buildFormView(formType, args);
    if (widget == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => widget),
    ).then((value) {
      // After the form's inline action bar approves or sends back, refresh
      // the list so the pending row drops away and the next request lights
      // up. The form's onActionDone passes 'approved' or 'sent_back' as the
      // Navigator.pop value.
      if (mounted && value != null) {
        _load();
      }
    });
  }

  Widget _profileCard(ColorScheme scheme, ProfileSnapshot p) {
    final rows = <(String, String)>[
      ('Email', p.email),
      ('Account Type', p.userAccountType),
      ('Company No.', p.companyNumber),
      ('Job Title', p.jobTitle),
      ('Company', p.company),
      ('Department', p.department),
      ('Cost Centre', p.costCentre),
      ('Location', p.location),
      ('Phone', p.phone),
      ('Occupation', p.occupation),
    ].where((r) => r.$2.isNotEmpty).toList();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: scheme.outlineVariant),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                  radius: 18,
                  backgroundColor: scheme.surfaceContainerHighest,
                  child: const Icon(Icons.person_outline, size: 20)),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    p.displayName.isEmpty ? p.email : p.displayName,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  Text('Submitted by',
                      style: TextStyle(
                          color: scheme.onSurfaceVariant, fontSize: 12)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 16,
            runSpacing: 8,
            children: [
              for (final r in rows)
                SizedBox(
                  width: 180,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(r.$1.toUpperCase(),
                          style: TextStyle(
                              color: scheme.onSurfaceVariant,
                              fontSize: 10,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(r.$2,
                          style: const TextStyle(fontSize: 13),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.color,
    required this.background,
    required this.child,
  });

  final Color color;
  final Color background;
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: background.withValues(alpha: 0.5),
          border: Border.all(color: color.withValues(alpha: 0.3)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: DefaultTextStyle.merge(
            style: TextStyle(color: color), child: child),
      );
}
