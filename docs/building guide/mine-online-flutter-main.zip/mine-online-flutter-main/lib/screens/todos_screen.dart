import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/todo.dart';
import '../providers/auth_provider.dart';
import '../providers/todos_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/todo_attachments.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/mobile_bottom_nav.dart';
import '../widgets/todos/create_user_request_dialog.dart';
import '../widgets/todos/todo_detail_dialog.dart';
import '../widgets/todos/todo_lane.dart';
import '../widgets/todos/todo_tree.dart';

/// Shared engineering + user-request todo list. Two sections, three lanes
/// each (Planned / In Progress / Completed). Engineering section is
/// service_role-write only (no in-app `+` button by design).
class TodosScreen extends StatelessWidget {
  const TodosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.of(context).size.width < 960;
    final tones = MolTones.of(context);

    return Scaffold(
      backgroundColor: tones.bgMuted,
      bottomNavigationBar: const MobileBottomNav(location: '/todos'),
      appBar: AppBar(
        title: const Text('To-Do List'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: commonAppBarActions(),
      ),
      body: Consumer<TodosProvider>(
        builder: (context, provider, _) {
          if (provider.loading && provider.todos.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          return RefreshIndicator(
            onRefresh: provider.reload,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(
                horizontal: narrow ? 12 : 20,
                vertical: narrow ? 12 : 20,
              ),
              child: Center(
                child: PageBody(
                  maxWidth: 1180,
                  child: Column(
                    children: [
                      _TodosSection(
                        title: 'User Requests',
                        subtitle:
                            "Add a screenshot, urgency, and what you'd like changed. Visible to every user and to the engineering side.",
                        icon: Icons.forum_outlined,
                        items: provider.userTodos,
                        narrow: narrow,
                        tone: tones.success,
                        emptyMessage:
                            'No user requests yet — tap the + button to add the first one.',
                        isUser: true,
                        onAddRequest: () => _openCreateRequest(context),
                      ),
                      SizedBox(height: narrow ? 18 : 24),
                      _TodosSection(
                        title: 'Engineering To-Dos',
                        subtitle:
                            'Tasks added automatically by the engineering system as work ships. Visible to all account types.',
                        icon: Icons.engineering_outlined,
                        items: provider.engTodos,
                        narrow: narrow,
                        tone: tones.info,
                        emptyMessage:
                            'No engineering tasks yet.',
                        isUser: false,
                        onAddRequest: null,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _openCreateRequest(BuildContext context) async {
    final auth = context.read<AuthProvider>();
    final provider = context.read<TodosProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final initial = auth.profile?.fullName ?? '';

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => CreateUserRequestDialog(
        initialName: initial,
        onSubmit: (draft) async {
          final user = auth.user;
          if (user == null) return false;
          String? path;
          try {
            final upload = await uploadTodoAttachment(
              bytes: draft.imageBytes,
              userId: user.id,
              filename: draft.imageFilename,
              contentType: draft.imageMime,
            );
            path = upload.path;
          } catch (err) {
            messenger.showSnackBar(SnackBar(
              content: Text('Could not upload screenshot: $err'),
            ));
            return false;
          }

          final inserted = await provider.insertUserRequest(
            title: draft.title,
            submitterName: draft.submitterName,
            urgency: draft.urgency,
            summary: draft.summary,
            imageStoragePath: path,
            imageNotes: draft.imageNotes.isEmpty ? null : draft.imageNotes,
          );
          if (inserted == null) {
            messenger.showSnackBar(const SnackBar(
              content: Text('Could not submit request'),
            ));
            return false;
          }
          messenger.showSnackBar(const SnackBar(
            content: Text('Request submitted'),
          ));
          return true;
        },
      ),
    );
  }
}

class _TodosSection extends StatelessWidget {
  const _TodosSection({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.items,
    required this.narrow,
    required this.tone,
    required this.emptyMessage,
    required this.isUser,
    required this.onAddRequest,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Todo> items;
  final bool narrow;
  final MolTone tone;
  final String emptyMessage;
  final bool isUser;
  final VoidCallback? onAddRequest;

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;
    final forest = buildTodoForest(items);

    final lanes = todoStatuses.map((s) {
      return TodoLane(
        status: s,
        nodes: pruneForestToLane(forest, s.id),
        onOpen: (todo) => _openDetail(context, todo),
        onToggleDone: (todo) =>
            context.read<TodosProvider>().toggleDone(todo.id),
      );
    }).toList(growable: false);

    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(16),
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(
              narrow ? 16 : 24,
              narrow ? 16 : 20,
              narrow ? 16 : 24,
              narrow ? 12 : 16,
            ),
            decoration: BoxDecoration(
              color: tone.tint,
              border: Border(
                bottom: BorderSide(color: tones.lineFaint),
              ),
            ),
            child: Flex(
              direction: narrow ? Axis.vertical : Axis.horizontal,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: narrow
                  ? CrossAxisAlignment.start
                  : CrossAxisAlignment.center,
              children: [
                Expanded(
                  flex: narrow ? 0 : 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(icon, size: 22, color: tone.accent),
                          const SizedBox(width: 10),
                          Text(
                            title,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: scheme.onSurface,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: scheme.surface,
                              borderRadius: BorderRadius.circular(9999),
                            ),
                            child: Text(
                              '${items.length} total',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: tone.fg,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 12,
                          color: tones.fg3,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                if (onAddRequest != null) ...[
                  if (narrow) const SizedBox(height: 12),
                  FilledButton.icon(
                    icon: const Icon(Icons.add),
                    label: const Text('Add request'),
                    onPressed: onAddRequest,
                  ),
                ],
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(narrow ? 12 : 16),
            child: narrow
                ? Column(
                    children: [
                      for (var i = 0; i < lanes.length; i++) ...[
                        if (i > 0) const SizedBox(height: 12),
                        lanes[i],
                      ],
                    ],
                  )
                : Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (var i = 0; i < lanes.length; i++) ...[
                        if (i > 0) const SizedBox(width: 12),
                        Expanded(child: lanes[i]),
                      ],
                    ],
                  ),
          ),
          if (items.isEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
              child: Text(
                emptyMessage,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: tones.fg3, height: 1.4),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _openDetail(BuildContext context, Todo todo) async {
    final provider = context.read<TodosProvider>();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => TodoDetailDialog(
        todo: todo,
        onSetStatus: (status) async {
          await provider.setStatus(todo.id, status);
          if (!dialogContext.mounted) return;
          Navigator.of(dialogContext).pop();
        },
        onDelete: () async {
          final path = todo.imageStoragePath;
          await provider.deleteTodo(todo.id);
          if (path != null) {
            await deleteTodoAttachment(path);
          }
          if (!dialogContext.mounted) return;
          Navigator.of(dialogContext).pop();
        },
      ),
    );
  }
}
