import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_shift_boss_daily_report_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/signature_canvas.dart';

class ShiftBossDailyReportFormScreen extends StatefulWidget {
  const ShiftBossDailyReportFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<ShiftBossDailyReportFormScreen> createState() =>
      _ShiftBossDailyReportFormScreenState();
}

class _ShiftBossDailyReportFormScreenState
    extends State<ShiftBossDailyReportFormScreen> {
  final _data = ShiftBossDailyReportFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('shift_boss_daily_report');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateShiftBossDailyReportPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Shift_Boss_Daily_Report.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    }
  }

  Future<void> _submit() async {
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await persistFormSubmission(
        'shift_boss_daily_report',
        'Shift Boss Daily Report',
        payload,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    double width = double.infinity,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return SizedBox(
      width: width,
      child: TextFormField(
        initialValue: value,
        onChanged: onChanged,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: ov?.label ?? label,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 10,
          ),
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _placeVisitedRow(int i) {
    final e = _data.placesVisited[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          SizedBox(
            width: 28,
            child: Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text('${i + 1}.'),
            ),
          ),
          Expanded(
            child: TextFormField(
              initialValue: e.placeVisited,
              onChanged: (v) => e.placeVisited = v,
              decoration: const InputDecoration(
                hintText: 'Place visited',
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              initialValue: e.miner,
              onChanged: (v) => e.miner = v,
              decoration: const InputDecoration(
                hintText: 'Miner',
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                border: OutlineInputBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _plannedInspectionRow(int i) {
    final e = _data.plannedInspections[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Inspection ${i + 1}',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            _tf('Working place', e.workingPlace, (v) => e.workingPlace = v),
            const SizedBox(height: 8),
            _tf(
              'Unsafe / unsatisfactory conditions observed',
              e.unsafeConditions,
              (v) => e.unsafeConditions = v,
              maxLines: 2,
            ),
            const SizedBox(height: 8),
            _tf(
              'Remedial Action',
              e.remedialAction,
              (v) => e.remedialAction = v,
              maxLines: 2,
            ),
            const SizedBox(height: 8),
            _tf(
              'Responsible person',
              e.responsiblePerson,
              (v) => e.responsiblePerson = v,
            ),
            const SizedBox(height: 8),
            _tf(
              'Responsible Person Signature',
              e.responsiblePersonSignature,
              (v) => e.responsiblePersonSignature = v,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DatePickerField(
                    value: e.plannedDate,
                    onChanged: (v) => setState(() => e.plannedDate = v),
                    label: 'Planned date',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DatePickerField(
                    value: e.completedDate,
                    onChanged: (v) => setState(() => e.completedDate = v),
                    label: 'Completed date',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _devEndRow(int i) {
    final e = _data.devEnds[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Dev End ${i + 1}',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            _tf(
              'Dev. End / Vent Holing',
              e.devEndVentHoling,
              (v) => e.devEndVentHoling = v,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _tf(
                    'Roofbolts from face',
                    e.roofboltsFromFace,
                    (v) => e.roofboltsFromFace = v,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _tf(
                    'Roofbolts from sidewall',
                    e.roofboltsFromSidewall,
                    (v) => e.roofboltsFromSidewall = v,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _tf(
                    'Sockets inspected',
                    e.socketsInspected,
                    (v) => e.socketsInspected = v,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _tf(
                    'Average length',
                    e.averageLength,
                    (v) => e.averageLength = v,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _tf(
                    'Service pipes (distance from face)',
                    e.servicePipes,
                    (v) => e.servicePipes = v,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _tf(
                    'Vent pipes (distance from face)',
                    e.ventPipes,
                    (v) => e.ventPipes = v,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _pillarRow(int i) {
    final e = _data.pillarDimensions[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Workplace ${i + 1}',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _tf('Workplace', e.workplace, (v) => e.workplace = v),
                ),
                const SizedBox(width: 8),
                Expanded(child: _tf('V/H No.', e.vhNo, (v) => e.vhNo = v)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Off sets — Survey note',
              style: Theme.of(context).textTheme.labelSmall,
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: _tf(
                    'Left',
                    e.surveyNoteLeft,
                    (v) => e.surveyNoteLeft = v,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _tf(
                    'Right',
                    e.surveyNoteRight,
                    (v) => e.surveyNoteRight = v,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Off sets — Actual',
              style: Theme.of(context).textTheme.labelSmall,
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: _tf('Left', e.actualLeft, (v) => e.actualLeft = v),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _tf('Right', e.actualRight, (v) => e.actualRight = v),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _tf(
              'Remedial Action',
              e.remedialAction,
              (v) => e.remedialAction = v,
              maxLines: 2,
            ),
          ],
        ),
      ),
    );
  }

  Widget _checklistRow(int i) {
    final c = _data.inspectionChecklist[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: TextFormField(
              initialValue: c.item,
              onChanged: (v) => c.item = v,
              decoration: const InputDecoration(
                labelText: 'Item',
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Checkbox(
            value: c.yes,
            onChanged: (v) => setState(() {
              c.yes = v ?? false;
              if (c.yes) c.no = false;
            }),
          ),
          const Padding(padding: EdgeInsets.only(top: 14), child: Text('Yes')),
          const SizedBox(width: 8),
          Checkbox(
            value: c.no,
            onChanged: (v) => setState(() {
              c.no = v ?? false;
              if (c.no) c.yes = false;
            }),
          ),
          const Padding(padding: EdgeInsets.only(top: 14), child: Text('No')),
          const SizedBox(width: 8),
          Expanded(
            flex: 4,
            child: TextFormField(
              initialValue: c.findings,
              onChanged: (v) => c.findings = v,
              decoration: const InputDecoration(
                labelText: 'Findings',
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                border: OutlineInputBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Shift Boss Daily Report'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 980,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Shift Boss Daily Report',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 4,
                            children: [
                              FilterChip(
                                label: const Text('Day Shift'),
                                selected: _data.dayShift,
                                onSelected: (v) =>
                                    setState(() => _data.dayShift = v),
                              ),
                              FilterChip(
                                label: const Text('Night Shift'),
                                selected: _data.nightShift,
                                onSelected: (v) =>
                                    setState(() => _data.nightShift = v),
                              ),
                              FilterChip(
                                label: const Text('Cycle A'),
                                selected: _data.cycleA,
                                onSelected: (v) =>
                                    setState(() => _data.cycleA = v),
                              ),
                              FilterChip(
                                label: const Text('Cycle B'),
                                selected: _data.cycleB,
                                onSelected: (v) =>
                                    setState(() => _data.cycleB = v),
                              ),
                              FilterChip(
                                label: const Text('Cycle C'),
                                selected: _data.cycleC,
                                onSelected: (v) =>
                                    setState(() => _data.cycleC = v),
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),
                          Text(
                            '1. Working places visited / inspected',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (var i = 0; i < _data.placesVisited.length; i++)
                            _placeVisitedRow(i),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.placesVisited.add(
                                  PlaceVisitedEntry(),
                                ),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add place'),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            '2. Planned Inspection conducted',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (
                            var i = 0;
                            i < _data.plannedInspections.length;
                            i++
                          )
                            _plannedInspectionRow(i),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.plannedInspections.add(
                                  PlannedInspectionEntry(),
                                ),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add inspection'),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            '3. Development Ends / Vent Holing blasted previous shift',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (var i = 0; i < _data.devEnds.length; i++)
                            _devEndRow(i),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.devEnds.add(DevEndEntry()),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add dev end'),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            '4. Pillar Dimensions / Survey Lines',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (
                            var i = 0;
                            i < _data.pillarDimensions.length;
                            i++
                          )
                            _pillarRow(i),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.pillarDimensions.add(
                                  PillarDimensionEntry(),
                                ),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add workplace'),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            '5. Inspection checklist',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (
                            var i = 0;
                            i < _data.inspectionChecklist.length;
                            i++
                          )
                            _checklistRow(i),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.inspectionChecklist.add(
                                  InspectionCheckItem(),
                                ),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add check item'),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            '6. Readings',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Ventilation flow (>0.5 m/s)',
                            _data.ventilationFlowReading,
                            (v) => _data.ventilationFlowReading = v,
                            id: 'ventilationFlowReading',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Temperature WB (<27.5 C)',
                            _data.temperatureWBReading,
                            (v) => _data.temperatureWBReading = v,
                            id: 'temperatureWBReading',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Temperature DB (<32.5 C)',
                            _data.temperatureDBReading,
                            (v) => _data.temperatureDBReading = v,
                            id: 'temperatureDBReading',
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            'General',
                            _data.general,
                            (v) => _data.general = v,
                            maxLines: 3,
                            id: 'general',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Mine Overseer Comments / Instruction',
                            _data.mineOverseerComments,
                            (v) => _data.mineOverseerComments = v,
                            maxLines: 3,
                            id: 'mineOverseerComments',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Manager / Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.managerMineOverseerSignature,
                            onChanged: (v) => setState(
                              () => _data.managerMineOverseerSignature = v,
                            ),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.signatureDate,
                            onChanged: (v) =>
                                setState(() => _data.signatureDate = v),
                            label: 'Signature date',
                          ),
                          FormOverlayHost(
                            formType: 'shift_boss_daily_report',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: const Text('Generate PDF'),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.save_outlined),
                                  label: Text(
                                    _submitting ? 'Saving...' : 'Save Report',
                                  ),
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
