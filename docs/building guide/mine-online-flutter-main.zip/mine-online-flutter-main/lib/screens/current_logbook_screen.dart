// ignore_for_file: unnecessary_underscores

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../theme/mol_tones.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/signature_chain.dart';
import '../widgets/submission_viewer_dialog.dart';

class CurrentLogbookScreen extends StatefulWidget {
  const CurrentLogbookScreen({super.key, this.justSubmittedId});

  final String? justSubmittedId;

  @override
  State<CurrentLogbookScreen> createState() => _CurrentLogbookScreenState();
}

class _CurrentLogbookScreenState extends State<CurrentLogbookScreen> {
  static final _formatter = DateFormat('d MMM, HH:mm');

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rows = const [];
  RealtimeChannel? _channel;
  bool _showedJustSubmittedSnack = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    super.dispose();
  }

  Future<void> _load() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await supabase
          .from('form_submissions')
          .select(
              'id,form_type,title,payload,workflow_status,current_signature_role,completed_at,created_at,updated_at')
          .eq('user_id', user.id)
          .order('updated_at', ascending: false, nullsFirst: false)
          .order('created_at', ascending: false)
          .limit(200);
      if (!mounted) return;
      setState(() {
        _rows = (rows as List).cast<Map<String, dynamic>>();
        _loading = false;
      });
      _resubscribe(user.id);
      _showJustSubmittedToast();
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _rows = const [];
        _loading = false;
      });
    }
  }

  void _resubscribe(String userId) {
    if (_channel != null) return;
    _channel = supabase
        .channel('my-current-logbook:$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'form_submissions',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (_) => _load(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'signature_requests',
          callback: (_) => _load(),
        )
        .subscribe();
  }

  void _showJustSubmittedToast() {
    final id = widget.justSubmittedId;
    if (_showedJustSubmittedSnack || id == null || !mounted) return;
    final row = _rows.firstWhere((r) => r['id'] == id, orElse: () => {});
    if (row.isEmpty) return;
    _showedJustSubmittedSnack = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                '${row['title']} submitted and queued for approval.')),
      );
    });
  }

  String _formatDate(String? s) {
    if (s == null || s.isEmpty) return '—';
    final d = DateTime.tryParse(s);
    if (d == null) return s;
    return _formatter.format(d.toLocal());
  }

  Widget _statusBadge(Map<String, dynamic> row, ColorScheme scheme) {
    final status = row['workflow_status'] as String?;
    final role = row['current_signature_role'] as String?;
    if (status == 'fully_signed') {
      return _chip('Fully signed', Colors.green.shade100, Colors.green.shade900);
    }
    if (status == 'pending_signature' && role != null) {
      return _chip('Pending: $role', Colors.amber.shade100,
          Colors.amber.shade900);
    }
    return _chip(
        'Submitted', scheme.surfaceContainerHigh, scheme.onSurfaceVariant);
  }

  Widget _chip(String label, Color bg, Color fg) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration:
            BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
        child: Text(label,
            style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w500)),
      );

  Future<void> _openDetails(Map<String, dynamic> row) {
    return showDialog(
      context: context,
      builder: (_) => SubmissionViewerDialog(row: row),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Current Logbook'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: PageBody.list(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(_error!,
                        style: TextStyle(color: scheme.error)),
                  )
                : _rows.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.description_outlined,
                                  size: 48,
                                  color: scheme.onSurfaceVariant
                                      .withValues(alpha: 0.6)),
                              const SizedBox(height: 12),
                              Text('No submissions yet',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleMedium),
                              const SizedBox(height: 4),
                              Text(
                                  'Submit any appointment or inspection form and it will appear here.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: scheme.onSurfaceVariant)),
                            ],
                          ),
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                          itemCount: _rows.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(height: 10),
                          itemBuilder: (_, i) {
                            final row = _rows[i];
                            final tones = MolTones.of(context);
                            final status =
                                row['workflow_status'] as String?;
                            final tone = status == 'fully_signed'
                                ? tones.success
                                : status == 'pending_signature'
                                    ? tones.warning
                                    : tones.info;
                            final submittedLabel =
                                _formatDate(row['created_at'] as String?);
                            final updatedLabel = _formatDate(
                                (row['updated_at'] as String?) ??
                                    row['created_at'] as String?);
                            return Material(
                              color: tone.tint,
                              borderRadius: BorderRadius.circular(16),
                              elevation: 1,
                              shadowColor:
                                  Colors.black.withValues(alpha: 0.08),
                              child: InkWell(
                                onTap: () => _openDetails(row),
                                borderRadius: BorderRadius.circular(16),
                                child: Stack(children: [
                                  Positioned(
                                    left: 0,
                                    top: 14,
                                    bottom: 14,
                                    child: Container(
                                      width: 4,
                                      decoration: BoxDecoration(
                                        color: tone.accent,
                                        borderRadius:
                                            BorderRadius.circular(9999),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    20, 14, 16, 14),
                                child: Row(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(row['title'] as String? ?? '—',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleMedium),
                                          const SizedBox(height: 4),
                                          Text(
                                              row['form_type'] as String? ??
                                                  '',
                                              style: TextStyle(
                                                  color: scheme
                                                      .onSurfaceVariant)),
                                          const SizedBox(height: 6),
                                          _statusBadge(row, scheme),
                                          const SizedBox(height: 8),
                                          SignatureChain.fromWorkflowStatus(
                                            row['workflow_status'] as String?,
                                            currentSignatureRole: row[
                                                    'current_signature_role']
                                                as String?,
                                            dense: true,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text('Submitted',
                                            style: TextStyle(
                                                color:
                                                    scheme.onSurfaceVariant,
                                                fontSize: 11)),
                                        Text(submittedLabel,
                                            style: const TextStyle(
                                                fontSize: 12)),
                                        const SizedBox(height: 4),
                                        Text('Updated',
                                            style: TextStyle(
                                                color:
                                                    scheme.onSurfaceVariant,
                                                fontSize: 11)),
                                        Text(updatedLabel,
                                            style: const TextStyle(
                                                fontSize: 12)),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                                ]),
                              ),
                            );
                          },
                        ),
                      ),
      ),
      ),
    );
  }
}

