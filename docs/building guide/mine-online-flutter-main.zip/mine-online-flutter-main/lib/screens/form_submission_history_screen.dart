// Mirrors src/components/FormSubmissionHistory.tsx. Used by
// /completed-logbook-history and /individual-completed-logbook-history.

// ignore_for_file: unnecessary_underscores

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../config/supabase_client.dart';
import '../theme/mol_tones.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/empty_state.dart';
import '../widgets/mol_chips.dart';
import '../widgets/page_body.dart';
import '../widgets/submission_viewer_dialog.dart';

class FormSubmissionHistoryScreen extends StatefulWidget {
  const FormSubmissionHistoryScreen({super.key, this.title});

  final String? title;

  @override
  State<FormSubmissionHistoryScreen> createState() =>
      _FormSubmissionHistoryScreenState();
}

class _FormSubmissionHistoryScreenState
    extends State<FormSubmissionHistoryScreen> {
  static final _formatter = DateFormat('d MMM yyyy, HH:mm');

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _rows = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await supabase
          .from('form_submissions')
          .select(
              'id,form_type,title,payload,workflow_status,current_signature_role,completed_at,created_at,updated_at')
          .order('created_at', ascending: false)
          .limit(100);
      if (!mounted) return;
      setState(() {
        _rows = (rows as List).cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _rows = const [];
        _loading = false;
      });
    }
  }

  String _formatDate(String? s) {
    if (s == null || s.isEmpty) return '';
    final d = DateTime.tryParse(s);
    return d == null ? s : _formatter.format(d.toLocal());
  }

  Future<void> _openDetails(Map<String, dynamic> row) {
    return showDialog(
      context: context,
      builder: (_) => SubmissionViewerDialog(row: row),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title ?? 'Form Submission History'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: PageBody.list(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(_error!,
                          style: TextStyle(color: scheme.error)),
                    )
                  : _rows.isEmpty
                      ? const EmptyState(
                          icon: Icons.description_outlined,
                          title: 'No saved submissions yet',
                          body:
                              'Submitted forms will appear here once they are saved.',
                        )
                      : RefreshIndicator(
                          onRefresh: _load,
                          child: SingleChildScrollView(
                            padding:
                                const EdgeInsets.fromLTRB(16, 12, 16, 24),
                            child: Card(
                              elevation: 1,
                              clipBehavior: Clip.antiAlias,
                              child: ListView.separated(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: _rows.length,
                                separatorBuilder: (_, _) => Divider(
                                  height: 1,
                                  color: MolTones.of(context).lineFaint,
                                ),
                                itemBuilder: (_, i) {
                                  final row = _rows[i];
                                  return _SubmissionRow(
                                    row: row,
                                    dateLabel: _formatDate(
                                        row['created_at'] as String?),
                                    onTap: () => _openDetails(row),
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
        ),
      ),
    );
  }
}

class _SubmissionRow extends StatefulWidget {
  const _SubmissionRow({
    required this.row,
    required this.dateLabel,
    required this.onTap,
  });

  final Map<String, dynamic> row;
  final String dateLabel;
  final VoidCallback onTap;

  @override
  State<_SubmissionRow> createState() => _SubmissionRowState();
}

class _SubmissionRowState extends State<_SubmissionRow> {
  bool _hover = false;

  StatusChipKind? _statusKind() {
    final status = widget.row['workflow_status'] as String?;
    if (status == 'fully_signed') return StatusChipKind.complete;
    if (status == 'pending_signature') return StatusChipKind.pending;
    return null;
  }

  String? _statusLabel() {
    final status = widget.row['workflow_status'] as String?;
    final role = widget.row['current_signature_role'] as String?;
    if (status == 'fully_signed') return 'Complete';
    if (status == 'pending_signature') {
      return role != null ? 'Pending • $role' : 'Pending';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    final kind = _statusKind();
    final label = _statusLabel();
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: Material(
        color: _hover ? tones.bgMuted : Colors.transparent,
        child: ListTile(
          onTap: widget.onTap,
          title: Text((widget.row['title'] as String?) ?? '—',
              maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(
                  (widget.row['form_type'] as String?) ?? '',
                  style: TextStyle(color: scheme.onSurfaceVariant),
                ),
                if (kind != null)
                  StatusChip(kind: kind, label: label, dense: true),
              ],
            ),
          ),
          trailing: Text(
            widget.dateLabel,
            style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
          ),
        ),
      ),
    );
  }
}
