import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_action_log_underground_visits_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class ActionLogUndergroundVisitsFormScreen extends StatefulWidget {
  const ActionLogUndergroundVisitsFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<ActionLogUndergroundVisitsFormScreen> createState() =>
      _ActionLogUndergroundVisitsFormScreenState();
}

class _ActionLogUndergroundVisitsFormScreenState
    extends State<ActionLogUndergroundVisitsFormScreen> {
  final _data = ActionLogUndergroundVisitsFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _generating = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('action_log_underground_visits');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final doc = await generateActionLogUndergroundVisitsPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Action_Log_Underground_Visits.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'action_log_underground_visits',
        _data.date.isNotEmpty
            ? 'Action Log Underground Visits — ${_data.date}'
            : 'Action Log Underground Visits',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _deviationRow(int i) {
    final d = _data.deviations[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 28,
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text('${i + 1}.'),
            ),
          ),
          Expanded(
            flex: 3,
            child: TextFormField(
              initialValue: d.deviationObserved,
              onChanged: (v) => d.deviationObserved = v,
              maxLines: 2,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Deviation observed',
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 3,
            child: TextFormField(
              initialValue: d.remedialAction,
              onChanged: (v) => d.remedialAction = v,
              maxLines: 2,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Remedial action',
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 130,
            child: DatePickerField(
              value: d.estimatedCompletionDate,
              onChanged: (v) => setState(() => d.estimatedCompletionDate = v),
              label: 'Est. completion',
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 130,
            child: DatePickerField(
              value: d.dateCompleted,
              onChanged: (v) => setState(() => d.dateCompleted = v),
              label: 'Date completed',
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              initialValue: d.signature,
              onChanged: (v) => d.signature = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Signature',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Action Log: Underground Visits'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 1180,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      "Action Log of Senior Official's Underground Visits",
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Working place visited',
                            _data.workingPlaceVisited,
                            (v) => _data.workingPlaceVisited = v,
                            id: 'workingPlaceVisited',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Name of senior official',
                            _data.nameOfSeniorOfficial,
                            (v) => _data.nameOfSeniorOfficial = v,
                            id: 'nameOfSeniorOfficial',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Designation',
                            _data.designation,
                            (v) => _data.designation = v,
                            id: 'designation',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Deviations',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          for (var i = 0; i < _data.deviations.length; i++)
                            _deviationRow(i),
                          if (!_isViewMode)
                            OutlinedButton.icon(
                              onPressed: () => setState(
                                () => _data.deviations.add(
                                  ActionLogDeviationEntry(),
                                ),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add Deviation'),
                            ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineOverseerSignature,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerSignature = v),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Senior Official Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.seniorOfficialSignature,
                            onChanged: (v) => setState(
                              () => _data.seniorOfficialSignature = v,
                            ),
                          ),
                          FormOverlayHost(
                            formType: 'action_log_underground_visits',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generating ? null : _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: Text(
                                    _generating
                                        ? 'Generating...'
                                        : 'Generate PDF',
                                  ),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
