import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/mobile_bottom_nav.dart';
import '../widgets/page_body.dart';
import '../widgets/dashboards/admin_dashboard.dart';
import '../widgets/dashboards/dashboard_card.dart';
import '../widgets/dashboards/mine_leadership_dashboard.dart';
import '../widgets/dashboards/shift_boss_dashboard.dart';
import '../widgets/dashboards/super_admin_dashboard.dart';
import 'admin_dashboard_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    final isAdmin = profile?.isAdmin == true || profile?.isSuperAdmin == true;
    final isSuperAdminHome = profile?.userAccountType == 'Super Admin' ||
        (profile?.isSuperAdmin ?? false);
    final isAdminHome =
        profile?.userAccountType == 'Admin' || (profile?.isAdmin ?? false);

    // Admin & Super Admin get the sidebar-driven AdminShell dashboard, which is
    // its own full Scaffold — return it directly instead of the centered grid.
    if (isSuperAdminHome || isAdminHome) {
      return const AdminDashboardScreen();
    }

    final isMineLeadershipHome =
        isMineOverseerProfile(profile) || isMineManagerProfile(profile);
    final isShiftBossHome = profile?.userAccountType == 'Shift Boss' ||
        isShiftBossProfile(profile);

    // Short-circuit role detection in the same order as src/components/Home.tsx
    Widget dashboard;
    if (isSuperAdminHome) {
      dashboard = const SuperAdminDashboard();
    } else if (isAdminHome) {
      dashboard = const AdminDashboard();
    } else if (isMineLeadershipHome) {
      dashboard = const MineLeadershipDashboard();
    } else if (isShiftBossHome) {
      dashboard = const ShiftBossDashboard();
    } else {
      dashboard = DashboardGrid(cards: _defaultCards(isAdmin: isAdmin));
    }

    return Scaffold(
      backgroundColor: scheme.surface,
      bottomNavigationBar: const MobileBottomNav(location: '/'),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
          child: PageBody(
            maxWidth: 1080,
            child: Column(
              children: [
                _Header(),
                const SizedBox(height: 32),
                Text(
                  'Black Rock Mine Operations',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.displaySmall,
                ),
                const SizedBox(height: 8),
                Text(
                  'Shift Boss Management System',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: scheme.onSurfaceVariant),
                ),
                const SizedBox(height: 32),
                dashboard,
                const SizedBox(height: 40),
                Text(
                  'Assmang (PTY) Limited — Black Rock Mine Operations',
                  style: TextStyle(
                    color: scheme.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

List<DashboardCardData> _defaultCards({required bool isAdmin}) => [
      const DashboardCardData(
        route: '/custom-forms',
        icon: Icons.list_alt_outlined,
        title: 'Custom Forms',
        description: 'Fill out forms published for your role.',
      ),
      const DashboardCardData(
        route: '/appointments',
        icon: Icons.assignment_outlined,
        title: 'Appointments',
        description: 'Create and manage appointment forms.',
      ),
      const DashboardCardData(
        route: '/my-profile',
        icon: Icons.person_outline,
        title: 'My Profile',
        description: 'Edit your personal profile and signature.',
      ),
      const DashboardCardData(
        route: '/profiles',
        icon: Icons.groups_outlined,
        title: 'User Profiles',
        description: 'Browse all employee profiles.',
      ),
      if (isAdmin)
        const DashboardCardData(
          route: '/admin',
          icon: Icons.shield_outlined,
          title: 'Admin Panel',
          description: 'System administration and user management.',
        ),
      const DashboardCardData(
        route: '/settings',
        icon: Icons.settings_outlined,
        title: 'Settings',
        description: 'System settings and configuration.',
      ),
    ];

const _kLogoAsset = 'assets/images/assmang-logo.png';
const _kLogoHeroTag = 'company-logo';

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(child: SizedBox()),
        // Borderless, shadow-free logo that reads as part of the page.
        // Tap to open a large version centred on the screen.
        Semantics(
          button: true,
          label: 'Black Rock Mine Operations logo',
          child: Tooltip(
            message: 'View logo',
            child: InkWell(
              onTap: () => _showLogoOverlay(context),
              borderRadius: BorderRadius.circular(12),
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Hero(
                  tag: _kLogoHeroTag,
                  child: Image(
                    image: AssetImage(_kLogoAsset),
                    height: 104,
                  ),
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: homeHeaderActions(),
          ),
        ),
      ],
    );
  }
}

/// Opens the company logo as a large, centred version of itself over a
/// dimmed backdrop. The logo sits on a white panel so its dark lettering
/// stays legible in both light and dark themes. Tap anywhere — or the
/// close button — to dismiss.
void _showLogoOverlay(BuildContext context) {
  showDialog<void>(
    context: context,
    barrierColor: Colors.black.withValues(alpha: 0.82),
    builder: (dialogContext) {
      final maxW = MediaQuery.of(dialogContext).size.width;
      return GestureDetector(
        onTap: () => Navigator.of(dialogContext).pop(),
        child: Stack(
          children: [
            Center(
              child: Hero(
                tag: _kLogoHeroTag,
                child: Material(
                  color: Colors.white,
                  elevation: 0,
                  borderRadius: BorderRadius.circular(20),
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: InteractiveViewer(
                      child: Image(
                        image: const AssetImage(_kLogoAsset),
                        width: (maxW * 0.7).clamp(240.0, 560.0),
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 24,
              right: 24,
              child: SafeArea(
                child: IconButton(
                  icon: const Icon(Icons.close),
                  color: Colors.white,
                  iconSize: 28,
                  tooltip: 'Close',
                  onPressed: () => Navigator.of(dialogContext).pop(),
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}
