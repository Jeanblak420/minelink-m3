// SP7 Analytics — admin dashboard of KPIs + breakdown charts + a submissions
// trend over a selectable date range. Client-side aggregation (no deps).

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/analytics_data.dart';
import '../utils/role_access.dart';
import '../widgets/admin/kpi_stat_card.dart';
import '../widgets/analytics/mini_bar_chart.dart';
import '../widgets/analytics/trend_sparkline.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  int _days = 30;
  bool _loading = true;
  String? _error;
  AnalyticsSummary? _summary;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = await loadAnalytics(days: _days);
      if (!mounted) return;
      setState(() {
        _summary = s;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Analytics'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Analytics is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : _body(context),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final s = _summary!;
    final tones = MolTones.of(context);
    return PageBody.list(
      scrollable: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 8,
            children: [
              for (final d in const [7, 30, 90, 365])
                ChoiceChip(
                  label: Text('${d}d'),
                  selected: _days == d,
                  onSelected: (_) {
                    setState(() => _days = d);
                    _load();
                  },
                ),
            ],
          ),
          const SizedBox(height: 16),

          // Forms
          _section(
            'Forms',
            [
              KpiStatCard(
                label: 'Submissions',
                value: s.formsTotal,
                icon: Icons.description_outlined,
                tone: tones.info,
                loading: false,
              ),
              if (s.formsChangePct != null)
                _statTile(
                  'vs previous',
                  '${s.formsChangePct! >= 0 ? '+' : ''}${s.formsChangePct!.round()}%',
                  s.formsChangePct! >= 0 ? tones.success : tones.danger,
                ),
            ],
            children: [
              _label('Submissions trend (per day)'),
              TrendSparkline(values: s.formsPerDay, color: tones.info.accent),
              const SizedBox(height: 12),
              _label('By form'),
              MiniBarChart(
                data: sortedDesc(s.formsByType),
                color: tones.info.accent,
              ),
              const SizedBox(height: 12),
              _label('By workflow status'),
              MiniBarChart(
                data: sortedDesc(s.formsByStatus),
                color: tones.warning.accent,
              ),
            ],
          ),

          // Appointments
          _section(
            'Appointments',
            [
              KpiStatCard(
                label: 'Issued',
                value: s.apptTotal,
                icon: Icons.assignment_ind_outlined,
                tone: tones.info,
                loading: false,
              ),
              _statTile(
                'Acceptance',
                '${(s.apptAcceptanceRate * 100).round()}%',
                tones.success,
              ),
            ],
            children: [
              _label('By status'),
              MiniBarChart(
                data: sortedDesc(s.apptByStatus),
                color: tones.success.accent,
              ),
              const SizedBox(height: 12),
              _label('By role'),
              MiniBarChart(
                data: sortedDesc(s.apptByRole),
                color: tones.info.accent,
              ),
            ],
          ),

          // Users & devices
          _section(
            'Users & Devices',
            [
              KpiStatCard(
                label: 'Devices',
                value: s.devicesTotal,
                icon: Icons.devices_outlined,
                tone: tones.info,
                loading: false,
              ),
              KpiStatCard(
                label: 'Pending devices',
                value: s.devicesPending,
                icon: Icons.pending_outlined,
                tone: tones.warning,
                loading: false,
              ),
            ],
            children: [
              _label('Users by account type'),
              MiniBarChart(
                data: sortedDesc(s.profilesByAccountType),
                color: tones.info.accent,
              ),
              const SizedBox(height: 12),
              _label('Devices by platform'),
              MiniBarChart(
                data: sortedDesc(s.devicesByPlatform),
                color: tones.success.accent,
              ),
            ],
          ),

          // Signatures
          _section(
            'Signatures',
            [
              _statTile(
                'Completion',
                '${(s.sigCompletionRate * 100).round()}%',
                tones.success,
              ),
            ],
            children: [
              _label('Pending by role'),
              MiniBarChart(
                data: sortedDesc(s.sigPendingByRole),
                color: tones.warning.accent,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _section(
    String title,
    List<Widget> kpis, {
    required List<Widget> children,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [for (final k in kpis) SizedBox(width: 220, child: k)],
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(
      t,
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
      ),
    ),
  );

  Widget _statTile(String label, String value, MolTone tone) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: tone.tint,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: tone.fg, fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: tone.accent,
              fontSize: 24,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
