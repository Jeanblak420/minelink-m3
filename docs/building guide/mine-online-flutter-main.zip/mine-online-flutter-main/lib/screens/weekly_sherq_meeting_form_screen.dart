import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_weekly_sherq_meeting_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

const _topicLabels = <(String, String)>[
  ('standards', 'Standards'),
  ('incident', 'Incident'),
  ('emergencyPreparedness', 'Emergency Preparedness'),
  ('soReport', 'S/O Report'),
  ('instruction', 'Instruction'),
  ('rockMechanicReport', 'Rock Mechanic Report'),
  ('ppe', 'PPE'),
  ('sheRepReport', 'SHE REP Report'),
  ('procedures', 'Procedures'),
  ('ventReport', 'Vent Report'),
];

class WeeklySherqMeetingFormScreen extends StatefulWidget {
  const WeeklySherqMeetingFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<WeeklySherqMeetingFormScreen> createState() =>
      _WeeklySherqMeetingFormScreenState();
}

class _WeeklySherqMeetingFormScreenState
    extends State<WeeklySherqMeetingFormScreen> {
  final _data = WeeklySherqMeetingFormData(
    attendance: List.generate(10, (_) => AttendanceEntry()),
  );

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('weekly_sherq_meeting');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    try {
      final doc = await generateWeeklySherqMeetingPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Weekly_SHERQ_Meeting.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'weekly_sherq_meeting',
        _data.date.isNotEmpty
            ? 'Weekly SHERQ Meeting — ${_data.date}'
            : 'Weekly SHERQ Meeting',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  bool _topicValue(String key) {
    final t = _data.topics;
    switch (key) {
      case 'standards':
        return t.standards;
      case 'incident':
        return t.incident;
      case 'emergencyPreparedness':
        return t.emergencyPreparedness;
      case 'soReport':
        return t.soReport;
      case 'instruction':
        return t.instruction;
      case 'rockMechanicReport':
        return t.rockMechanicReport;
      case 'ppe':
        return t.ppe;
      case 'sheRepReport':
        return t.sheRepReport;
      case 'procedures':
        return t.procedures;
      case 'ventReport':
        return t.ventReport;
    }
    return false;
  }

  void _setTopicValue(String key, bool v) {
    final t = _data.topics;
    switch (key) {
      case 'standards':
        t.standards = v;
        break;
      case 'incident':
        t.incident = v;
        break;
      case 'emergencyPreparedness':
        t.emergencyPreparedness = v;
        break;
      case 'soReport':
        t.soReport = v;
        break;
      case 'instruction':
        t.instruction = v;
        break;
      case 'rockMechanicReport':
        t.rockMechanicReport = v;
        break;
      case 'ppe':
        t.ppe = v;
        break;
      case 'sheRepReport':
        t.sheRepReport = v;
        break;
      case 'procedures':
        t.procedures = v;
        break;
      case 'ventReport':
        t.ventReport = v;
        break;
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Weekly SHERQ Meeting'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Weekly SHERQ Meeting',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Time',
                            _data.time,
                            (v) => _data.time = v,
                            id: 'time',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Workplace',
                            _data.workplace,
                            (v) => _data.workplace = v,
                            id: 'workplace',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Duration',
                            _data.duration,
                            (v) => _data.duration = v,
                            id: 'duration',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Supervisor Coy No.',
                            _data.supervisorCoyNo,
                            (v) => _data.supervisorCoyNo = v,
                            id: 'supervisorCoyNo',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'SHE REP Coy No.',
                            _data.sheRepCoyNo,
                            (v) => _data.sheRepCoyNo = v,
                            id: 'sheRepCoyNo',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Topics discussed',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 4,
                            children: [
                              for (final (key, label) in _topicLabels)
                                FilterChip(
                                  label: Text(label),
                                  selected: _topicValue(key),
                                  onSelected: (v) =>
                                      setState(() => _setTopicValue(key, v)),
                                ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            'Matters Discussed',
                            _data.mattersDiscussed,
                            (v) => _data.mattersDiscussed = v,
                            maxLines: 4,
                            id: 'mattersDiscussed',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Feedback from Crew',
                            _data.feedbackFromCrew,
                            (v) => _data.feedbackFromCrew = v,
                            maxLines: 4,
                            id: 'feedbackFromCrew',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Attendance',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (var i = 0; i < _data.attendance.length; i++)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: _tf(
                                      'Coy No. ${i + 1}',
                                      _data.attendance[i].coyNo,
                                      (v) => _data.attendance[i].coyNo = v,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _tf(
                                      'Signature ${i + 1}',
                                      _data.attendance[i].signature,
                                      (v) => _data.attendance[i].signature = v,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(height: 24),
                          Text(
                            'Supervisor Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.supervisorSignature,
                            onChanged: (v) =>
                                setState(() => _data.supervisorSignature = v),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'SHE Rep Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.sheRepSignature,
                            onChanged: (v) =>
                                setState(() => _data.sheRepSignature = v),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineOverseerSignature,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerSignature = v),
                          ),
                          FormOverlayHost(
                            formType: 'weekly_sherq_meeting',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: const Text('Generate PDF'),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
