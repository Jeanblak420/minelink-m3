import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_special_instruction_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/signature_canvas.dart';

class SpecialInstructionFormScreen extends StatefulWidget {
  const SpecialInstructionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<SpecialInstructionFormScreen> createState() =>
      _SpecialInstructionFormScreenState();
}

class _SpecialInstructionFormScreenState
    extends State<SpecialInstructionFormScreen> {
  final _data = SpecialInstructionFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('special_instruction');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'special_instruction',
        'Special Instruction',
        payload,
      );
      final doc = await generateSpecialInstructionPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Special_Instruction.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Widget _sectionBlock(
    String title,
    SpecialInstructionSection sec,
    String idPrefix,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        DatePickerField(
          value: sec.date,
          onChanged: (v) => setState(() => sec.date = v),
        ),
        const SizedBox(height: 12),
        _tf('Time', sec.time, (v) => sec.time = v, id: '$idPrefix.time'),
        const SizedBox(height: 12),
        _tf(
          'Instruction to',
          sec.instructionTo,
          (v) => sec.instructionTo = v,
          id: '$idPrefix.instructionTo',
        ),
        const SizedBox(height: 12),
        _tf(
          'Detail of instruction',
          sec.detailOfInstruction,
          (v) => sec.detailOfInstruction = v,
          maxLines: 4,
          id: '$idPrefix.detailOfInstruction',
        ),
        const SizedBox(height: 12),
        _tf(
          'Remedial action',
          sec.remedialAction,
          (v) => sec.remedialAction = v,
          maxLines: 3,
          id: '$idPrefix.remedialAction',
        ),
        const SizedBox(height: 16),
        Text('Issuer Signature', style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        SignatureCanvasField(
          value: sec.issuerSignature,
          onChanged: (v) => setState(() => sec.issuerSignature = v),
        ),
        const SizedBox(height: 8),
        DatePickerField(
          value: sec.issuerSignatureDate,
          onChanged: (v) => setState(() => sec.issuerSignatureDate = v),
          label: 'Issuer date',
        ),
        const SizedBox(height: 12),
        Text(
          'Receiver Signature',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        SignatureCanvasField(
          value: sec.receiverSignature,
          onChanged: (v) => setState(() => sec.receiverSignature = v),
        ),
        const SizedBox(height: 8),
        DatePickerField(
          value: sec.receiverSignatureDate,
          onChanged: (v) => setState(() => sec.receiverSignatureDate = v),
          label: 'Receiver date',
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Special Instruction'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Special Instruction',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _sectionBlock(
                            'Section 1',
                            _data.section1,
                            'section1',
                          ),
                          const SizedBox(height: 32),
                          const Divider(thickness: 2),
                          const SizedBox(height: 16),
                          _sectionBlock(
                            'Section 2',
                            _data.section2,
                            'section2',
                          ),
                          FormOverlayHost(
                            formType: 'special_instruction',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
