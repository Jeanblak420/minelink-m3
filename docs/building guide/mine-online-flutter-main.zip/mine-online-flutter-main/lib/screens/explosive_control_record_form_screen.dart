import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_explosive_control_record_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

class ExplosiveControlRecordFormScreen extends StatefulWidget {
  const ExplosiveControlRecordFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<ExplosiveControlRecordFormScreen> createState() =>
      _ExplosiveControlRecordFormScreenState();
}

class _ExplosiveControlRecordFormScreenState
    extends State<ExplosiveControlRecordFormScreen> {
  final _data = ExplosiveControlRecordFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _generating = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};
  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('explosive_control_record');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
        if (_data.shiftBossDate.trim().isEmpty) {
          _data.shiftBossDate = _today;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final doc = await generateExplosiveControlRecordPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Explosive_Control_Record.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'explosive_control_record',
        _data.date.isNotEmpty
            ? 'Explosive Control Record — ${_data.date}'
            : 'Explosive Control Record',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _yn(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return Row(
      children: [
        Expanded(child: Text(ov?.label ?? label)),
        SizedBox(
          width: 110,
          child: DropdownButtonFormField<String>(
            initialValue: value.isEmpty ? null : value,
            decoration: const InputDecoration(
              isDense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'Yes', child: Text('Yes')),
              DropdownMenuItem(value: 'No', child: Text('No')),
            ],
            onChanged: (v) => onChanged(v ?? ''),
          ),
        ),
      ],
    );
  }

  Widget _entryRow(int i) {
    final e = _data.entries[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 28,
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text('${i + 1}.'),
            ),
          ),
          Expanded(
            flex: 4,
            child: TextFormField(
              initialValue: e.description,
              onChanged: (v) => e.description = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Description',
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 90,
            child: TextFormField(
              initialValue: e.boxNo,
              onChanged: (v) => e.boxNo = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Box No.',
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              initialValue: e.amountInControlBook,
              onChanged: (v) => e.amountInControlBook = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'In control book',
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              initialValue: e.amountObserved,
              onChanged: (v) => e.amountObserved = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Observed',
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              initialValue: e.amountDelivered,
              onChanged: (v) => e.amountDelivered = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Delivered yesterday',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Explosive Control Record'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 1080,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Explosive Control Record',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _tf(
                            'Section',
                            _data.section,
                            (v) => _data.section = v,
                            id: 'section',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Strike',
                            _data.strike,
                            (v) => _data.strike = v,
                            id: 'strike',
                          ),
                          const SizedBox(height: 12),
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Miner Coy No.',
                            _data.minerCoyNo,
                            (v) => _data.minerCoyNo = v,
                            id: 'minerCoyNo',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Entries',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          for (var i = 0; i < _data.entries.length; i++)
                            _entryRow(i),
                          if (!_isViewMode)
                            OutlinedButton.icon(
                              onPressed: () => setState(
                                () =>
                                    _data.entries.add(ExplosiveControlEntry()),
                              ),
                              icon: const Icon(Icons.add),
                              label: const Text('Add Entry'),
                            ),
                          const SizedBox(height: 24),
                          _yn(
                            'Deviations observed?',
                            _data.deviationsObserved,
                            (v) => setState(() => _data.deviationsObserved = v),
                            id: 'deviationsObserved',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            "If 'yes', give details and remedial actions",
                            _data.deviationsDetails,
                            (v) => _data.deviationsDetails = v,
                            maxLines: 2,
                            id: 'deviationsDetails',
                          ),
                          const SizedBox(height: 16),
                          _yn(
                            'Are the old explosive boxes marked?',
                            _data.oldBoxesMarked,
                            (v) => setState(() => _data.oldBoxesMarked = v),
                            id: 'oldBoxesMarked',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            "If 'NO', give details and remedial actions",
                            _data.oldBoxesMarkedDetails,
                            (v) => _data.oldBoxesMarkedDetails = v,
                            maxLines: 2,
                            id: 'oldBoxesMarkedDetails',
                          ),
                          const SizedBox(height: 16),
                          _yn(
                            'Are the old explosive boxes locked?',
                            _data.oldBoxesLocked,
                            (v) => setState(() => _data.oldBoxesLocked = v),
                            id: 'oldBoxesLocked',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            "If 'no' give details and remedial actions",
                            _data.oldBoxesLockedDetails,
                            (v) => _data.oldBoxesLockedDetails = v,
                            maxLines: 2,
                            id: 'oldBoxesLockedDetails',
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            'Type of explosive in the box?',
                            _data.typeOfExplosiveInBox,
                            (v) => _data.typeOfExplosiveInBox = v,
                            id: 'typeOfExplosiveInBox',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Total in the box',
                            _data.totalInBox,
                            (v) => _data.totalInBox = v,
                            id: 'totalInBox',
                          ),
                          const SizedBox(height: 16),
                          _yn(
                            'Recorded correctly in the miners control book?',
                            _data.recordedCorrectly,
                            (v) => setState(() => _data.recordedCorrectly = v),
                            id: 'recordedCorrectly',
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            "If 'no' give details and remedial actions",
                            _data.recordedDetails,
                            (v) => _data.recordedDetails = v,
                            maxLines: 2,
                            id: 'recordedDetails',
                          ),
                          const SizedBox(height: 16),
                          _tf(
                            'Special instructions given',
                            _data.specialInstructions,
                            (v) => _data.specialInstructions = v,
                            maxLines: 3,
                            id: 'specialInstructions',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossDate,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossDate = v),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineOverseerSignature,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.mineOverseerDate,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerDate = v),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'explosive_control_record',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generating ? null : _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: Text(
                                    _generating
                                        ? 'Generating...'
                                        : 'Generate PDF',
                                  ),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
