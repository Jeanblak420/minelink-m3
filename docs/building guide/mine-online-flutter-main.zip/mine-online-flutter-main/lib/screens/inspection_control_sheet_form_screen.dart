import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../pdf/generate_inspection_control_sheet_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';

const List<int> _dayCols = [
  26,
  27,
  28,
  29,
  30,
  31,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  16,
  17,
  18,
  19,
  20,
  21,
  22,
  23,
  24,
  25,
];

class InspectionControlSheetFormScreen extends StatefulWidget {
  const InspectionControlSheetFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<InspectionControlSheetFormScreen> createState() =>
      _InspectionControlSheetFormScreenState();
}

class _InspectionControlSheetFormScreenState
    extends State<InspectionControlSheetFormScreen> {
  final _data = InspectionControlSheetFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('inspection_control_sheet');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'inspection_control_sheet',
        'Inspection Control Sheet',
        payload,
      );
      final doc = await generateInspectionControlSheetPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Inspection_Control_Sheet.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Inspection Control Sheet'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: PageBody.form(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Inspection Control Sheet',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: _tf(
                                  'Month from',
                                  _data.monthFrom,
                                  (v) => _data.monthFrom = v,
                                  id: 'monthFrom',
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _tf(
                                  'Month to',
                                  _data.monthTo,
                                  (v) => _data.monthTo = v,
                                  id: 'monthTo',
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'Abbreviations: B – Blasted, L - Loaded, S – Supported, I – Inspected, N – Not Inspected',
                          ),
                          const SizedBox(height: 16),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: DataTable(
                              columnSpacing: 8,
                              columns: [
                                const DataColumn(label: Text('Workplace')),
                                for (final d in _dayCols)
                                  DataColumn(label: Text('$d')),
                              ],
                              rows: [
                                for (var i = 0; i < _data.rows.length; i++)
                                  DataRow(
                                    cells: [
                                      DataCell(
                                        SizedBox(
                                          width: 160,
                                          child: TextFormField(
                                            initialValue:
                                                _data.rows[i].workplace,
                                            onChanged: (v) =>
                                                _data.rows[i].workplace = v,
                                            decoration: const InputDecoration(
                                              isDense: true,
                                              contentPadding:
                                                  EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 8,
                                                  ),
                                              border: OutlineInputBorder(),
                                            ),
                                          ),
                                        ),
                                      ),
                                      for (var d = 0; d < _dayCols.length; d++)
                                        DataCell(
                                          SizedBox(
                                            width: 36,
                                            child: TextFormField(
                                              initialValue:
                                                  _data.rows[i].days[d],
                                              onChanged: (v) =>
                                                  _data.rows[i].days[d] = v,
                                              textAlign: TextAlign.center,
                                              decoration: const InputDecoration(
                                                isDense: true,
                                                contentPadding:
                                                    EdgeInsets.symmetric(
                                                      horizontal: 4,
                                                      vertical: 8,
                                                    ),
                                                border: OutlineInputBorder(),
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: OutlinedButton.icon(
                                onPressed: () => setState(
                                  () => _data.rows.add(
                                    InspectionControlSheetRow(),
                                  ),
                                ),
                                icon: const Icon(Icons.add),
                                label: const Text('Add Row'),
                              ),
                            ),
                          FormOverlayHost(
                            formType: 'inspection_control_sheet',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
