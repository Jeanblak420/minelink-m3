import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../pdf/generate_monthly_fire_fighting_inspection_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/signature_canvas.dart';

class MonthlyFireFightingInspectionFormScreen extends StatefulWidget {
  const MonthlyFireFightingInspectionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<MonthlyFireFightingInspectionFormScreen> createState() =>
      _MonthlyFireFightingInspectionFormScreenState();
}

class _MonthlyFireFightingInspectionFormScreenState
    extends State<MonthlyFireFightingInspectionFormScreen> {
  final _data = MonthlyFireFightingInspectionFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('monthly_fire_fighting_inspection');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'monthly_fire_fighting_inspection',
        'Monthly Fire Fighting Inspection',
        payload,
      );
      final doc = await generateMonthlyFireFightingInspectionPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Monthly_Fire_Fighting_Inspection.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _entryRow(int i) {
    final e = _data.entries[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          SizedBox(width: 32, child: Center(child: Text('${i + 1}.'))),
          SizedBox(
            width: 160,
            child: TextFormField(
              initialValue: e.workingPlace,
              onChanged: (v) => e.workingPlace = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Working place',
              ),
            ),
          ),
          SizedBox(
            width: 120,
            child: TextFormField(
              initialValue: e.localityVehicleNo,
              onChanged: (v) => e.localityVehicleNo = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Locality / Vehicle no.',
              ),
            ),
          ),
          SizedBox(
            width: 140,
            child: DatePickerField(
              value: e.inspectionDate,
              onChanged: (v) => setState(() => e.inspectionDate = v),
              label: 'Inspection date',
            ),
          ),
          SizedBox(
            width: 110,
            child: TextFormField(
              initialValue: e.conditionOfSeal,
              onChanged: (v) => e.conditionOfSeal = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Cond. of seal',
              ),
            ),
          ),
          SizedBox(
            width: 110,
            child: TextFormField(
              initialValue: e.pressureGauge,
              onChanged: (v) => e.pressureGauge = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Pressure gauge',
              ),
            ),
          ),
          SizedBox(
            width: 130,
            child: TextFormField(
              initialValue: e.conditionOfHandleNozzle,
              onChanged: (v) => e.conditionOfHandleNozzle = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Handle/nozzle',
              ),
            ),
          ),
          SizedBox(
            width: 110,
            child: TextFormField(
              initialValue: e.conditionOfHose,
              onChanged: (v) => e.conditionOfHose = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Hose',
              ),
            ),
          ),
          SizedBox(
            width: 160,
            child: TextFormField(
              initialValue: e.deficiency,
              onChanged: (v) => e.deficiency = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Deficiency / action',
              ),
            ),
          ),
          SizedBox(
            width: 150,
            child: DatePickerField(
              value: e.dateOfLastAnnualService,
              onChanged: (v) => setState(() => e.dateOfLastAnnualService = v),
              label: 'Last annual service',
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Monthly Fire Fighting Inspection'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 1180,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Monthly Fire Fighting Equipment Inspection Report',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _tf(
                            'Department',
                            _data.department,
                            (v) => _data.department = v,
                            id: 'department',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Area',
                            _data.area,
                            (v) => _data.area = v,
                            id: 'area',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Name',
                            _data.name,
                            (v) => _data.name = v,
                            id: 'name',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Designation',
                            _data.designation,
                            (v) => _data.designation = v,
                            id: 'designation',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Equipment Inspection Entries',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          for (var i = 0; i < _data.entries.length; i++)
                            _entryRow(i),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: OutlinedButton.icon(
                                onPressed: () => setState(
                                  () => _data.entries.add(
                                    FireFightingEquipmentEntry(),
                                  ),
                                ),
                                icon: const Icon(Icons.add),
                                label: const Text('Add Entry'),
                              ),
                            ),
                          const SizedBox(height: 24),
                          Text(
                            'Inspector Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.inspectorSignature,
                            onChanged: (v) =>
                                setState(() => _data.inspectorSignature = v),
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Inspector name',
                            _data.inspectorName,
                            (v) => _data.inspectorName = v,
                            id: 'inspectorName',
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.inspectorDate,
                            onChanged: (v) =>
                                setState(() => _data.inspectorDate = v),
                            label: 'Inspector date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Section Head Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.sectionHeadSignature,
                            onChanged: (v) =>
                                setState(() => _data.sectionHeadSignature = v),
                          ),
                          const SizedBox(height: 8),
                          _tf(
                            'Section head name',
                            _data.sectionHeadName,
                            (v) => _data.sectionHeadName = v,
                            id: 'sectionHeadName',
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.sectionHeadDate,
                            onChanged: (v) =>
                                setState(() => _data.sectionHeadDate = v),
                            label: 'Section head date',
                          ),
                          FormOverlayHost(
                            formType: 'monthly_fire_fighting_inspection',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
