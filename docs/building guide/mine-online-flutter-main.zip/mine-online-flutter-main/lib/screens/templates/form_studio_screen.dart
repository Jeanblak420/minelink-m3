// FS1 Form Template Studio: Originals (read-only, clone-to-edit, never delete) +
// Edited (drafts: edit / test / set active / delete). The active draft drives
// the real form (loadFormOverlay); the original is the permanent fallback.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../models/form_view_args.dart';
import '../../providers/auth_provider.dart';
import '../../utils/form_metadata.dart';
import '../../utils/form_overlay_data.dart';
import '../../utils/form_registry.dart';
import '../../utils/role_access.dart';
import '../../utils/signature_workflow.dart' show formTestMode;
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';
import '../form_builder_screen.dart' show OverlayEditorScreen;

class FormStudioScreen extends StatefulWidget {
  const FormStudioScreen({super.key});

  @override
  State<FormStudioScreen> createState() => _FormStudioScreenState();
}

class _FormStudioScreenState extends State<FormStudioScreen> {
  bool _loading = true;
  String? _error;
  List<OverlayDraft> _drafts = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final drafts = await listOverlayDrafts();
      if (!mounted) return;
      setState(() {
        _drafts = drafts;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _editDraft(String id, String baseFormType) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) =>
            OverlayEditorScreen(draftId: id, baseFormType: baseFormType),
      ),
    );
    if (mounted) _load();
  }

  Future<void> _editOriginal(FormMetadata m) async {
    final id = await createOverlayDraft(m.formType, 'Copy of ${m.title}');
    if (!mounted) return;
    await _editDraft(id, m.formType);
  }

  Future<void> _test(OverlayDraft draft) async {
    final view = buildFormView(
      draft.baseFormType,
      FormViewArgs(overlayOverride: draft.overlay),
    );
    if (view == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No test view for this form.')),
      );
      return;
    }
    formTestMode = true;
    await Navigator.of(
      context,
    ).push<void>(MaterialPageRoute(builder: (_) => view)).whenComplete(() {
      formTestMode = false;
    });
  }

  Future<void> _setActive(OverlayDraft draft) async {
    await setOverlayDraftActive(draft.id, draft.baseFormType);
    if (mounted) _load();
  }

  Future<void> _deactivate(OverlayDraft draft) async {
    await deactivateOverlayForForm(draft.baseFormType);
    if (mounted) _load();
  }

  Future<void> _delete(OverlayDraft draft) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete edited form?'),
        content: Text(
          'Delete "${draft.name}"? This cannot be undone. The original form is '
          'unaffected.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await deleteOverlayDraft(draft.id);
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Form Studio'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Form Studio is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Form Studio'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
          actions: [
            IconButton(
              tooltip: 'Refresh',
              onPressed: _loading ? null : _load,
              icon: const Icon(Icons.refresh),
            ),
            ...commonAppBarActions(),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Originals'),
              Tab(text: 'Edited'),
            ],
          ),
        ),
        body: SafeArea(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(_error!, style: TextStyle(color: scheme.error)),
                  ),
                )
              : TabBarView(children: [_originals(scheme), _edited(scheme)]),
        ),
      ),
    );
  }

  Widget _originals(ColorScheme scheme) {
    return PageBody.list(
      scrollable: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Tap Edit to make an editable copy. Originals are never changed or '
            'deleted.',
            style: TextStyle(color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 8),
          for (final entry in groupFormsByCategory(
            kFormMetadataRegistry,
          ).entries) ...[
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 4),
              child: Text(
                entry.key,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
            for (final m in entry.value)
              Card(
                margin: const EdgeInsets.only(bottom: 6),
                child: ListTile(
                  title: Text(m.title),
                  subtitle: () {
                    final active = activeDraftName(_drafts, m.formType);
                    return active == null
                        ? Text(m.category)
                        : Text('${m.category} • Active: $active');
                  }(),
                  trailing: FilledButton.tonalIcon(
                    onPressed: () => _editOriginal(m),
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    label: const Text('Edit'),
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _edited(ColorScheme scheme) {
    if (_drafts.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'No edited forms yet. Edit an original to create one.',
            textAlign: TextAlign.center,
            style: TextStyle(color: scheme.onSurfaceVariant),
          ),
        ),
      );
    }
    return PageBody.list(
      scrollable: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final draft in _drafts)
            Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            draft.name,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        if (draft.isActive)
                          Chip(
                            label: const Text('Active'),
                            visualDensity: VisualDensity.compact,
                            backgroundColor: scheme.secondaryContainer,
                          ),
                      ],
                    ),
                    Text(
                      formMetadataByType(draft.baseFormType)?.title ??
                          draft.baseFormType,
                      style: TextStyle(
                        fontSize: 12,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () =>
                              _editDraft(draft.id, draft.baseFormType),
                          icon: const Icon(Icons.edit_outlined, size: 18),
                          label: const Text('Edit'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => _test(draft),
                          icon: const Icon(Icons.play_arrow_outlined, size: 18),
                          label: const Text('Test'),
                        ),
                        if (draft.isActive)
                          OutlinedButton.icon(
                            onPressed: () => _deactivate(draft),
                            icon: const Icon(Icons.pause_outlined, size: 18),
                            label: const Text('Deactivate'),
                          )
                        else
                          FilledButton.tonalIcon(
                            onPressed: () => _setActive(draft),
                            icon: const Icon(Icons.check, size: 18),
                            label: const Text('Set active'),
                          ),
                        IconButton(
                          tooltip: 'Delete',
                          onPressed: () => _delete(draft),
                          icon: Icon(Icons.delete_outline, color: scheme.error),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
