import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_overlay.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_waiting_place_inspection_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/form_sign_actions.dart';
import '../widgets/signature_canvas.dart';

const List<String> _labels = [
  'Is the waiting place sign posted?',
  'Is the dustbin sign posted?',
  'Is the waiting place clean?',
  'Is the waiting place illuminated?',
  'Is the waiting place disinfectant available and disinfected?',
  'Are the seating available?',
  'Are the seating secured and safe?',
  'Are the ticket boards/box available and posted?',
  'Are the ticket boards/box locked?',
  'Are clothing racks available and secured?',
  'Is the waiting place whitewashed?',
  'Are the roofbolts installed in the hangingwall as per mine standard?',
  'Are the geological features demarcated?',
  'Are the geological features supported as per the mine standard?',
  'Are the sidewalls secured?',
  'Are the sidewalls and the hangingwall barred down to solid?',
  'Is the waiting place ventilated?',
  'Good housekeeping?',
  'Is the noticeboard banners posted secured and updated?',
  'Is the entry examination board available, posted and secured?',
  'Is the waiting place barricade available? (Entry to workings)',
  'Are the signs posted?',
  'Level and secured?',
  'Toilets lockable?',
  'Is the toilet clean and disinfected?',
  'Is the area illuminated?',
  'Is the area ventilated?',
  'Is the wash water available?',
  'Is there a good housekeeping in the area?',
];

class WaitingPlaceInspectionFormScreen extends StatefulWidget {
  const WaitingPlaceInspectionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<WaitingPlaceInspectionFormScreen> createState() =>
      _WaitingPlaceInspectionFormScreenState();
}

class _WaitingPlaceInspectionFormScreenState
    extends State<WaitingPlaceInspectionFormScreen> {
  final _data = WaitingPlaceInspectionFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _generating = false;
  bool _submitting = false;
  String? _submitError;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};
  static final _today = DateFormat('dd/MM/yyyy').format(DateTime.now());

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('waiting_place_inspection');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final savedSig = (profile.signatureData ?? '').trim();
      if (savedSig.isNotEmpty) {
        if (_data.shiftBossSignature.trim().isEmpty) {
          _data.shiftBossSignature = savedSig;
        }
        if (_data.shiftBossDate.trim().isEmpty) {
          _data.shiftBossDate = _today;
        }
      }
    }
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final doc = await generateWaitingPlaceInspectionPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Waiting_Place_Inspection.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _submit() async {
    final profile = context.read<AuthProvider>().profile;
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      final id = await saveFormSubmissionAndStartWorkflow(
        'waiting_place_inspection',
        _data.date.isNotEmpty
            ? 'Waiting Place Inspection — ${_data.date}'
            : 'Waiting Place Inspection',
        payload,
        profile: profile,
      );
      if (id != null && mounted) {
        context.go('/current-logbook?submitted=$id');
      } else if (mounted) {
        setState(() => _submitError = 'Submission failed — please try again.');
      }
    } catch (err) {
      setState(() => _submitError = err.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _itemRow(int i) {
    final item = _data.items[i];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 28,
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text('${i + 1}.'),
            ),
          ),
          Expanded(
            flex: 6,
            child: Padding(
              padding: const EdgeInsets.only(top: 14, right: 8),
              child: Text(_labels[i]),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Checkbox(
              value: item.yes,
              onChanged: (v) => setState(() {
                item.yes = v ?? false;
                if (item.yes) item.no = false;
              }),
            ),
          ),
          const Padding(padding: EdgeInsets.only(top: 14), child: Text('Yes')),
          const SizedBox(width: 8),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Checkbox(
              value: item.no,
              onChanged: (v) => setState(() {
                item.no = v ?? false;
                if (item.no) item.yes = false;
              }),
            ),
          ),
          const Padding(padding: EdgeInsets.only(top: 14), child: Text('No')),
          const SizedBox(width: 12),
          Expanded(
            flex: 4,
            child: TextFormField(
              initialValue: item.remarks,
              onChanged: (v) => item.remarks = v,
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 12,
                ),
                border: OutlineInputBorder(),
                hintText: 'Remarks',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Waiting Place Inspection'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 980,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Waiting Place Inspection Record',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _tf(
                            'Section',
                            _data.section,
                            (v) => _data.section = v,
                            id: 'section',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Miner',
                            _data.miner,
                            (v) => _data.miner = v,
                            id: 'miner',
                          ),
                          const SizedBox(height: 12),
                          DatePickerField(
                            value: _data.date,
                            onChanged: (v) => setState(() => _data.date = v),
                          ),
                          const SizedBox(height: 24),
                          for (var i = 0; i < 21; i++) _itemRow(i),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: 8,
                              horizontal: 12,
                            ),
                            color: scheme.surfaceContainerHigh,
                            child: const Text(
                              'UNDERGROUND PORTABLE TOILETS',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(height: 12),
                          for (var i = 21; i < 29; i++) _itemRow(i),
                          const SizedBox(height: 16),
                          _tf(
                            'Special instructions given',
                            _data.specialInstructions,
                            (v) => _data.specialInstructions = v,
                            maxLines: 3,
                            id: 'specialInstructions',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossDate,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossDate = v),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineOverseerSignature,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.mineOverseerDate,
                            onChanged: (v) =>
                                setState(() => _data.mineOverseerDate = v),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'waiting_place_inspection',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          if (_submitError != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _submitError!,
                              style: TextStyle(color: scheme.error),
                            ),
                          ],
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: _generating ? null : _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: Text(
                                    _generating
                                        ? 'Generating...'
                                        : 'Generate PDF',
                                  ),
                                ),
                                FilledButton.icon(
                                  onPressed: _submitting ? null : _submit,
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(
                                    _submitting
                                        ? 'Submitting...'
                                        : 'Submit for Approval',
                                  ),
                                ),
                              ],
                            ),
                          if (widget.viewArgs?.canSign ?? false)
                            FormSignActions(
                              viewArgs: widget.viewArgs!,
                              onActionDone: (status) {
                                if (context.mounted) {
                                  Navigator.of(context).pop(status);
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
