// Mirrors src/components/UserProfiles.tsx (lines 174-972). Full admin CRUD over
// the `profiles` table with create / edit / delete flows that talk to the
// `admin-create-user` Supabase edge function. Non-admin users still see the
// list but the edit / create / delete affordances are hidden.

// ignore_for_file: unnecessary_underscores

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../config/supabase_client.dart';
import '../constants/account_types.dart';
import '../constants/occupations.dart';
import '../constants/profile_options.dart';
import '../providers/auth_provider.dart';
import '../theme/mol_tones.dart';
import '../utils/admin_user.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/empty_state.dart';
import '../widgets/mol_chips.dart';
import '../widgets/page_body.dart';
import '../widgets/combo_box_field.dart';
import '../widgets/user_presence_tracker.dart';

enum _PresenceFilter { all, online, offline }

class ProfilesScreen extends StatefulWidget {
  const ProfilesScreen({super.key});

  @override
  State<ProfilesScreen> createState() => _ProfilesScreenState();
}

class _ProfilesScreenState extends State<ProfilesScreen> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _profiles = const [];
  String _query = '';
  _PresenceFilter _presenceFilter = _PresenceFilter.all;
  final _presence = UserPresenceTracker();

  @override
  void initState() {
    super.initState();
    _load();
    _presence.addListener(_onPresenceUpdate);
    _presence.start();
  }

  @override
  void dispose() {
    _presence.removeListener(_onPresenceUpdate);
    _presence.dispose();
    super.dispose();
  }

  void _onPresenceUpdate() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await supabase
          .from('profiles')
          .select('*')
          .order('full_name', ascending: true);
      if (!mounted) return;
      setState(() {
        _profiles = (rows as List).cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _profiles = const [];
        _loading = false;
      });
    }
  }

  List<Map<String, dynamic>> get _filtered {
    final q = _query.trim().toLowerCase();
    return _profiles.where((row) {
      if (q.isNotEmpty) {
        final haystack = [
          row['email'],
          row['full_name'],
          row['cost_centre'],
          row['user_account_type'],
          row['company_number'],
          row['job_title'],
          row['department'],
        ].whereType<String>().map((s) => s.toLowerCase()).join(' ');
        if (!haystack.contains(q)) return false;
      }
      if (_presenceFilter != _PresenceFilter.all) {
        final online = _presence.isOnline(row['id'] as String? ?? '');
        if (_presenceFilter == _PresenceFilter.online && !online) return false;
        if (_presenceFilter == _PresenceFilter.offline && online) return false;
      }
      return true;
    }).toList();
  }

  Future<void> _openEdit(Map<String, dynamic>? row) async {
    final me = context.read<AuthProvider>().profile;
    final isAdmin = isAdminProfile(me);
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) =>
          _ProfileEditDialog(existing: row, currentUserIsAdmin: isAdmin),
    );
    if (saved == true) await _load();
  }

  Future<void> _confirmDelete(Map<String, dynamic> row) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete user?'),
        content: Text(
          'This will permanently delete ${row['full_name'] ?? row['email']}. '
          'They will lose access immediately.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final res = await adminDeleteUser(userId: row['id'] as String);
    if (!mounted) return;
    if (!res.success) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(res.error ?? 'Delete failed')));
      return;
    }
    await _load();
  }

  Future<void> _confirmToggleDisabled(Map<String, dynamic> row) async {
    final disabled = (row['disabled'] as bool?) ?? false;
    final name = row['full_name'] ?? row['email'];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(disabled ? 'Re-enable user?' : 'Disable user?'),
        content: Text(
          disabled
              ? 'This will restore access for $name.'
              : 'This will block $name from signing in. They are signed out '
                    'immediately and cannot log back in until re-enabled.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(disabled ? 'Re-enable' : 'Disable'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final res = await adminSetUserDisabled(
      userId: row['id'] as String,
      disabled: !disabled,
    );
    if (!mounted) return;
    if (!res.success) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(res.error ?? 'Update failed')));
      return;
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final me = context.watch<AuthProvider>().profile;
    final isAdmin = isAdminProfile(me);
    final isSuperAdmin = isSuperAdminProfile(me);
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profiles'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: isAdmin
          ? FloatingActionButton.extended(
              onPressed: () => _openEdit(null),
              icon: const Icon(Icons.person_add_alt_1),
              label: const Text('Add user'),
            )
          : null,
      body: SafeArea(
        child: PageBody.list(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        onChanged: (v) => setState(() => _query = v),
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText:
                              'Search by name, email, Coy No., job, department, role',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              if (isAdmin)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: Wrap(
                    spacing: 8,
                    children: [
                      for (final f in _PresenceFilter.values)
                        ChoiceChip(
                          label: Text(switch (f) {
                            _PresenceFilter.all => 'All',
                            _PresenceFilter.online => 'Online',
                            _PresenceFilter.offline => 'Offline',
                          }),
                          selected: _presenceFilter == f,
                          onSelected: (_) =>
                              setState(() => _presenceFilter = f),
                        ),
                    ],
                  ),
                ),
              Expanded(
                child: _loading
                    ? const Center(child: CircularProgressIndicator())
                    : _error != null
                    ? Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          _error!,
                          style: TextStyle(color: scheme.error),
                        ),
                      )
                    : _filtered.isEmpty
                    ? const Center(
                        child: EmptyState(
                          icon: Icons.person_off_outlined,
                          title: 'No profiles match',
                          body:
                              'Try a different search term or clear the presence filter.',
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        child: Card(
                          elevation: 1,
                          clipBehavior: Clip.antiAlias,
                          child: ListView.separated(
                            shrinkWrap: false,
                            itemCount: _filtered.length,
                            separatorBuilder: (_, _) => Divider(
                              height: 1,
                              color: MolTones.of(context).lineFaint,
                            ),
                            itemBuilder: (_, i) {
                              final row = _filtered[i];
                              return _ProfileRow(
                                row: row,
                                online: _presence.isOnline(row['id'] as String),
                                isAdmin: isAdmin,
                                canDisable: isSuperAdmin,
                                onEdit: () => _openEdit(row),
                                onDelete: () => _confirmDelete(row),
                                onToggleDisabled: () =>
                                    _confirmToggleDisabled(row),
                              );
                            },
                          ),
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileRow extends StatefulWidget {
  const _ProfileRow({
    required this.row,
    required this.online,
    required this.isAdmin,
    required this.onEdit,
    required this.onDelete,
    this.canDisable = false,
    this.onToggleDisabled,
  });

  final Map<String, dynamic> row;
  final bool online;
  final bool isAdmin;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final bool canDisable;
  final VoidCallback? onToggleDisabled;

  @override
  State<_ProfileRow> createState() => _ProfileRowState();
}

class _ProfileRowState extends State<_ProfileRow> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    final row = widget.row;
    final name =
        (row['full_name'] as String?) ??
        (row['first_name'] as String?) ??
        (row['email'] as String? ?? '—');
    final subtitleParts = <String>[
      if ((row['job_title'] as String? ?? '').isNotEmpty)
        row['job_title'] as String,
      if ((row['department'] as String? ?? '').isNotEmpty)
        row['department'] as String,
      if ((row['company'] as String? ?? '').isNotEmpty)
        row['company'] as String,
    ];
    final accountType = row['user_account_type'] as String? ?? '';
    final rowIsAdmin =
        (row['is_admin'] as bool?) == true ||
        (row['is_super_admin'] as bool?) == true;
    final rowDisabled = (row['disabled'] as bool?) ?? false;
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: Material(
        color: _hover ? tones.bgMuted : Colors.transparent,
        child: ListTile(
          onTap: widget.isAdmin ? widget.onEdit : null,
          leading: Stack(
            children: [
              CircleAvatar(
                backgroundColor: scheme.surfaceContainerHighest,
                child: Text(_initials(name)),
              ),
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: widget.online
                        ? Colors.green.shade500
                        : scheme.outlineVariant,
                    shape: BoxShape.circle,
                    border: Border.all(color: scheme.surface, width: 2),
                  ),
                ),
              ),
            ],
          ),
          title: Row(
            children: [
              Expanded(
                child: Text(name, overflow: TextOverflow.ellipsis, maxLines: 1),
              ),
              if (rowIsAdmin) ...[
                const SizedBox(width: 6),
                Icon(Icons.shield_outlined, size: 16, color: scheme.primary),
              ],
              if (rowDisabled) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: scheme.errorContainer,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    'Disabled',
                    style: TextStyle(
                      fontSize: 11,
                      color: scheme.onErrorContainer,
                    ),
                  ),
                ),
              ],
            ],
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (subtitleParts.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    subtitleParts.join(' • '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: scheme.onSurfaceVariant),
                  ),
                ),
              if (accountType.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: RolePill(role: accountType, dense: true),
                ),
            ],
          ),
          trailing: widget.isAdmin
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit_outlined),
                      onPressed: widget.onEdit,
                      tooltip: 'Edit',
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      color: scheme.error,
                      onPressed: widget.onDelete,
                      tooltip: 'Delete',
                    ),
                    if (widget.canDisable && widget.onToggleDisabled != null)
                      IconButton(
                        icon: Icon(
                          rowDisabled
                              ? Icons.lock_open_outlined
                              : Icons.block_outlined,
                        ),
                        color: rowDisabled ? null : scheme.error,
                        onPressed: widget.onToggleDisabled,
                        tooltip: rowDisabled ? 'Re-enable' : 'Disable',
                      ),
                  ],
                )
              : Text(
                  (row['company_number'] as String?) ?? '',
                  style: TextStyle(
                    color: scheme.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
          isThreeLine: true,
        ),
      ),
    );
  }
}

String _initials(String name) {
  final parts = name.trim().split(RegExp(r'\s+'));
  if (parts.isEmpty || parts.first.isEmpty) return '?';
  if (parts.length == 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

class _ProfileEditDialog extends StatefulWidget {
  const _ProfileEditDialog({
    required this.existing,
    required this.currentUserIsAdmin,
  });
  final Map<String, dynamic>? existing;
  final bool currentUserIsAdmin;

  @override
  State<_ProfileEditDialog> createState() => _ProfileEditDialogState();
}

class _ProfileEditDialogState extends State<_ProfileEditDialog> {
  late final bool isEditing;
  late Map<String, String> _f;
  String _password = '';
  String _changePassword = '';
  bool _saving = false;
  String? _error;

  // Per-field option lists (mutable in-session).
  late List<String> _payrollIdOptions;
  late List<String> _deptCodeOptions;
  late List<String> _workAreaOptions;
  late List<String> _shiftCycleOptions;
  late List<String> _categoryOptions;
  late List<String> _occupationOptions;
  late List<String> _departmentOptions;
  late List<String> _locationOptions;
  late List<String> _companyOptions;

  @override
  void initState() {
    super.initState();
    isEditing = widget.existing != null;
    final e = widget.existing ?? const <String, dynamic>{};
    _f = <String, String>{
      'email': (e['email'] as String?) ?? '',
      'title': (e['title'] as String?) ?? '',
      'first_name': (e['first_name'] as String?) ?? '',
      'full_name': (e['full_name'] as String?) ?? '',
      'sa_id_number': (e['sa_id_number'] as String?) ?? '',
      'phone': (e['phone'] as String?) ?? '',
      'company_number': (e['company_number'] as String?) ?? '',
      'payroll_id': (e['payroll_id'] as String?) ?? '',
      'company': (e['company'] as String?) ?? '',
      'job_title': (e['job_title'] as String?) ?? '',
      'occupation': (e['occupation'] as String?) ?? '',
      'category': (e['category'] as String?) ?? '',
      'location': (e['location'] as String?) ?? '',
      'section_shaft': (e['section_shaft'] as String?) ?? '',
      'work_area': (e['work_area'] as String?) ?? '',
      'department': (e['department'] as String?) ?? '',
      'dept_code': (e['dept_code'] as String?) ?? '',
      'cost_centre': (e['cost_centre'] as String?) ?? '',
      'user_account_type':
          (e['user_account_type'] as String?) ?? 'none of the above',
      'shift_cycle_id': (e['shift_cycle_id'] as String?) ?? '',
    };
    _payrollIdOptions = List.of(kDefaultPayrollIds);
    _deptCodeOptions = List.of(kDefaultDeptCodes);
    _workAreaOptions = List.of(kDefaultWorkAreas);
    _shiftCycleOptions = List.of(kDefaultShiftCycles);
    _categoryOptions = List.of(kDefaultCategories);
    _occupationOptions = List.of(kDefaultOccupations);
    _departmentOptions = List.of(kDefaultDepartments);
    _locationOptions = List.of(kDefaultLocations);
    _companyOptions = List.of(kDefaultCompanies);
  }

  String? _validate() {
    final missing = <String>[];
    if (_f['full_name']!.trim().isEmpty) missing.add('Full Name');
    if (_f['email']!.trim().isEmpty) missing.add('Email Address');
    if (!isEditing && _password.isEmpty) missing.add('Password');
    if (_f['cost_centre']!.trim().isEmpty) missing.add('Cost Centre');
    if (missing.isNotEmpty) return 'Please complete: ${missing.join(', ')}.';
    if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(_f['email']!.trim())) {
      return 'Please enter a valid email address.';
    }
    if (!isEditing && _password.length < 6) {
      return 'Password must be at least 6 characters.';
    }
    return null;
  }

  Future<void> _save() async {
    final error = _validate();
    if (error != null) {
      setState(() => _error = error);
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      String userId;
      if (isEditing) {
        userId = widget.existing!['id'] as String;
      } else {
        final res = await adminCreateUser(
          email: _f['email']!.trim(),
          password: _password,
        );
        if (!res.success || res.userId == null) {
          setState(() {
            _error = res.error ?? 'User creation failed.';
            _saving = false;
          });
          return;
        }
        userId = res.userId!;
      }

      final flags = getAccountTypeFlags(_f['user_account_type']);
      final payload = <String, dynamic>{
        'id': userId,
        'email': _f['email']!.trim(),
        ..._f,
        'is_admin': flags.isAdmin,
        'is_super_admin': flags.isSuperAdmin,
        'updated_at': DateTime.now().toIso8601String(),
      };
      await supabase.from('profiles').upsert(payload, onConflict: 'id');

      if (_changePassword.isNotEmpty) {
        final res = await adminUpdatePassword(
          userId: userId,
          password: _changePassword,
        );
        if (!res.success) {
          setState(() {
            _error = res.error ?? 'Password update failed.';
            _saving = false;
          });
          return;
        }
      }

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      setState(() {
        _error = err.toString();
        _saving = false;
      });
    }
  }

  Widget _tf(
    String key,
    String label, {
    int maxLines = 1,
    int? maxLength,
    TextInputType? keyboardType,
    bool enabled = true,
  }) => TextFormField(
    initialValue: _f[key],
    onChanged: (v) => _f[key] = v,
    maxLines: maxLines,
    maxLength: maxLength,
    keyboardType: keyboardType,
    enabled: enabled,
    decoration: InputDecoration(labelText: label),
  );

  Widget _dropdown(String key, String label, List<String> options) {
    final current = _f[key] ?? '';
    return DropdownButtonFormField<String>(
      initialValue: current.isEmpty ? null : current,
      decoration: InputDecoration(labelText: label),
      items: [
        for (final o in options) DropdownMenuItem(value: o, child: Text(o)),
      ],
      onChanged: (v) => setState(() => _f[key] = v ?? ''),
    );
  }

  Widget _combo(
    String key,
    String label,
    List<String> options,
    void Function(String) onAddOption, {
    bool allowCustom = true,
  }) {
    return ComboBoxField(
      label: label,
      value: _f[key] ?? '',
      options: options,
      allowCustom: allowCustom,
      onChanged: (v) => setState(() => _f[key] = v),
      onAddOption: allowCustom
          ? (v) => setState(() {
              onAddOption(v);
              _f[key] = v;
            })
          : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 720, maxHeight: 760),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      isEditing
                          ? 'Edit user: ${_f['full_name']?.isNotEmpty == true ? _f['full_name'] : _f['email']}'
                          : 'Add new user',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),
                  IconButton(
                    onPressed: _saving
                        ? null
                        : () => Navigator.of(context).pop(false),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: scheme.errorContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _error!,
                      style: TextStyle(color: scheme.onErrorContainer),
                    ),
                  ),
                ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _section('Account', [
                        _tf('email', 'Email', enabled: !isEditing),
                        if (!isEditing)
                          TextFormField(
                            onChanged: (v) => _password = v,
                            obscureText: true,
                            decoration: const InputDecoration(
                              labelText: 'Password',
                            ),
                          ),
                        if (isEditing)
                          TextFormField(
                            onChanged: (v) => _changePassword = v,
                            obscureText: true,
                            decoration: const InputDecoration(
                              labelText:
                                  'Change password (leave blank to keep)',
                            ),
                          ),
                        if (widget.currentUserIsAdmin)
                          _dropdown(
                            'user_account_type',
                            'Account type',
                            kUserAccountTypes,
                          ),
                      ]),
                      _section('Personal Information', [
                        _dropdown('title', 'Title', kTitleOptions),
                        _tf('first_name', 'First Name'),
                        _tf('full_name', 'Full Name'),
                        _tf(
                          'sa_id_number',
                          'SA ID Number',
                          maxLength: 13,
                          keyboardType: TextInputType.number,
                        ),
                        _tf(
                          'phone',
                          'Phone Number',
                          keyboardType: TextInputType.phone,
                        ),
                      ]),
                      _section('Employment Details', [
                        _tf('company_number', 'Company Number'),
                        _combo(
                          'payroll_id',
                          'Payroll ID',
                          _payrollIdOptions,
                          _payrollIdOptions.add,
                        ),
                        _combo(
                          'company',
                          'Company',
                          _companyOptions,
                          _companyOptions.add,
                        ),
                        _tf('job_title', 'Job Title'),
                        _combo(
                          'occupation',
                          'Occupation',
                          _occupationOptions,
                          _occupationOptions.add,
                        ),
                        _combo(
                          'category',
                          'Category',
                          _categoryOptions,
                          _categoryOptions.add,
                        ),
                      ]),
                      _section('Location & Department', [
                        _combo(
                          'location',
                          'Location',
                          _locationOptions,
                          _locationOptions.add,
                        ),
                        _dropdown(
                          'section_shaft',
                          'Section / Shaft',
                          kSectionShaftOptions,
                        ),
                        _combo(
                          'work_area',
                          'Work Area',
                          _workAreaOptions,
                          _workAreaOptions.add,
                        ),
                        _combo(
                          'department',
                          'Department',
                          _departmentOptions,
                          _departmentOptions.add,
                        ),
                        _combo(
                          'dept_code',
                          'Department Code',
                          _deptCodeOptions,
                          _deptCodeOptions.add,
                        ),
                        _dropdown('cost_centre', 'Cost Centre', kCostCentres),
                        _combo(
                          'shift_cycle_id',
                          'Shift Cycle ID',
                          _shiftCycleOptions,
                          _shiftCycleOptions.add,
                        ),
                      ]),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: _saving
                        ? null
                        : () => Navigator.of(context).pop(false),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: const Icon(Icons.save_outlined),
                    label: Text(
                      _saving
                          ? 'Saving...'
                          : (isEditing ? 'Save changes' : 'Create user'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title.toUpperCase(),
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            for (final w in children) ...[w, const SizedBox(height: 8)],
          ],
        ),
      ),
    );
  }
}
