import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_rock_breaker_inspection_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/inspection_items_field.dart';
import '../widgets/signature_canvas.dart';

class RockBreakerInspectionFormScreen extends StatefulWidget {
  const RockBreakerInspectionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<RockBreakerInspectionFormScreen> createState() =>
      _RockBreakerInspectionFormScreenState();
}

class _RockBreakerInspectionFormScreenState
    extends State<RockBreakerInspectionFormScreen> {
  final _data = RockBreakerInspectionFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('rock_breaker_inspection');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'rock_breaker_inspection',
        'Rock Breaker Inspection',
        payload,
      );
      final doc = await generateRockBreakerInspectionPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Rock_Breaker_Inspection.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Weekly Rock Breaker Inspection'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 980,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Weekly Rock Breaker Inspection',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.dateOfInspection,
                            onChanged: (v) =>
                                setState(() => _data.dateOfInspection = v),
                            label: 'Date of Inspection',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Position of rock breaker',
                            _data.positionOfRockBreaker,
                            (v) => _data.positionOfRockBreaker = v,
                            id: 'positionOfRockBreaker',
                          ),
                          const SizedBox(height: 24),
                          InspectionItemsField(
                            labels: const [
                              'Rock breaker locked out when not in use?',
                              'Re-use checklist available?',
                              'Pre-use checklist completed according to requirements?',
                              'Spillages controlled?',
                              'Fire extinguisher available?',
                              'Fire extinguisher inspected monthly?',
                              'Fire extinguisher in good working order?',
                              'Operator trained / licence available?',
                              'Housekeeping of high standard?',
                              'Area adequately illuminated?',
                            ],
                            items: _data.items,
                            onChanged: () => setState(() {}),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossDate,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossDate = v),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Mine Manager / Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineManagerOverseerSignature,
                            onChanged: (v) => setState(
                              () => _data.mineManagerOverseerSignature = v,
                            ),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.mineManagerOverseerDate,
                            onChanged: (v) => setState(
                              () => _data.mineManagerOverseerDate = v,
                            ),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'rock_breaker_inspection',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
