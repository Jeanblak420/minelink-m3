import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_safety_health_rep_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/appointment_profile.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/signature_canvas.dart';

class SafetyHealthRepFormScreen extends StatefulWidget {
  const SafetyHealthRepFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<SafetyHealthRepFormScreen> createState() =>
      _SafetyHealthRepFormScreenState();
}

class _SafetyHealthRepFormScreenState extends State<SafetyHealthRepFormScreen> {
  final _data = SafetyHealthRepFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('safety_health_rep');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final d = getProfilePersonalDetails(profile);
      _data.primary.name = d.name;
      _data.primary.companyNumber = d.companyNumber;
      _data.primary.shaft = d.shaft;
      _data.primary.section = d.section;
      _data.primary.signatures.acceptedSignature = d.signature;
      _data.alternative.signatures.acceptedSignature = d.signature;
    }
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'safety_health_rep',
        'Safety Health Representative Appointment',
        payload,
      );
      final doc = await generateSafetyHealthRepPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name:
            'Safety_Health_Rep_Appointment_${_safeName(_data.primary.name)}.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  String _safeName(String s) {
    final cleaned = s.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
    return cleaned.isEmpty ? 'form' : cleaned;
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Widget _section(
    BuildContext context,
    String title,
    SafetyHealthRepSection section,
    String idPrefix,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        _tf(
          'Name',
          section.name,
          (v) => section.name = v,
          id: '$idPrefix.name',
        ),
        const SizedBox(height: 12),
        _tf(
          'Coy No.',
          section.companyNumber,
          (v) => section.companyNumber = v,
          id: '$idPrefix.companyNumber',
        ),
        const SizedBox(height: 12),
        _tf(
          'Shaft',
          section.shaft,
          (v) => section.shaft = v,
          id: '$idPrefix.shaft',
        ),
        const SizedBox(height: 12),
        _tf(
          'Section',
          section.section,
          (v) => section.section = v,
          id: '$idPrefix.section',
        ),
        const SizedBox(height: 20),
        Text(
          'Manager Signature',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        SignatureCanvasField(
          value: section.signatures.managerSignature,
          onChanged: (v) =>
              setState(() => section.signatures.managerSignature = v),
        ),
        const SizedBox(height: 8),
        DatePickerField(
          value: section.signatures.managerDate,
          onChanged: (v) => setState(() => section.signatures.managerDate = v),
        ),
        const SizedBox(height: 8),
        _tf(
          'Manager Witness',
          section.signatures.managerWitness,
          (v) => section.signatures.managerWitness = v,
          id: '$idPrefix.signatures.managerWitness',
        ),
        const SizedBox(height: 20),
        Text(
          'Accepted Signature',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        SignatureCanvasField(
          value: section.signatures.acceptedSignature,
          onChanged: (v) =>
              setState(() => section.signatures.acceptedSignature = v),
        ),
        const SizedBox(height: 8),
        DatePickerField(
          value: section.signatures.acceptedDate,
          onChanged: (v) => setState(() => section.signatures.acceptedDate = v),
        ),
        const SizedBox(height: 8),
        _tf(
          'Accepted Witness',
          section.signatures.acceptedWitness,
          (v) => section.signatures.acceptedWitness = v,
          id: '$idPrefix.signatures.acceptedWitness',
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Safety & Health Rep Appointment'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 880,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Safety & Health Representative Appointment',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        children: [
                          _section(
                            context,
                            'Safety and Health Representative Appointment',
                            _data.primary,
                            'primary',
                          ),
                          const SizedBox(height: 32),
                          const Divider(),
                          const SizedBox(height: 16),
                          _section(
                            context,
                            'Alternative Safety and Health Representative Appointment',
                            _data.alternative,
                            'alternative',
                          ),
                          FormOverlayHost(
                            formType: 'safety_health_rep',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 24),
                          if (!_isViewMode)
                            Wrap(
                              alignment: WrapAlignment.end,
                              spacing: 12,
                              runSpacing: 12,
                              children: [
                                FilledButton.icon(
                                  onPressed: _generating ? null : _generatePdf,
                                  icon: const Icon(
                                    Icons.picture_as_pdf_outlined,
                                  ),
                                  label: Text(
                                    _generating
                                        ? 'Generating...'
                                        : 'Generate PDF',
                                  ),
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
