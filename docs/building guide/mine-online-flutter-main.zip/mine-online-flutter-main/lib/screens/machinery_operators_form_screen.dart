import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_machinery_operators_pdf.dart';
import '../providers/auth_provider.dart';
import '../utils/appointment_profile.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';

class MachineryOperatorsFormScreen extends StatefulWidget {
  const MachineryOperatorsFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<MachineryOperatorsFormScreen> createState() =>
      _MachineryOperatorsFormScreenState();
}

class _MachineryOperatorsFormScreenState
    extends State<MachineryOperatorsFormScreen> {
  final _data = MachineryOperatorsFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _initialised = false;
  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('machinery_operators_appointment');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    if (widget.viewArgs?.isViewMode == true) return;
    final profile = context.read<AuthProvider>().profile;
    if (profile != null) {
      final d = getProfilePersonalDetails(profile);
      final first = _data.operators.first;
      if (first.companyNumber.isEmpty) first.companyNumber = d.companyNumber;
      if (first.location.isEmpty) first.location = d.location;
      if (first.signature.isEmpty) first.signature = d.name;
    }
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'machinery_operators_appointment',
        'Machinery Operators Appointment',
        payload,
      );
      final doc = await generateMachineryOperatorsPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Machinery_Operators_Appointments.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  void _addRow() {
    setState(() => _data.operators.add(MachineryOperatorEntry()));
  }

  void _removeRow(int i) {
    if (_data.operators.length <= 1) return;
    setState(() => _data.operators.removeAt(i));
  }

  DataCell _textCell(
    String value,
    ValueChanged<String> onChanged, {
    String? hint,
    double width = 140,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const DataCell(SizedBox.shrink());
    return DataCell(
      SizedBox(
        width: width,
        child: TextFormField(
          initialValue: value,
          onChanged: onChanged,
          decoration: InputDecoration(
            hintText: ov?.label ?? hint,
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 8,
              vertical: 8,
            ),
            border: const OutlineInputBorder(),
          ),
        ),
      ),
    );
  }

  DataCell _dateCell(
    String value,
    ValueChanged<String> onChanged, {
    double width = 140,
  }) {
    return DataCell(
      SizedBox(
        width: width,
        child: DatePickerField(value: value, onChanged: onChanged),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Machinery Operators Appointments'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: PageBody.form(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: AbsorbPointer(
              absorbing: _isViewMode,
              child: Column(
                children: [
                  Card(
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                          color: scheme.primaryContainer,
                          child: Text(
                            'Machinery Operators Appointments',
                            style: Theme.of(context).textTheme.titleLarge
                                ?.copyWith(color: scheme.onPrimaryContainer),
                          ),
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            columnSpacing: 12,
                            columns: const [
                              DataColumn(label: Text('#')),
                              DataColumn(label: Text('COY NO.')),
                              DataColumn(label: Text('Location')),
                              DataColumn(label: Text('Type of Equipment')),
                              DataColumn(label: Text('Licence Expiry')),
                              DataColumn(label: Text('Appointed for Month')),
                              DataColumn(label: Text('Signature of Operator')),
                              DataColumn(label: Text('')),
                            ],
                            rows: [
                              for (var i = 0; i < _data.operators.length; i++)
                                DataRow(
                                  cells: [
                                    DataCell(Text('${i + 1}')),
                                    _textCell(
                                      _data.operators[i].companyNumber,
                                      (v) =>
                                          _data.operators[i].companyNumber = v,
                                      hint: 'Company No.',
                                      width: 110,
                                    ),
                                    _textCell(
                                      _data.operators[i].location,
                                      (v) => _data.operators[i].location = v,
                                      hint: 'Location',
                                      width: 130,
                                    ),
                                    _textCell(
                                      _data.operators[i].typeOfEquipment,
                                      (v) =>
                                          _data.operators[i].typeOfEquipment =
                                              v,
                                      hint: 'Equipment type',
                                      width: 170,
                                    ),
                                    _dateCell(
                                      _data.operators[i].licenceExpiryDate,
                                      (v) =>
                                          _data.operators[i].licenceExpiryDate =
                                              v,
                                      width: 140,
                                    ),
                                    _textCell(
                                      _data.operators[i].appointedForMonth,
                                      (v) =>
                                          _data.operators[i].appointedForMonth =
                                              v,
                                      hint: 'Month',
                                      width: 120,
                                    ),
                                    _textCell(
                                      _data.operators[i].signature,
                                      (v) => _data.operators[i].signature = v,
                                      hint: 'Signature',
                                      width: 160,
                                    ),
                                    DataCell(
                                      IconButton(
                                        onPressed: _data.operators.length <= 1
                                            ? null
                                            : () => _removeRow(i),
                                        icon: const Icon(Icons.delete_outline),
                                        tooltip: 'Remove row',
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                        if (!_isViewMode)
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: OutlinedButton.icon(
                                onPressed: _addRow,
                                icon: const Icon(Icons.add),
                                label: const Text('Add Operator'),
                              ),
                            ),
                          ),
                        if (!_isViewMode)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                            child: Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  FormOverlayHost(
                    formType: 'machinery_operators_appointment',
                    values:
                        widget.viewArgs?.initialPayload?['overlay']
                            as Map<String, dynamic>? ??
                        const {},
                    readOnly: _isViewMode,
                    overlayOverride: widget.viewArgs?.overlayOverride,
                    onChanged: (v) => _overlayValues = v,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
