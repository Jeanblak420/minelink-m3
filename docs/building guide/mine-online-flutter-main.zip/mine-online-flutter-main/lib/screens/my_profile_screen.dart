import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../constants/occupations.dart';
import '../constants/profile_options.dart';
import '../providers/auth_provider.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../widgets/combo_box_field.dart';
import '../widgets/mobile_bottom_nav.dart';
import '../widgets/signature_canvas.dart';

class MyProfileScreen extends StatefulWidget {
  const MyProfileScreen({super.key});

  @override
  State<MyProfileScreen> createState() => _MyProfileScreenState();
}

class _MyProfileScreenState extends State<MyProfileScreen> {
  late Map<String, String> _fields;
  // Controllers are only created for fields where the value must be
  // re-asserted into the TextField after onChanged mutation — e.g. the SA ID
  // Number, which strips non-digits as the user types so the visible text
  // must reflect the stripped value, not what the user pressed.
  final TextEditingController _saIdCtl = TextEditingController();
  String _signatureData = '';
  bool _editingSignature = false;
  bool _saving = false;
  bool _saved = false;
  String? _error;
  bool _initialised = false;

  @override
  void dispose() {
    _saIdCtl.dispose();
    super.dispose();
  }

  // Per-field option lists. Each ComboBox can push runtime additions in
  // (in-memory only for the session), matching MyProfile.tsx behaviour.
  late List<String> _payrollIdOptions;
  late List<String> _deptCodeOptions;
  late List<String> _workAreaOptions;
  late List<String> _shiftCycleOptions;
  late List<String> _categoryOptions;
  late List<String> _occupationOptions;
  late List<String> _departmentOptions;
  late List<String> _locationOptions;
  late List<String> _companyOptions;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    final p = context.read<AuthProvider>().profile;
    _fields = <String, String>{
      'title': p?.title ?? '',
      'first_name': p?.firstName ?? '',
      'full_name': p?.fullName ?? '',
      'sa_id_number': p?.saIdNumber ?? '',
      'phone': p?.phone ?? '',
      'company_number': p?.companyNumber ?? '',
      'payroll_id': p?.payrollId ?? '',
      'company': p?.company ?? '',
      'job_title': p?.jobTitle ?? '',
      'occupation': p?.occupation ?? '',
      'category': p?.category ?? '',
      'location': p?.location ?? '',
      'section_shaft': p?.sectionShaft ?? '',
      'work_area': p?.workArea ?? '',
      'department': p?.department ?? '',
      'dept_code': p?.deptCode ?? '',
      'cost_centre': p?.costCentre ?? '',
      'shift_cycle_id': p?.shiftCycleId ?? '',
      'email': p?.email ?? '',
    };
    _signatureData = p?.signatureData ?? '';
    _saIdCtl.text = _fields['sa_id_number'] ?? '';
    _payrollIdOptions = List.of(kDefaultPayrollIds);
    _deptCodeOptions = List.of(kDefaultDeptCodes);
    _workAreaOptions = List.of(kDefaultWorkAreas);
    _shiftCycleOptions = List.of(kDefaultShiftCycles);
    _categoryOptions = List.of(kDefaultCategories);
    _occupationOptions = List.of(kDefaultOccupations);
    _departmentOptions = List.of(kDefaultDepartments);
    _locationOptions = List.of(kDefaultLocations);
    _companyOptions = List.of(kDefaultCompanies);
  }

  Future<void> _save() async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      _saving = true;
      _saved = false;
      _error = null;
    });
    try {
      await context.read<AuthProvider>().updateProfile({
        ..._fields,
        'signature_data': _signatureData,
      });
      if (!mounted) return;
      setState(() => _saved = true);
      messenger.showSnackBar(
        const SnackBar(content: Text('Profile saved')),
      );
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) setState(() => _saved = false);
      });
    } catch (err) {
      if (!mounted) return;
      setState(() => _error = err.toString());
      messenger.showSnackBar(
        SnackBar(content: Text('Could not save profile: $err')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _tf(String key, String label,
      {int maxLines = 1,
      int? maxLength,
      TextInputType? keyboardType,
      TextEditingController? controller}) {
    return TextFormField(
      controller: controller,
      initialValue: controller == null ? _fields[key] : null,
      onChanged: (v) => _fields[key] = v,
      maxLines: maxLines,
      maxLength: maxLength,
      keyboardType: keyboardType,
      decoration: InputDecoration(labelText: label),
    );
  }

  /// Mirrors web `MyProfile.tsx` line 474: strips non-digits and caps the
  /// length on every keystroke, so the visible text always equals what gets
  /// stored. Uses a controller because TextFormField's onChanged alone
  /// can't re-assert the value the user sees.
  Widget _digitsOnlyField(String key, String label,
      {required int maxLength, required TextEditingController controller}) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      maxLength: maxLength,
      decoration: InputDecoration(labelText: label),
      onChanged: (v) {
        var cleaned = v.replaceAll(RegExp(r'\D'), '');
        if (cleaned.length > maxLength) {
          cleaned = cleaned.substring(0, maxLength);
        }
        if (cleaned != v) {
          controller.value = TextEditingValue(
            text: cleaned,
            selection: TextSelection.collapsed(offset: cleaned.length),
          );
        }
        _fields[key] = cleaned;
      },
    );
  }

  Widget _dropdown(String key, String label, List<String> options) {
    final current = _fields[key] ?? '';
    // Web's <select> silently renders the current value even when no <option>
    // matches (e.g. legacy profile rows where cost_centre is hand-set to
    // 'Super Admin'). Flutter's DropdownButtonFormField asserts. To match web
    // behaviour, splice the current value into the items list when missing,
    // and defensively dedupe in case the predefined list ever has dupes.
    final union = current.isNotEmpty && !options.contains(current)
        ? <String>[current, ...options]
        : options;
    final seen = <String>{};
    final items = <String>[for (final o in union) if (seen.add(o)) o];
    return DropdownButtonFormField<String>(
      initialValue: current.isEmpty ? null : current,
      decoration: InputDecoration(labelText: label),
      items: [
        for (final o in items) DropdownMenuItem(value: o, child: Text(o)),
      ],
      onChanged: (v) => setState(() => _fields[key] = v ?? ''),
    );
  }

  Widget _combo(
    String key,
    String label,
    List<String> options,
    void Function(String) onAddOption, {
    bool allowCustom = true,
  }) {
    return ComboBoxField(
      label: label,
      value: _fields[key] ?? '',
      options: options,
      allowCustom: allowCustom,
      onChanged: (v) => setState(() => _fields[key] = v),
      onAddOption: allowCustom
          ? (v) => setState(() {
                onAddOption(v);
                _fields[key] = v;
              })
          : null,
    );
  }

  Widget _section(String title, IconData icon, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        initiallyExpanded: true,
        title: Row(
          children: [
            Icon(icon, size: 20),
            const SizedBox(width: 12),
            Text(title.toUpperCase(),
                style: Theme.of(context).textTheme.titleSmall),
          ],
        ),
        childrenPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        expandedCrossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final w in children) ...[w, const SizedBox(height: 12)],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final auth = context.watch<AuthProvider>();
    final occupationAllowCustom = isAdminProfile(auth.profile);
    return Scaffold(
      bottomNavigationBar: const MobileBottomNav(location: '/my-profile'),
      appBar: AppBar(
        title: const Text('My Profile'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await auth.signOut();
              if (context.mounted) context.go('/login');
            },
            child: Text('Sign Out', style: TextStyle(color: scheme.error)),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 720,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(auth.user?.email ?? '',
                    style: TextStyle(color: scheme.onSurfaceVariant)),
                const SizedBox(height: 16),
                _section('Personal Information', Icons.person_outline, [
                  _dropdown('title', 'Title', kTitleOptions),
                  _tf('first_name', 'First Name'),
                  _tf('full_name', 'Full Name'),
                  _digitsOnlyField('sa_id_number', 'SA ID Number',
                      maxLength: 13, controller: _saIdCtl),
                  _tf('phone', 'Phone Number',
                      keyboardType: TextInputType.phone),
                ]),
                _section('Employment Details', Icons.work_outline, [
                  _tf('company_number', 'Company Number'),
                  _combo('payroll_id', 'Payroll ID', _payrollIdOptions,
                      (v) => _payrollIdOptions.add(v)),
                  _combo('company', 'Company', _companyOptions,
                      (v) => _companyOptions.add(v)),
                  _tf('job_title', 'Job Title'),
                  _combo('occupation', 'Occupation', _occupationOptions,
                      (v) => _occupationOptions.add(v),
                      allowCustom: occupationAllowCustom),
                  _combo('category', 'Category', _categoryOptions,
                      (v) => _categoryOptions.add(v)),
                ]),
                _section('Location & Department', Icons.place_outlined, [
                  _combo('location', 'Location', _locationOptions,
                      (v) => _locationOptions.add(v)),
                  _dropdown(
                      'section_shaft', 'Section / Shaft', kSectionShaftOptions),
                  _combo('work_area', 'Work Area', _workAreaOptions,
                      (v) => _workAreaOptions.add(v)),
                  _combo('department', 'Department', _departmentOptions,
                      (v) => _departmentOptions.add(v)),
                  _combo('dept_code', 'Department Code', _deptCodeOptions,
                      (v) => _deptCodeOptions.add(v)),
                  _dropdown('cost_centre', 'Cost Centre', kCostCentres),
                  _combo('shift_cycle_id', 'Shift Cycle ID',
                      _shiftCycleOptions, (v) => _shiftCycleOptions.add(v)),
                ]),
                if (_error != null) ...[
                  Card(
                    color: scheme.errorContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(_error!,
                          style: TextStyle(color: scheme.onErrorContainer)),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: Icon(_saved
                      ? Icons.check_circle_outline
                      : Icons.save_outlined),
                  label: Text(_saved
                      ? 'Saved!'
                      : (_saving ? 'Saving...' : 'Save Profile')),
                ),
                const SizedBox(height: 20),
                Card(
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.draw_outlined),
                            const SizedBox(width: 8),
                            Text('My Signature',
                                style: Theme.of(context).textTheme.titleMedium),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (_signatureData.isNotEmpty && !_editingSignature)
                          Container(
                            height: 120,
                            decoration: BoxDecoration(
                              border:
                                  Border.all(color: scheme.outlineVariant),
                              borderRadius: BorderRadius.circular(8),
                              color: Colors.white,
                            ),
                            padding: const EdgeInsets.all(8),
                            child:
                                _SavedSignatureImage(dataUrl: _signatureData),
                          ),
                        if (_editingSignature) ...[
                          SignatureCanvasField(
                            value: _signatureData,
                            onChanged: (v) =>
                                setState(() => _signatureData = v),
                            label: '',
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: () => setState(
                                    () => _editingSignature = false),
                                child: const Text('Done'),
                              ),
                            ],
                          ),
                        ] else ...[
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            onPressed: () =>
                                setState(() => _editingSignature = true),
                            icon: const Icon(Icons.edit_outlined),
                            label: Text(_signatureData.isEmpty
                                ? 'Draw your signature'
                                : 'Draw new signature'),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SavedSignatureImage extends StatelessWidget {
  const _SavedSignatureImage({required this.dataUrl});
  final String dataUrl;

  @override
  Widget build(BuildContext context) {
    if (!dataUrl.startsWith('data:image')) {
      return const SizedBox.shrink();
    }
    final Uint8List bytes = base64Decode(dataUrl.split(',').last);
    return Image.memory(bytes, fit: BoxFit.contain);
  }
}
