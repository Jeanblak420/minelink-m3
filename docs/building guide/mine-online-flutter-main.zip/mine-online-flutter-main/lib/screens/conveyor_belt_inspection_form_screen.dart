import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/page_body.dart';
import '../models/form_view_args.dart';
import '../models/form_data_apply_map.dart';
import 'package:printing/printing.dart';

import '../models/form_data.dart';
import '../models/form_overlay.dart';
import '../pdf/generate_conveyor_belt_inspection_pdf.dart';
import '../utils/form_overlay_data.dart';
import '../utils/signature_workflow.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/form_builder/form_overlay_host.dart';
import '../widgets/inspection_items_field.dart';
import '../widgets/signature_canvas.dart';

const List<String> _walkwayLabels = [
  'Is the area adequately illuminated?',
  'Free of obstructions? (Both sides of the belt)',
  'Housekeeping of high standard?',
  'Cross over ladder installed?',
  'Walk way signs posted?',
  'Pillars demarcated according to standard?',
  'Pinch bar holders available with pinch bars?',
  'Safe hangingwall and sidewall?',
  'Geological features demarcated to standard?',
  'Support installed to standard?',
];

const List<({int num, String label})> _beltLabels = [
  (num: 1, label: 'Belt lockout when not in use?'),
  (num: 2, label: 'Pre-use checklist available?'),
  (num: 3, label: 'Pre-use checklist completed according to requirements?'),
  (num: 4, label: 'Operator trained/ licence available?'),
  (num: 5, label: 'Fire extinguisher available?'),
  (num: 6, label: 'Fire extinguisher inspected monthly?'),
  (num: 7, label: 'Fire extinguisher in good working order?'),
  (num: 8, label: 'Housekeeping of high standard?'),
  (num: 9, label: 'All guards installed at tail pulley?'),
  (num: 10, label: 'All guards installed at drive pulley?'),
  (num: 12, label: 'Spillage control at tail pulley?'),
  (num: 13, label: 'Spillage control at drive pulley?'),
  (num: 14, label: 'Spillages controlled along total belt?'),
  (num: 15, label: 'Belt running clear of obstructions?'),
  (num: 16, label: 'Damage/Broken idlers observed along the belt?'),
  (
    num: 17,
    label: 'Primary and secondary scraper in working condition and effective?',
  ),
  (num: 18, label: 'Belt aligned according to the requirements?'),
];

class ConveyorBeltInspectionFormScreen extends StatefulWidget {
  const ConveyorBeltInspectionFormScreen({super.key, this.viewArgs});

  final FormViewArgs? viewArgs;

  @override
  State<ConveyorBeltInspectionFormScreen> createState() =>
      _ConveyorBeltInspectionFormScreenState();
}

class _ConveyorBeltInspectionFormScreenState
    extends State<ConveyorBeltInspectionFormScreen> {
  final _data = ConveyorBeltInspectionFormData();

  @override
  void initState() {
    super.initState();
    final payload = widget.viewArgs?.initialPayload;
    if (payload != null) _data.applyMap(payload);
    _loadOverrides();
  }

  bool _generating = false;
  Map<String, dynamic> _overlayValues = {};
  Map<String, FieldOverride> _overrides = {};

  bool get _isViewMode => widget.viewArgs?.isViewMode == true;

  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('conveyor_belt_inspection');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }

  Widget _tf(
    String label,
    String value,
    ValueChanged<String> onChanged, {
    int maxLines = 1,
    String? id,
  }) {
    final ov = id == null ? null : _overrides[id];
    if (ov?.hidden == true) return const SizedBox.shrink();
    return TextFormField(
      initialValue: value,
      onChanged: onChanged,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: ov?.label ?? label),
    );
  }

  Future<void> _generatePdf() async {
    setState(() => _generating = true);
    try {
      final payload = _data.toMap();
      if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;
      await persistFormSubmission(
        'conveyor_belt_inspection',
        'Conveyor Belt Inspection',
        payload,
      );
      final doc = await generateConveyorBeltInspectionPdf(_data);
      final bytes = await doc.save();
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Conveyor_Belt_Inspection.pdf',
      );
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error generating PDF: $err')));
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: (widget.viewArgs?.embedded ?? false)
          ? null
          : AppBar(
              title: const Text('Weekly Conveyor Belt Inspection'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () =>
                    context.canPop() ? context.pop() : context.go('/'),
              ),
              actions: commonAppBarActions(),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: PageBody(
            maxWidth: 980,
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
                    color: scheme.primaryContainer,
                    child: Text(
                      'Weekly Strike Conveyor Belt Inspection',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: scheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: AbsorbPointer(
                      absorbing: _isViewMode,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          DatePickerField(
                            value: _data.dateOfInspection,
                            onChanged: (v) =>
                                setState(() => _data.dateOfInspection = v),
                            label: 'Date of Inspection',
                          ),
                          const SizedBox(height: 12),
                          _tf(
                            'Position of the belt',
                            _data.positionOfBelt,
                            (v) => _data.positionOfBelt = v,
                            id: 'positionOfBelt',
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Walkways Conditions',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          InspectionItemsField(
                            labels: _walkwayLabels,
                            items: _data.walkwayItems,
                            onChanged: () => setState(() {}),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Belt Condition',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          InspectionItemsField(
                            labels: _beltLabels.map((l) => l.label).toList(),
                            items: _data.beltConditionItems,
                            numbers: _beltLabels.map((l) => l.num).toList(),
                            onChanged: () => setState(() {}),
                          ),
                          const SizedBox(height: 24),
                          Text(
                            'Shift Boss Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.shiftBossSignature,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossSignature = v),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.shiftBossDate,
                            onChanged: (v) =>
                                setState(() => _data.shiftBossDate = v),
                            label: 'Date',
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Mine Manager / Mine Overseer Signature',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          SignatureCanvasField(
                            value: _data.mineManagerOverseerSignature,
                            onChanged: (v) => setState(
                              () => _data.mineManagerOverseerSignature = v,
                            ),
                          ),
                          const SizedBox(height: 8),
                          DatePickerField(
                            value: _data.mineManagerOverseerDate,
                            onChanged: (v) => setState(
                              () => _data.mineManagerOverseerDate = v,
                            ),
                            label: 'Date',
                          ),
                          FormOverlayHost(
                            formType: 'conveyor_belt_inspection',
                            values:
                                widget.viewArgs?.initialPayload?['overlay']
                                    as Map<String, dynamic>? ??
                                const {},
                            readOnly: _isViewMode,
                            overlayOverride: widget.viewArgs?.overlayOverride,
                            onChanged: (v) => _overlayValues = v,
                          ),
                          const SizedBox(height: 20),
                          if (!_isViewMode)
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton.icon(
                                onPressed: _generating ? null : _generatePdf,
                                icon: const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(
                                  _generating
                                      ? 'Generating...'
                                      : 'Generate PDF',
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
