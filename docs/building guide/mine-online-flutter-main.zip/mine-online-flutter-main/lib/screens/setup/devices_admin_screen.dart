// SP6 Device Management — admin screen to review registered devices and
// approve / revoke / restore them. Informational + audit (no hard gate).

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../config/supabase_client.dart';
import '../../models/device.dart';
import '../../providers/auth_provider.dart';
import '../../utils/device_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';

final _dateFmt = DateFormat('dd MMM yyyy, HH:mm');

enum _Filter { all, pending, approved, revoked }

class DevicesAdminScreen extends StatefulWidget {
  const DevicesAdminScreen({super.key});

  @override
  State<DevicesAdminScreen> createState() => _DevicesAdminScreenState();
}

class _DevicesAdminScreenState extends State<DevicesAdminScreen> {
  bool _loading = true;
  String? _error;
  List<Device> _devices = const [];
  Map<String, String> _names = const {};
  _Filter _filter = _Filter.all;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final devices = await loadDevices();
      final rows = await supabase.from('profiles').select('id, full_name');
      final names = <String, String>{
        for (final m in (rows as List).cast<Map<String, dynamic>>())
          m['id'] as String: ((m['full_name'] ?? '') as String).isEmpty
              ? '(no name)'
              : m['full_name'] as String,
      };
      if (!mounted) return;
      setState(() {
        _devices = devices;
        _names = names;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  List<Device> get _filtered {
    switch (_filter) {
      case _Filter.all:
        return _devices;
      case _Filter.pending:
        return _devices.where((d) => d.isPending).toList();
      case _Filter.approved:
        return _devices.where((d) => d.isActive && d.approved).toList();
      case _Filter.revoked:
        return _devices.where((d) => !d.isActive).toList();
    }
  }

  Future<void> _approve(Device d) async {
    await setDeviceApproved(d.id, true);
    _load();
  }

  Future<void> _revoke(Device d) async {
    await setDeviceActive(d.id, false);
    _load();
  }

  Future<void> _restore(Device d) async {
    await setDeviceActive(d.id, true);
    _load();
  }

  IconData _platformIcon(String p) {
    switch (p) {
      case 'windows':
        return Icons.desktop_windows_outlined;
      case 'android':
        return Icons.phone_android_outlined;
      default:
        return Icons.devices_other_outlined;
    }
  }

  Color _statusColor(Device d, ColorScheme s) {
    if (!d.isActive) return s.error;
    return d.approved ? Colors.green : s.tertiary;
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Devices'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Device management is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Devices'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                scrollable: true,
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Wrap(
                      spacing: 8,
                      children: [
                        for (final f in _Filter.values)
                          ChoiceChip(
                            label: Text(_filterLabel(f)),
                            selected: _filter == f,
                            onSelected: (_) => setState(() => _filter = f),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (_filtered.isEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 48),
                        child: Text(
                          'No devices in this view.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    else
                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filtered.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (_, i) =>
                            _deviceCard(_filtered[i], scheme),
                      ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _deviceCard(Device d, ColorScheme scheme) {
    return Card(
      child: ListTile(
        leading: Icon(_platformIcon(d.platform)),
        title: Text(d.deviceName),
        subtitle: Text(
          '${_names[d.userId] ?? d.userId} • '
          '${d.statusLabel} • seen ${_dateFmt.format(d.lastSeenAt.toLocal())}',
          style: TextStyle(color: scheme.onSurfaceVariant),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: _statusColor(d, scheme).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                d.statusLabel,
                style: TextStyle(
                  color: _statusColor(d, scheme),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'approve') _approve(d);
                if (v == 'revoke') _revoke(d);
                if (v == 'restore') _restore(d);
              },
              itemBuilder: (_) => [
                if (d.isActive && !d.approved)
                  const PopupMenuItem(value: 'approve', child: Text('Approve')),
                if (d.isActive)
                  const PopupMenuItem(value: 'revoke', child: Text('Revoke'))
                else
                  const PopupMenuItem(value: 'restore', child: Text('Restore')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _filterLabel(_Filter f) {
    switch (f) {
      case _Filter.all:
        return 'All';
      case _Filter.pending:
        return 'Pending';
      case _Filter.approved:
        return 'Approved';
      case _Filter.revoked:
        return 'Revoked';
    }
  }
}
