// SP4 Appointments lifecycle — admin issue + monitor screen. Issues appointments
// from SP3 dynamic templates or the built-in appointment forms, and monitors all
// appointments through their lifecycle (pending acceptance -> sign-off -> active
// -> resigned). Admin/super-admin only.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../../config/supabase_client.dart';
import '../../models/appointment.dart';
import '../../models/appointment_template.dart';
import '../../models/custom_form_template.dart';
import '../../models/org_location.dart';
import '../../models/user_profile.dart';
import '../../providers/auth_provider.dart';
import '../../utils/appointable_forms.dart';
import '../../utils/appointment_data.dart';
import '../../utils/appointment_template_data.dart';
import '../../utils/form_registry.dart';
import '../../utils/org_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';

final _dateFmt = DateFormat('dd MMM yyyy');

class AppointmentsAdminScreen extends StatefulWidget {
  const AppointmentsAdminScreen({super.key});

  @override
  State<AppointmentsAdminScreen> createState() =>
      _AppointmentsAdminScreenState();
}

class _AppointmentsAdminScreenState extends State<AppointmentsAdminScreen> {
  bool _loading = true;
  String? _error;
  List<Appointment> _appointments = const [];
  List<AppointmentTemplate> _templates = const [];
  List<AppointmentRole> _roles = const [];
  List<Shaft> _shafts = const [];
  List<({String id, String name})> _people = const [];
  AppointmentStatus? _filter;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<List<({String id, String name})>> _loadPeople() async {
    final rows = await supabase
        .from('profiles')
        .select('id, full_name')
        .order('full_name');
    return (rows as List).cast<Map<String, dynamic>>().map((m) {
      final name = (m['full_name'] ?? '') as String;
      return (id: m['id'] as String, name: name.isEmpty ? '(no name)' : name);
    }).toList();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final appts = await loadAllAppointments();
      final templates = await loadAppointmentTemplates();
      final roles = await loadAppointmentRoles(includeArchived: true);
      final shafts = await loadShafts();
      final people = await _loadPeople();
      if (!mounted) return;
      setState(() {
        _appointments = appts;
        _templates = templates;
        _roles = roles;
        _shafts = shafts;
        _people = people;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  String _personName(String id) {
    for (final p in _people) {
      if (p.id == id) return p.name;
    }
    return id;
  }

  Future<void> _issue() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => _IssueAppointmentDialog(
        templates: _templates,
        roles: _roles,
        shafts: _shafts,
        people: _people,
      ),
    );
    if (saved == true) _load();
  }

  Future<void> _viewPdf(Appointment a) async {
    final formType = a.formType;
    if (formType == null || formType.isEmpty) {
      _snack('Nothing to preview yet.');
      return;
    }
    var payload = a.payload;
    if (a.submissionId != null) {
      final row = await supabase
          .from('form_submissions')
          .select('payload')
          .eq('id', a.submissionId!)
          .maybeSingle();
      if (row != null && row['payload'] is Map) {
        payload = (row['payload'] as Map).cast<String, dynamic>();
      }
    }
    final doc = await generatePdfForFormType(formType, payload);
    if (doc == null) {
      _snack('Could not render this appointment.');
      return;
    }
    await Printing.layoutPdf(onLayout: (_) async => doc.save());
  }

  Future<void> _resign(Appointment a) async {
    final reason = await _promptReason();
    if (reason == null) return;
    await resignAppointment(a, reason);
    _load();
  }

  Future<String?> _promptReason() async {
    final ctrl = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Resign appointment'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(labelText: 'Reason'),
          minLines: 1,
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: const Text('Resign'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return null;
    return result;
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  List<Appointment> get _filtered => _filter == null
      ? _appointments
      : _appointments.where((a) => a.status == _filter).toList();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Appointments'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Appointments management is available to Admin and Super Admin '
              'accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Appointments'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _loading ? null : _issue,
        icon: const Icon(Icons.add),
        label: const Text('Issue appointment'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                scrollable: true,
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Wrap(
                      spacing: 8,
                      children: [
                        ChoiceChip(
                          label: const Text('All'),
                          selected: _filter == null,
                          onSelected: (_) => setState(() => _filter = null),
                        ),
                        for (final s in AppointmentStatus.values)
                          ChoiceChip(
                            label: Text(s.label),
                            selected: _filter == s,
                            onSelected: (_) => setState(() => _filter = s),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (_filtered.isEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 48),
                        child: Text(
                          'No appointments. Tap "Issue appointment" to create one.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    else
                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filtered.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final a = _filtered[i];
                          return Card(
                            child: ListTile(
                              title: Text(
                                '${a.roleCode} — ${_personName(a.appointeeId)}',
                              ),
                              subtitle: Text(
                                '${a.status.label} • '
                                'effective ${_dateFmt.format(a.effectiveDate)}'
                                '${a.section != null && a.section!.isNotEmpty ? ' • ${a.section}' : ''}',
                              ),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'pdf') _viewPdf(a);
                                  if (v == 'resign') _resign(a);
                                },
                                itemBuilder: (_) => [
                                  const PopupMenuItem(
                                    value: 'pdf',
                                    child: Text('View letter PDF'),
                                  ),
                                  if (a.canResign)
                                    const PopupMenuItem(
                                      value: 'resign',
                                      child: Text('Resign'),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Issue dialog
// ---------------------------------------------------------------------------

class _IssueAppointmentDialog extends StatefulWidget {
  const _IssueAppointmentDialog({
    required this.templates,
    required this.roles,
    required this.shafts,
    required this.people,
  });

  final List<AppointmentTemplate> templates;
  final List<AppointmentRole> roles;
  final List<Shaft> shafts;
  final List<({String id, String name})> people;

  @override
  State<_IssueAppointmentDialog> createState() =>
      _IssueAppointmentDialogState();
}

class _IssueAppointmentDialogState extends State<_IssueAppointmentDialog> {
  // Selection key: 'tmpl:<id>' for a dynamic template, 'form:<code>' for built-in.
  String? _selectionKey;
  String? _appointeeId;
  String? _shaftId;
  final _section = TextEditingController();
  final _cycle = TextEditingController();
  DateTime _effective = DateTime.now();
  final Map<String, dynamic> _fieldValues = {};
  bool _saving = false;

  @override
  void dispose() {
    _section.dispose();
    _cycle.dispose();
    super.dispose();
  }

  AppointmentTemplate? get _selectedTemplate {
    final key = _selectionKey;
    if (key == null || !key.startsWith('tmpl:')) return null;
    final id = key.substring(5);
    for (final t in widget.templates) {
      if (t.id == id) return t;
    }
    return null;
  }

  AppointableForm? get _selectedBuiltIn {
    final key = _selectionKey;
    if (key == null || !key.startsWith('form:')) return null;
    return appointableFormByCode(key.substring(5));
  }

  AppointmentRole? _roleById(String? id) {
    if (id == null) return null;
    for (final r in widget.roles) {
      if (r.id == id) return r;
    }
    return null;
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _effective,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _effective = picked);
  }

  Future<void> _issue() async {
    final tmpl = _selectedTemplate;
    final builtIn = _selectedBuiltIn;
    if (tmpl == null && builtIn == null) {
      _snack('Choose what to appoint.');
      return;
    }
    final appointeeId = _appointeeId;
    if (appointeeId == null) {
      _snack('Choose the appointee.');
      return;
    }

    final formType = tmpl?.code ?? builtIn!.code;
    final role = _roleById(tmpl?.roleId);
    final roleCode = tmpl != null
        ? (role?.code ?? role?.label ?? tmpl.name)
        : builtIn!.roleLabel;

    setState(() => _saving = true);
    try {
      final conflict = await appointmentUniquenessConflict(
        appointeeId: appointeeId,
        roleCode: roleCode,
        shaftId: _shaftId,
        effectiveDate: _effective,
      );
      if (conflict != null) {
        setState(() => _saving = false);
        _snack(conflict);
        return;
      }
      final appointee = await _loadProfile(appointeeId);
      if (appointee == null) {
        setState(() => _saving = false);
        _snack('Could not load the appointee profile.');
        return;
      }
      await issueAppointment(
        formType: formType,
        template: tmpl,
        roleId: tmpl?.roleId,
        roleCode: roleCode,
        appointee: appointee,
        shaftId: _shaftId,
        section: _section.text.trim().isEmpty ? null : _section.text.trim(),
        cycle: _cycle.text.trim().isEmpty ? null : _cycle.text.trim(),
        effectiveDate: _effective,
        fieldValues: _fieldValues,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      _snack('Issue failed: $err');
    }
  }

  Future<UserProfile?> _loadProfile(String id) async {
    final row = await supabase
        .from('profiles')
        .select()
        .eq('id', id)
        .maybeSingle();
    if (row == null) return null;
    return UserProfile.fromMap(row);
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    final tmpl = _selectedTemplate;
    return AlertDialog(
      title: const Text('Issue appointment'),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                initialValue: _selectionKey,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'What to appoint'),
                items: [
                  for (final f in kAppointableForms)
                    DropdownMenuItem(
                      value: 'form:${f.code}',
                      child: Text('${f.label} (form)'),
                    ),
                  for (final t in widget.templates)
                    DropdownMenuItem(
                      value: 'tmpl:${t.id}',
                      child: Text('${t.name} (template)'),
                    ),
                ],
                onChanged: (v) => setState(() {
                  _selectionKey = v;
                  _fieldValues.clear();
                }),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _appointeeId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Appointee'),
                items: [
                  for (final p in widget.people)
                    DropdownMenuItem(value: p.id, child: Text(p.name)),
                ],
                onChanged: (v) => setState(() => _appointeeId = v),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _shaftId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Shaft'),
                items: [
                  for (final s in widget.shafts)
                    DropdownMenuItem(value: s.id, child: Text(s.name)),
                ],
                onChanged: (v) => setState(() => _shaftId = v),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _section,
                decoration: const InputDecoration(
                  labelText: 'Section (optional)',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _cycle,
                decoration: const InputDecoration(
                  labelText: 'Cycle (optional)',
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: Text('Effective: ${_dateFmt.format(_effective)}'),
                  ),
                  TextButton(
                    onPressed: _pickDate,
                    child: const Text('Pick date'),
                  ),
                ],
              ),
              if (tmpl != null) ...[
                const Divider(height: 24),
                Text(
                  'Form fields',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const SizedBox(height: 8),
                for (final f in tmpl.fields) _fieldInput(f),
              ] else if (_selectedBuiltIn != null)
                const Padding(
                  padding: EdgeInsets.only(top: 12),
                  child: Text(
                    'The appointee completes and signs this form when they '
                    'accept the appointment.',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(false),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _saving ? null : _issue,
          child: _saving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Issue'),
        ),
      ],
    );
  }

  Widget _fieldInput(FormFieldDef f) {
    switch (f.type) {
      case FormFieldType.section:
        return Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 4),
          child: Text(
            f.label,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
        );
      case FormFieldType.boolean:
        return SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(f.label),
          value: _fieldValues[f.key] == true,
          onChanged: (v) => setState(() => _fieldValues[f.key] = v),
        );
      case FormFieldType.dropdown:
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: DropdownButtonFormField<String>(
            initialValue: _fieldValues[f.key] as String?,
            isExpanded: true,
            decoration: InputDecoration(labelText: f.label),
            items: [
              for (final o in f.options ?? const <String>[])
                DropdownMenuItem(value: o, child: Text(o)),
            ],
            onChanged: (v) => setState(() => _fieldValues[f.key] = v),
          ),
        );
      default:
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: TextField(
            decoration: InputDecoration(labelText: f.label),
            keyboardType: f.type == FormFieldType.number
                ? TextInputType.number
                : TextInputType.text,
            minLines: f.type == FormFieldType.multiline ? 2 : 1,
            maxLines: f.type == FormFieldType.multiline ? 4 : 1,
            onChanged: (v) => _fieldValues[f.key] = v,
          ),
        );
    }
  }
}
