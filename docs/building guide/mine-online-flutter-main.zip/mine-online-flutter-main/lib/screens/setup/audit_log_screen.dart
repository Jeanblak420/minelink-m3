// SP9a Audit Log — admin-gated read-only feed over public.audit_log, rendered
// as human sentences via describeAuditEntry. Action filter chips.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../utils/audit_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';

class AuditLogScreen extends StatefulWidget {
  const AuditLogScreen({super.key});

  @override
  State<AuditLogScreen> createState() => _AuditLogScreenState();
}

class _Filter {
  const _Filter(this.label, this.actions);
  final String label;
  final List<String>? actions; // null = all
}

const _filters = [
  _Filter('All', null),
  _Filter('Role changes', ['user.role_change']),
  _Filter('Disabled', ['user.disable']),
  _Filter('Re-enabled', ['user.enable']),
  _Filter('Created', ['user.create']),
  _Filter('Deleted', ['user.delete']),
  _Filter('Passwords', ['user.update_password']),
  _Filter('Submission reviews', ['submission.review']),
  _Filter('Appointments', [
    'appointment.issued',
    'appointment.accepted',
    'appointment.declined',
    'appointment.activated',
    'appointment.resigned',
  ]),
  _Filter('Devices', ['device.approved', 'device.revoked', 'device.restored']),
];

class _AuditLogScreenState extends State<AuditLogScreen> {
  bool _loading = true;
  String? _error;
  List<AuditEntry> _entries = const [];
  Map<String, String> _names = const {};
  String _filterLabel = 'All';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final f = _filters.firstWhere((x) => x.label == _filterLabel);
      final entries = await loadAuditLog(actions: f.actions);
      final names = await loadAuditNames(entries);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _names = names;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  static String _fmt(DateTime? d) {
    if (d == null) return '';
    final l = d.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${l.year}-${two(l.month)}-${two(l.day)} '
        '${two(l.hour)}:${two(l.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Audit Log'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'The audit log is available to Admin and Super Admin accounts '
              'only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Audit Log'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final f in _filters)
                    ChoiceChip(
                      label: Text(f.label),
                      selected: _filterLabel == f.label,
                      onSelected: (_) {
                        setState(() => _filterLabel = f.label);
                        _load();
                      },
                    ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          _error!,
                          style: TextStyle(color: scheme.error),
                        ),
                      ),
                    )
                  : _entries.isEmpty
                  ? Center(
                      child: Text(
                        'No audit entries.',
                        style: TextStyle(color: scheme.onSurfaceVariant),
                      ),
                    )
                  : PageBody.list(
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _entries.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final e = _entries[i];
                          return ListTile(
                            leading: const Icon(Icons.fact_check_outlined),
                            title: Text(
                              describeAuditEntry(
                                e,
                                actorName: _names[e.actorId],
                                targetName: _names[e.entityId],
                              ),
                            ),
                            subtitle: Text(_fmt(e.createdAt)),
                            dense: true,
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
