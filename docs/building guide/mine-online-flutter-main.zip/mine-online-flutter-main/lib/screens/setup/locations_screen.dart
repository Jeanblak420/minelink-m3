// Admin Locations manager: the Shaft -> Section -> Area hierarchy with CRUD
// (add / edit / archive / restore). Part of SP5 Org structure.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../models/org_location.dart';
import '../../providers/auth_provider.dart';
import '../../utils/org_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';

class LocationsScreen extends StatefulWidget {
  const LocationsScreen({super.key});

  @override
  State<LocationsScreen> createState() => _LocationsScreenState();
}

class _LocationsScreenState extends State<LocationsScreen> {
  bool _loading = true;
  String? _error;
  bool _showArchived = false;
  List<Shaft> _shafts = const [];
  Map<String, List<Section>> _sectionsByShaft = const {};
  Map<String, List<Area>> _areasBySection = const {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final shafts = await loadShafts(includeArchived: _showArchived);
      final sections = await loadSections(includeArchived: _showArchived);
      final areas = await loadAreas(includeArchived: _showArchived);
      if (!mounted) return;
      setState(() {
        _shafts = shafts;
        _sectionsByShaft = groupByParent(sections, (s) => s.shaftId);
        _areasBySection = groupByParent(areas, (a) => a.sectionId);
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  /// Name + description editor. Returns (name, description) or null on cancel.
  Future<(String, String?)?> _editor(
    String title, {
    String name = '',
    String? description,
  }) {
    final nameCtl = TextEditingController(text: name);
    final descCtl = TextEditingController(text: description ?? '');
    return showDialog<(String, String?)?>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtl,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descCtl,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final n = nameCtl.text.trim();
              if (n.isEmpty) return;
              Navigator.pop(ctx, (
                n,
                descCtl.text.trim().isEmpty ? null : descCtl.text.trim(),
              ));
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _runSave(Future<void> Function() op) async {
    try {
      await op();
      await _load();
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Locations'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Locations management is available to Admin and Super Admin '
              'accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Locations'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: _showArchived ? 'Hide archived' : 'Show archived',
            icon: Icon(_showArchived ? Icons.visibility_off : Icons.visibility),
            onPressed: () {
              setState(() => _showArchived = !_showArchived);
              _load();
            },
          ),
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final r = await _editor('New shaft');
          if (r != null) {
            await _runSave(() => saveShaft(name: r.$1, description: r.$2));
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('New shaft'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(12),
                child: _shafts.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'No shafts yet. Tap "New shaft" to add one.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView(
                        shrinkWrap: true,
                        children: [
                          for (final shaft in _shafts) _shaftTile(shaft),
                        ],
                      ),
              ),
      ),
    );
  }

  Widget _shaftTile(Shaft shaft) {
    final sections = _sectionsByShaft[shaft.id] ?? const [];
    return Card(
      child: ExpansionTile(
        leading: const Icon(Icons.account_tree_outlined),
        title: Text(shaft.name),
        subtitle: _subtitle(
          shaft.description,
          shaft.isActive,
          '${sections.length} section${sections.length == 1 ? '' : 's'}',
        ),
        trailing: _menu(
          isActive: shaft.isActive,
          onEdit: () async {
            final r = await _editor(
              'Edit shaft',
              name: shaft.name,
              description: shaft.description,
            );
            if (r != null) {
              await _runSave(
                () => saveShaft(id: shaft.id, name: r.$1, description: r.$2),
              );
            }
          },
          onToggle: () => _runSave(
            () => setLocationActive('shafts', shaft.id, !shaft.isActive),
          ),
        ),
        childrenPadding: const EdgeInsets.only(left: 16, bottom: 8),
        children: [
          for (final section in sections) _sectionTile(section),
          _addButton('Add section', () async {
            final r = await _editor('New section');
            if (r != null) {
              await _runSave(
                () => saveSection(
                  shaftId: shaft.id,
                  name: r.$1,
                  description: r.$2,
                ),
              );
            }
          }),
        ],
      ),
    );
  }

  Widget _sectionTile(Section section) {
    final areas = _areasBySection[section.id] ?? const [];
    return ExpansionTile(
      leading: const Icon(Icons.layers_outlined),
      title: Text(section.name),
      subtitle: _subtitle(
        section.description,
        section.isActive,
        '${areas.length} area${areas.length == 1 ? '' : 's'}',
      ),
      trailing: _menu(
        isActive: section.isActive,
        onEdit: () async {
          final r = await _editor(
            'Edit section',
            name: section.name,
            description: section.description,
          );
          if (r != null) {
            await _runSave(
              () => saveSection(
                id: section.id,
                shaftId: section.shaftId,
                name: r.$1,
                description: r.$2,
              ),
            );
          }
        },
        onToggle: () => _runSave(
          () => setLocationActive('sections', section.id, !section.isActive),
        ),
      ),
      childrenPadding: const EdgeInsets.only(left: 16, bottom: 8),
      children: [
        for (final area in areas) _areaTile(area),
        _addButton('Add area', () async {
          final r = await _editor('New area');
          if (r != null) {
            await _runSave(
              () => saveArea(
                sectionId: section.id,
                name: r.$1,
                description: r.$2,
              ),
            );
          }
        }),
      ],
    );
  }

  Widget _areaTile(Area area) {
    return ListTile(
      leading: const Icon(Icons.place_outlined),
      title: Text(area.name),
      subtitle: _subtitle(area.description, area.isActive, null),
      trailing: _menu(
        isActive: area.isActive,
        onEdit: () async {
          final r = await _editor(
            'Edit area',
            name: area.name,
            description: area.description,
          );
          if (r != null) {
            await _runSave(
              () => saveArea(
                id: area.id,
                sectionId: area.sectionId,
                name: r.$1,
                description: r.$2,
              ),
            );
          }
        },
        onToggle: () =>
            _runSave(() => setLocationActive('areas', area.id, !area.isActive)),
      ),
    );
  }

  Widget? _subtitle(String? description, bool isActive, String? count) {
    final parts = <String>[];
    if (count != null) parts.add(count);
    if (description != null && description.isNotEmpty) parts.add(description);
    if (!isActive) parts.add('archived');
    return parts.isEmpty ? null : Text(parts.join(' • '));
  }

  Widget _menu({
    required bool isActive,
    required VoidCallback onEdit,
    required VoidCallback onToggle,
  }) {
    return PopupMenuButton<String>(
      onSelected: (v) {
        if (v == 'edit') onEdit();
        if (v == 'toggle') onToggle();
      },
      itemBuilder: (_) => [
        const PopupMenuItem(value: 'edit', child: Text('Edit')),
        PopupMenuItem(
          value: 'toggle',
          child: Text(isActive ? 'Archive' : 'Restore'),
        ),
      ],
    );
  }

  Widget _addButton(String label, VoidCallback onTap) {
    return Align(
      alignment: Alignment.centerLeft,
      child: TextButton.icon(
        icon: const Icon(Icons.add, size: 18),
        label: Text(label),
        onPressed: onTap,
      ),
    );
  }
}
