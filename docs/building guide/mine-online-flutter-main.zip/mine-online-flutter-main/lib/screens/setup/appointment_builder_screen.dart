// SP3 Appointment Builder + Letter Builder. Admin/super-admin screen to author
// appointment templates: a role + form fields (reusing the SP2 field editor) and
// an appointment letter body with {{placeholder}} tokens, previewable as a PDF.
// Issuing appointments to real people + the sign/resign lifecycle is SP4.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';

import '../../models/appointment_template.dart';
import '../../models/custom_form_template.dart';
import '../../pdf/generate_appointment_letter_pdf.dart';
import '../../providers/auth_provider.dart';
import '../../utils/appointment_template_data.dart';
import '../../utils/dynamic_form_payload.dart' show kChainSignerLabels;
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/form_builder/field_editor.dart';
import '../../widgets/page_body.dart';

const Map<String, String> _kLanguages = {
  'en': 'English',
  'af': 'Afrikaans',
  'zu': 'Zulu',
  'xh': 'Xhosa',
  'st': 'Sesotho',
  'tn': 'Setswana',
};

class AppointmentBuilderScreen extends StatefulWidget {
  const AppointmentBuilderScreen({super.key});

  @override
  State<AppointmentBuilderScreen> createState() =>
      _AppointmentBuilderScreenState();
}

class _AppointmentBuilderScreenState extends State<AppointmentBuilderScreen> {
  bool _loading = true;
  String? _error;
  List<AppointmentTemplate> _templates = const [];
  List<AppointmentRole> _roles = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final templates = await loadAppointmentTemplates(includeArchived: true);
      final roles = await loadAppointmentRoles(includeArchived: true);
      if (!mounted) return;
      setState(() {
        _templates = templates;
        _roles = roles;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  AppointmentRole? _roleFor(String? id) {
    if (id == null) return null;
    for (final r in _roles) {
      if (r.id == id) return r;
    }
    return null;
  }

  Future<void> _openEditor([AppointmentTemplate? existing]) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) =>
            _AppointmentEditorScreen(existing: existing, roles: _roles),
      ),
    );
    if (saved == true) _load();
  }

  Future<void> _toggleActive(AppointmentTemplate t) async {
    await setAppointmentTemplateActive(t.id, !t.isActive);
    _load();
  }

  Future<void> _manageRoles() async {
    await showDialog<void>(
      context: context,
      builder: (_) => const _RolesManagerDialog(),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Appointment Builder'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Appointment Builder is available to Admin and Super Admin '
              'accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Appointment Builder'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Manage roles',
            onPressed: _loading ? null : _manageRoles,
            icon: const Icon(Icons.badge_outlined),
          ),
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('New appointment'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(16),
                child: _templates.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'No appointment templates yet. Tap "New appointment" '
                          'to build one.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView.separated(
                        shrinkWrap: true,
                        itemCount: _templates.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final t = _templates[i];
                          final role = _roleFor(t.roleId);
                          final fieldCount = t.fields
                              .where((f) => f.type != FormFieldType.section)
                              .length;
                          return Card(
                            child: ListTile(
                              title: Text(t.name),
                              subtitle: Text(
                                '${role?.displayLabel ?? 'No role'} • '
                                '$fieldCount fields'
                                '${t.letterBody.trim().isEmpty ? '' : ' • letter'}'
                                '${t.isActive ? '' : ' • archived'}',
                              ),
                              onTap: () => _openEditor(t),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'edit') _openEditor(t);
                                  if (v == 'toggle') _toggleActive(t);
                                },
                                itemBuilder: (_) => [
                                  const PopupMenuItem(
                                    value: 'edit',
                                    child: Text('Edit'),
                                  ),
                                  PopupMenuItem(
                                    value: 'toggle',
                                    child: Text(
                                      t.isActive ? 'Archive' : 'Restore',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Editor
// ---------------------------------------------------------------------------

class _AppointmentEditorScreen extends StatefulWidget {
  const _AppointmentEditorScreen({this.existing, required this.roles});
  final AppointmentTemplate? existing;
  final List<AppointmentRole> roles;

  @override
  State<_AppointmentEditorScreen> createState() =>
      _AppointmentEditorScreenState();
}

class _AppointmentEditorScreenState extends State<_AppointmentEditorScreen> {
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _letter;
  String? _roleId;
  late String _language;
  late List<FormFieldDef> _fields;
  late List<String> _requiredSigners;
  bool _showPreview = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _description = TextEditingController(text: e?.description ?? '');
    _letter = TextEditingController(text: e?.letterBody ?? '');
    _roleId = e?.roleId;
    _language = e?.language ?? 'en';
    _fields = e == null ? [] : [...e.fields];
    _requiredSigners = e == null ? [] : [...e.requiredSigners];
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _letter.dispose();
    super.dispose();
  }

  /// Roles offered in the dropdown: active ones plus the currently-selected role
  /// even if it was since archived (so editing an old template never loses it).
  List<AppointmentRole> get _roleOptions =>
      widget.roles.where((r) => r.isActive || r.id == _roleId).toList();

  AppointmentRole? get _selectedRole {
    for (final r in widget.roles) {
      if (r.id == _roleId) return r;
    }
    return null;
  }

  /// Sample values for live preview / preview PDF — standard profile tokens plus
  /// one sample per template field key.
  Map<String, String> _sampleValues() {
    final values = <String, String>{
      'full_name': 'Jane Doe',
      'first_name': 'Jane',
      'last_name': 'Doe',
      'employee_number': 'EMP001',
      'id_number': '8001015009087',
      'occupation': 'Shift Supervisor',
      'section': 'Section A',
      'company': 'Mine Online',
      'date': '21 June 2026',
    };
    for (final f in _fields) {
      if (f.type == FormFieldType.section) continue;
      values.putIfAbsent(f.key, () => '[${f.label}]');
    }
    return values;
  }

  AppointmentTemplate _draftTemplate() {
    final e = widget.existing;
    return AppointmentTemplate(
      id: e?.id ?? '',
      code: e?.code ?? 'appt_preview',
      name: _name.text.trim().isEmpty ? 'Untitled' : _name.text.trim(),
      description: _description.text.trim().isEmpty
          ? null
          : _description.text.trim(),
      roleId: _roleId,
      language: _language,
      fields: _fields,
      letterBody: _letter.text,
      requiredSigners: _requiredSigners,
      version: e?.version ?? 1,
      isActive: e?.isActive ?? true,
      createdBy: e?.createdBy,
    );
  }

  void _insertToken(String token) {
    final text = _letter.text;
    final sel = _letter.selection;
    final start = sel.start < 0 ? text.length : sel.start;
    final end = sel.end < 0 ? text.length : sel.end;
    final insert = '{{$token}}';
    final next = text.replaceRange(start, end, insert);
    _letter.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: start + insert.length),
    );
  }

  Future<void> _previewPdf() async {
    final t = _draftTemplate();
    await Printing.layoutPdf(
      onLayout: (_) async => (await generateAppointmentLetterPdf(
        t,
        _sampleValues(),
        role: _selectedRole,
      )).save(),
    );
  }

  Future<void> _save() async {
    final errors = validateAppointmentTemplate(
      name: _name.text,
      roleId: _roleId,
      fields: _fields,
    );
    if (errors.isNotEmpty) {
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Fix these first'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [for (final e in errors) Text('• $e')],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      final e = widget.existing;
      final code =
          e?.code ??
          appointmentTemplateCode(
            _name.text,
            DateTime.now().microsecondsSinceEpoch.toRadixString(36),
          );
      await saveAppointmentTemplate(
        id: e?.id,
        code: code,
        name: _name.text.trim(),
        description: _description.text.trim().isEmpty
            ? null
            : _description.text.trim(),
        roleId: _roleId,
        language: _language,
        fields: _fields,
        letterBody: _letter.text,
        requiredSigners: _requiredSigners,
        version: e?.version ?? 1,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            widget.existing == null ? 'New appointment' : 'Edit appointment',
          ),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Details & fields'),
              Tab(text: 'Letter'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Save'),
            ),
          ],
        ),
        body: SafeArea(
          child: TabBarView(children: [_detailsTab(), _letterTab()]),
        ),
      ),
    );
  }

  Widget _detailsTab() {
    return PageBody.form(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          DropdownButtonFormField<String>(
            initialValue: _roleId,
            decoration: const InputDecoration(labelText: 'Appointment role'),
            items: [
              for (final r in _roleOptions)
                DropdownMenuItem(
                  value: r.id,
                  child: Text(
                    r.isActive
                        ? r.displayLabel
                        : '${r.displayLabel} (archived)',
                  ),
                ),
            ],
            onChanged: (v) => setState(() => _roleId = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Template name'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _description,
            decoration: const InputDecoration(
              labelText: 'Description (optional)',
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _language,
            decoration: const InputDecoration(labelText: 'Language'),
            items: [
              for (final entry in _kLanguages.entries)
                DropdownMenuItem(value: entry.key, child: Text(entry.value)),
            ],
            onChanged: (v) => setState(() => _language = v ?? 'en'),
          ),
          const SizedBox(height: 16),
          const Text(
            'Signature workflow',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          const Text(
            'Who must sign the appointment after the appointee. '
            'Leave both off for no signature chain.',
            style: TextStyle(fontSize: 12),
          ),
          Wrap(
            spacing: 8,
            children: [
              for (final entry in kChainSignerLabels.entries)
                FilterChip(
                  label: Text(entry.value),
                  selected: _requiredSigners.contains(entry.key),
                  onSelected: (sel) => setState(() {
                    if (sel) {
                      _requiredSigners = [..._requiredSigners, entry.key];
                    } else {
                      _requiredSigners = _requiredSigners
                          .where((s) => s != entry.key)
                          .toList();
                    }
                  }),
                ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Fields',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
          ),
          const Text(
            'Captured when issuing the appointment; also usable as letter '
            'placeholders.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          FieldEditorList(
            fields: _fields,
            onChanged: (f) => setState(() => _fields = f),
          ),
        ],
      ),
    );
  }

  Widget _letterTab() {
    final scheme = Theme.of(context).colorScheme;
    final fieldTokens = _fields
        .where((f) => f.type != FormFieldType.section)
        .map((f) => f.key)
        .where((k) => k.trim().isNotEmpty)
        .toList();

    return PageBody.form(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          const Text(
            'Letter body',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
          ),
          const Text(
            'Plain text with {{placeholders}}. Use "# " for a centered heading '
            'and **bold** for emphasis.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          if (fieldTokens.isNotEmpty) ...[
            const Text(
              'Insert field',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
            ),
            Wrap(
              spacing: 6,
              runSpacing: 0,
              children: [
                for (final k in fieldTokens)
                  ActionChip(
                    label: Text('{{$k}}'),
                    onPressed: () => _insertToken(k),
                  ),
              ],
            ),
            const SizedBox(height: 4),
          ],
          const Text(
            'Insert profile detail',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
          ),
          Wrap(
            spacing: 6,
            runSpacing: 0,
            children: [
              for (final token in kStandardLetterTokens)
                ActionChip(
                  label: Text('{{$token}}'),
                  onPressed: () => _insertToken(token),
                ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _letter,
            minLines: 8,
            maxLines: 16,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Dear {{full_name}},\n\nYou are hereby appointed...',
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: () => setState(() => _showPreview = !_showPreview),
                icon: Icon(
                  _showPreview ? Icons.visibility_off : Icons.visibility,
                ),
                label: Text(_showPreview ? 'Hide preview' : 'Show preview'),
              ),
              const SizedBox(width: 12),
              FilledButton.icon(
                onPressed: _previewPdf,
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('Preview PDF'),
              ),
            ],
          ),
          if (_showPreview) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: scheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
              ),
              child: AnimatedBuilder(
                animation: _letter,
                builder: (_, _) => Text(
                  renderLetterBody(_letter.text, _sampleValues()),
                  style: TextStyle(color: scheme.onSurface),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Roles manager dialog
// ---------------------------------------------------------------------------

class _RolesManagerDialog extends StatefulWidget {
  const _RolesManagerDialog();

  @override
  State<_RolesManagerDialog> createState() => _RolesManagerDialogState();
}

class _RolesManagerDialogState extends State<_RolesManagerDialog> {
  bool _loading = true;
  List<AppointmentRole> _roles = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final roles = await loadAppointmentRoles(includeArchived: true);
    if (!mounted) return;
    setState(() {
      _roles = roles;
      _loading = false;
    });
  }

  Future<void> _editRole([AppointmentRole? role]) async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => _RoleEditorDialog(existing: role),
    );
    if (saved == true) _load();
  }

  Future<void> _toggleActive(AppointmentRole r) async {
    await setAppointmentRoleActive(r.id, !r.isActive);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return AlertDialog(
      title: const Text('Appointment roles'),
      content: SizedBox(
        width: 420,
        height: 420,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Expanded(
                    child: _roles.isEmpty
                        ? Center(
                            child: Text(
                              'No roles yet.',
                              style: TextStyle(color: scheme.onSurfaceVariant),
                            ),
                          )
                        : ListView.separated(
                            itemCount: _roles.length,
                            separatorBuilder: (_, _) =>
                                const Divider(height: 1),
                            itemBuilder: (_, i) {
                              final r = _roles[i];
                              return ListTile(
                                dense: true,
                                title: Text(r.displayLabel),
                                subtitle: Text(
                                  '${r.isMandatory ? 'Mandatory' : 'Optional'}'
                                  '${r.isActive ? '' : ' • archived'}',
                                ),
                                trailing: PopupMenuButton<String>(
                                  onSelected: (v) {
                                    if (v == 'edit') _editRole(r);
                                    if (v == 'toggle') _toggleActive(r);
                                  },
                                  itemBuilder: (_) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Edit'),
                                    ),
                                    PopupMenuItem(
                                      value: 'toggle',
                                      child: Text(
                                        r.isActive ? 'Archive' : 'Restore',
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
      ),
      actions: [
        TextButton(onPressed: () => _editRole(), child: const Text('Add role')),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}

class _RoleEditorDialog extends StatefulWidget {
  const _RoleEditorDialog({this.existing});
  final AppointmentRole? existing;

  @override
  State<_RoleEditorDialog> createState() => _RoleEditorDialogState();
}

class _RoleEditorDialogState extends State<_RoleEditorDialog> {
  late final TextEditingController _code;
  late final TextEditingController _label;
  late final TextEditingController _description;
  late final TextEditingController _sortOrder;
  bool _mandatory = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _code = TextEditingController(text: e?.code ?? '');
    _label = TextEditingController(text: e?.label ?? '');
    _description = TextEditingController(text: e?.description ?? '');
    _sortOrder = TextEditingController(text: (e?.sortOrder ?? 0).toString());
    _mandatory = e?.isMandatory ?? false;
  }

  @override
  void dispose() {
    _code.dispose();
    _label.dispose();
    _description.dispose();
    _sortOrder.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_label.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Role label is required.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await saveAppointmentRole(
        id: widget.existing?.id,
        code: _code.text,
        label: _label.text,
        description: _description.text,
        isMandatory: _mandatory,
        sortOrder: int.tryParse(_sortOrder.text.trim()) ?? 0,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? 'Add role' : 'Edit role'),
      content: SizedBox(
        width: 380,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _label,
              decoration: const InputDecoration(labelText: 'Label'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _code,
              decoration: const InputDecoration(
                labelText: 'Regulation code (optional)',
                hintText: 'e.g. 2.13.1',
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _description,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
              ),
              minLines: 1,
              maxLines: 3,
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _sortOrder,
              decoration: const InputDecoration(labelText: 'Sort order'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Mandatory (required per law)'),
              value: _mandatory,
              onChanged: (v) => setState(() => _mandatory = v),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(false),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _saving ? null : _save,
          child: _saving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Save'),
        ),
      ],
    );
  }
}
