// Admin Gangs manager: gangs (with shaft/section/shift), members, and a shifts
// editor. Part of SP5 Org structure. Builds on SP5a locations.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../models/org_location.dart';
import '../../providers/auth_provider.dart';
import '../../utils/org_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';

class GangsScreen extends StatefulWidget {
  const GangsScreen({super.key});

  @override
  State<GangsScreen> createState() => _GangsScreenState();
}

class _GangsScreenState extends State<GangsScreen> {
  bool _loading = true;
  String? _error;
  bool _showArchived = false;
  List<Gang> _gangs = const [];
  List<Shaft> _shafts = const [];
  List<Section> _sections = const [];
  List<Shift> _shifts = const [];
  Map<String, int> _memberCounts = const {};
  Map<String, String> _profileNames = const {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final gangs = await loadGangs(includeArchived: _showArchived);
      final shafts = await loadShafts();
      final sections = await loadSections();
      final shifts = await loadShifts();
      final counts = await loadGangMemberCounts();
      final profiles = await loadPickProfiles();
      if (!mounted) return;
      setState(() {
        _gangs = gangs;
        _shafts = shafts;
        _sections = sections;
        _shifts = shifts;
        _memberCounts = counts;
        _profileNames = {for (final p in profiles) p.id: p.name};
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _runSave(Future<void> Function() op) async {
    try {
      await op();
      await _load();
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  String _gangSubtitle(Gang g) {
    String? nameOf<T>(
      List<T> list,
      String? id,
      String Function(T) name,
      String Function(T) idOf,
    ) {
      if (id == null) return null;
      for (final e in list) {
        if (idOf(e) == id) return name(e);
      }
      return null;
    }

    final shaft = nameOf(_shafts, g.shaftId, (s) => s.name, (s) => s.id);
    final section = nameOf(_sections, g.sectionId, (s) => s.name, (s) => s.id);
    final shift = nameOf(_shifts, g.shiftId, (s) => s.name, (s) => s.id);
    final count = _memberCounts[g.id] ?? 0;
    final parts = <String>[
      for (final p in [shaft, section, shift])
        if (p != null && p.isNotEmpty) p,
      '$count member${count == 1 ? '' : 's'}',
      if (!g.isActive) 'archived',
    ];
    return parts.join(' • ');
  }

  Future<void> _openEditor([Gang? existing]) async {
    final result = await showDialog<_GangResult?>(
      context: context,
      builder: (_) => _GangEditorDialog(
        existing: existing,
        shafts: _shafts,
        sections: _sections,
        shifts: _shifts,
      ),
    );
    if (result != null) {
      await _runSave(
        () => saveGang(
          id: existing?.id,
          name: result.name,
          shaftId: result.shaftId,
          sectionId: result.sectionId,
          shiftId: result.shiftId,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Gangs'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Gang management is available to Admin and Super Admin accounts '
              'only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gangs'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Manage shifts',
            icon: const Icon(Icons.schedule_outlined),
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const _ShiftsManagerScreen()),
              );
              _load(); // refresh shift names
            },
          ),
          IconButton(
            tooltip: _showArchived ? 'Hide archived' : 'Show archived',
            icon: Icon(_showArchived ? Icons.visibility_off : Icons.visibility),
            onPressed: () {
              setState(() => _showArchived = !_showArchived);
              _load();
            },
          ),
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('New gang'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(12),
                child: _gangs.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'No gangs yet. Tap "New gang" to add one.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView(
                        shrinkWrap: true,
                        children: [
                          for (final g in _gangs)
                            Card(
                              child: ListTile(
                                leading: const Icon(Icons.groups_2_outlined),
                                title: Text(g.name),
                                subtitle: Text(_gangSubtitle(g)),
                                onTap: () async {
                                  await Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => _GangDetailScreen(
                                        gang: g,
                                        profileNames: _profileNames,
                                      ),
                                    ),
                                  );
                                  _load();
                                },
                                trailing: PopupMenuButton<String>(
                                  onSelected: (v) {
                                    if (v == 'edit') _openEditor(g);
                                    if (v == 'toggle') {
                                      _runSave(
                                        () => setLocationActive(
                                          'gangs',
                                          g.id,
                                          !g.isActive,
                                        ),
                                      );
                                    }
                                  },
                                  itemBuilder: (_) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Edit'),
                                    ),
                                    PopupMenuItem(
                                      value: 'toggle',
                                      child: Text(
                                        g.isActive ? 'Archive' : 'Restore',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
      ),
    );
  }
}

typedef _GangResult = ({
  String name,
  String? shaftId,
  String? sectionId,
  String? shiftId,
});

class _GangEditorDialog extends StatefulWidget {
  const _GangEditorDialog({
    required this.existing,
    required this.shafts,
    required this.sections,
    required this.shifts,
  });
  final Gang? existing;
  final List<Shaft> shafts;
  final List<Section> sections;
  final List<Shift> shifts;

  @override
  State<_GangEditorDialog> createState() => _GangEditorDialogState();
}

class _GangEditorDialogState extends State<_GangEditorDialog> {
  late final TextEditingController _name;
  String? _shaftId;
  String? _sectionId;
  String? _shiftId;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _shaftId = e?.shaftId;
    _sectionId = e?.sectionId;
    _shiftId = e?.shiftId;
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Sections filtered to the chosen shaft.
    final sections = widget.sections
        .where((s) => s.shaftId == _shaftId)
        .toList();
    // Guard: clear section if it no longer belongs to the chosen shaft.
    if (_sectionId != null && !sections.any((s) => s.id == _sectionId)) {
      _sectionId = null;
    }
    return AlertDialog(
      title: Text(widget.existing == null ? 'New gang' : 'Edit gang'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _name,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Gang name'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String?>(
              initialValue: _shaftId,
              decoration: const InputDecoration(labelText: 'Shaft'),
              items: [
                const DropdownMenuItem(value: null, child: Text('— None —')),
                for (final s in widget.shafts)
                  DropdownMenuItem(value: s.id, child: Text(s.name)),
              ],
              onChanged: (v) => setState(() {
                _shaftId = v;
                _sectionId = null;
              }),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String?>(
              initialValue: _sectionId,
              decoration: InputDecoration(
                labelText: 'Section',
                helperText: _shaftId == null ? 'Pick a shaft first' : null,
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('— None —')),
                for (final s in sections)
                  DropdownMenuItem(value: s.id, child: Text(s.name)),
              ],
              onChanged: (v) => setState(() => _sectionId = v),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String?>(
              initialValue: _shiftId,
              decoration: const InputDecoration(labelText: 'Shift'),
              items: [
                const DropdownMenuItem(value: null, child: Text('— None —')),
                for (final s in widget.shifts)
                  DropdownMenuItem(value: s.id, child: Text(s.name)),
              ],
              onChanged: (v) => setState(() => _shiftId = v),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () {
            final n = _name.text.trim();
            if (n.isEmpty) return;
            Navigator.pop(context, (
              name: n,
              shaftId: _shaftId,
              sectionId: _sectionId,
              shiftId: _shiftId,
            ));
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}

class _GangDetailScreen extends StatefulWidget {
  const _GangDetailScreen({required this.gang, required this.profileNames});
  final Gang gang;
  final Map<String, String> profileNames;

  @override
  State<_GangDetailScreen> createState() => _GangDetailScreenState();
}

class _GangDetailScreenState extends State<_GangDetailScreen> {
  bool _loading = true;
  String? _error;
  List<GangMember> _members = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final members = await loadGangMembers(widget.gang.id);
      if (!mounted) return;
      setState(() {
        _members = members;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  String _nameOf(String userId) => widget.profileNames[userId] ?? 'Unknown';

  Future<void> _addMember() async {
    final existing = _members.map((m) => m.userId).toSet();
    final candidates =
        widget.profileNames.entries
            .where((e) => !existing.contains(e.key))
            .map((e) => PickProfile(id: e.key, name: e.value))
            .toList()
          ..sort(
            (a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
          );
    final picked = await showDialog<String?>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Add member'),
        children: [
          if (candidates.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Everyone is already in this gang.'),
            )
          else
            for (final p in candidates)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(ctx, p.id),
                child: Text(p.name),
              ),
        ],
      ),
    );
    if (picked != null) {
      try {
        await addGangMember(widget.gang.id, picked);
        await _load();
      } catch (err) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not add: $err')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(widget.gang.name)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addMember,
        icon: const Icon(Icons.person_add_alt),
        label: const Text('Add member'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(12),
                child: _members.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'No members yet. Tap "Add member".',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView(
                        shrinkWrap: true,
                        children: [
                          for (final m in _members)
                            Card(
                              child: ListTile(
                                leading: const Icon(Icons.person_outline),
                                title: Text(_nameOf(m.userId)),
                                trailing: IconButton(
                                  icon: const Icon(Icons.close),
                                  tooltip: 'Remove',
                                  onPressed: () async {
                                    await removeGangMember(m.id);
                                    await _load();
                                  },
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
      ),
    );
  }
}

class _ShiftsManagerScreen extends StatefulWidget {
  const _ShiftsManagerScreen();

  @override
  State<_ShiftsManagerScreen> createState() => _ShiftsManagerScreenState();
}

class _ShiftsManagerScreenState extends State<_ShiftsManagerScreen> {
  bool _loading = true;
  String? _error;
  List<Shift> _shifts = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final shifts = await loadShifts(includeArchived: true);
      if (!mounted) return;
      setState(() {
        _shifts = shifts;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _editor([Shift? existing]) async {
    final nameCtl = TextEditingController(text: existing?.name ?? '');
    final startCtl = TextEditingController(text: existing?.startTime ?? '');
    final endCtl = TextEditingController(text: existing?.endTime ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(existing == null ? 'New shift' : 'Edit shift'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtl,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: startCtl,
              decoration: const InputDecoration(
                labelText: 'Start time (optional)',
                hintText: 'e.g. 06:00',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: endCtl,
              decoration: const InputDecoration(
                labelText: 'End time (optional)',
                hintText: 'e.g. 14:00',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (nameCtl.text.trim().isEmpty) return;
              Navigator.pop(ctx, true);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await saveShift(
          id: existing?.id,
          name: nameCtl.text.trim(),
          startTime: startCtl.text.trim().isEmpty ? null : startCtl.text.trim(),
          endTime: endCtl.text.trim().isEmpty ? null : endCtl.text.trim(),
        );
        await _load();
      } catch (err) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Save failed: $err')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Shifts')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editor(),
        icon: const Icon(Icons.add),
        label: const Text('New shift'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_error!, style: TextStyle(color: scheme.error)),
                ),
              )
            : PageBody.list(
                padding: const EdgeInsets.all(12),
                child: _shifts.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 64),
                        child: Text(
                          'No shifts yet. Tap "New shift".',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    : ListView(
                        shrinkWrap: true,
                        children: [
                          for (final s in _shifts)
                            Card(
                              child: ListTile(
                                leading: const Icon(Icons.schedule_outlined),
                                title: Text(s.name),
                                subtitle: Text(
                                  [
                                    if (s.timeRange.isNotEmpty) s.timeRange,
                                    if (!s.isActive) 'archived',
                                  ].join(' • '),
                                ),
                                trailing: PopupMenuButton<String>(
                                  onSelected: (v) async {
                                    if (v == 'edit') _editor(s);
                                    if (v == 'toggle') {
                                      await setLocationActive(
                                        'shifts',
                                        s.id,
                                        !s.isActive,
                                      );
                                      await _load();
                                    }
                                  },
                                  itemBuilder: (_) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Edit'),
                                    ),
                                    PopupMenuItem(
                                      value: 'toggle',
                                      child: Text(
                                        s.isActive ? 'Archive' : 'Restore',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
              ),
      ),
    );
  }
}
