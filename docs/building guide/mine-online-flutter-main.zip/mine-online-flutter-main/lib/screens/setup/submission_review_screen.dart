// SP9b Submission Review — admin queue to approve/reject/flag submitted forms
// outside the signature chain. Writes via the set_submission_review RPC.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../utils/review_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';
import '../../widgets/submission_viewer_dialog.dart';

class SubmissionReviewScreen extends StatefulWidget {
  const SubmissionReviewScreen({super.key});

  @override
  State<SubmissionReviewScreen> createState() => _SubmissionReviewScreenState();
}

class _StatusFilter {
  const _StatusFilter(this.label, this.status);
  final String label;
  final String? status;
}

const _filters = [
  _StatusFilter('Pending', 'pending'),
  _StatusFilter('Approved', 'approved'),
  _StatusFilter('Rejected', 'rejected'),
  _StatusFilter('Flagged', 'flagged'),
  _StatusFilter('All', null),
];

class _SubmissionReviewScreenState extends State<SubmissionReviewScreen> {
  bool _loading = true;
  String? _error;
  List<ReviewSubmission> _items = const [];
  String? _status = 'pending';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final items = await loadReviewQueue(status: _status);
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Color _badgeColor(ColorScheme s, String status) {
    switch (status) {
      case 'approved':
        return Colors.green.shade600;
      case 'rejected':
        return s.error;
      case 'flagged':
        return Colors.orange.shade700;
      default:
        return s.outline;
    }
  }

  static String _fmt(DateTime? d) {
    if (d == null) return '';
    final l = d.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${l.year}-${two(l.month)}-${two(l.day)} '
        '${two(l.hour)}:${two(l.minute)}';
  }

  Future<void> _review(ReviewSubmission item) async {
    final result = await showDialog<({String status, String note})>(
      context: context,
      builder: (ctx) => _ReviewDialog(item: item),
    );
    if (result == null) return;
    try {
      await setSubmissionReview(
        id: item.id,
        status: result.status,
        note: result.note,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Marked ${reviewStatusLabel(result.status)}')),
      );
      await _load();
    } catch (err) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Review failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Submission Review'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Submission review is available to Admin and Super Admin accounts '
              'only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Submission Review'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final f in _filters)
                    ChoiceChip(
                      label: Text(f.label),
                      selected: _status == f.status,
                      onSelected: (_) {
                        setState(() => _status = f.status);
                        _load();
                      },
                    ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          _error!,
                          style: TextStyle(color: scheme.error),
                        ),
                      ),
                    )
                  : _items.isEmpty
                  ? Center(
                      child: Text(
                        'No submissions in this view.',
                        style: TextStyle(color: scheme.onSurfaceVariant),
                      ),
                    )
                  : PageBody.list(
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _items.length,
                        separatorBuilder: (_, _) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final it = _items[i];
                          return ListTile(
                            title: Text(it.title),
                            subtitle: Text(
                              '${it.formLabel} · ${it.submitter} · '
                              '${_fmt(it.createdAt)}',
                            ),
                            leading: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: _badgeColor(
                                  scheme,
                                  it.reviewStatus,
                                ).withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                reviewStatusLabel(it.reviewStatus),
                                style: TextStyle(
                                  fontSize: 11,
                                  color: _badgeColor(scheme, it.reviewStatus),
                                ),
                              ),
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  tooltip: 'View',
                                  icon: const Icon(Icons.visibility_outlined),
                                  onPressed: () => showDialog<void>(
                                    context: context,
                                    builder: (_) =>
                                        SubmissionViewerDialog(row: it.raw),
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'Review',
                                  icon: const Icon(Icons.rate_review_outlined),
                                  onPressed: () => _review(it),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReviewDialog extends StatefulWidget {
  const _ReviewDialog({required this.item});
  final ReviewSubmission item;

  @override
  State<_ReviewDialog> createState() => _ReviewDialogState();
}

class _ReviewDialogState extends State<_ReviewDialog> {
  String _status = 'approved';
  final _note = TextEditingController();

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Review: ${widget.item.title}'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            children: [
              for (final s in const ['approved', 'rejected', 'flagged'])
                ChoiceChip(
                  label: Text(reviewStatusLabel(s)),
                  selected: _status == s,
                  onSelected: (_) => setState(() => _status = s),
                ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _note,
            decoration: const InputDecoration(
              labelText: 'Note (optional)',
              border: OutlineInputBorder(),
            ),
            maxLines: 2,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: () =>
              Navigator.pop(context, (status: _status, note: _note.text)),
          child: const Text('Save'),
        ),
      ],
    );
  }
}
