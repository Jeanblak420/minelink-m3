import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../theme/mol_tones.dart';
import '../utils/admin_dashboard_data.dart';
import '../widgets/admin/admin_shell.dart';
import '../widgets/admin/appointment_activity_feed.dart';
import '../widgets/admin/kpi_stat_card.dart';
import '../widgets/admin/mobile_app_info_dialog.dart';
import '../widgets/admin/quick_actions_grid.dart';
import '../widgets/page_body.dart';
import '../widgets/submission_viewer_dialog.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool _loading = true;
  String? _error;
  bool _tipDismissed = false;
  AdminDashboardData _data = AdminDashboardData.empty;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await loadAdminDashboard();
      if (!mounted) return;
      setState(() {
        _data = data;
        _loading = false;
      });
      _resubscribe();
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  void _resubscribe() {
    if (_channel != null) return;
    _channel = supabase
        .channel('admin-dashboard')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'form_submissions',
          callback: (_) => _load(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'profiles',
          callback: (_) => _load(),
        )
        .subscribe();
  }

  List<QuickAction> _quickActions() => [
    QuickAction(
      icon: Icons.add_circle_outline,
      label: 'New Appointment',
      onTap: () => context.go('/appointments'),
    ),
    QuickAction(
      icon: Icons.hourglass_empty,
      label: 'Incomplete',
      onTap: () => context.go('/active-individual-current-logbook'),
    ),
    QuickAction(
      icon: Icons.design_services_outlined,
      label: 'Design Form',
      onTap: () => context.go('/form-builder'),
    ),
    QuickAction(
      icon: Icons.groups_outlined,
      label: 'Manage Workforce',
      onTap: () => context.go('/profiles'),
    ),
    QuickAction(
      icon: Icons.folder_open_outlined,
      label: 'Forms Management',
      onTap: () => context.go('/appointments'),
    ),
    QuickAction(
      icon: Icons.bar_chart_outlined,
      label: 'View Reports',
      onTap: () => context.go('/completed-logbook-history'),
    ),
    QuickAction(
      icon: Icons.smartphone_outlined,
      label: 'Mobile App',
      onTap: () => showMobileAppInfo(context),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);

    return AdminShell(
      location: '/',
      title: 'Admin Dashboard',
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            PageBody.list(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Mine Online',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'Admin Dashboard',
                    style: TextStyle(color: scheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: 20),

                  if (_error != null)
                    Card(
                      color: tones.danger.tint,
                      child: ListTile(
                        leading: Icon(
                          Icons.error_outline,
                          color: tones.danger.accent,
                        ),
                        title: Text(
                          'Could not load dashboard data',
                          style: TextStyle(color: tones.danger.fg),
                        ),
                        subtitle: Text(
                          _error!,
                          style: TextStyle(color: tones.danger.fg),
                        ),
                        trailing: TextButton(
                          onPressed: _load,
                          child: const Text('Retry'),
                        ),
                      ),
                    ),

                  // KPI cards
                  LayoutBuilder(
                    builder: (context, c) {
                      final cols = c.maxWidth >= 900
                          ? 4
                          : c.maxWidth >= 560
                          ? 2
                          : 1;
                      final cards = [
                        KpiStatCard(
                          label: 'Total Employees',
                          value: _data.totalEmployees,
                          icon: Icons.people_outline,
                          tone: tones.info,
                          loading: _loading,
                          onTap: () => context.go('/profiles'),
                        ),
                        KpiStatCard(
                          label: 'Active Appointments',
                          value: _data.activeAppointments,
                          icon: Icons.assignment_turned_in_outlined,
                          tone: tones.success,
                          loading: _loading,
                          onTap: () => context.go('/appointment-history-logs'),
                        ),
                        KpiStatCard(
                          label: 'Pending Forms',
                          value: _data.pendingForms,
                          icon: Icons.pending_actions_outlined,
                          tone: tones.warning,
                          loading: _loading,
                          onTap: () =>
                              context.go('/active-individual-current-logbook'),
                        ),
                        KpiStatCard(
                          label: 'Safety Incidents',
                          value: _data.safetyIncidents,
                          icon: Icons.warning_amber_outlined,
                          tone: tones.danger,
                          loading: _loading,
                          onTap: () => context.go('/completed-logbook-history'),
                        ),
                      ];
                      // Fixed cell height (not aspect ratio) so cards never get
                      // too short to fit their content at narrow widths.
                      return GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: cols,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          mainAxisExtent: 92,
                        ),
                        children: cards,
                      );
                    },
                  ),
                  const SizedBox(height: 24),

                  // Quick Actions
                  Row(
                    children: [
                      Icon(
                        Icons.bolt_outlined,
                        size: 20,
                        color: scheme.primary,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'Quick Actions',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  QuickActionsGrid(actions: _quickActions()),
                  const SizedBox(height: 12),

                  // Demo tip banner (dismissible)
                  if (!_tipDismissed)
                    Card(
                      color: tones.success.tint,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
                        child: Row(
                          children: [
                            Icon(
                              Icons.lightbulb_outline,
                              color: tones.success.accent,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Tip: Quick Actions give fast access to common tasks — create appointments, manage your workforce, and review reports.',
                                style: TextStyle(
                                  color: tones.success.fg,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, size: 18),
                              tooltip: 'Dismiss',
                              onPressed: () =>
                                  setState(() => _tipDismissed = true),
                            ),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),

                  // Appointment activity
                  AppointmentActivityFeed(
                    items: _data.recentActivity,
                    loading: _loading,
                    onViewAll: () => context.go('/appointment-history-logs'),
                    onOpen: (item) => showDialog<void>(
                      context: context,
                      builder: (_) => SubmissionViewerDialog(row: item.row),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
