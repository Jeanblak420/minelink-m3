// Category tone palette matching ui_kits/mine-online-app/Tokens.jsx
// (success / warning / danger / info, each with soft / tint / accent / fg).
// These complement the M3 ColorScheme that lives in theme_provider.dart.
//
// Used by the todos screen lanes/cards, notifications, signature requests,
// current logbook, etc. Keep values in lockstep with the UI kit.

import 'package:flutter/material.dart';

class MolTone {
  const MolTone({
    required this.soft,
    required this.tint,
    required this.accent,
    required this.fg,
  });

  /// Stronger background tint (chip/banner bg).
  final Color soft;

  /// Softer background tint (card bg).
  final Color tint;

  /// The accent line / icon color.
  final Color accent;

  /// Foreground color suitable for text on `soft`.
  final Color fg;
}

class MolTones {
  const MolTones({
    required this.info,
    required this.success,
    required this.warning,
    required this.danger,
    required this.bgMuted,
    required this.bgSunken,
    required this.line,
    required this.lineFaint,
    required this.fg3,
    required this.fg4,
    required this.navy,
    required this.navyDeep,
    required this.navySoft,
    required this.amber,
    required this.amberDeep,
    required this.amberSoft,
    required this.ink,
    required this.inkSoft,
  });

  final MolTone info;
  final MolTone success;
  final MolTone warning;
  final MolTone danger;
  final Color bgMuted;
  final Color bgSunken;
  final Color line;
  final Color lineFaint;
  final Color fg3;
  final Color fg4;
  // Brand colors — Mine Online uses navy + amber + industrial ink as the
  // product mark palette (see mine-online-design-system/README.md). These
  // are not part of the M3 ColorScheme; consume via MolTones.of(context).
  //   navy        — primary brand mark, focused border, key actions
  //   navyDeep    — pressed state, on-amber text, heading on light
  //   navySoft    — informational banner / subtle container
  //   amber       — secondary brand mark, warning emphasis, priority chip
  //   amberDeep   — pressed state, icon-on-amber
  //   amberSoft   — warning banner background, highlight chip
  //   ink         — logotype black / display headings
  //   inkSoft     — body copy on light surfaces
  // The live Flutter app still ships M3 default purple as the primary seed;
  // brand tokens are exposed for opt-in adoption (login button, focused
  // borders, brand accents) and for the redesign migration path.
  final Color navy;
  final Color navyDeep;
  final Color navySoft;
  final Color amber;
  final Color amberDeep;
  final Color amberSoft;
  final Color ink;
  final Color inkSoft;

  static const _light = MolTones(
    info: MolTone(
      soft: Color(0xFFD2DEF2),
      tint: Color(0xFFE6EDF7),
      accent: Color(0xFF0F4090),
      fg: Color(0xFF0A2E6B),
    ),
    success: MolTone(
      soft: Color(0xFFCFE9D8),
      tint: Color(0xFFE3F2EA),
      accent: Color(0xFF1E7E45),
      fg: Color(0xFF0B3E20),
    ),
    warning: MolTone(
      soft: Color(0xFFFCE6B5),
      tint: Color(0xFFFDF1D6),
      accent: Color(0xFFB4690E),
      fg: Color(0xFF4A2A05),
    ),
    danger: MolTone(
      soft: Color(0xFFF8CFCB),
      tint: Color(0xFFFCE7E4),
      accent: Color(0xFFB3261E),
      fg: Color(0xFF410E0B),
    ),
    bgMuted: Color(0xFFF4F6FA),
    bgSunken: Color(0xFFEBEEF4),
    line: Color(0xFFE4E7EE),
    lineFaint: Color(0xFFEEF1F5),
    fg3: Color(0xFF6B7280),
    fg4: Color(0xFF9AA1AB),
    navy: Color(0xFF0F4090),
    navyDeep: Color(0xFF0A2E6B),
    navySoft: Color(0xFFE4ECF8),
    amber: Color(0xFFFFB010),
    amberDeep: Color(0xFFC98300),
    amberSoft: Color(0xFFFFF3D6),
    ink: Color(0xFF1F1F1F),
    inkSoft: Color(0xFF4A4A4A),
  );

  static const _dark = MolTones(
    info: MolTone(
      soft: Color(0xFF22325A),
      tint: Color(0xFF192447),
      accent: Color(0xFF9DBEF7),
      fg: Color(0xFFCFE0FA),
    ),
    success: MolTone(
      soft: Color(0xFF234D32),
      tint: Color(0xFF1B3B26),
      accent: Color(0xFF9BD9B0),
      fg: Color(0xFFC9EED4),
    ),
    warning: MolTone(
      soft: Color(0xFF5B3F15),
      tint: Color(0xFF3E2A0D),
      accent: Color(0xFFFFC974),
      fg: Color(0xFFFFE0A8),
    ),
    danger: MolTone(
      soft: Color(0xFF5A2622),
      tint: Color(0xFF3F1B18),
      accent: Color(0xFFF2B8B5),
      fg: Color(0xFFFBD7D4),
    ),
    bgMuted: Color(0xFF141417),
    bgSunken: Color(0xFF2A2A30),
    line: Color(0xFF3B3B40),
    lineFaint: Color(0xFF2A2A30),
    fg3: Color(0xFF9C9AA1),
    fg4: Color(0xFF6B6A70),
    navy: Color(0xFF9DBEF7),
    navyDeep: Color(0xFFC2D6F9),
    navySoft: Color(0xFF1B2540),
    amber: Color(0xFFFFCB6B),
    amberDeep: Color(0xFFFFB010),
    amberSoft: Color(0xFF3A2D10),
    ink: Color(0xFFE6E1E5),
    inkSoft: Color(0xFFC9C5CB),
  );

  static MolTones of(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark ? _dark : _light;
  }
}
