import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/auth_provider.dart';
import 'providers/notifications_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/todos_provider.dart';
import 'routing/router.dart';

class MineOnlineApp extends StatelessWidget {
  const MineOnlineApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProxyProvider<AuthProvider, ThemeProvider>(
          create: (ctx) => ThemeProvider(
            Provider.of<AuthProvider>(ctx, listen: false),
          ),
          update: (_, auth, previous) => previous ?? ThemeProvider(auth),
        ),
        ChangeNotifierProvider(create: (_) => NotificationsProvider()),
        ChangeNotifierProvider(create: (_) => TodosProvider()),
      ],
      child: Consumer2<AuthProvider, ThemeProvider>(
        builder: (context, auth, theme, _) {
          final router = AppRouter.build(auth);
          return MaterialApp.router(
            title: 'Mine Online',
            debugShowCheckedModeBanner: false,
            theme: theme.themeData,
            routerConfig: router,
          );
        },
      ),
    );
  }
}
