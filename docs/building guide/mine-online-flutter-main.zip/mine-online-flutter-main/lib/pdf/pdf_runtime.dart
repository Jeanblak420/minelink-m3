// Shared helpers that mirror the jsPDF primitives used in
// src/utils/pdfGenerator.ts. The web PDF coordinates are in **millimetres**;
// these helpers convert to the PDF library's points (PdfPageFormat.mm = 1mm
// in points) so coordinates can be copied directly.

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

const double mm = PdfPageFormat.mm;
const PdfColor borderColor = PdfColor.fromInt(0xff000000);
const PdfColor lightFill = PdfColor.fromInt(0xffc4c4c4);
const PdfColor darkFill = PdfColor.fromInt(0xff545454);

/// Loads bundled image asset bytes for embedding in a PDF later.
Future<Uint8List> loadAssetBytes(String path) async {
  final data = await rootBundle.load(path);
  return data.buffer.asUint8List();
}

/// Sanitizes a string for the 14 base PDF fonts (Helvetica, Times, etc.),
/// which only support Latin-1 (codepoints ≤ 0xFF). Common typographic
/// punctuation that flows in from form titles ("Shift Boss Appointment —
/// User") would otherwise trip the dart_pdf Latin1 encoder and trigger the
/// "Helvetica has no Unicode support" warning. Replaces the offenders with
/// ASCII equivalents and falls back to '?' for anything else above 0xFF.
///
/// A future improvement is to bundle a TTF font (Roboto / Noto Sans) in
/// `assets/fonts/` and load it via `PdfTtfFont(doc, …)`. That would let
/// PDFs render the original Unicode glyphs identically to the web app's
/// jsPDF output. Until then this keeps PDFs producing without errors.
String latin1Safe(String s) {
  if (s.isEmpty) return s;
  const replacements = <String, String>{
    '–': '-',     // en dash
    '—': '-',     // em dash
    '‘': "'",     // left single quote
    '’': "'",     // right single quote / apostrophe
    '‚': ',',     // single low-9 quote
    '“': '"',     // left double quote
    '”': '"',     // right double quote
    '„': '"',     // double low-9 quote
    '•': '*',     // bullet
    '…': '...',   // horizontal ellipsis
    '′': "'",     // prime
    '″': '"',     // double prime
    ' ': ' ',     // non-breaking space (technically Latin-1 but normalise)
  };
  final buf = StringBuffer();
  for (final rune in s.runes) {
    final ch = String.fromCharCode(rune);
    final replaced = replacements[ch];
    if (replaced != null) {
      buf.write(replaced);
    } else if (rune <= 0xFF) {
      buf.write(ch);
    } else {
      buf.write('?');
    }
  }
  return buf.toString();
}

/// Decodes a `data:image/png;base64,...` data URL into raw bytes, or null
/// when the URL is empty / not an image data URL.
Uint8List? decodeSignatureBytes(String dataUrl) {
  if (dataUrl.isEmpty || !dataUrl.startsWith('data:image')) return null;
  final base64Part = dataUrl.split(',').last;
  try {
    return base64Decode(base64Part);
  } catch (_) {
    return null;
  }
}

/// Reads the pixel dimensions out of a PNG header (8-byte signature, then
/// IHDR chunk: 4 bytes length, 4 bytes "IHDR", 4 bytes width, 4 bytes
/// height — both big-endian). Returns null for non-PNG or malformed bytes.
({int width, int height})? readPngDimensions(Uint8List bytes) {
  if (bytes.length < 24) return null;
  // PNG magic: 89 50 4E 47 0D 0A 1A 0A
  if (bytes[0] != 0x89 ||
      bytes[1] != 0x50 ||
      bytes[2] != 0x4E ||
      bytes[3] != 0x47) {
    return null;
  }
  // IHDR width starts at byte 16, height at byte 20.
  int u32(int offset) =>
      (bytes[offset] << 24) |
      (bytes[offset + 1] << 16) |
      (bytes[offset + 2] << 8) |
      bytes[offset + 3];
  final width = u32(16);
  final height = u32(20);
  if (width <= 0 || height <= 0) return null;
  return (width: width, height: height);
}

/// Embeds a signature data URL into a PDF cell *with aspect ratio
/// preserved*. The web app and the previous Flutter call sites stretched
/// the captured PNG to fill the cell, which made wide-thin signature cells
/// (Shift Boss / Mine Manager rows are ~83 mm × 5.7 mm — 14.5 : 1) squash a
/// roughly 5 : 1 captured signature out of proportion. This helper computes
/// the largest rect that fits inside (cellW, cellH) at the PNG's native
/// aspect, then centers the image inside the cell.
///
/// No-op when the data URL is empty or not a recognisable image. Errors
/// during embedding are swallowed so a single corrupt signature can't break
/// the whole document.
void drawFittedSignature(
  PageCtx page,
  String dataUrl, {
  required double cellX,
  required double cellY,
  required double cellW,
  required double cellH,
}) {
  final bytes = decodeSignatureBytes(dataUrl);
  if (bytes == null) return;
  drawFittedSignatureBytes(
    page,
    bytes,
    cellX: cellX,
    cellY: cellY,
    cellW: cellW,
    cellH: cellH,
  );
}

/// Same as [drawFittedSignature] but starting from already-decoded bytes.
/// Used by `drawAutoTable`'s `cellSignature` callback, which hands back
/// `Uint8List?` rather than the original data URL.
void drawFittedSignatureBytes(
  PageCtx page,
  Uint8List bytes, {
  required double cellX,
  required double cellY,
  required double cellW,
  required double cellH,
}) {
  final dims = readPngDimensions(bytes);
  double drawW = cellW;
  double drawH = cellH;
  double offsetX = 0;
  double offsetY = 0;
  if (dims != null) {
    final imageAspect = dims.width / dims.height;
    final cellAspect = cellW / cellH;
    if (imageAspect > cellAspect) {
      // Image is wider than the cell — fit by width, shrink height.
      drawW = cellW;
      drawH = cellW / imageAspect;
      offsetY = (cellH - drawH) / 2;
    } else {
      // Image is taller than the cell — fit by height, shrink width.
      drawH = cellH;
      drawW = cellH * imageAspect;
      offsetX = (cellW - drawW) / 2;
    }
  }
  try {
    final image = page.imageFromBytes(bytes);
    page.drawImage(image, cellX + offsetX, cellY + offsetY, drawW, drawH);
  } catch (_) {
    // Skip broken signature without breaking the rest of the PDF.
  }
}

/// PDF fonts used by every generator. The web app uses jsPDF's default
/// Helvetica (a base-14 Type1 font with no Unicode support), and dart_pdf
/// prints a "Helvetica has no Unicode support" warning every time the base
/// fonts are instantiated in debug. We bundle Roboto (Apache 2.0, ships in
/// the Flutter SDK) so PDFs render any Unicode glyph and the warning never
/// fires. Roboto's metrics are close to Helvetica's so existing
/// mm-coordinate layouts still match the web output.
class Fonts {
  Fonts({
    required this.regular,
    required this.bold,
    required this.italic,
    required this.boldItalic,
  });
  final PdfFont regular;
  final PdfFont bold;
  final PdfFont italic;
  final PdfFont boldItalic;
}

/// Bundled-font byte cache. dart_pdf wants raw TTF bytes per document, but
/// loading from `rootBundle` four times per PDF page is wasteful — cache the
/// bytes on first use.
class _PdfFontBytes {
  _PdfFontBytes._();
  static Uint8List? _regular;
  static Uint8List? _bold;
  static Uint8List? _italic;
  static Uint8List? _boldItalic;

  static Future<void> _ensureLoaded() async {
    _regular ??= (await rootBundle.load('assets/fonts/Roboto-Regular.ttf'))
        .buffer
        .asUint8List();
    _bold ??= (await rootBundle.load('assets/fonts/Roboto-Bold.ttf'))
        .buffer
        .asUint8List();
    _italic ??= (await rootBundle.load('assets/fonts/Roboto-Italic.ttf'))
        .buffer
        .asUint8List();
    _boldItalic ??=
        (await rootBundle.load('assets/fonts/Roboto-BoldItalic.ttf'))
            .buffer
            .asUint8List();
  }

  static Fonts forDocument(PdfDocument doc) {
    // _ensureLoaded must have already been awaited before this synchronous
    // call. `buildMultiPageDocument` does that before each painter runs.
    return Fonts(
      regular: PdfTtfFont(doc, ByteData.sublistView(_regular!)),
      bold: PdfTtfFont(doc, ByteData.sublistView(_bold!)),
      italic: PdfTtfFont(doc, ByteData.sublistView(_italic!)),
      boldItalic: PdfTtfFont(doc, ByteData.sublistView(_boldItalic!)),
    );
  }
}

Future<void> ensurePdfFontsLoaded() => _PdfFontBytes._ensureLoaded();

/// Drawing helper that translates jsPDF top-down mm coordinates to the
/// pdf package's bottom-up points-based canvas.
class PageCtx {
  PageCtx(this.pageFormat, this.canvas, this.fonts, this.pdfDocument);
  final PdfPageFormat pageFormat;
  final PdfGraphics canvas;
  final Fonts fonts;
  final PdfDocument pdfDocument;

  double get pageWidth => pageFormat.width / mm;
  double get pageHeight => pageFormat.height / mm;

  /// jsPDF mm → pdf-package points, flipped so y grows downward in callers.
  double _yTop(double yMm) => pageFormat.height - (yMm * mm);

  PdfFont fontFor(String style) {
    switch (style) {
      case 'bold':
        return fonts.bold;
      case 'italic':
        return fonts.italic;
      case 'bolditalic':
      case 'boldItalic':
        return fonts.boldItalic;
      default:
        return fonts.regular;
    }
  }

  void setLineWidth(double w) => canvas.setLineWidth(w);
  void setDrawColor(PdfColor color) => canvas.setStrokeColor(color);

  void rectStroke(double x, double y, double w, double h) {
    canvas.setStrokeColor(borderColor);
    canvas.drawRect(x * mm, _yTop(y + h), w * mm, h * mm);
    canvas.strokePath();
  }

  void rectFill(double x, double y, double w, double h, PdfColor fill) {
    canvas.setFillColor(fill);
    canvas.drawRect(x * mm, _yTop(y + h), w * mm, h * mm);
    canvas.fillPath();
  }

  void rectFillStroke(double x, double y, double w, double h, PdfColor fill) {
    canvas.setFillColor(fill);
    canvas.setStrokeColor(borderColor);
    canvas.drawRect(x * mm, _yTop(y + h), w * mm, h * mm);
    canvas.fillAndStrokePath();
  }

  void line(double x1, double y1, double x2, double y2) {
    canvas.setStrokeColor(borderColor);
    canvas.drawLine(x1 * mm, _yTop(y1), x2 * mm, _yTop(y2));
    canvas.strokePath();
  }

  /// `text(...)` mirrors `doc.text(s, x, y, {align})`. x/y in mm, y is baseline.
  void text(
    String s,
    double x,
    double y, {
    required double size,
    required String style,
    String align = 'left',
    PdfColor color = PdfColors.black,
  }) {
    final safe = latin1Safe(s);
    final font = fontFor(style);
    final metrics = font.stringMetrics(safe);
    final width = metrics.width * size; // metrics are normalised to 1pt
    double drawX = x * mm;
    if (align == 'center') drawX -= width / 2;
    if (align == 'right') drawX -= width;
    canvas.setFillColor(color);
    canvas.drawString(font, size, safe, drawX, _yTop(y));
    canvas.setFillColor(PdfColors.black);
  }

  void drawImage(PdfImage image, double x, double y, double w, double h) {
    canvas.drawImage(image, x * mm, _yTop(y + h), w * mm, h * mm);
  }

  PdfImage imageFromBytes(Uint8List bytes) {
    return PdfImage.file(pdfDocument, bytes: bytes);
  }

  /// Measures rendered text width in mm. Mirrors `doc.getTextWidth`.
  double textWidth(String s, double fontSize, String style) {
    final font = fontFor(style);
    final widthPts = font.stringMetrics(latin1Safe(s)).width * fontSize;
    return widthPts / mm;
  }

  /// Soft-wraps a string to a maximum width in mm — mirrors `doc.splitTextToSize`.
  List<String> splitTextToSize(
    String s,
    double maxWidthMm,
    double fontSize,
    String style,
  ) {
    final font = fontFor(style);
    final words = latin1Safe(s).split(RegExp(r'\s+'));
    final lines = <String>[];
    var current = '';
    final maxWidthPts = maxWidthMm * mm;
    for (final word in words) {
      final candidate = current.isEmpty ? word : '$current $word';
      final widthPts = font.stringMetrics(candidate).width * fontSize;
      if (widthPts > maxWidthPts && current.isNotEmpty) {
        lines.add(current);
        current = word;
      } else {
        current = candidate;
      }
    }
    if (current.isNotEmpty) lines.add(current);
    return lines;
  }
}

/// Two-column key/value table used by appointment forms (label + value rows).
/// Mirrors the inline `drawTwoColumnTable` in pdfGenerator.ts.
void drawTwoColumnTable(
  PageCtx page, {
  required double margin,
  required double contentWidth,
  required double startY,
  required List<List<String>> rows,
  required double rowHeight,
  required double labelWidth,
  required double fontSize,
}) {
  final valueWidth = contentWidth - labelWidth;
  for (var i = 0; i < rows.length; i++) {
    final rowY = startY + i * rowHeight;
    final textY = rowY + rowHeight - 1.15;

    page.rectFillStroke(margin, rowY, labelWidth, rowHeight, lightFill);
    page.rectStroke(margin + labelWidth, rowY, valueWidth, rowHeight);

    page.text(rows[i][0], margin + 2.1, textY, size: fontSize, style: 'bold');
    page.text(rows[i][1], margin + labelWidth + 2.1, textY,
        size: fontSize, style: 'normal');
  }
}

double drawBulletedParagraphs(
  PageCtx page, {
  required double margin,
  required double contentWidth,
  required List<String> paragraphs,
  required double startY,
  required double fontSize,
  required double lineHeight,
}) {
  var currentY = startY;
  for (final paragraph in paragraphs) {
    final lines = page.splitTextToSize(paragraph, contentWidth - 18, fontSize, 'normal');
    for (var i = 0; i < lines.length; i++) {
      if (i == 0) {
        page.text('•', margin + 6, currentY, size: fontSize, style: 'normal');
      }
      page.text(lines[i], margin + 10, currentY, size: fontSize, style: 'normal');
      currentY += lineHeight;
    }
  }
  return currentY;
}

typedef PageBuilder = void Function(PageCtx page);

Future<pw.Document> buildSinglePageDocument({
  required PdfPageFormat pageFormat,
  required PageBuilder draw,
  String subject = 'Generated appointment form',
}) =>
    buildMultiPageDocument(
      pageFormat: pageFormat,
      pages: [draw],
      subject: subject,
    );

/// Builds a multi-page document. Each entry in [pages] paints one page using
/// the same coordinate helpers as single-page forms.
Future<pw.Document> buildMultiPageDocument({
  required PdfPageFormat pageFormat,
  required List<PageBuilder> pages,
  String subject = 'Generated appointment form',
}) async {
  final doc = pw.Document(
    creator: 'Mine Online',
    subject: subject,
    keywords: 'generated_at=${DateTime.now().toIso8601String()}',
  );
  // `PdfPageFormat.letter` (and A4) ship with `marginAll: 72` (1 inch). When
  // `pw.Page` uses that format it places the body widget in the margin-inset
  // area only, which would clamp our absolute-coordinate `CustomPaint`
  // (`size: full page`) down to ~76% × 82% of the page — exactly the symptom
  // of content drawn too small with cut-offs on the right and bottom. Our
  // PDF coordinates are explicit and assume the painter spans the full page,
  // so strip the format-level margins before handing the format to `pw.Page`.
  final fullBleedFormat = pageFormat.copyWith(
    marginLeft: 0,
    marginTop: 0,
    marginRight: 0,
    marginBottom: 0,
  );
  // Roboto TTFs are bundled as flutter assets — load the bytes once before
  // pages start painting (the painter callback below is synchronous, so we
  // can't await inside it).
  await ensurePdfFontsLoaded();
  for (final draw in pages) {
    doc.addPage(
      pw.Page(
        pageFormat: fullBleedFormat,
        build: (context) {
          return pw.CustomPaint(
            size: PdfPoint(pageFormat.width, pageFormat.height),
            painter: (canvas, size) {
              final fonts = _PdfFontBytes.forDocument(doc.document);
              draw(PageCtx(pageFormat, canvas, fonts, doc.document));
            },
          );
        },
      ),
    );
  }
  return doc;
}
