// Port of `generateInspectionControlSheetPDF` in src/utils/pdfGenerator.ts (4121-4199).
// Landscape letter — 31-day workplace grid.

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffd2d2d2);

const List<int> _dayCols = [
  26, 27, 28, 29, 30, 31,
  1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
];

Future<pw.Document> generateInspectionControlSheetPdf(
    InspectionControlSheetFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter.landscape,
    subject: 'Inspection Control Sheet',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(PageCtx page, InspectionControlSheetFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Inspection Control Sheet'],
    ],
    style: const GridStyle(
      fontSize: 14,
      cellPaddingTop: 3,
      cellPaddingBottom: 3,
      minCellHeight: 9,
    ),
  );
  y += 4;

  // Instructions paragraph
  final intro = page.splitTextToSize(
      'Shift Boss should record all working places, refuge bays, stores, waiting places and old working not permanently barricaded in this inspection control page.',
      contentWidth,
      8.5,
      'normal');
  for (final line in intro) {
    page.text(line, margin, y, size: 8.5, style: 'normal');
    y += 3.6;
  }
  y += 2;

  // Month from / to dotted line row
  page.text('Month', margin, y, size: 8.5, style: 'normal');
  drawDotLine(page, margin + 13, y + 0.5, 77);
  if (data.monthFrom.isNotEmpty) {
    page.text(data.monthFrom, margin + 14, y,
        size: 8.5, style: 'normal');
  }
  page.text('to', margin + 93, y, size: 8.5, style: 'normal');
  drawDotLine(page, margin + 99, y + 0.5, 76);
  if (data.monthTo.isNotEmpty) {
    page.text(data.monthTo, margin + 100, y, size: 8.5, style: 'normal');
  }
  y += 5;

  // Main grid: workplace + 31 day columns
  const wpW = 50.0;
  final dayW = (contentWidth - wpW) / _dayCols.length;

  final body = data.rows
      .map((r) => <String>[r.workplace, ...r.days.take(31)])
      .toList();

  final columns = <GridColumn>[
    const GridColumn(cellWidth: wpW),
    ..._dayCols.map((_) => GridColumn(cellWidth: dayW, halign: 'center')),
  ];

  final head = <GridHeader>[
    const GridHeader(
        text: 'Workplace',
        fillColor: PdfColors.white,
        fontStyle: 'bold',
        halign: 'left'),
    ..._dayCols.map((d) => GridHeader(
          text: '$d',
          fillColor: PdfColors.white,
          fontStyle: 'bold',
        )),
  ];

  y = drawAutoTable(
    page,
    startY: y,
    columns: columns,
    head: head,
    body: body,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1,
      cellPaddingBottom: 1,
      cellPaddingLeft: 1,
      cellPaddingRight: 1,
      minCellHeight: 8,
    ),
  );
  y += 3;

  page.text(
      'Abbreviations: B – Blasted, L - Loaded, S – Supported, I – Inspected, N – Not Inspected',
      margin,
      y,
      size: 8,
      style: 'bold');

  drawInspectionFooter(page, pageNum: 'Page 10 of 84');
}
