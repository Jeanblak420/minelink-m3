// Port of `generateRockBreakerInspectionPDF` in src/utils/pdfGenerator.ts (3734-3804).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'inspection_items_table.dart';
import 'pdf_runtime.dart';

const List<String> rockBreakerItemLabels = [
  'Rock breaker locked out when not in use?',
  'Re-use checklist available?',
  'Pre-use checklist completed according to requirements?',
  'Spillages controlled?',
  'Fire extinguisher available?',
  'Fire extinguisher inspected monthly?',
  'Fire extinguisher in good working order?',
  'Operator trained / licence available?',
  'Housekeeping of high standard?',
  'Area adequately illuminated?',
];

Future<pw.Document> generateRockBreakerInspectionPdf(
    RockBreakerInspectionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Rock Breaker Inspection',
    draw: (page) {
      const margin = 10.5;
      final rightEdge = page.pageWidth - margin;
      var y = drawInspectionHeader(page, startY: 8, logoBytes: logoBytes) + 3;

      y = drawInspectionTitle(page, y, 'Weekly Rock Breaker Inspection');
      y += 6;

      page.text('Date of Inspection:', margin, y, size: 8, style: 'normal');
      drawDotLine(page, margin + 30, y + 0.5, 54);
      if (data.dateOfInspection.isNotEmpty) {
        page.text(data.dateOfInspection, margin + 31, y,
            size: 8, style: 'normal');
      }
      page.text('Position of rock breaker:', margin + 90, y,
          size: 8, style: 'normal');
      drawDotLine(page, margin + 122, y + 0.5, rightEdge - margin - 122);
      if (data.positionOfRockBreaker.isNotEmpty) {
        page.text(data.positionOfRockBreaker, margin + 123, y,
            size: 8, style: 'normal');
      }
      y += 4;

      y = drawInspectionItemsTable(
          page, y, rockBreakerItemLabels, data.items);
      y += 7;

      drawInspectionSignatureRow(
        page,
        y,
        shiftBossSignature: data.shiftBossSignature,
        shiftBossDate: data.shiftBossDate,
        mineManagerOverseerSignature: data.mineManagerOverseerSignature,
        mineManagerOverseerDate: data.mineManagerOverseerDate,
      );

      drawInspectionFooter(page, pageNum: 'Page 70 of 84');
    },
  );
}
