// Port of `generateEarlyShiftRecordPDF` in src/utils/pdfGenerator.ts (1842-2057).
// 2-page form with yes/no questions, dotted-line details, and signature block.

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const double _margin = 10.5;
const double _fs = 8;
const double _lineH = 5.2;

Future<pw.Document> generateEarlyShiftRecordPdf(
    EarlyShiftRecordFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildMultiPageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Early Shift Record',
    pages: [
      (page) => _drawPage1(page, formData, logoBytes),
      (page) => _drawPage2(page, formData, logoBytes),
    ],
  );
}

void _drawPage1(
    PageCtx page, EarlyShiftRecordFormData data, Uint8List? logo) {
  final contentWidth = page.pageWidth - _margin * 2;
  final rightEdge = _margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3.2;

  // Title block (white-on-white bordered grid)
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    body: const [
      ['Early Shift Record'],
      ['(A Shift Boss must conduct an early shift once a week)'],
    ],
    style: const GridStyle(fontSize: 16, minCellHeight: 9),
  );
  y += 5;

  // Section / Strike / Date row
  page.text('Section:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 14, y + 0.5, 52);
  page.text('Strike:', _margin + 73, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 85, y + 0.5, 38);
  page.text('Date:', _margin + 130, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 140, y + 0.5, rightEdge - (_margin + 140));
  if (data.section.isNotEmpty) {
    page.text(data.section, _margin + 15, y, size: _fs, style: 'normal');
  }
  if (data.strike.isNotEmpty) {
    page.text(data.strike, _margin + 86, y, size: _fs, style: 'normal');
  }
  if (data.date.isNotEmpty) {
    page.text(data.date, _margin + 141, y, size: _fs, style: 'normal');
  }
  y += _lineH + 3;

  // I went underground at / I arrived at the waiting place at
  final ampmX = rightEdge - 32;
  page.text('I went underground at:', _margin, y, size: _fs, style: 'normal');
  page.text('am/pm', ampmX, y, size: _fs, style: 'normal');
  drawDotLine(page, ampmX + 10, y + 0.5, rightEdge - ampmX - 10);
  if (data.wentUndergroundAt.isNotEmpty) {
    page.text(data.wentUndergroundAt, ampmX + 11, y,
        size: _fs, style: 'normal');
  }
  y += _lineH;

  page.text('I arrived at the waiting place at:', _margin, y,
      size: _fs, style: 'normal');
  page.text('am/pm', ampmX, y, size: _fs, style: 'normal');
  drawDotLine(page, ampmX + 10, y + 0.5, rightEdge - ampmX - 10);
  if (data.arrivedAtWaitingPlace.isNotEmpty) {
    page.text(data.arrivedAtWaitingPlace, ampmX + 11, y,
        size: _fs, style: 'normal');
  }
  y += _lineH;

  page.text('The miner arrived at:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 36, y + 0.5, 14);
  page.text('am/pm', _margin + 50, y, size: _fs, style: 'normal');
  page.text('Miner coy no:', _margin + 68, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 92, y + 0.5, rightEdge - (_margin + 92));
  if (data.minerArrivedAt.isNotEmpty) {
    page.text(data.minerArrivedAt, _margin + 37, y,
        size: _fs, style: 'normal');
  }
  if (data.minerCoyNo.isNotEmpty) {
    page.text(data.minerCoyNo, _margin + 93, y, size: _fs, style: 'normal');
  }
  y += _lineH;

  page.text('Waiting place location:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 36, y + 0.5, rightEdge - (_margin + 36));
  if (data.waitingPlaceLocation.isNotEmpty) {
    page.text(data.waitingPlaceLocation, _margin + 37, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  y = _yesNo(page,
      'Is the barricade erected at the entrance to the working place?',
      data.barricadeErected, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and remedial action:', y,
      2, data.barricadeDetails, rightEdge, contentWidth);
  y += 1;

  y = _yesNo(page, 'Did the Miner follow the waiting place procedure/',
      data.minerFollowedProcedure, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and remedial actions:', y,
      2, data.minerFollowedDetails, rightEdge, contentWidth);
  y += 1;

  y = _yesNo(page,
      'Did the Miner give permission to the COMP A to enter the workings/',
      data.permissionToCompA, y, rightEdge);
  y = _yesNo(page, 'Was the Miner in possession of a GDI?',
      data.minerPossessionGDI, y, rightEdge);

  page.text('If "YES" give a GDI NO', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 38, y + 0.5, rightEdge - _margin - 38);
  if (data.gdiNo.isNotEmpty) {
    page.text(data.gdiNo, _margin + 39, y, size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  y = _yesNo(page,
      'Was the blasting cable disconnected at the terminal box?',
      data.blastingCableDisconnected, y, rightEdge);

  y = _yesNo(page,
      'Did the Miner conduct the early entry examination according to the procedure?',
      data.earlyEntryExamination, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and remedial action:', y,
      2, data.earlyEntryDetails, rightEdge, contentWidth);
  y += 1;

  y = _yesNo(page,
      'Did the miner complete the safe declaration booklet according to the requirements?',
      data.safeDeclarationBooklet, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and remedial actions:', y,
      2, data.safeDeclarationDetails, rightEdge, contentWidth);
  y += 1;

  y = _yesNo(page,
      'Did the Miner test for flammable gases and CO according to the procedure?',
      data.flammableGasesTest, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and the remedial actions:',
      y, 3, data.flammableGasesDetails, rightEdge, contentWidth);
  y += 1;

  y = _yesNo(page,
      'Was entry examination equipment available and in order?',
      data.entryEquipmentAvailable, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and remedial actions:', y,
      3, data.entryEquipmentDetails, rightEdge, contentWidth);
  y += 1;

  y = _yesNo(page,
      'Does the Miner have a whirling hygrometer and Anemo meter?',
      data.hygrometerAndAnemo, y, rightEdge);
  _detailsLines(page, 'If "NO" give details and remedial actions:', y, 2,
      data.hygrometerDetails, rightEdge, contentWidth);

  drawInspectionFooter(page, pageNum: 'Page 58 of 84');
}

void _drawPage2(
    PageCtx page, EarlyShiftRecordFormData data, Uint8List? logo) {
  final contentWidth = page.pageWidth - _margin * 2;
  final rightEdge = _margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 5;

  y = _yesNo(page, 'Were the working places water down properly?',
      data.waterDownProperly, y, rightEdge);

  y = _yesNo(page,
      'Is drinking water available in close proximity to the working places?',
      data.drinkingWaterAvailable, y, rightEdge);
  y = _detailsLines(page, 'If "NO" give details and remedial action:', y,
      2, data.drinkingWaterDetails, rightEdge, contentWidth);
  y += 1;

  // Special instruction (with 2 blank dotted continuation lines)
  page.text('Special instruction given:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 40, y + 0.5, rightEdge - _margin - 40);
  if (data.specialInstruction.isNotEmpty) {
    final lines = page.splitTextToSize(data.specialInstruction,
        rightEdge - _margin - 41, _fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, _margin + 41, y, size: _fs, style: 'normal');
    }
  }
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH + 1;

  page.text('Additional remarks:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 32, y + 0.5, rightEdge - _margin - 32);
  if (data.additionalRemarks.isNotEmpty) {
    final lines = page.splitTextToSize(data.additionalRemarks,
        rightEdge - _margin - 33, _fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, _margin + 33, y, size: _fs, style: 'normal');
    }
  }
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH + 6;

  // Signature lines
  page.text('Shift Boss Signature:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 34, y + 0.5, 52);
  page.text('Date:', _margin + 92, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 102, y + 0.5, 30);
  _drawSig(page, data.shiftBossSignature, _margin + 35, y - 6, 50, 5);
  if (data.shiftBossSignatureDate.isNotEmpty) {
    page.text(data.shiftBossSignatureDate, _margin + 103, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 3;

  page.text('Miner Overseer Signature:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 42, y + 0.5, 44);
  page.text('Date:', _margin + 92, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 102, y + 0.5, 30);
  _drawSig(page, data.minerOverseerSignature, _margin + 43, y - 6, 42, 5);
  if (data.minerOverseerSignatureDate.isNotEmpty) {
    page.text(data.minerOverseerSignatureDate, _margin + 103, y,
        size: _fs, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 59 of 84');
}

double _yesNo(
    PageCtx page, String question, String val, double y, double rightEdge) {
  page.text(question, _margin, y, size: _fs, style: 'normal');
  page.text(val.isEmpty ? 'Yes/No' : val, rightEdge - 12, y,
      size: _fs, style: 'normal');
  return y + _lineH;
}

double _detailsLines(
    PageCtx page,
    String prefix,
    double y,
    int numLines,
    String val,
    double rightEdge,
    double contentWidth) {
  final prefixW = page.textWidth(prefix, _fs, 'normal') + 1;
  page.text(prefix, _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + prefixW, y + 0.5, rightEdge - _margin - prefixW);
  if (val.isNotEmpty) {
    final lines = page.splitTextToSize(
        val, rightEdge - _margin - prefixW - 1, _fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, _margin + prefixW + 1, y,
          size: _fs, style: 'normal');
    }
  }
  var cur = y;
  for (var i = 1; i < numLines; i++) {
    cur += _lineH;
    drawDotLine(page, _margin, cur + 0.5, contentWidth);
  }
  return cur + _lineH;
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
