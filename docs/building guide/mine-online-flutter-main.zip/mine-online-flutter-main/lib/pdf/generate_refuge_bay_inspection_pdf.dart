// Port of `generateRefugeBayInspectionPDF` in src/utils/pdfGenerator.ts (2838-3199).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffadd8e6);
const PdfColor _labelFill = PdfColor.fromInt(0xffdcdcdc);
const PdfColor _yellowFill = PdfColor.fromInt(0xfffff3cd);
const PdfColor _redFill = PdfColor.fromInt(0xffffdcdc);

const List<int> _itemNumbers = [
  1, 2, 3, 4, 5, 6, 7, 8, 9,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
  21, 22, 23, 24, 25, 26, 27, 28, 29,
];

const List<String> _itemLabels = [
  'Route Demarcated',
  'Refuge Bay Numbered',
  'Green Indication Light',
  'Door opens to inside & seal',
  'Back Wall Sealed',
  'Compressed Air Available',
  'Compressed Air Valve with 50mm steel column in Chamber',
  'Compressed Air Silencer',
  'Refuge Bay Ventilated',
  'Refuge Bay Pressurising',
  'Air Whistle',
  'Activator in the refuge bay',
  'Drinking Water Inside',
  'First Aid Box',
  'Emergency Procedures displayed inside Chamber',
  'Telephone Working',
  'Number Indicated on Phone List',
  'Radio Comms (transmittance between Control Room and Refuge Bay)',
  'Benches',
  'Toilet Facilities',
  'Illumination',
  'Free from Other Material',
  'Size of the refuge bay',
  'Ambient Temperature',
  'Emergency Escape Route Plan',
  'Oxygen Candles',
  'Entrance free from obstructions and combustible material',
  'Are the electrical cable well routed?',
];

const Map<int, String> _extraFieldMap = {
  16: 'Tel No.',
  18: 'Qty. seating available',
  25: 'Qty.',
};

Future<pw.Document> generateRefugeBayInspectionPdf(
    RefugeBayInspectionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Refuge Bay Inspection',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(PageCtx page, RefugeBayInspectionFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar (light blue)
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Refuge Bay Inspection Record'],
    ],
    style: const GridStyle(
      fontSize: 16,
      cellPaddingTop: 4,
      cellPaddingBottom: 4,
      minCellHeight: 11,
    ),
  );
  y += 3;

  // 3-row 4-col info table (label/value/label/value)
  final halfW = contentWidth / 2;
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(
          cellWidth: halfW * 0.35, fontStyle: 'bold', fillColor: _labelFill),
      GridColumn(cellWidth: halfW * 0.65),
      GridColumn(
          cellWidth: halfW * 0.35, fontStyle: 'bold', fillColor: _labelFill),
      GridColumn(cellWidth: halfW * 0.65),
    ],
    body: [
      ['Shaft:', data.shaft, 'Date:', data.date],
      ['Observer:', data.observer, 'Refuge Bay No.:', data.refugeBayNo],
      ['Mine Overseer:', data.mineOverseer, 'Section:', data.section],
    ],
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
  y += 3;

  // Checklist table — alternating row fill isn't supported per-row, so we
  // draw it as a flat table with column widths matching the source.
  final checkRows = <List<String>>[];
  for (var i = 0; i < data.items.length && i < _itemLabels.length; i++) {
    final item = data.items[i];
    var location = _itemLabels[i];
    if (_extraFieldMap.containsKey(i) && item.extraField.isNotEmpty) {
      location += '\n${_extraFieldMap[i]}: ${item.extraField}';
    }
    checkRows.add([
      '${_itemNumbers[i]}',
      location,
      item.consequenceClassification,
      item.yes ? '✓' : '',
      item.no ? '✓' : '',
      item.remarks,
    ]);
  }
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 10, halign: 'center'),
      const GridColumn(cellWidth: 80),
      const GridColumn(cellWidth: 28, halign: 'center'),
      const GridColumn(cellWidth: 12, halign: 'center'),
      const GridColumn(cellWidth: 12, halign: 'center'),
      GridColumn(cellWidth: contentWidth - 142),
    ],
    head: const [
      GridHeader(text: 'No.', fillColor: _titleBg, fontStyle: 'bold'),
      GridHeader(
          text: 'Location',
          fillColor: _titleBg,
          fontStyle: 'bold',
          halign: 'left'),
      GridHeader(
          text: '*Consequence\nClassification',
          fillColor: _titleBg,
          fontStyle: 'bold'),
      GridHeader(text: 'Yes', fillColor: _titleBg, fontStyle: 'bold'),
      GridHeader(text: 'No', fillColor: _titleBg, fontStyle: 'bold'),
      GridHeader(
          text: 'Remarks',
          fillColor: _titleBg,
          fontStyle: 'bold',
          halign: 'left'),
    ],
    body: checkRows,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 4.5,
    ),
  );
  y += 3;

  // Legend row
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 44, fontStyle: 'bold', fillColor: _labelFill),
      const GridColumn(cellWidth: 37),
      const GridColumn(cellWidth: 33),
      const GridColumn(cellWidth: 37),
      GridColumn(cellWidth: contentWidth - 151),
    ],
    body: const [
      [
        '*Consequence Classification:',
        '5 = Catastrophic (Fix Immediately)',
        '4 = Major (Fix same Shift)',
        '3 = Serious (Fix within seven days)',
        '2 = Minor (Fix ASAP)',
      ],
    ],
    style: const GridStyle(
      fontSize: 6.5,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 5,
    ),
  );
  y += 3;

  // Life sustainable row (3 cols)
  final isNo = data.isLifeSustainable == 'No';
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(
          cellWidth: 100, fontStyle: 'bold', fillColor: _labelFill),
      GridColumn(
          cellWidth: 43,
          halign: 'center',
          fontStyle: 'bold',
          fillColor: isNo ? _redFill : PdfColors.white),
      GridColumn(cellWidth: contentWidth - 143, halign: 'center'),
    ],
    body: [
      [
        'Is this Refuge Bay life sustainable?',
        data.isLifeSustainable.isEmpty ? 'YES / NO' : data.isLifeSustainable,
        isNo ? '(Highlighted in red – NOT life sustainable)' : '',
      ],
    ],
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
  y += 3;

  // Instructions table
  final instrRows = data.instructions
      .map((i) => [i.instruction, i.completionDate])
      .toList();
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth - 40),
      const GridColumn(cellWidth: 40),
    ],
    head: const [
      GridHeader(
          text: 'Instructions',
          fillColor: _labelFill,
          fontStyle: 'bold',
          halign: 'left'),
      GridHeader(
          text: 'Completion Date',
          fillColor: _labelFill,
          fontStyle: 'bold',
          halign: 'left'),
    ],
    body: instrRows,
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 7,
    ),
  );
  y += 3;

  // "Not Life Sustainable if..." box
  const bullets = [
    'No compressed air available in chamber',
    'Door does not open to inside or does not seal',
    'Back wall not sealed',
    'Refuge Bay not pressurising',
    'No drinking water inside',
    'No telephone working or radio comms to control room',
  ];
  final leftBullets = bullets.take(3).map((b) => '•  $b').join('\n');
  final rightBullets = bullets.skip(3).map((b) => '•  $b').join('\n');
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'left', fillColor: _yellowFill),
    ],
    body: const [
      ['Refuge Bay not Life Sustainable if the following occurs:'],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 1,
      minCellHeight: 5,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth / 2),
      GridColumn(cellWidth: contentWidth / 2),
    ],
    body: [
      [leftBullets, rightBullets],
    ],
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1,
      cellPaddingBottom: 2,
      minCellHeight: 14,
    ),
  );
  y += 8;

  // Signature boxes (Observer left, Mine Overseer right)
  const sigW = 72.0;
  const sigBoxH = 14.0;
  const dateBoxW = 32.0;
  const dateLabelW = 10.0;
  final pageWidth = page.pageWidth;

  // Observer
  page.text('Observer:', margin, y, size: 8, style: 'bold');
  page.rectStroke(margin, y + 2, sigW, sigBoxH);
  _drawSig(page, '', margin + 1, y + 3, sigW - 2, sigBoxH - 2);
  page.text('Signature', margin + 2, y + 2 + 5, size: 7, style: 'normal');
  page.text('Date:', margin + sigW + 4, y + 2 + 5, size: 8, style: 'normal');
  page.rectStroke(margin + sigW + 4 + dateLabelW, y + 2, dateBoxW, sigBoxH);
  if (data.observerDate.isNotEmpty) {
    page.text(data.observerDate, margin + sigW + 4 + dateLabelW + 1,
        y + 2 + sigBoxH / 2 + 1,
        size: 8, style: 'normal');
  }

  // Mine Overseer (right)
  final rightSigX = pageWidth - margin - dateBoxW - dateLabelW - 4 - sigW;
  page.text('Mine Overseer:', rightSigX, y, size: 8, style: 'bold');
  page.rectStroke(rightSigX, y + 2, sigW, sigBoxH);
  page.text('Signature', rightSigX + 2, y + 2 + 5, size: 7, style: 'normal');
  page.text('Date:', rightSigX + sigW + 4, y + 2 + 5,
      size: 8, style: 'normal');
  page.rectStroke(rightSigX + sigW + 4 + dateLabelW, y + 2, dateBoxW, sigBoxH);
  if (data.mineOverseerDate.isNotEmpty) {
    page.text(data.mineOverseerDate,
        rightSigX + sigW + 4 + dateLabelW + 1, y + 2 + sigBoxH / 2 + 1,
        size: 8, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 64 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
