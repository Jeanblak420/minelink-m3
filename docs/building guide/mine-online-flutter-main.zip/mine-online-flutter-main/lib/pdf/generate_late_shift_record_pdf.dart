// Port of `generateLateShiftRecordPDF` in src/utils/pdfGenerator.ts (2059-2348).

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const double _margin = 10.5;
const double _fs = 8;
const double _lineH = 5.5;
const double _yesNoX = _margin + 118;

Future<pw.Document> generateLateShiftRecordPdf(
    LateShiftRecordFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildMultiPageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Late Shift Record',
    pages: [
      (page) => _drawPage1(page, formData, logoBytes),
      (page) => _drawPage2(page, formData, logoBytes),
    ],
  );
}

void _drawPage1(
    PageCtx page, LateShiftRecordFormData data, Uint8List? logo) {
  final contentWidth = page.pageWidth - _margin * 2;
  final rightEdge = _margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar (grey fill, 2 lines: title + subtitle)
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _greyBg),
    ],
    body: const [
      ['Late Shift Record'],
      ['(A Shift Boss must conduct a late shift once a week)'],
    ],
    style: const GridStyle(fontSize: 18, minCellHeight: 11),
  );
  y += 6;

  // Section / Strike / Date
  page.text('Section:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 14, y + 0.5, 54);
  page.text('Strike:', _margin + 74, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 84, y + 0.5, 36);
  page.text('Date:', _margin + 126, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 135, y + 0.5, rightEdge - (_margin + 135));
  if (data.section.isNotEmpty) {
    page.text(data.section, _margin + 15, y, size: _fs, style: 'normal');
  }
  if (data.strike.isNotEmpty) {
    page.text(data.strike, _margin + 85, y, size: _fs, style: 'normal');
  }
  if (data.date.isNotEmpty) {
    page.text(data.date, _margin + 136, y, size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  page.text('Miner in charge coy no:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 40, y + 0.5, rightEdge - _margin - 40);
  if (data.minerInChargeCoyNo.isNotEmpty) {
    page.text(data.minerInChargeCoyNo, _margin + 41, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  y = _yesNo(page, 'Charges correctly prepared?',
      data.chargesCorrectlyPrepared, y);
  y = _detailsLines(page, 'If "NO" give details and remedial actions:', y,
      2, data.chargesDetails, rightEdge, contentWidth);
  y += 3;

  page.text('Charging up development end no:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 54, y + 0.5, 34);
  page.text('Vent holing no:', _margin + 92, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 110, y + 0.5, rightEdge - (_margin + 110));
  if (data.chargingUpDevEndNo.isNotEmpty) {
    page.text(data.chargingUpDevEndNo, _margin + 55, y,
        size: _fs, style: 'normal');
  }
  if (data.ventHolingNo.isNotEmpty) {
    page.text(data.ventHolingNo, _margin + 111, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  y = _yesNo(page, 'Explosive correctly transported to the face?',
      data.explosiveCorrectlyTransported, y);

  page.text('Tested for flammable gas and CO gas with a GDI? GDI No:',
      _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 93, y + 0.5, _yesNoX - (_margin + 93) - 4);
  page.text(
      data.testedForFlammableGas.isEmpty ? 'Yes/No' : data.testedForFlammableGas,
      _yesNoX,
      y,
      size: _fs,
      style: 'normal');
  if (data.gdiNo.isNotEmpty) {
    page.text(data.gdiNo, _margin + 94, y, size: _fs, style: 'normal');
  }
  y += _lineH;

  y = _yesNo(page, 'Was charging done under direct supervision of Miner?',
      data.chargingUnderDirectSupervision, y);

  page.text('Type of explosives used:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 40, y + 0.5, rightEdge - _margin - 40);
  if (data.typeOfExplosivesUsed.isNotEmpty) {
    page.text(data.typeOfExplosivesUsed, _margin + 41, y,
        size: _fs, style: 'normal');
  }
  y += _lineH;

  page.text('Type of fuse used:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 30, y + 0.5, 56);
  page.text('Length:', _margin + 92, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 102, y + 0.5, rightEdge - (_margin + 102));
  if (data.typeOfFuseUsed.isNotEmpty) {
    page.text(data.typeOfFuseUsed, _margin + 31, y,
        size: _fs, style: 'normal');
  }
  if (data.fuseLength.isNotEmpty) {
    page.text(data.fuseLength, _margin + 103, y,
        size: _fs, style: 'normal');
  }
  y += _lineH;

  page.text('Amount of fuses used:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 36, y + 0.5, rightEdge - _margin - 36);
  if (data.amountOfFusesUsed.isNotEmpty) {
    page.text(data.amountOfFusesUsed, _margin + 37, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  y = _yesNo(
      page, 'Where holes dislodged correctly?', data.holesDislodgedCorrectly, y);
  y = _detailsLines(page, 'If "NO" give details and remedial action:', y, 2,
      data.holesDislodgedDetails, rightEdge, contentWidth);
  y += 3;

  page.text('Length of drill holes:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 33, y + 0.5, 54);
  page.text('Length of the blow pipe:', _margin + 93, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 120, y + 0.5, rightEdge - (_margin + 120));
  if (data.lengthOfDrillHoles.isNotEmpty) {
    page.text(data.lengthOfDrillHoles, _margin + 34, y,
        size: _fs, style: 'normal');
  }
  if (data.lengthOfBlowPipe.isNotEmpty) {
    page.text(data.lengthOfBlowPipe, _margin + 121, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  y = _yesNo(page, 'Blasting cable installed to standard?',
      data.blastingCableToStandard, y);
  y = _detailsLines(page, 'If "NO" give details and remedial actions:', y,
      2, data.blastingCableDetails, rightEdge, contentWidth);
  y += 1;

  _yesNo(page, 'Circuit tested?', data.circuitTested, y);

  drawInspectionFooter(page, pageNum: 'Page 60 of 84');
}

void _drawPage2(
    PageCtx page, LateShiftRecordFormData data, Uint8List? logo) {
  final contentWidth = page.pageWidth - _margin * 2;
  final rightEdge = _margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 6;

  y = _yesNo(page, 'Blasting cable connected correctly to terminal box?',
      data.blastingCableConnectedToTerminalBox, y);
  y = _detailsLines(page, 'If "NO" give details and remedial action:', y, 2,
      data.blastingCableTerminalDetails, rightEdge, contentWidth);
  y += 4;

  y = _yesNo(page, 'Distribution of old explosives observed?',
      data.distributionOfOldExplosivesObserved, y);
  y = _yesNo(page, 'Distribution of old explosives discussed?',
      data.distributionOfOldExplosivesDiscussed, y);

  // Inline 2-question row
  page.text('Working place barricade in position?', _margin, y,
      size: _fs, style: 'normal');
  page.text(
      data.workingPlaceBarricadeInPosition.isEmpty
          ? 'Yes/No'
          : data.workingPlaceBarricadeInPosition,
      _margin + 64,
      y,
      size: _fs,
      style: 'normal');
  page.text('Explosive boxes locked?', _margin + 85, y,
      size: _fs, style: 'normal');
  page.text(
      data.explosiveBoxesLocked.isEmpty ? 'Yes/No' : data.explosiveBoxesLocked,
      _margin + 120,
      y,
      size: _fs,
      style: 'normal');
  y += _lineH;

  y = _detailsLines(page, 'If "NO" give details and remedial actions:', y,
      3, data.barricadeExplosiveDetails, rightEdge, contentWidth);
  y += 3;

  y = _yesNo(page, 'Were ID cards correctly issued?',
      data.idCardsCorrectlyIssued, y);
  y = _yesNo(
      page, 'Air and water hoses closed?', data.airAndWaterHosesClosed, y);
  y = _yesNo(page, 'Any incident /injuries reported?',
      data.anyIncidentInjuriesReported, y);

  page.text('Arrived on surface at:', _margin, y,
      size: _fs, style: 'normal');
  final ampmX = _margin + 108;
  page.text('am/pm', ampmX, y, size: _fs, style: 'normal');
  drawDotLine(page, ampmX + 10, y + 0.5, rightEdge - ampmX - 10);
  if (data.arrivedOnSurfaceAt.isNotEmpty) {
    page.text(data.arrivedOnSurfaceAt, ampmX + 11, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 1;

  page.text('Special instructions given:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 44, y + 0.5, rightEdge - _margin - 44);
  if (data.specialInstructionsGiven.isNotEmpty) {
    final lines = page.splitTextToSize(data.specialInstructionsGiven,
        rightEdge - _margin - 45, _fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, _margin + 45, y, size: _fs, style: 'normal');
    }
  }
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH + 3;

  page.text('Additional remarks:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 32, y + 0.5, rightEdge - _margin - 32);
  if (data.additionalRemarks.isNotEmpty) {
    final lines = page.splitTextToSize(data.additionalRemarks,
        rightEdge - _margin - 33, _fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, _margin + 33, y, size: _fs, style: 'normal');
    }
  }
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH;
  drawDotLine(page, _margin, y + 0.5, contentWidth);
  y += _lineH + 10;

  page.text('Shift Boss Signature:', _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 36, y + 0.5, 55);
  page.text('Date:', _margin + 99, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 108, y + 0.5, 28);
  _drawSig(page, data.shiftBossSignature, _margin + 37, y - 6, 53, 5);
  if (data.shiftBossSignatureDate.isNotEmpty) {
    page.text(data.shiftBossSignatureDate, _margin + 109, y,
        size: _fs, style: 'normal');
  }
  y += _lineH + 7;

  page.text('Miner Overseer Signature:', _margin, y,
      size: _fs, style: 'normal');
  drawDotLine(page, _margin + 44, y + 0.5, 47);
  page.text('Date:', _margin + 99, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + 108, y + 0.5, 28);
  _drawSig(page, data.minerOverseerSignature, _margin + 45, y - 6, 45, 5);
  if (data.minerOverseerSignatureDate.isNotEmpty) {
    page.text(data.minerOverseerSignatureDate, _margin + 109, y,
        size: _fs, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 61 of 84');
}

const PdfColor _greyBg = PdfColor.fromInt(0xffc8c8c8);

double _yesNo(PageCtx page, String question, String val, double y) {
  page.text(question, _margin, y, size: _fs, style: 'normal');
  page.text(val.isEmpty ? 'Yes/No' : val, _yesNoX, y,
      size: _fs, style: 'normal');
  return y + _lineH;
}

double _detailsLines(
    PageCtx page,
    String prefix,
    double y,
    int numLines,
    String val,
    double rightEdge,
    double contentWidth) {
  final prefixW = page.textWidth(prefix, _fs, 'normal') + 1;
  page.text(prefix, _margin, y, size: _fs, style: 'normal');
  drawDotLine(page, _margin + prefixW, y + 0.5, rightEdge - _margin - prefixW);
  if (val.isNotEmpty) {
    final lines = page.splitTextToSize(
        val, rightEdge - _margin - prefixW - 1, _fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, _margin + prefixW + 1, y,
          size: _fs, style: 'normal');
    }
  }
  var cur = y;
  for (var i = 1; i < numLines; i++) {
    cur += _lineH;
    drawDotLine(page, _margin, cur + 0.5, contentWidth);
  }
  return cur + _lineH;
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
