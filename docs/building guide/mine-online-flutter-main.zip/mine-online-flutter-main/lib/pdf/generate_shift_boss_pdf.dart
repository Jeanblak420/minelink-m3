// Line-for-line port of `generateShiftBossPDF` in
// src/utils/pdfGenerator.ts (lines 93-422). Coordinates pasted as mm exactly.

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'pdf_runtime.dart';

Future<pw.Document> generateShiftBossPdf(ShiftBossFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');

  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Shift Boss Appointment',
    draw: (page) => _drawShiftBoss(page, formData, logoBytes),
  );
}

void _drawShiftBoss(
  PageCtx page,
  ShiftBossFormData formData,
  Uint8List? logoBytes,
) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final pageWidth = page.pageWidth;
  final pageHeight = page.pageHeight;

  // === Header block ===
  const headerTop = 9.1;
  const headerHeight = 33.1;
  const logoColWidth = 37.0;
  const labelColWidth = 16.2;
  const valueColWidth = 19.1;
  final centerColWidth = contentWidth - logoColWidth - labelColWidth - valueColWidth;
  final centerX = margin + logoColWidth + centerColWidth / 2;
  final headerRightX = margin + logoColWidth + centerColWidth;

  page.setLineWidth(0.35);
  page.setDrawColor(borderColor);
  page.rectStroke(margin, headerTop, contentWidth, headerHeight);
  page.line(margin + logoColWidth, headerTop, margin + logoColWidth,
      headerTop + headerHeight);
  page.line(headerRightX, headerTop, headerRightX, headerTop + headerHeight);
  page.line(headerRightX + labelColWidth, headerTop,
      headerRightX + labelColWidth, headerTop + headerHeight);

  final metaRowHeight = headerHeight / 3;
  page.line(headerRightX, headerTop + metaRowHeight, margin + contentWidth,
      headerTop + metaRowHeight);
  page.line(headerRightX, headerTop + metaRowHeight * 2, margin + contentWidth,
      headerTop + metaRowHeight * 2);

  if (logoBytes != null) {
    final logo = page.imageFromBytes(logoBytes);
    page.drawImage(logo, margin + 1.9, headerTop + 2.4, logoColWidth - 4, 18.6);
  }

  page.text('BLACK ROCK MINE OPERATIONS', margin + logoColWidth / 2,
      headerTop + headerHeight - 5.8,
      size: 6, style: 'normal', align: 'center');

  page.text('ASSMANG (PTY) LIMITED', centerX, headerTop + 5.9,
      size: 15.8, style: 'bold', align: 'center');
  page.text('FORM', centerX, headerTop + 13.3,
      size: 10.2, style: 'bold', align: 'center');
  page.text('Logbook - Shift Boss', centerX, headerTop + 20.4,
      size: 10.8, style: 'boldItalic', align: 'center');
  page.text('Document No: FOR-MIN-PROD-GEN-U-2518', centerX, headerTop + 27.7,
      size: 9.1, style: 'bold', align: 'center');

  // Right-hand meta-label column (three rows × multi-line labels)
  page.text('Revision', headerRightX + 1.2, headerTop + 3.1,
      size: 7.9, style: 'bold');
  page.text('No.:', headerRightX + 1.2, headerTop + 6.1,
      size: 7.9, style: 'bold');
  page.text('Next', headerRightX + 1.2, headerTop + metaRowHeight + 2.6,
      size: 7.9, style: 'bold');
  page.text('Revision', headerRightX + 1.2, headerTop + metaRowHeight + 5.6,
      size: 7.9, style: 'bold');
  page.text('Date:', headerRightX + 1.2, headerTop + metaRowHeight + 8.6,
      size: 7.9, style: 'bold');
  page.text('Effective', headerRightX + 1.2,
      headerTop + metaRowHeight * 2 + 3.1,
      size: 7.9, style: 'bold');
  page.text('Date:', headerRightX + 1.2, headerTop + metaRowHeight * 2 + 6.1,
      size: 7.9, style: 'bold');

  // Right-hand meta-value column
  page.text('6.0', margin + contentWidth - 1.8, headerTop + 3.6,
      size: 7.8, style: 'normal', align: 'right');
  page.text(formData.nextRevisionDate, margin + contentWidth - 1.8,
      headerTop + metaRowHeight + 7.2,
      size: 7.8, style: 'normal', align: 'right');
  page.text(formData.effectiveDate, margin + contentWidth - 1.8,
      headerTop + metaRowHeight * 2 + 7.1,
      size: 7.8, style: 'normal', align: 'right');

  // === Appointment title bar ===
  const appointmentBarTop = 46.7;
  const infoTableTop = 57.8;
  const appointmentTextY = 84.7;
  const workplaceTableTop = 88.2;
  const dutiesIntroY = 138.5;
  const responsibilitiesIntroY = 173.6;
  const signatureTableTop = 209.8;
  const footerLineY = 248.0;
  const labelWidth = 50.0;

  page.rectFillStroke(margin, appointmentBarTop, contentWidth, 8.9, darkFill);
  final titleLines = page.splitTextToSize(
    'Appointment as a SHIFT BOSS for Black Rock Mine Operations in terms of Minerals Regulation 2.15.1, Read with Section 7(4) of the Mine Health and Safety Act',
    contentWidth - 10,
    8.1,
    'bold',
  );
  for (var i = 0; i < titleLines.length; i++) {
    page.text(titleLines[i], pageWidth / 2, appointmentBarTop + 3.8 + i * 3.0,
        size: 8.1, style: 'bold', align: 'center', color: PdfColors.white);
  }

  drawTwoColumnTable(
    page,
    margin: margin,
    contentWidth: contentWidth,
    startY: infoTableTop,
    rows: [
      ['Title', formData.title.isEmpty ? 'Mr/Mrs/Miss' : formData.title],
      ['Name', formData.name],
      ['Identity number', formData.identityNumber],
      ['Company number', formData.companyNumber],
      ['Shaft', formData.shaft],
    ],
    rowHeight: 4.48,
    labelWidth: labelWidth,
    fontSize: 7.2,
  );

  page.text(
    'You are hereby appointed as a Shift Boss to take charge of the following sections of the mine:',
    margin,
    appointmentTextY,
    size: 7.05,
    style: 'normal',
  );

  drawTwoColumnTable(
    page,
    margin: margin,
    contentWidth: contentWidth,
    startY: workplaceTableTop,
    rows: [
      ['Stopes/Working places', formData.workplaces.stopes],
      ['Development ends / Vent Holings', formData.workplaces.developmentEnds],
      ['Declines', formData.workplaces.declines],
      ['Load and Haul / Roadway', formData.workplaces.loadAndHaul],
      ['Travelling way', formData.workplaces.travellingWay],
      ['Refuge Bay', formData.workplaces.refugeBay],
      ['Store', formData.workplaces.store],
      ['Waiting place', formData.workplaces.waitingPlace],
      ['Conveyor belts / Tipping area', formData.workplaces.conveyorBelts],
      ['Any other workplaces specified', formData.workplaces.otherWorkplaces],
    ],
    rowHeight: 4.58,
    labelWidth: labelWidth,
    fontSize: 7.0,
  );

  page.text(
    'Within your geographic area of responsibility, your attention is drawn to, but not limited to, the following specific legal duties, functions and activities;',
    margin,
    dutiesIntroY,
    size: 6.4,
    style: 'normal',
  );

  drawBulletedParagraphs(
    page,
    margin: margin,
    contentWidth: contentWidth,
    paragraphs: const [
      'In terms of Section 7(4) of the Mine Health and Safety Act, 29 of 1996 you are responsible for compliance with the following functions and provisions which are entrusted to the manager by the MHS Act: Sections 5(1) and (2), Sections 6, 7(1), Sections 9, 10, 11, 23(2) and Section 26 and 33.',
      'In terms of the Mine Health and Safety Act, 29 of 1996 Regulations you are responsible for compliance with the following functions and provisions: Chapters 4, 5 and 8.',
      'In terms of the Minerals Act, 51 of 1991 Regulations you are responsible for compliance with the following functions and provisions: Regulations 2.10.2, 2.10.4, 2.10.5, 2.15.4 to 2.15.11 including 4.7.1; Minerals Act Chapter 3 - General Provisions; Minerals Act Chapter 4 - Workmen; Minerals Act Chapter 10 - Ventilation, Gases and Dust; MHSA Regulations Chapter 13 - Outlets, Ladder ways and Travelling ways read with Minerals Act Chapter 6 (Outlets, Ladder ways and Travelling ways); MHSA Regulations Chapter 14 - Protection of the Surface and in Workings, read with Minerals Act Chapter 5 (Surface Protection and Minerals Act Chapter 7 (Protection in Workings); and MHSA Regulations Chapter 16 - Rescue, First Aid Emergency Preparedness and Response, read with Minerals Act Chapter 24 (First Aid and Rescue Brigades).',
    ],
    startY: dutiesIntroY + 5.5,
    fontSize: 6.35,
    lineHeight: 3.23,
  );

  page.text(
    'In addition to the regulations pertaining to the appointment of Shift Boss you will also be responsible for / to:',
    margin,
    responsibilitiesIntroY,
    size: 6.4,
    style: 'normal',
  );

  drawBulletedParagraphs(
    page,
    margin: margin,
    contentWidth: contentWidth,
    paragraphs: const [
      'The democratic election and appointment of Health and Safety Representatives for each working place.',
      'The maintenance of a high standard of fire prevention and emergency preparedness and the regular monitoring by conducting emergency drills.',
      'Ensure that you and your supervisors under your control are in possession of a valid first aid certificates.',
      "Wherever a miner's area of responsibility changes, you must ensure that s/he is re-appointed on the date of change.",
      'Manage and control of all contractors / service department employees in your area of responsibility.',
      'Identify, control and monitor risk exposure by conducting and recording planned inspections.',
      'Ensuring that all persons under your control are competent in executing the work they are responsible for and are trained and familiar with all procedures and standards pertaining to the work undertaken and to monitor and measure compliance by conducting regular planned task observations',
    ],
    startY: responsibilitiesIntroY + 5.5,
    fontSize: 6.35,
    lineHeight: 3.42,
  );

  _drawSignatureTable(
    page,
    margin: margin,
    contentWidth: contentWidth,
    startY: signatureTableTop,
    sigs: formData.signatures,
  );

  page.setLineWidth(0.4);
  page.line(margin, footerLineY, pageWidth - margin, footerLineY);
  page.text('NOTE:', margin, footerLineY + 3.2, size: 6.2, style: 'bold');
  page.text(
    'Uncontrolled Copy - This document is only valid if same as Master Document on DMMA',
    margin + 9.5,
    footerLineY + 3.2,
    size: 6.2,
    style: 'normal',
  );
  page.text('Page 13 of 84', pageWidth - margin, footerLineY + 3.2,
      size: 6.2, style: 'normal', align: 'right');

  final popiLines = page.splitTextToSize(
    'POPI ACT: BRMO guarantees to keep and use your Information only for the purpose it was collected for. When that purpose is no longer effective, the Information will be destroyed beyond reconstruction, except when there is a statutory or regulatory obligation that requires BRMO to keep your Information for a specific period that is longer than the purpose for which it was received.',
    contentWidth - 8,
    5.15,
    'italic',
  );
  var popiY = footerLineY + 7.0;
  for (final line in popiLines) {
    page.text(line, pageWidth / 2, popiY,
        size: 5.15, style: 'italic', align: 'center');
    popiY += 2.0;
  }

  page.text('©Assmang (Pty) Limited, P O Box 187, Santoy, 8491',
      pageWidth / 2, pageHeight - 4.0,
      size: 6.15, style: 'normal', align: 'center');
}

void _drawSignatureTable(
  PageCtx page, {
  required double margin,
  required double contentWidth,
  required double startY,
  required ShiftBossSignatures sigs,
}) {
  final colWidths = <double>[45, 62.5, contentWidth - 107.5];
  const headerHeight = 5.6;
  final rowHeights = <double>[8.3, 8.3, 8.5];
  final rowTitles = ['Shift Boss', 'Mine Overseer', 'Mine Manager'];
  final rowDates = [sigs.shiftBossDate, sigs.mineOverseerDate, sigs.mineManagerDate];
  final rowSignatureUrls = [
    sigs.shiftBossSignature,
    sigs.mineOverseerSignature,
    sigs.mineManagerSignature,
  ];
  final totalHeight = headerHeight + rowHeights.reduce((a, b) => a + b);

  page.rectFillStroke(margin, startY, contentWidth, headerHeight, lightFill);
  page.rectStroke(margin, startY, contentWidth, totalHeight);

  var runningX = margin;
  for (var i = 0; i < colWidths.length; i++) {
    if (i > 0) page.line(runningX, startY, runningX, startY + totalHeight);
    runningX += colWidths[i];
  }

  final headerLabels = ['Title', 'Date', 'Signature'];
  var headerX = margin;
  for (var i = 0; i < headerLabels.length; i++) {
    page.text(headerLabels[i], headerX + colWidths[i] / 2,
        startY + headerHeight - 1.7,
        size: 7.3, style: 'bold', align: 'center');
    headerX += colWidths[i];
  }

  var rowY = startY + headerHeight;
  for (var i = 0; i < rowHeights.length; i++) {
    final h = rowHeights[i];
    page.line(margin, rowY, margin + contentWidth, rowY);
    page.rectFillStroke(margin, rowY, colWidths[0], h, lightFill);
    final textY = rowY + h - 2.2;
    page.text(rowTitles[i], margin + 2.1, textY, size: 7.1, style: 'bold');
    page.text(rowDates[i], margin + colWidths[0] + 2.1, textY,
        size: 7.1, style: 'normal');

    drawFittedSignature(
      page,
      rowSignatureUrls[i],
      cellX: margin + colWidths[0] + colWidths[1] + 2.2,
      cellY: rowY + 1.3,
      cellW: colWidths[2] - 4.4,
      cellH: h - 2.6,
    );
    rowY += h;
  }
  page.line(margin, rowY, margin + contentWidth, rowY);
}
