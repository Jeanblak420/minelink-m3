// Port of `generateSpecialBriefInstructionRegisterPDF` in src/utils/pdfGenerator.ts (4240-4270).

import 'dart:math' as math;

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _headFill = PdfColor.fromInt(0xffe6e6e6);

Future<pw.Document> generateSpecialBriefInstructionRegisterPdf(
    SpecialBriefInstructionRegisterFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Special Brief Instruction Register',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(
    PageCtx page, SpecialBriefInstructionRegisterFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Special Brief / Instruction Register'],
    ],
    style: const GridStyle(
      fontSize: 13.2,
      cellPaddingTop: 2.1,
      cellPaddingBottom: 2.1,
      minCellHeight: 9,
    ),
  );
  y += 3;

  final info = page.splitTextToSize(
      'Any management brief, message or instruction must be communicated to employees. A proper register must be kept in this regard. (In some cases persons must sign to the effect.)',
      contentWidth,
      8,
      'normal');
  for (final line in info) {
    page.text(line, margin, y, size: 8, style: 'normal');
    y += 3.4;
  }
  y += 1.4;

  // Pad to at least 25 rows
  final totalRows = math.max(data.entries.length, 25);
  final body = <List<String>>[];
  for (var i = 0; i < totalRows; i++) {
    final e = i < data.entries.length ? data.entries[i] : null;
    body.add([e?.title ?? '', e?.communicatedTo ?? '']);
  }

  drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth / 2),
      GridColumn(cellWidth: contentWidth / 2),
    ],
    head: const [
      GridHeader(
          text: 'Title', fillColor: _headFill, fontStyle: 'bold'),
      GridHeader(
          text: 'Communicated to', fillColor: _headFill, fontStyle: 'bold'),
    ],
    body: body,
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 6.3,
    ),
  );

  drawInspectionFooter(page, pageNum: 'Page 78 of 84');
}
