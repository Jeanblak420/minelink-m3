// SP4.5: appends an admin's form overlay (added fields + pages) to a bespoke
// form's generated PDF as an "Additional information" section. No-op when the
// form has no overlay content — so un-edited forms' PDFs are unchanged.
//
// Self-contained (own kv/signature/table block helpers) so it never disturbs the
// existing bespoke or custom-form PDF generators.

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/custom_form_template.dart';
import '../models/form_overlay.dart';
import '../utils/form_overlay_data.dart';
import 'pdf_runtime.dart' show decodeSignatureBytes;

/// Appends the overlay appendix to [doc] for [formType], reading values from
/// payload['overlay']. Loads the overlay itself; no-op when empty/none.
Future<void> appendOverlayToPdf(
  pw.Document doc,
  String formType,
  Map<String, dynamic> payload,
) async {
  final FormOverlay? overlay = await loadFormOverlay(formType);
  if (overlay == null || !overlay.hasContent) return;
  final values = overlayValuesFromPayload(payload);

  final base = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Regular.ttf'),
  );
  final bold = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Bold.ttf'),
  );
  final theme = pw.ThemeData.withFont(base: base, bold: bold);

  final blocks = <pw.Widget>[
    pw.Text(
      'Additional information',
      style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
    ),
    pw.SizedBox(height: 8),
  ];

  blocks.addAll(_fieldBlocks(overlay.addedFields, values));
  for (final page in overlay.addedPages) {
    blocks.add(
      pw.Padding(
        padding: const pw.EdgeInsets.only(top: 12, bottom: 6),
        child: pw.Text(
          page.title.isEmpty ? 'Additional page' : page.title,
          style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold),
        ),
      ),
    );
    blocks.addAll(_fieldBlocks(page.fields, values));
  }

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.letter,
      theme: theme,
      margin: const pw.EdgeInsets.all(36),
      build: (ctx) => blocks,
    ),
  );
}

List<pw.Widget> _fieldBlocks(
  List<FormFieldDef> fields,
  Map<String, dynamic> values,
) {
  final out = <pw.Widget>[];
  for (final f in fields) {
    switch (f.type) {
      case FormFieldType.section:
        out.add(
          pw.Padding(
            padding: const pw.EdgeInsets.only(top: 10, bottom: 4),
            child: pw.Text(
              f.label,
              style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold),
            ),
          ),
        );
        break;
      case FormFieldType.signature:
        out.add(_signatureBlock(f.label, values[f.key]));
        break;
      case FormFieldType.table:
        out.add(_tableBlock(f, values[f.key]));
        break;
      case FormFieldType.boolean:
        out.add(_kvRow(f.label, values[f.key] == true ? 'Yes' : 'No'));
        break;
      default:
        out.add(_kvRow(f.label, _valueString(values[f.key])));
    }
  }
  return out;
}

String _valueString(dynamic v) {
  if (v == null) return '—';
  if (v is String) return v.trim().isEmpty ? '—' : v;
  return '$v';
}

pw.Widget _kvRow(String label, String value) => pw.Padding(
  padding: const pw.EdgeInsets.symmetric(vertical: 3),
  child: pw.Row(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [
      pw.SizedBox(
        width: 150,
        child: pw.Text(
          label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
        ),
      ),
      pw.SizedBox(width: 8),
      pw.Expanded(
        child: pw.Text(value, style: const pw.TextStyle(fontSize: 10)),
      ),
    ],
  ),
);

pw.Widget _signatureBlock(String label, dynamic value) {
  final bytes = decodeSignatureBytes(value is String ? value : '');
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 4),
    child: pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
        ),
        pw.SizedBox(height: 4),
        if (bytes == null)
          pw.Text('—', style: const pw.TextStyle(fontSize: 10))
        else
          pw.Container(
            height: 60,
            alignment: pw.Alignment.centerLeft,
            child: pw.Image(
              pw.MemoryImage(bytes),
              height: 60,
              fit: pw.BoxFit.contain,
            ),
          ),
      ],
    ),
  );
}

pw.Widget _tableBlock(FormFieldDef field, dynamic value) {
  final cols = field.columns ?? const <FormFieldColumn>[];
  final rows = (value is List)
      ? value.map((e) => (e as Map).cast<String, dynamic>()).toList()
      : <Map<String, dynamic>>[];

  pw.Widget cell(String text, {bool header = false}) => pw.Padding(
    padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
    child: pw.Text(
      text,
      style: pw.TextStyle(
        fontSize: 9,
        fontWeight: header ? pw.FontWeight.bold : pw.FontWeight.normal,
      ),
    ),
  );

  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 6),
    child: pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          field.label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
        ),
        pw.SizedBox(height: 4),
        pw.Table(
          border: pw.TableBorder.all(width: 0.5, color: PdfColors.grey600),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey300),
              children: [for (final c in cols) cell(c.label, header: true)],
            ),
            if (rows.isEmpty)
              pw.TableRow(
                children: [
                  for (var i = 0; i < cols.length; i++) cell(i == 0 ? '—' : ''),
                ],
              )
            else
              for (final r in rows)
                pw.TableRow(
                  children: [
                    for (final c in cols) cell(_valueString(r[c.key])),
                  ],
                ),
          ],
        ),
      ],
    ),
  );
}
