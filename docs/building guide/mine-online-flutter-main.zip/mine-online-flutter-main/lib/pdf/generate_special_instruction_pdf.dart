// Port of `generateSpecialInstructionPDF` in src/utils/pdfGenerator.ts (3959-4031).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const String _siInfo =
    'Instructions issued for securing the safety and health of workers and for observance of the Mine Health and Safety Act Regulations, Mine Standards and Code of Practices.';

Future<pw.Document> generateSpecialInstructionPdf(
    SpecialInstructionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Special Instruction',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(PageCtx page, SpecialInstructionFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 5;

  y = _drawSection(page, y, contentWidth, rightEdge, data.section1);

  // Thick separator line between sections
  page.setLineWidth(1.2);
  page.line(margin, y + 2, rightEdge, y + 2);
  page.setLineWidth(0.3);
  y += 8;

  _drawSection(page, y, contentWidth, rightEdge, data.section2);

  drawInspectionFooter(page, pageNum: 'Page 73 of 84');
}

double _drawSection(
  PageCtx page,
  double startY,
  double contentWidth,
  double rightEdge,
  SpecialInstructionSection sec,
) {
  const margin = 10.5;
  var y = startY;

  // Title (centred)
  page.text('Special Instruction', margin + contentWidth / 2, y,
      size: 16, style: 'bold', align: 'center');
  y += 6;

  // Info paragraph
  final infoLines = page.splitTextToSize(_siInfo, contentWidth, 8, 'normal');
  for (final line in infoLines) {
    page.text(line, margin, y, size: 8, style: 'normal');
    y += 4;
  }
  y += 2;

  // Date / Time / Instruction to
  page.text('Date:', margin, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 10, y + 0.5, 40);
  if (sec.date.isNotEmpty) {
    page.text(sec.date, margin + 11, y, size: 8, style: 'normal');
  }
  page.text('Time:', margin + 56, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 66, y + 0.5, 35);
  if (sec.time.isNotEmpty) {
    page.text(sec.time, margin + 67, y, size: 8, style: 'normal');
  }
  page.text('Instruction to:', margin + 107, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 128, y + 0.5, rightEdge - margin - 128);
  if (sec.instructionTo.isNotEmpty) {
    page.text(sec.instructionTo, margin + 129, y,
        size: 8, style: 'normal');
  }
  y += 5;

  // Detail of instruction: first line beside label, 4 continuation lines
  page.text('Detail of instruction:', margin, y, size: 8, style: 'bold');
  drawDotLine(page, margin + 35, y + 0.5, contentWidth - 35);
  final detailLines = sec.detailOfInstruction.isEmpty
      ? <String>[]
      : page.splitTextToSize(
          sec.detailOfInstruction, contentWidth, 8, 'normal');
  if (detailLines.isNotEmpty) {
    page.text(detailLines.first, margin + 36, y, size: 8, style: 'normal');
  }
  y += 5;
  for (var i = 0; i < 4; i++) {
    drawDotLine(page, margin, y + 0.5, contentWidth);
    if (i + 1 < detailLines.length) {
      page.text(detailLines[i + 1], margin, y,
          size: 8, style: 'normal');
    }
    y += 5;
  }
  y += 2;

  // Remedial Action
  page.text('Remedial Action:', margin, y, size: 8, style: 'bold');
  drawDotLine(page, margin + 29, y + 0.5, contentWidth - 29);
  final remLines = sec.remedialAction.isEmpty
      ? <String>[]
      : page.splitTextToSize(sec.remedialAction, contentWidth, 8, 'normal');
  if (remLines.isNotEmpty) {
    page.text(remLines.first, margin + 30, y, size: 8, style: 'normal');
  }
  y += 5;
  for (var i = 0; i < 2; i++) {
    drawDotLine(page, margin, y + 0.5, contentWidth);
    if (i + 1 < remLines.length) {
      page.text(remLines[i + 1], margin, y, size: 8, style: 'normal');
    }
    y += 5;
  }
  y += 6;

  // Signature lines (3 column footer)
  drawDotLine(page, margin, y + 0.5, 52);
  drawDotLine(page, margin + 68, y + 0.5, 62);
  drawDotLine(page, margin + 146, y + 0.5, rightEdge - margin - 146);
  _drawSig(page, sec.issuerSignature, margin + 1, y - 7, 50, 6);
  _drawSig(page, sec.receiverSignature, margin + 69, y - 7, 60, 6);
  y += 4;

  page.text('Issuer Signature', margin, y, size: 7.5, style: 'normal');
  page.text('Receiver Signature', margin + 68, y, size: 7.5, style: 'normal');
  page.text('Date', margin + 146, y, size: 7.5, style: 'normal');
  final combinedDate = [sec.issuerSignatureDate, sec.receiverSignatureDate]
      .where((s) => s.isNotEmpty)
      .join(' / ');
  if (combinedDate.isNotEmpty) {
    page.text(combinedDate, margin + 147, y - 4,
        size: 7.5, style: 'normal');
  }
  return y + 4;
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
