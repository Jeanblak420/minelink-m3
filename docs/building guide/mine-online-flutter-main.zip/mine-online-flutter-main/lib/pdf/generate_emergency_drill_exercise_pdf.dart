// Port of `generateEmergencyDrillExercisePDF` in src/utils/pdfGenerator.ts (4329-4391).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _headFill = PdfColor.fromInt(0xffe6e6e6);

Future<pw.Document> generateEmergencyDrillExercisePdf(
    EmergencyDrillExerciseFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Emergency Drill Exercise',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(
    PageCtx page, EmergencyDrillExerciseFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Emergency Drill Exercise (Fire or Event)'],
    ],
    style: const GridStyle(
      fontSize: 14,
      cellPaddingTop: 3,
      cellPaddingBottom: 3,
      minCellHeight: 9,
    ),
  );
  y += 4;

  // Shift Boss / Working Place dotted-underline row
  page.text('Shift Boss:', margin, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 18, y + 0.5, 70);
  if (data.shiftBoss.isNotEmpty) {
    page.text(data.shiftBoss, margin + 19, y, size: 8, style: 'normal');
  }
  page.text('Working Place:', margin + 100, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 122, y + 0.5, rightEdge - margin - 122);
  if (data.workingPlace.isNotEmpty) {
    page.text(data.workingPlace, margin + 123, y,
        size: 8, style: 'normal');
  }
  y += 5;

  // Bold paragraph
  final paraLines = page.splitTextToSize(
      'Every Shift Boss will conduct an emergency drill exercise with his gangs at least once every three months. The following procedure to be observed:',
      contentWidth,
      8,
      'bold');
  for (final line in paraLines) {
    page.text(line, margin, y, size: 8, style: 'bold');
    y += 3.4;
  }
  y += 5;

  // First content row: Date of Exercise / value / Type of Emergency / italic note / value
  // We approximate the source's 5-col layout with stacked smaller tables.
  final labelW = 60.0;
  final shortValW = 30.0;
  final medLabelW = 30.0;
  final italicW = 40.0;
  final valueW = contentWidth - labelW - shortValW - medLabelW - italicW;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: labelW, fontStyle: 'bold', fillColor: _headFill),
      GridColumn(cellWidth: shortValW),
      GridColumn(cellWidth: medLabelW, fontStyle: 'bold', fillColor: _headFill),
      GridColumn(cellWidth: italicW, fontStyle: 'italic'),
      GridColumn(cellWidth: valueW),
    ],
    body: [
      [
        'Date of Exercise',
        data.dateOfExercise,
        'Type of Emergency',
        '(Fire / Seismic Event)',
        data.typeOfEmergency
      ],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );

  // 1. Alarm made at  / value / (time) — second + remaining 3 cols are "(time)" label spanning rest.
  // Render as 3-col: label | value | spacer-italic
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: labelW, fontStyle: 'bold', fillColor: _headFill),
      GridColumn(cellWidth: shortValW),
      GridColumn(
          cellWidth: medLabelW + italicW + valueW, fontStyle: 'italic'),
    ],
    body: [
      ['1. Alarm made at:', data.alarmMadeAt, '(time)'],
      ['2. All persons evacuated by', data.allPersonsEvacuatedBy, '(time)'],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );

  // Section heading + routes (full width)
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, fontStyle: 'bold', fillColor: _headFill),
    ],
    body: const [
      ['3. The following routes were taken to the Refuge Bay/s'],
    ],
    style: const GridStyle(fontSize: 7.5, minCellHeight: 6),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth)],
    body: [
      [data.routesTaken],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 10,
    ),
  );

  // Procedure heading
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, fontStyle: 'bold', fillColor: _headFill),
    ],
    body: const [
      ['4. The following procedure were followed in the refuge chamber/s'],
    ],
    style: const GridStyle(fontSize: 7.5, minCellHeight: 6),
  );

  // Procedure rows a..f
  final procRows = <List<String>>[
    ['a. Compressed air and water valves opened.',
        data.procedureA.isEmpty ? 'Yes / No' : data.procedureA],
    ['b. Door closed', data.procedureB.isEmpty ? 'Yes / No' : data.procedureB],
    [
      'c. Outside siren operated',
      data.procedureC.isEmpty ? 'Yes / No' : data.procedureC
    ],
    [
      'd. Gang cards checked',
      data.procedureD.isEmpty ? 'Yes / No' : data.procedureD
    ],
    [
      'e. Phoned to report emergency',
      data.procedureE.isEmpty ? 'Yes / No' : data.procedureE
    ],
    [
      'f. Persons instructed in the waiting place',
      data.procedureF.isEmpty ? 'Yes / No' : data.procedureF
    ],
  ];
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth - 30),
      const GridColumn(cellWidth: 30, halign: 'right'),
    ],
    body: procRows,
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );

  // Section heading 5
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, fontStyle: 'bold', fillColor: _headFill),
    ],
    body: const [
      [
        '5. Depending on the type of emergency, the following strategies were discussed by the Shift Boss with the Miner, Team Leader and Other Workers.'
      ],
    ],
    style: const GridStyle(fontSize: 7.5, minCellHeight: 8),
  );

  // 5.1 / 5.2 / 5.3 + 6. — each label row + value box
  final sections = <(String, String)>[
    ('5.1 Rescuing of injured /trapped workers:', data.rescuingInjuredWorkers),
    ('5.2 Extinguishing a fire which has just started:', data.extinguishingFire),
    ('5.3 A major fire or explosion:', data.majorFireOrExplosion),
    ('6. General remarks:', data.generalRemarks),
  ];
  for (final (label, value) in sections) {
    y = drawAutoTable(
      page,
      startY: y,
      columns: [
        GridColumn(cellWidth: contentWidth, fontStyle: 'bold'),
      ],
      body: [
        [label],
      ],
      style: const GridStyle(fontSize: 7.5, minCellHeight: 5),
    );
    y = drawAutoTable(
      page,
      startY: y,
      columns: [GridColumn(cellWidth: contentWidth)],
      body: [
        [value],
      ],
      style: const GridStyle(
        fontSize: 7.5,
        cellPaddingTop: 2,
        cellPaddingBottom: 2,
        minCellHeight: 12,
      ),
    );
  }

  y += 7;

  // Shift Boss signature line
  drawDotLine(page, margin, y + 0.5, 60);
  page.text('Shift Boss Signature', margin, y + 5, size: 8, style: 'normal');
  _drawSig(page, data.shiftBossSignature, margin + 1, y - 6, 58, 5);
  drawDotLine(page, margin + 80, y + 0.5, 50);
  page.text('Date', margin + 80, y + 5, size: 8, style: 'normal');
  if (data.shiftBossSignatureDate.isNotEmpty) {
    page.text(data.shiftBossSignatureDate, margin + 81, y,
        size: 8, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 82 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
