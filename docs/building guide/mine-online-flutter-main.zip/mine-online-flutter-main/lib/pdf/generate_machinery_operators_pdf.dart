// Port of `generateMachineryOperatorsPDF` in src/utils/pdfGenerator.ts (946-1034).

import 'dart:typed_data';
import 'dart:math' as math;

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

Future<pw.Document> generateMachineryOperatorsPdf(
    MachineryOperatorsFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Machinery Operators Appointment',
    draw: (page) => _draw(page, formData, logoBytes),
  );
}

void _draw(
    PageCtx page, MachineryOperatorsFormData data, Uint8List? logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3.5;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: const [
      GridHeader(
        text: 'Machinery Operators Appointments',
        fillColor: lightFill,
      ),
    ],
    body: const [],
    style: const GridStyle(
      fontSize: 11.4,
      cellPaddingTop: 2.1,
      cellPaddingBottom: 2.1,
      minCellHeight: 12.0,
    ),
  );

  // Pad to at least 18 rows
  final totalRows = math.max(data.operators.length, 18);
  final body = <List<String>>[];
  for (var i = 0; i < totalRows; i++) {
    final op = i < data.operators.length ? data.operators[i] : null;
    body.add([
      op?.companyNumber ?? '',
      op?.location ?? '',
      op?.typeOfEquipment ?? '',
      op?.licenceExpiryDate ?? '',
      op?.appointedForMonth ?? '',
      op?.signature ?? '',
    ]);
  }

  drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 23),
      const GridColumn(cellWidth: 28),
      const GridColumn(cellWidth: 42),
      const GridColumn(cellWidth: 23, halign: 'center'),
      const GridColumn(cellWidth: 24, halign: 'center'),
      GridColumn(cellWidth: contentWidth - 140),
    ],
    head: const [
      GridHeader(text: 'COY NO.', fillColor: PdfColors.white),
      GridHeader(text: 'Location', fillColor: PdfColors.white),
      GridHeader(text: 'Type of Equipment', fillColor: PdfColors.white),
      GridHeader(text: 'Licence\nExpiry Date', fillColor: PdfColors.white),
      GridHeader(text: 'Appointed for\nMonth', fillColor: PdfColors.white),
      GridHeader(text: 'Signature of\nOperator', fillColor: PdfColors.white),
    ],
    body: body,
    style: const GridStyle(
      fontSize: 7.1,
      cellPaddingTop: 1.4,
      cellPaddingBottom: 1.4,
      cellPaddingLeft: 1.6,
      cellPaddingRight: 1.6,
      minCellHeight: 8.0,
    ),
  );

  drawInspectionFooter(page, pageNum: 'Page 33 of 84');
}
