// Shared layout helpers for inspection-checklist forms (rock-breaker,
// belt-tip-area, conveyor-belt). All of these forms share the same
// "No. / Item / Yes-No / Remedial action taken" table and a signature row
// with two dotted-line blocks for Shift Boss and Mine Manager/Overseer.

import 'package:pdf/pdf.dart';

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const double _margin = 10.5;

/// Draws the grey title bar used by every inspection checklist form.
double drawInspectionTitle(PageCtx page, double y, String title) {
  final contentWidth = page.pageWidth - _margin * 2;
  return drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    body: [
      [title],
    ],
    style: const GridStyle(
      fontSize: 18,
      cellPaddingTop: 4,
      cellPaddingBottom: 4,
      minCellHeight: 12,
    ),
  );
}

/// Draws a "No. / Item / Yes-No / Remedial action" body for an inspection
/// checklist. Returns the new y position.
double drawInspectionItemsTable(
  PageCtx page,
  double y,
  List<String> itemLabels,
  List<InspectionItem> items, {
  bool drawHeader = true,
}) {
  final contentWidth = page.pageWidth - _margin * 2;
  final body = <List<String>>[];
  for (var i = 0; i < itemLabels.length; i++) {
    final item = i < items.length ? items[i] : InspectionItem();
    body.add(['${i + 1}.', itemLabels[i], item.yesNo, item.remedialAction]);
  }
  return drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 12, halign: 'center'),
      const GridColumn(cellWidth: 100),
      const GridColumn(cellWidth: 20, halign: 'center'),
      GridColumn(cellWidth: contentWidth - 132),
    ],
    head: drawHeader
        ? const [
            GridHeader(
                text: 'No.', fillColor: PdfColors.white, fontStyle: 'bold'),
            GridHeader(
                text: 'Item',
                fillColor: PdfColors.white,
                fontStyle: 'bold',
                halign: 'left'),
            GridHeader(
                text: 'Yes/No', fillColor: PdfColors.white, fontStyle: 'bold'),
            GridHeader(
                text: 'Remedial action taken',
                fillColor: PdfColors.white,
                fontStyle: 'bold',
                halign: 'left'),
          ]
        : null,
    body: body,
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
}

/// Standard signature row used by the rock-breaker / belt-tip / conveyor-belt
/// inspections. Shift Boss block (signature + date) on the left,
/// Mine Manager/Overseer on the right.
void drawInspectionSignatureRow(
  PageCtx page,
  double y, {
  required String shiftBossSignature,
  required String shiftBossDate,
  required String mineManagerOverseerSignature,
  required String mineManagerOverseerDate,
}) {
  final contentWidth = page.pageWidth - _margin * 2;
  final rightEdge = _margin + contentWidth;

  page.text('Signatures:', _margin, y, size: 8, style: 'bold');
  y += 8;

  // Shift Boss: signature line + label, date line + label
  drawDotLine(page, _margin, y + 0.5, 52);
  _drawSig(page, shiftBossSignature, _margin + 1, y - 6, 50, 5);
  page.text('Shift Boss', _margin, y + 5, size: 8, style: 'normal');
  drawDotLine(page, _margin + 58, y + 0.5, 30);
  page.text('Date', _margin + 58, y + 5, size: 8, style: 'normal');
  if (shiftBossDate.isNotEmpty) {
    page.text(shiftBossDate, _margin + 59, y, size: 8, style: 'normal');
  }

  drawDotLine(page, _margin + 97, y + 0.5, 52);
  _drawSig(page, mineManagerOverseerSignature, _margin + 98, y - 6, 50, 5);
  page.text('Mine Manager/Mine Overseer', _margin + 97, y + 5,
      size: 8, style: 'normal');
  drawDotLine(page, _margin + 155, y + 0.5, rightEdge - _margin - 155);
  page.text('Date', _margin + 155, y + 5, size: 8, style: 'normal');
  if (mineManagerOverseerDate.isNotEmpty) {
    page.text(mineManagerOverseerDate, _margin + 156, y,
        size: 8, style: 'normal');
  }
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
