// SP3 letter PDF: substitutes {{placeholders}} into the template letter body and
// renders a formal appointment letter. Supports a minimal markdown subset:
// a line starting with '# ' is a centered heading, '**bold**' spans render bold.
// Used by the builder's preview now; reused at issue time in SP4.

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/appointment_template.dart';

Future<pw.Document> generateAppointmentLetterPdf(
  AppointmentTemplate template,
  Map<String, String> values, {
  AppointmentRole? role,
}) async {
  final base = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Regular.ttf'),
  );
  final bold = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Bold.ttf'),
  );
  final theme = pw.ThemeData.withFont(base: base, bold: bold);

  final title = (role != null && role.displayLabel.isNotEmpty)
      ? role.displayLabel
      : template.name;
  final rendered = renderLetterBody(template.letterBody, values);

  final blocks = <pw.Widget>[];
  for (final rawLine in rendered.split('\n')) {
    final line = rawLine.trimRight();
    if (line.trim().isEmpty) {
      blocks.add(pw.SizedBox(height: 8));
    } else if (line.startsWith('# ')) {
      blocks.add(
        pw.Center(
          child: pw.Text(
            line.substring(2).trim(),
            style: pw.TextStyle(font: bold, fontSize: 14),
          ),
        ),
      );
      blocks.add(pw.SizedBox(height: 6));
    } else {
      blocks.add(
        pw.RichText(text: pw.TextSpan(children: _inline(line, base, bold))),
      );
      blocks.add(pw.SizedBox(height: 2));
    }
  }

  // Signature blocks: each required chain signer, then the appointee.
  final signers = <String>[...template.requiredSigners, 'appointee'];
  blocks.add(pw.SizedBox(height: 24));
  for (final s in signers) {
    blocks.add(
      pw.Padding(
        padding: const pw.EdgeInsets.only(top: 18),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Container(width: 220, height: 0.8, color: PdfColors.black),
            pw.SizedBox(height: 2),
            pw.Text(
              _signerLabel(s),
              style: pw.TextStyle(font: base, fontSize: 9),
            ),
          ],
        ),
      ),
    );
  }

  final doc = pw.Document();
  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.letter,
      theme: theme,
      margin: const pw.EdgeInsets.all(36),
      header: (ctx) => ctx.pageNumber == 1
          ? pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 16),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Text(
                    'LETTER OF APPOINTMENT',
                    style: pw.TextStyle(font: bold, fontSize: 16),
                  ),
                  pw.SizedBox(height: 4),
                  pw.Text(title, style: pw.TextStyle(font: base, fontSize: 12)),
                ],
              ),
            )
          : pw.SizedBox(),
      build: (ctx) => blocks,
    ),
  );
  return doc;
}

List<pw.TextSpan> _inline(String line, pw.Font base, pw.Font bold) {
  final spans = <pw.TextSpan>[];
  final re = RegExp(r'\*\*(.+?)\*\*');
  var idx = 0;
  for (final m in re.allMatches(line)) {
    if (m.start > idx) {
      spans.add(
        pw.TextSpan(
          text: line.substring(idx, m.start),
          style: pw.TextStyle(font: base, fontSize: 11),
        ),
      );
    }
    spans.add(
      pw.TextSpan(
        text: m.group(1),
        style: pw.TextStyle(font: bold, fontSize: 11),
      ),
    );
    idx = m.end;
  }
  if (idx < line.length) {
    spans.add(
      pw.TextSpan(
        text: line.substring(idx),
        style: pw.TextStyle(font: base, fontSize: 11),
      ),
    );
  }
  return spans;
}

String _signerLabel(String key) {
  switch (key) {
    case 'appointee':
      return 'Signature of appointee';
    case 'mine_overseer':
      return 'Mine Overseer';
    case 'mine_manager':
      return 'Mine Manager';
    default:
      return key.replaceAll('_', ' ');
  }
}
