// Port of `generatePlannedTaskObservationPDF` in src/utils/pdfGenerator.ts (4203-4236).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);

Future<pw.Document> generatePlannedTaskObservationPdf(
    PlannedTaskObservationFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter.landscape,
    subject: 'Planned Task Observation',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(PageCtx page, PlannedTaskObservationFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Control Sheet - Planned Task Observation'],
    ],
    style: const GridStyle(
      fontSize: 14,
      cellPaddingTop: 3,
      cellPaddingBottom: 3,
      minCellHeight: 9,
    ),
  );
  y += 3;

  page.text(
      'Shift Boss should record all the planned task observations done in this PTO control sheet',
      margin + contentWidth / 2,
      y,
      size: 8,
      style: 'bold',
      align: 'center');
  y += 5;

  // 8-col table: task | annual | semester | quarterly | monthly | bi-weekly | weekly | daily
  final colW = (contentWidth - 70) / 7;
  drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 70, fontStyle: 'bold'),
      GridColumn(cellWidth: colW, halign: 'center'),
      GridColumn(cellWidth: colW, halign: 'center'),
      GridColumn(cellWidth: colW, halign: 'center'),
      GridColumn(cellWidth: colW, halign: 'center'),
      GridColumn(cellWidth: colW, halign: 'center'),
      GridColumn(cellWidth: colW, halign: 'center'),
      GridColumn(cellWidth: colW, halign: 'center'),
    ],
    head: const [
      GridHeader(text: '', fillColor: PdfColors.white, fontStyle: 'bold'),
      GridHeader(
          text: 'Annual\n(1L, 2L)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Semester\n(3L, 4L, 5L)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Quarterly\n(6, 7, 8M)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Monthly\n(9, 10, 11, 12M)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Bi-Weekly\n(13, 14, 15H)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Weekly\n(16, 17, 18, 19H)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Daily Observations\n(20-25H)',
          fillColor: PdfColors.white,
          fontStyle: 'bold'),
    ],
    body: data.rows
        .map((r) => [
              r.task,
              r.annual,
              r.semester,
              r.quarterly,
              r.monthly,
              r.biWeekly,
              r.weekly,
              r.daily,
            ])
        .toList(),
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 7,
    ),
  );

  drawInspectionFooter(page, pageNum: 'Page 11 of 84');
}
