// Generic, schema-driven PDF for custom (Form Builder) submissions. Unlike the
// 27 ported forms (which mirror jsPDF coordinate-for-coordinate via PageCtx),
// custom forms have no web equivalent, so this uses the high-level pw.MultiPage
// API for automatic pagination. Roboto is bundled for Unicode support.

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/custom_form_template.dart';
import '../utils/dynamic_form_payload.dart'
    show kChainSignerFields, kChainSignerLabels;
import 'pdf_runtime.dart' show decodeSignatureBytes;

/// Pure: the printable string for a field value. Exposed for unit testing.
String customPdfValueString(dynamic value, FormFieldType type) {
  if (type == FormFieldType.boolean) return value == true ? 'Yes' : 'No';
  if (value == null) return '—';
  if (value is String) return value.trim().isEmpty ? '—' : value;
  return '$value';
}

Future<pw.Document> generateCustomFormPdf(
  CustomFormTemplate template,
  Map<String, dynamic> payload, {
  DateTime? generatedAt,
}) async {
  final base = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Regular.ttf'),
  );
  final bold = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Bold.ttf'),
  );
  final theme = pw.ThemeData.withFont(base: base, bold: bold);
  final stamp = generatedAt ?? DateTime.now();

  final doc = pw.Document(creator: 'Mine Online', subject: template.name);

  final blocks = <pw.Widget>[];
  for (final f in template.fields) {
    switch (f.type) {
      case FormFieldType.section:
        blocks.add(
          pw.Padding(
            padding: const pw.EdgeInsets.only(top: 14, bottom: 6),
            child: pw.Text(
              f.label,
              style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold),
            ),
          ),
        );
        break;
      case FormFieldType.signature:
        blocks.add(_signatureBlock(f.label, payload[f.key]));
        break;
      case FormFieldType.table:
        blocks.add(_tableBlock(f, payload[f.key]));
        break;
      case FormFieldType.dynamicDropdown:
        // Prefer the resolved option label stashed by the renderer.
        final shown = payload['${f.key}__label'] ?? payload[f.key];
        blocks.add(_kvRow(f.label, customPdfValueString(shown, f.type)));
        break;
      default:
        blocks.add(
          _kvRow(f.label, customPdfValueString(payload[f.key], f.type)),
        );
    }
  }

  // Approvals: render any recognized chain signatures present in the payload.
  final sig = (payload['signatures'] is Map)
      ? (payload['signatures'] as Map).cast<String, dynamic>()
      : null;
  if (sig != null) {
    final approvals = <pw.Widget>[];
    for (final entry in kChainSignerLabels.entries) {
      final field = kChainSignerFields[entry.key]!.first;
      if (sig.containsKey(field)) {
        approvals.add(_signatureBlock(entry.value, sig[field]));
      }
    }
    if (approvals.isNotEmpty) {
      blocks.add(
        pw.Padding(
          padding: const pw.EdgeInsets.only(top: 16, bottom: 6),
          child: pw.Text(
            'Approvals',
            style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold),
          ),
        ),
      );
      blocks.addAll(approvals);
    }
  }

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.letter,
      theme: theme,
      margin: const pw.EdgeInsets.fromLTRB(36, 36, 36, 36),
      header: (ctx) =>
          ctx.pageNumber == 1 ? _header(template, stamp) : pw.SizedBox(),
      build: (ctx) => blocks,
    ),
  );
  return doc;
}

pw.Widget _header(CustomFormTemplate template, DateTime stamp) {
  final d =
      '${stamp.year}-${stamp.month.toString().padLeft(2, '0')}-${stamp.day.toString().padLeft(2, '0')}';
  return pw.Container(
    margin: const pw.EdgeInsets.only(bottom: 12),
    padding: const pw.EdgeInsets.only(bottom: 8),
    decoration: const pw.BoxDecoration(
      border: pw.Border(bottom: pw.BorderSide(width: 1)),
    ),
    child: pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'Mine Online',
          style: pw.TextStyle(fontSize: 11, color: PdfColors.grey700),
        ),
        pw.SizedBox(height: 2),
        pw.Text(
          template.name,
          style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 2),
        pw.Text(
          'Generated: $d',
          style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
        ),
      ],
    ),
  );
}

pw.Widget _kvRow(String label, String value) {
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 3),
    child: pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.SizedBox(
          width: 150,
          child: pw.Text(
            label,
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
          ),
        ),
        pw.SizedBox(width: 8),
        pw.Expanded(
          child: pw.Text(value, style: const pw.TextStyle(fontSize: 10)),
        ),
      ],
    ),
  );
}

pw.Widget _signatureBlock(String label, dynamic value) {
  final bytes = decodeSignatureBytes(value is String ? value : '');
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 4),
    child: pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
        ),
        pw.SizedBox(height: 4),
        if (bytes == null)
          pw.Text('—', style: const pw.TextStyle(fontSize: 10))
        else
          pw.Container(
            height: 60,
            alignment: pw.Alignment.centerLeft,
            child: pw.Image(
              pw.MemoryImage(bytes),
              height: 60,
              fit: pw.BoxFit.contain,
            ),
          ),
      ],
    ),
  );
}

pw.Widget _tableBlock(FormFieldDef field, dynamic value) {
  final cols = field.columns ?? const <FormFieldColumn>[];
  final rows = (value is List)
      ? value.map((e) => (e as Map).cast<String, dynamic>()).toList()
      : <Map<String, dynamic>>[];

  pw.Widget cell(String text, {bool header = false}) => pw.Padding(
    padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
    child: pw.Text(
      text,
      style: pw.TextStyle(
        fontSize: 9,
        fontWeight: header ? pw.FontWeight.bold : pw.FontWeight.normal,
      ),
    ),
  );

  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 6),
    child: pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          field.label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
        ),
        pw.SizedBox(height: 4),
        pw.Table(
          border: pw.TableBorder.all(width: 0.5, color: PdfColors.grey600),
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey300),
              children: [for (final c in cols) cell(c.label, header: true)],
            ),
            if (rows.isEmpty)
              pw.TableRow(
                children: [
                  for (var i = 0; i < cols.length; i++) cell(i == 0 ? '—' : ''),
                ],
              )
            else
              for (final r in rows)
                pw.TableRow(
                  children: [for (final c in cols) cell(_cellString(r[c.key]))],
                ),
          ],
        ),
      ],
    ),
  );
}

String _cellString(dynamic v) {
  if (v == null) return '';
  if (v is String) return v;
  return '$v';
}
