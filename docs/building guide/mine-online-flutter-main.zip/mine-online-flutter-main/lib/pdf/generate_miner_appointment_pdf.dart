// Port of `generateMinerAppointmentPDF` in src/utils/pdfGenerator.ts (424-609).

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

Future<pw.Document> generateMinerAppointmentPdf(
    MinerAppointmentFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Miner Appointment',
    draw: (page) => _draw(page, formData, logoBytes),
  );
}

void _draw(PageCtx page, MinerAppointmentFormData data, Uint8List? logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: const [
      GridHeader(
        text:
            'Appointment as a MINER for Black Rock Mine Operations in terms of Section 7(4) and Regulation 4.4(1) of the Mine Health and\nSafety Act',
        fillColor: darkFill,
        textColor: PdfColors.white,
      ),
    ],
    body: const [],
    style: const GridStyle(
      fontSize: 8.8,
      minCellHeight: 10.5,
    ),
  );
  y += 2.2;

  // Identity table
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: 48, fontStyle: 'bold', fillColor: lightFill),
      GridColumn(cellWidth: contentWidth - 48),
    ],
    body: [
      ['Title', data.title.isEmpty ? 'Mr/Mrs/Miss' : data.title],
      ['Name', data.name],
      ['Identity number', data.identityNumber],
      ['Company number', data.companyNumber],
      ['Section/Shaft', data.sectionShaft],
    ],
    style: const GridStyle(fontSize: 7.6, minCellHeight: 5.3),
  );
  y += 2.4;

  page.text(
    'You are hereby appointed as a Miner to take charge of the following sections of the mine:',
    margin,
    y,
    size: 7.2,
    style: 'normal',
  );
  y += 2.8;

  // Workplace table
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: 56, fontStyle: 'bold', fillColor: lightFill),
      GridColumn(cellWidth: contentWidth - 56),
    ],
    body: [
      ['Stopes/Working places', data.workplaces.stopes],
      ['Development ends / Vent Holings', data.workplaces.developmentEnds],
      ['Declines', data.workplaces.declines],
      ['Load and Haul / Roadway', data.workplaces.loadAndHaul],
      ['Travelling way', data.workplaces.travellingWay],
      ['Refuge Bay', data.workplaces.refugeBay],
      ['Store', data.workplaces.store],
      ['Waiting place', data.workplaces.waitingPlace],
      ['Conveyor belts / Tipping area', data.workplaces.conveyorBelts],
      ['Any other workplaces specified', data.workplaces.otherWorkplaces],
    ],
    style: const GridStyle(fontSize: 7.2, minCellHeight: 4.9),
  );
  y += 3.6;

  final intro = page.splitTextToSize(
    'Furthermore, this appointment extends to cover all special rules and instructions as determined by the Manager, and as defined by the section blasting schedule. Within your geographic area of responsibility, your attention is drawn to, but not limited to, the following specific legal duties, functions and activities;',
    contentWidth,
    6.2,
    'normal',
  );
  for (final line in intro) {
    page.text(line, margin, y, size: 6.2, style: 'normal');
    y += 2.35;
  }
  y += 1.1;

  const duties = [
    'In terms of Section 7(4) of the Mine Health and Safety Act, 29 of 1996 you are responsible for compliance with the following functions and provisions which are entrusted to the manager by the MHS Act: Sections 5(1) and (2), Sections 6, 7, 9, 10, 11, 13, 23 and 24.',
    'In terms of the Mine Health and Safety Act, 29 of 1996 Regulations you are responsible for compliance with the following functions and provisions: Chapters 4.4(1), 4.4(2), 4.4(3), 4.6, 4.9, 4.10, 4.11(2), 4.11(5), 4.11(6), 4.11(7), 4.11(8), 4.12(1), 4.12(2), 4.12(3), 4.14, 4.16(5), 4.16(8).',
    'In terms of the Minerals Act, 51 of 1991 Regulations you are responsible for compliance with the following functions and provisions: Minerals Act Chapter 3 – General Provisions; Minerals Act Chapter 4 – Workmen; Minerals Act Chapter 10 – Ventilation, Gases and Dust; MHSA Regulations Chapter 13, – Outlets, Ladder ways and Travelling ways read with Minerals Act Chapter 6 (Outlets, Ladder ways and Travelling ways); MHSA Regulations Chapter 14 - Protection of the Surface and in Workings, read with Minerals Act Chapter 5 (Surface Protection and Minerals Act Chapter 7 (Protection in Workings); and MHSA Regulations Chapter 16 – Rescue, First Aid Emergency Preparedness and Response, read with Minerals Act Chapter 24 (First Aid and Rescue Brigades).',
  ];
  for (final duty in duties) {
    final lines = page.splitTextToSize(duty, contentWidth - 11, 6.05, 'normal');
    for (var i = 0; i < lines.length; i++) {
      if (i == 0) {
        page.text('•', margin + 4.3, y, size: 6.05, style: 'normal');
      }
      page.text(lines[i], margin + 8.2, y, size: 6.05, style: 'normal');
      y += 2.18;
    }
    y += 0.45;
  }
  y += 1.3;

  // Signature table
  final signatureBytes = [
    decodeSignatureBytes(data.signatures.minerSignature),
    decodeSignatureBytes(data.signatures.shiftBossSignature),
    decodeSignatureBytes(data.signatures.mineOverseerSignature),
    decodeSignatureBytes(data.signatures.mineManagerSignature),
  ];

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: 42, fontStyle: 'bold', fillColor: lightFill),
      GridColumn(cellWidth: 62),
      GridColumn(cellWidth: contentWidth - 104),
    ],
    head: const [
      GridHeader(text: 'Title'),
      GridHeader(text: 'Date'),
      GridHeader(text: 'Signature'),
    ],
    body: [
      ['Miner', data.signatures.minerDate, ''],
      ['Shift Boss', data.signatures.shiftBossDate, ''],
      ['Mine Overseer', data.signatures.mineOverseerDate, ''],
      ['Mine Manager', data.signatures.mineManagerDate, ''],
    ],
    cellSignature: (row, col) => col == 2 ? signatureBytes[row] : null,
    style: const GridStyle(fontSize: 7.3, minCellHeight: 8.2),
  );

  drawInspectionFooter(page, pageNum: 'Page 20 of 84');
}
