// Port of `generateGassingIncidentPDF` in src/utils/pdfGenerator.ts (1416-1556).

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

Future<pw.Document> generateGassingIncidentPdf(
    GassingIncidentFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Gassing Incident Record',
    draw: (page) => _draw(page, formData, logoBytes),
  );
}

void _draw(PageCtx page, GassingIncidentFormData data, Uint8List? logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3.5;

  // Title bar: grey fill, centred 16pt bold. theme:'plain' = no border.
  const titleHeight = 14.0;
  const titleFill = PdfColor.fromInt(0xffc8c8c8);
  page.rectFill(margin, y, contentWidth, titleHeight, titleFill);
  page.text(
    'Gassing / Smoke / Dust / Incident Record',
    margin + contentWidth / 2,
    y + titleHeight - 4.5,
    size: 16,
    style: 'bold',
    align: 'center',
  );
  y += titleHeight + 4;

  const lineSpacing = 10.0;
  const labelFontSize = 9.0;

  void labeledField(String label, String value, double x, double valX,
      double underlineWidth) {
    page.text(label, x, y, size: labelFontSize, style: 'bold');
    if (value.isNotEmpty) {
      page.text(value, valX + 2, y,
          size: labelFontSize, style: 'normal');
    }
    drawDotLine(page, valX, y + 1, underlineWidth);
  }

  // Row 1: Date / Coy No of injured / Time
  labeledField('Date:', data.date, margin, margin + 12, 40);
  labeledField('Coy No. of injured:', data.coyNoOfInjured, margin + 60,
      margin + 96, 36);
  labeledField('Time:', data.time, margin + 138, margin + 150,
      contentWidth - 138 - 12);

  y += lineSpacing;

  // Row 2: Working place / Severity
  labeledField('Working place:', data.workingPlace, margin, margin + 28,
      contentWidth / 2 - 28);
  final sevLabelX = margin + contentWidth / 2 + 5;
  labeledField('Severity:', data.severity, sevLabelX, sevLabelX + 18,
      contentWidth / 2 - 23);

  y += lineSpacing;

  // Description — first line beside label, continuation lines fill width.
  page.text('Description:', margin, y, size: labelFontSize, style: 'bold');
  const descValX = margin + 24;
  final descMaxWidth = contentWidth - 24;
  final descLines = data.description.isEmpty
      ? <String>['']
      : page.splitTextToSize(
          data.description, descMaxWidth, labelFontSize, 'normal');
  if (descLines[0].isNotEmpty) {
    page.text(descLines[0], descValX + 2, y,
        size: labelFontSize, style: 'normal');
  }
  drawDotLine(page, descValX, y + 1, descMaxWidth);
  final continuationCount = (descLines.length - 1).clamp(0, 3);
  for (var i = 1; i <= continuationCount; i++) {
    y += lineSpacing;
    page.text(descLines[i], margin + 2, y,
        size: labelFontSize, style: 'normal');
    drawDotLine(page, margin, y + 1, contentWidth);
  }
  final blankLines = 3 - continuationCount;
  for (var i = 0; i < blankLines; i++) {
    y += lineSpacing;
    drawDotLine(page, margin, y + 1, contentWidth);
  }

  y += lineSpacing + 2;

  // Injuries
  page.text('Injuries:', margin, y, size: labelFontSize, style: 'bold');
  const injValX = margin + 18;
  if (data.injuries.isNotEmpty) {
    final injLines = page.splitTextToSize(
        data.injuries, contentWidth - 18, labelFontSize, 'normal');
    page.text(injLines.first, injValX + 2, y,
        size: labelFontSize, style: 'normal');
  }
  drawDotLine(page, injValX, y + 1, contentWidth - 18);

  y += lineSpacing + 4;

  // Signatures
  page.text('Shift Boss Signature:', margin, y,
      size: labelFontSize, style: 'bold');
  drawDotLine(page, margin + 38, y + 1, 55);
  _drawSig(page, data.shiftBossSignature, margin + 39, y - 7, 53, 6);

  final overseerLabelX = margin + contentWidth / 2;
  page.text('Mine Overseer Signature:', overseerLabelX, y,
      size: labelFontSize, style: 'bold');
  drawDotLine(page, overseerLabelX + 46, y + 1, contentWidth / 2 - 46);
  _drawSig(page, data.mineOverseerSignature, overseerLabelX + 47, y - 7,
      contentWidth / 2 - 48, 6);

  drawInspectionFooter(page, pageNum: 'Page 56 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
