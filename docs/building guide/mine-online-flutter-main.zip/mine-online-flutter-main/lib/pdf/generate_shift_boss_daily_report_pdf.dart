// Port of `generateShiftBossDailyReportPDF` in src/utils/pdfGenerator.ts (1036-1413).
// 2-page form with several complex multi-row table headers.

import 'dart:math' as math;

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _headerWhite = PdfColors.white;

Future<pw.Document> generateShiftBossDailyReportPdf(
    ShiftBossDailyReportFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildMultiPageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Shift Boss Daily Report',
    pages: [
      (page) => _drawPage1(page, data, logoBytes),
      (page) => _drawPage2(page, data, logoBytes),
    ],
  );
}

void _drawPage1(
    PageCtx page, ShiftBossDailyReportFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title
  page.text('Shift Boss Daily Report', margin + contentWidth / 2, y + 8,
      size: 16, style: 'bold', align: 'center');
  y += 14;

  // Date / Shift / Cycle — 13-cell row.
  // Widths: 22, 22, 22, 14, 18, 14, 22, 10, 10, 10, 10, 6, 6 = 186mm
  final dateRowWidths = <double>[
    22, 22, 22, 14, 18, 14, 22, 10, 10, 10, 10, 6, 6,
  ];
  // Pad the last cell so the row spans full contentWidth
  dateRowWidths[dateRowWidths.length - 1] +=
      contentWidth - dateRowWidths.fold<double>(0, (a, b) => a + b);
  final dateRowCells = <SpanCell>[
    const SpanCell(text: 'Date'),
    SpanCell(
        text: data.date, fontStyle: 'normal', fillColor: PdfColors.white),
    const SpanCell(text: 'DAY\nSHIFT'),
    SpanCell(
        text: data.dayShift ? 'X' : '',
        fontStyle: 'normal',
        fillColor: PdfColors.white),
    const SpanCell(text: 'NIGHT\nSHIFT'),
    SpanCell(
        text: data.nightShift ? 'X' : '',
        fontStyle: 'normal',
        fillColor: PdfColors.white),
    const SpanCell(text: 'CYCLE'),
    const SpanCell(text: 'A'),
    SpanCell(
        text: data.cycleA ? 'X' : '',
        fontStyle: 'normal',
        fillColor: PdfColors.white),
    const SpanCell(text: 'B'),
    SpanCell(
        text: data.cycleB ? 'X' : '',
        fontStyle: 'normal',
        fillColor: PdfColors.white),
    const SpanCell(text: 'C'),
    SpanCell(
        text: data.cycleC ? 'X' : '',
        fontStyle: 'normal',
        fillColor: PdfColors.white),
  ];
  y = drawSpanningHeader(
    page,
    startY: y,
    leftX: margin,
    columnWidths: dateRowWidths,
    rows: [dateRowCells],
    rowHeight: 10,
  );
  y += 1;

  // Section 1: places visited
  page.text('1. I have this day visited and inspected the following working places:',
      margin, y + 3, size: 8, style: 'bold');
  y += 4;

  final placesMinRows = 16;
  final placesRows =
      math.max(data.placesVisited.length, placesMinRows);
  final half = (placesRows / 2).ceil();
  final leftPlaces = <List<String>>[];
  for (var i = 0; i < half; i++) {
    final l = i < data.placesVisited.length ? data.placesVisited[i] : null;
    final r =
        (i + half) < data.placesVisited.length ? data.placesVisited[i + half] : null;
    leftPlaces.add([
      l?.placeVisited ?? '',
      l?.miner ?? '',
      r?.placeVisited ?? '',
      r?.miner ?? '',
    ]);
  }
  while (leftPlaces.length < 8) {
    leftPlaces.add(['', '', '', '']);
  }
  final colW = contentWidth / 4;
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: colW),
      GridColumn(cellWidth: colW),
      GridColumn(cellWidth: colW),
      GridColumn(cellWidth: colW),
    ],
    head: const [
      GridHeader(
          text: 'Place visited',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Miner', fillColor: _headerWhite, fontStyle: 'bold'),
      GridHeader(
          text: 'Place visited',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Miner', fillColor: _headerWhite, fontStyle: 'bold'),
    ],
    body: leftPlaces,
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 10,
    ),
  );
  y += 1;

  page.text('2. Planned Inspection conducted:', margin, y + 3,
      size: 8, style: 'bold');
  y += 4;

  // Planned inspections — 7 cols
  final inspMinRows = 8;
  final inspRows = math.max(data.plannedInspections.length, inspMinRows);
  final inspBody = <List<String>>[];
  for (var i = 0; i < inspRows; i++) {
    final e =
        i < data.plannedInspections.length ? data.plannedInspections[i] : null;
    inspBody.add([
      e?.workingPlace ?? '',
      e?.unsafeConditions ?? '',
      e?.remedialAction ?? '',
      e?.responsiblePerson ?? '',
      e?.responsiblePersonSignature ?? '',
      e?.plannedDate ?? '',
      e?.completedDate ?? '',
    ]);
  }
  drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 22),
      const GridColumn(cellWidth: 34),
      const GridColumn(cellWidth: 30),
      const GridColumn(cellWidth: 26),
      const GridColumn(cellWidth: 26),
      const GridColumn(cellWidth: 20),
      GridColumn(cellWidth: contentWidth - 158),
    ],
    head: const [
      GridHeader(
          text: 'Working\nplace',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Unsafe/ unsatisfactory\nconditions observed',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Remedial Action',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Responsible\nperson',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Responsible Person\nSignature',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Planned\nDate',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Completed\nDate',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
    ],
    body: inspBody,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 9,
    ),
  );

  drawInspectionFooter(page, pageNum: 'Page 42 of 84');
}

void _drawPage2(
    PageCtx page, ShiftBossDailyReportFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 1;

  // Section 3: development ends
  page.text('3. Development Ends/Ventilation Holing blasted on previous shift:',
      margin, y + 3, size: 8, style: 'bold');
  y += 4;

  // Column widths for the dev-ends table (7 cols, 30+24+26+24+26+remaining+26)
  // Source: 0:30, 1:24, 2:26, 3:24, 4:26, 5: contentWidth - sums - 26, 6: 26
  final devColWidths = <double>[30, 24, 26, 24, 26, 0, 26];
  devColWidths[5] =
      contentWidth - devColWidths.fold<double>(0, (a, b) => a + b);
  // Spanning header (2 rows)
  y = drawSpanningHeader(
    page,
    startY: y,
    leftX: margin,
    columnWidths: devColWidths,
    rows: const [
      [
        SpanCell(
            text: 'Dev. Ends/Vent\nHoling', rowSpan: 2, fontSize: 7),
        SpanCell(text: 'Roofbolts', colSpan: 2, fontSize: 7),
        SpanCell(
            text: 'No. of sockets\ninspected',
            rowSpan: 2,
            fontSize: 7),
        SpanCell(text: 'Average length', rowSpan: 2, fontSize: 7),
        SpanCell(text: 'Distance from the Face', colSpan: 2, fontSize: 7),
      ],
      [
        SpanCell(text: 'From face', fontSize: 7),
        SpanCell(text: 'From sidewall', fontSize: 7),
        SpanCell(text: 'Service pipes', fontSize: 7),
        SpanCell(text: 'Vent pipes', fontSize: 7),
      ],
    ],
    rowHeight: 5.5,
  );

  // Body rows
  final devMinRows = 3;
  final devRows = math.max(data.devEnds.length, devMinRows);
  final devBody = <List<String>>[];
  for (var i = 0; i < devRows; i++) {
    final e = i < data.devEnds.length ? data.devEnds[i] : null;
    devBody.add([
      e?.devEndVentHoling ?? '',
      e?.roofboltsFromFace ?? '',
      e?.roofboltsFromSidewall ?? '',
      e?.socketsInspected ?? '',
      e?.averageLength ?? '',
      e?.servicePipes ?? '',
      e?.ventPipes ?? '',
    ]);
  }
  y = drawAutoTable(
    page,
    startY: y,
    columns: [for (final w in devColWidths) GridColumn(cellWidth: w)],
    body: devBody,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 7,
    ),
  );
  y += 2;

  // Section 4: pillar dimensions
  page.text('4. Pillar Dimensions/Survey Lines', margin, y + 3,
      size: 8, style: 'bold');
  y += 4;

  final pillarColWidths = <double>[28, 20, 20, 20, 20, 20, 0];
  pillarColWidths[6] =
      contentWidth - pillarColWidths.fold<double>(0, (a, b) => a + b);
  y = drawSpanningHeader(
    page,
    startY: y,
    leftX: margin,
    columnWidths: pillarColWidths,
    rows: const [
      [
        SpanCell(text: 'Workplace', rowSpan: 3, fontSize: 7),
        SpanCell(text: 'V/H No.', rowSpan: 3, fontSize: 7),
        SpanCell(text: 'Off sets', colSpan: 4, fontSize: 7),
        SpanCell(text: 'Remedial Action', rowSpan: 3, fontSize: 7),
      ],
      [
        SpanCell(text: 'Survey note', colSpan: 2, fontSize: 7),
        SpanCell(text: 'Actual', colSpan: 2, fontSize: 7),
      ],
      [
        SpanCell(text: 'Left', fontStyle: 'italic', fontSize: 7),
        SpanCell(text: 'Right', fontStyle: 'italic', fontSize: 7),
        SpanCell(text: 'Left', fontStyle: 'italic', fontSize: 7),
        SpanCell(text: 'Right', fontStyle: 'italic', fontSize: 7),
      ],
    ],
    rowHeight: 5.0,
  );

  final pillarMinRows = 3;
  final pillarRows = math.max(data.pillarDimensions.length, pillarMinRows);
  final pillarBody = <List<String>>[];
  for (var i = 0; i < pillarRows; i++) {
    final e =
        i < data.pillarDimensions.length ? data.pillarDimensions[i] : null;
    pillarBody.add([
      e?.workplace ?? '',
      e?.vhNo ?? '',
      e?.surveyNoteLeft ?? '',
      e?.surveyNoteRight ?? '',
      e?.actualLeft ?? '',
      e?.actualRight ?? '',
      e?.remedialAction ?? '',
    ]);
  }
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      for (final w in pillarColWidths) GridColumn(cellWidth: w),
    ],
    body: pillarBody,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 7,
    ),
  );
  y += 2;

  // Section 5: inspection checklist
  page.text('5. I have also inspected the following:', margin, y + 3,
      size: 8, style: 'bold');
  y += 4;

  final checkRows = data.inspectionChecklist
      .map((c) => [
            c.item,
            c.yes ? 'X' : '',
            c.no ? 'X' : '',
            c.findings,
          ])
      .toList();
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 55),
      const GridColumn(cellWidth: 12, halign: 'center'),
      const GridColumn(cellWidth: 12, halign: 'center'),
      GridColumn(cellWidth: contentWidth - 79),
    ],
    head: const [
      GridHeader(
          text: 'Item', fillColor: _headerWhite, fontStyle: 'bold'),
      GridHeader(text: 'Yes', fillColor: _headerWhite, fontStyle: 'bold'),
      GridHeader(text: 'No', fillColor: _headerWhite, fontStyle: 'bold'),
      GridHeader(
          text: 'Findings and Instructions',
          fillColor: _headerWhite,
          fontStyle: 'bold'),
    ],
    body: checkRows,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.2,
      cellPaddingBottom: 1.2,
      minCellHeight: 5.8,
    ),
  );

  // Section 6: readings (3 cols, with rowSpan=2 on "Temperature")
  page.text('6. I have taken the following readings:', margin, y + 3,
      size: 8, style: 'bold');
  y += 4;

  final readColWidths = <double>[35, 30, 0];
  readColWidths[2] =
      contentWidth - readColWidths.fold<double>(0, (a, b) => a + b);
  // Header: ['', '', 'Actual Reading']
  y = drawSpanningHeader(
    page,
    startY: y,
    leftX: margin,
    columnWidths: readColWidths,
    rows: const [
      [
        SpanCell(text: '', fontSize: 7),
        SpanCell(text: '', fontSize: 7),
        SpanCell(text: 'Actual Reading', fontSize: 7),
      ],
    ],
    rowHeight: 6,
  );

  // Row 1: Ventilation Flow | >0.5m/s | reading
  // Row 2-3: Temperature (rowSpan 2) | WB<27.5C | reading
  //                                  | DB<32.5C | reading
  y = drawSpanningHeader(
    page,
    startY: y,
    leftX: margin,
    columnWidths: readColWidths,
    rows: [
      [
        const SpanCell(
            text: 'Ventilation Flow',
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
        const SpanCell(
            text: '>0.5m/s',
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
        SpanCell(
            text: data.ventilationFlowReading,
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
      ],
      [
        const SpanCell(
            text: 'Temperature',
            rowSpan: 2,
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
        const SpanCell(
            text: 'WB<27.5C',
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
        SpanCell(
            text: data.temperatureWBReading,
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
      ],
      [
        const SpanCell(
            text: 'DB<32.5C',
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
        SpanCell(
            text: data.temperatureDBReading,
            fontStyle: 'normal',
            fillColor: _headerWhite,
            halign: 'left'),
      ],
    ],
    rowHeight: 6,
  );

  // General row + Mine Overseer Comments row
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 25, fontStyle: 'bold'),
      GridColumn(cellWidth: contentWidth - 25),
    ],
    body: [
      ['General:', data.general],
    ],
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 8,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 55, fontStyle: 'bold'),
      GridColumn(cellWidth: contentWidth - 55),
    ],
    body: [
      ['Mine Overseer Comments/Instruction:', data.mineOverseerComments],
    ],
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 12,
    ),
  );
  y += 8;

  // Signature lines (3 cols)
  page.line(margin, y, margin + 52, y);
  page.line(margin + 62, y, margin + 62 + 58, y);
  page.line(rightEdge - 38, y, rightEdge, y);
  _drawSig(page, data.shiftBossSignature, margin + 1, y - 7, 50, 6);
  _drawSig(page, data.managerMineOverseerSignature, margin + 63, y - 7, 56, 6);

  y += 2;
  page.text('Shift Boss', margin, y, size: 7, style: 'normal');
  page.text('Manager/Mine Overseer', margin + 62, y, size: 7, style: 'normal');
  page.text('Date', rightEdge - 38, y, size: 7, style: 'normal');
  if (data.signatureDate.isNotEmpty) {
    page.text(data.signatureDate, rightEdge - 37, y - 4,
        size: 7, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 43 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
