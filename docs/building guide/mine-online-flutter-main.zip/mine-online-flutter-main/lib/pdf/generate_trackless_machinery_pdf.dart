// Port of `generateTracklessMachineryPDF` in src/utils/pdfGenerator.ts (3202-3387).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _bannerFill = PdfColor.fromInt(0xffdcdcdc);
const PdfColor _headFill = PdfColor.fromInt(0xfff0f0f0);

const List<String> _itemLabels = [
  'Operator trained?',
  'Operator licence available?',
  'Pre-use checklist available?',
  'Pre-use checklist completed according to requirements?',
  'Operator wearing correct PPE?',
  'Operator wearing safety belt?',
];

Future<pw.Document> generateTracklessMachineryPdf(
    TracklessMachineryFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Trackless Machinery Inspection',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(PageCtx page, TracklessMachineryFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Weekly Trackless Mobile Machinery Over-Inspection'],
    ],
    style: const GridStyle(
      fontSize: 14,
      cellPaddingTop: 4,
      cellPaddingBottom: 4,
      minCellHeight: 10,
    ),
  );
  y += 4;

  const noColW = 10.0;
  const itemColW = 72.0;
  const yesNoColW = 22.0;
  final remedialColW = contentWidth - noColW - itemColW - yesNoColW;

  // Render up to 4 inspection blocks
  final blocks = data.inspections.take(4).toList();
  for (final entry in blocks) {
    // Date banner (full width)
    y = drawAutoTable(
      page,
      startY: y,
      columns: [
        GridColumn(
            cellWidth: contentWidth, fontStyle: 'bold', fillColor: _bannerFill),
      ],
      body: [
        ['Date of inspection: ${entry.dateOfInspection}'.trimRight()],
      ],
      style: const GridStyle(
        fontSize: 9,
        cellPaddingTop: 2,
        cellPaddingBottom: 2,
        minCellHeight: 6,
      ),
    );
    // Operator Coy # / Machine # — 4 cols
    final labelW = contentWidth * 0.18;
    final valueW = contentWidth / 2 - labelW;
    y = drawAutoTable(
      page,
      startY: y,
      columns: [
        GridColumn(cellWidth: labelW, fontStyle: 'bold'),
        GridColumn(cellWidth: valueW),
        GridColumn(cellWidth: labelW, fontStyle: 'bold'),
        GridColumn(cellWidth: valueW),
      ],
      body: [
        [
          'Operator Coy Number:',
          entry.operatorCoyNumber,
          'Machine Number:',
          entry.machineNumber,
        ],
      ],
      style: const GridStyle(
        fontSize: 8,
        cellPaddingTop: 2,
        cellPaddingBottom: 2,
        minCellHeight: 6,
      ),
    );

    // Items table (header + 6 rows)
    final values = [
      [entry.operatorTrained, entry.operatorTrained_remedial],
      [entry.operatorLicence, entry.operatorLicence_remedial],
      [entry.preUseChecklistAvailable, entry.preUseChecklistAvailable_remedial],
      [entry.preUseChecklistCompleted, entry.preUseChecklistCompleted_remedial],
      [entry.correctPPE, entry.correctPPE_remedial],
      [entry.safetyBelt, entry.safetyBelt_remedial],
    ];
    final body = <List<String>>[];
    for (var i = 0; i < _itemLabels.length; i++) {
      body.add([
        '${i + 1}',
        _itemLabels[i],
        values[i][0],
        values[i][1],
      ]);
    }
    y = drawAutoTable(
      page,
      startY: y,
      columns: [
        const GridColumn(cellWidth: noColW, halign: 'center'),
        const GridColumn(cellWidth: itemColW),
        const GridColumn(cellWidth: yesNoColW, halign: 'center'),
        GridColumn(cellWidth: remedialColW),
      ],
      head: const [
        GridHeader(text: 'No.', fillColor: _headFill, fontStyle: 'bold'),
        GridHeader(
            text: 'Item',
            fillColor: _headFill,
            fontStyle: 'bold',
            halign: 'left'),
        GridHeader(text: 'Yes/No', fillColor: _headFill, fontStyle: 'bold'),
        GridHeader(
            text: 'Remedial Action taken',
            fillColor: _headFill,
            fontStyle: 'bold',
            halign: 'left'),
      ],
      body: body,
      style: const GridStyle(
        fontSize: 8,
        cellPaddingTop: 2,
        cellPaddingBottom: 2,
        minCellHeight: 5.5,
      ),
    );
    y += 5;
  }

  y += 4;

  // Shiftboss signature line
  page.text('Shiftboss Signature:', margin, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 36, y + 0.5, 55);
  page.text('Date:', margin + 99, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 108, y + 0.5, rightEdge - margin - 108);
  _drawSig(page, data.shiftbossSignature, margin + 37, y - 6, 53, 5);
  if (data.shiftbossSignatureDate.isNotEmpty) {
    page.text(data.shiftbossSignatureDate, margin + 109, y,
        size: 8, style: 'normal');
  }
  y += 5.5 + 7;

  page.text('Mine Overseer Signature:', margin, y,
      size: 8, style: 'normal');
  drawDotLine(page, margin + 44, y + 0.5, 47);
  page.text('Date:', margin + 99, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 108, y + 0.5, rightEdge - margin - 108);
  _drawSig(page, data.mineOverseerSignature, margin + 45, y - 6, 45, 5);
  if (data.mineOverseerSignatureDate.isNotEmpty) {
    page.text(data.mineOverseerSignatureDate, margin + 109, y,
        size: 8, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 65 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
