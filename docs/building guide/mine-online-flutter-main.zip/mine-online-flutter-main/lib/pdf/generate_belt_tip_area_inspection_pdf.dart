// Port of `generateBeltTipAreaInspectionPDF` in src/utils/pdfGenerator.ts (3818-3888).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'inspection_items_table.dart';
import 'pdf_runtime.dart';

const List<String> beltTipItemLabels = [
  'Is the robot in working condition?',
  'Tip are clean – no big rocks lying around?',
  'Area adequately illuminated?',
  'Tool rack available?',
  'Required tools available? (spade/rake/pinch bar)',
  'Roadway is of good construction?',
  'Housekeeping is of high standard?',
  'Safe hangingwall and sidewall?',
];

Future<pw.Document> generateBeltTipAreaInspectionPdf(
    BeltTipAreaInspectionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Belt Tip Area Inspection',
    draw: (page) {
      const margin = 10.5;
      final rightEdge = page.pageWidth - margin;
      var y = drawInspectionHeader(page, startY: 8, logoBytes: logoBytes) + 3;

      y = drawInspectionTitle(page, y, 'Weekly Belt Tip Area Inspection');
      y += 6;

      page.text('Date of Inspection:', margin, y, size: 8, style: 'normal');
      drawDotLine(page, margin + 30, y + 0.5, 54);
      if (data.dateOfInspection.isNotEmpty) {
        page.text(data.dateOfInspection, margin + 31, y,
            size: 8, style: 'normal');
      }
      page.text('Position of the tip:', margin + 90, y,
          size: 8, style: 'normal');
      drawDotLine(page, margin + 115, y + 0.5, rightEdge - margin - 115);
      if (data.positionOfTip.isNotEmpty) {
        page.text(data.positionOfTip, margin + 116, y,
            size: 8, style: 'normal');
      }
      y += 4;

      y = drawInspectionItemsTable(page, y, beltTipItemLabels, data.items);
      y += 7;

      drawInspectionSignatureRow(
        page,
        y,
        shiftBossSignature: data.shiftBossSignature,
        shiftBossDate: data.shiftBossDate,
        mineManagerOverseerSignature: data.mineManagerOverseerSignature,
        mineManagerOverseerDate: data.mineManagerOverseerDate,
      );

      drawInspectionFooter(page, pageNum: 'Page 70 of 84');
    },
  );
}
