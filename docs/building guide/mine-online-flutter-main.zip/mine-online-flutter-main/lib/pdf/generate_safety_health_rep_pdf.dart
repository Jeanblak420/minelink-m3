// Port of `generateSafetyHealthRepPDF` / `renderSafetyRepSection` in
// src/utils/pdfGenerator.ts (798-944).

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

Future<pw.Document> generateSafetyHealthRepPdf(
    SafetyHealthRepFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Safety Health Representative Appointment',
    draw: (page) => _draw(page, formData, logoBytes),
  );
}

void _draw(PageCtx page, SafetyHealthRepFormData data, Uint8List? logo) {
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3.5;
  y = _renderSection(
      page, 'Safety and Health Representative Appointment', data.primary, y);
  y += 4;
  y = _renderSection(page,
      'Alternative Safety and Health Representative Appointment',
      data.alternative,
      y);
  drawInspectionFooter(page, pageNum: 'Page 30 of 84');
}

double _renderSection(
  PageCtx page,
  String sectionTitle,
  SafetyHealthRepSection data,
  double yPos,
) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;

  // Title bar
  yPos = drawAutoTable(
    page,
    startY: yPos,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: [
      GridHeader(
        text: sectionTitle,
        fillColor: darkFill,
        textColor: PdfColors.white,
      ),
    ],
    body: const [],
    style: const GridStyle(
      fontSize: 9.2,
      cellPaddingTop: 2.2,
      cellPaddingBottom: 2.2,
      minCellHeight: 10.0,
    ),
  );
  yPos += 1.5;

  // 2x4 identity table: label / value / label / value.
  yPos = drawAutoTable(
    page,
    startY: yPos,
    columns: const [
      GridColumn(cellWidth: 30, fontStyle: 'bold', fillColor: lightFill),
      GridColumn(cellWidth: 57.5),
      GridColumn(cellWidth: 30, fontStyle: 'bold', fillColor: lightFill),
      GridColumn(cellWidth: 57.5),
    ],
    body: [
      ['Name', data.name, 'Coy No.', data.companyNumber],
      ['Shaft', data.shaft, 'Section', data.section],
    ],
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 1.8,
      cellPaddingBottom: 1.8,
      cellPaddingLeft: 1.8,
      cellPaddingRight: 1.8,
      minCellHeight: 5.4,
    ),
  );
  yPos += 2.2;

  // Body paragraphs
  for (final paragraph in const [
    'In terms of Section 25 of the Mine Health and Safety Act 1996 (Act No. 29 of 1996) ("MHSA") and MHSA Regulation 6.9 you are appointed as the Safety and Health Representative at the above mentioned working place.',
    'In terms of section 30 of the Act, your functions, rights and power during normal working hours will be associated with the above working place. In order to promote or protect the health and safety of employees you represent, you may exercise the duties as stipulated under the Health and Safety Act.',
  ]) {
    final lines = page.splitTextToSize(paragraph, contentWidth, 8, 'normal');
    for (final line in lines) {
      page.text(line, margin, yPos, size: 8, style: 'normal');
      yPos += 3.4;
    }
    yPos += 1.2;
  }
  yPos += 1.4;

  page.text('Yours Faithfully', margin, yPos, size: 8, style: 'normal');
  yPos += 10;

  page.setLineWidth(0.3);
  const col1X = margin;
  const col2X = margin + 65;
  const col3X = margin + 115;
  const lineLen1 = 55.0;
  const lineLen2 = 40.0;
  const lineLen3 = 50.0;

  _drawSignatureRow(
    page,
    yPos,
    col1X,
    col2X,
    col3X,
    lineLen1,
    lineLen2,
    lineLen3,
    label: 'Manager',
    dateText: data.signatures.managerDate.isEmpty
        ? 'Date'
        : data.signatures.managerDate,
    witnessText: data.signatures.managerWitness.isEmpty
        ? 'Witness'
        : data.signatures.managerWitness,
    signature: data.signatures.managerSignature,
  );

  yPos += 13;

  _drawSignatureRow(
    page,
    yPos,
    col1X,
    col2X,
    col3X,
    lineLen1,
    lineLen2,
    lineLen3,
    label: 'Accepted',
    dateText: data.signatures.acceptedDate.isEmpty
        ? 'Date'
        : data.signatures.acceptedDate,
    witnessText: data.signatures.acceptedWitness.isEmpty
        ? 'Witness'
        : data.signatures.acceptedWitness,
    signature: data.signatures.acceptedSignature,
  );

  yPos += 7.5;
  return yPos;
}

void _drawSignatureRow(
  PageCtx page,
  double yPos,
  double col1X,
  double col2X,
  double col3X,
  double lineLen1,
  double lineLen2,
  double lineLen3, {
  required String label,
  required String dateText,
  required String witnessText,
  required String signature,
}) {
  page.line(col1X, yPos, col1X + lineLen1, yPos);
  page.line(col2X, yPos, col2X + lineLen2, yPos);
  page.line(col3X, yPos, col3X + lineLen3, yPos);

  drawFittedSignature(
    page,
    signature,
    cellX: col1X + 1,
    cellY: yPos - 7,
    cellW: lineLen1 - 2,
    cellH: 6,
  );

  final labelY = yPos + 3;
  page.text(label, col1X + lineLen1 / 2, labelY,
      size: 7.5, style: 'normal', align: 'center');
  page.text(dateText, col2X + lineLen2 / 2, labelY,
      size: 7.5, style: 'normal', align: 'center');
  page.text(witnessText, col3X + lineLen3 / 2, labelY,
      size: 7.5, style: 'normal', align: 'center');
}
