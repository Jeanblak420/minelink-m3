// Port of `generateMonthlyFireFightingInspectionPDF` in src/utils/pdfGenerator.ts (4394-4483).

import 'dart:math' as math;

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _bannerBg = PdfColor.fromInt(0xffdcdcdc);
const PdfColor _labelBg = PdfColor.fromInt(0xffdcdcdc);
const PdfColor _headFill = PdfColor.fromInt(0xffe6e6e6);

Future<pw.Document> generateMonthlyFireFightingInspectionPdf(
    MonthlyFireFightingInspectionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Monthly Fire Fighting Inspection',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(PageCtx page, MonthlyFireFightingInspectionFormData data,
    dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Monthly Fire Fighting Equipment Inspection Report'],
    ],
    style: const GridStyle(
      fontSize: 12.8,
      cellPaddingTop: 2.1,
      cellPaddingBottom: 2.1,
      minCellHeight: 9,
    ),
  );
  y += 3;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _bannerBg),
    ],
    body: const [
      [
        'MONTHLY:  Inspection by Appointed Competent Person to Fire Master by the 25th of each month'
      ],
    ],
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 1.8,
      cellPaddingBottom: 1.8,
      minCellHeight: 6,
    ),
  );
  y += 2;

  // Department / Area + Name / Designation
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 28, fontStyle: 'bold', fillColor: _labelBg),
      GridColumn(cellWidth: contentWidth - 28),
    ],
    body: [
      ['Department', data.department],
      ['Area', data.area],
    ],
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 28, fontStyle: 'bold', fillColor: _labelBg),
      const GridColumn(cellWidth: 84),
      const GridColumn(cellWidth: 24, fontStyle: 'bold', fillColor: _labelBg),
      GridColumn(cellWidth: contentWidth - 28 - 84 - 24),
    ],
    body: [
      ['Name', data.name, 'Designation', data.designation],
    ],
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
  y += 2;

  // 9-col entries table (pad to >=15 rows)
  final totalRows = math.max(data.entries.length, 15);
  final body = <List<String>>[];
  for (var i = 0; i < totalRows; i++) {
    final e = i < data.entries.length ? data.entries[i] : null;
    body.add([
      e?.workingPlace ?? '',
      e?.localityVehicleNo ?? '',
      e?.inspectionDate ?? '',
      e?.conditionOfSeal ?? '',
      e?.pressureGauge ?? '',
      e?.conditionOfHandleNozzle ?? '',
      e?.conditionOfHose ?? '',
      e?.deficiency ?? '',
      e?.dateOfLastAnnualService ?? '',
    ]);
  }
  // total = 27+20+18+18+21+22+16+20+21 = 183mm; remaining ~12mm goes to last col
  final lastColW = contentWidth - (27 + 20 + 18 + 18 + 21 + 22 + 16 + 20);
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 27),
      const GridColumn(cellWidth: 20, halign: 'center'),
      const GridColumn(cellWidth: 18, halign: 'center'),
      const GridColumn(cellWidth: 18, halign: 'center'),
      const GridColumn(cellWidth: 21, halign: 'center'),
      const GridColumn(cellWidth: 22, halign: 'center'),
      const GridColumn(cellWidth: 16, halign: 'center'),
      const GridColumn(cellWidth: 20),
      GridColumn(cellWidth: lastColW, halign: 'center'),
    ],
    head: const [
      GridHeader(text: 'Working Place', fillColor: _headFill, fontStyle: 'bold'),
      GridHeader(
          text: 'Locality /\nVehicle No.',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Inspection\nDate',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Condition\nof Seal',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Pressure\nGauge\n(Needle in\ngreen section',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Condition\nof Handle\nand Nozzle',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Condition\nof Hose',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Deficiency\n(Action Taken)',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Date of last\nAnnual Service',
          fillColor: _headFill,
          fontStyle: 'bold'),
    ],
    body: body,
    style: const GridStyle(
      fontSize: 6.7,
      cellPaddingTop: 1.2,
      cellPaddingBottom: 1.2,
      minCellHeight: 6.2,
    ),
  );
  y += 4.5;

  // Inspector signature line
  page.text('Signature of Person carrying out Inspection', margin, y,
      size: 8, style: 'bold');
  page.line(margin + 66, y + 0.5, margin + 96, y + 0.5);
  _drawSig(page, data.inspectorSignature, margin + 67, y - 7, 28, 6);
  if (data.inspectorName.isNotEmpty) {
    page.text(data.inspectorName, margin + 68, y, size: 8, style: 'normal');
  }
  page.text('Name', margin + 98, y, size: 8, style: 'normal');
  page.line(margin + 106, y + 0.5, margin + 126, y + 0.5);
  page.text('Date', margin + 128, y, size: 8, style: 'normal');
  page.line(margin + 136, y + 0.5, rightEdge, y + 0.5);
  if (data.inspectorDate.isNotEmpty) {
    page.text(data.inspectorDate, margin + 138, y,
        size: 8, style: 'normal');
  }
  y += 6.5;

  // Section head signature line
  page.text('Signature by Section Head', margin, y, size: 8, style: 'bold');
  page.line(margin + 42, y + 0.5, margin + 78, y + 0.5);
  _drawSig(page, data.sectionHeadSignature, margin + 43, y - 7, 34, 6);
  page.text('Name', margin + 80, y, size: 8, style: 'normal');
  page.line(margin + 88, y + 0.5, margin + 108, y + 0.5);
  if (data.sectionHeadName.isNotEmpty) {
    page.text(data.sectionHeadName, margin + 89, y,
        size: 8, style: 'normal');
  }
  page.text('Date', margin + 110, y, size: 8, style: 'normal');
  page.line(margin + 118, y + 0.5, rightEdge, y + 0.5);
  if (data.sectionHeadDate.isNotEmpty) {
    page.text(data.sectionHeadDate, margin + 120, y,
        size: 8, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 83 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
