// Port of `generateConveyorBeltInspectionPDF` in src/utils/pdfGenerator.ts (3389-3613).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _sectionTitleFill = PdfColor.fromInt(0xffdcdcdc);
const PdfColor _headerFill = PdfColor.fromInt(0xfff0f0f0);
const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);

const List<String> _walkwayLabels = [
  'Is the area adequately illuminated?',
  'Free of obstructions? (Both sides of the belt)',
  'Housekeeping of high standard?',
  'Cross over ladder installed?',
  'Walk way signs posted?',
  'Pillars demarcated according to standard?',
  'Pinch bar holders available with pinch bars?',
  'Safe hangingwall and sidewall?',
  'Geological features demarcated to standard?',
  'Support installed to standard?',
];

const List<({int num, String label})> _beltLabels = [
  (num: 1, label: 'Belt lockout when not in use?'),
  (num: 2, label: 'Pre-use checklist available?'),
  (num: 3, label: 'Pre-use checklist completed according to requirements?'),
  (num: 4, label: 'Operator trained/ licence available?'),
  (num: 5, label: 'Fire extinguisher available?'),
  (num: 6, label: 'Fire extinguisher inspected monthly?'),
  (num: 7, label: 'Fire extinguisher in good working order?'),
  (num: 8, label: 'Housekeeping of high standard?'),
  (num: 9, label: 'All guards installed at tail pulley?'),
  (num: 10, label: 'All guards installed at drive pulley?'),
  (num: 12, label: 'Spillage control at tail pulley?'),
  (num: 13, label: 'Spillage control at drive pulley?'),
  (num: 14, label: 'Spillages controlled along total belt?'),
  (num: 15, label: 'Belt running clear of obstructions?'),
  (num: 16, label: 'Damage/Broken idlers observed along the belt?'),
  (
    num: 17,
    label: 'Primary and secondary scraper in working condition and effective?'
  ),
  (num: 18, label: 'Belt aligned according to the requirements?'),
];

Future<pw.Document> generateConveyorBeltInspectionPdf(
    ConveyorBeltInspectionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Conveyor Belt Inspection',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(
    PageCtx page, ConveyorBeltInspectionFormData data, dynamic logoBytes) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logoBytes) + 3;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Weekly Strike Conveyor Belt Inspection'],
    ],
    style: const GridStyle(
        fontSize: 14,
        cellPaddingTop: 4,
        cellPaddingBottom: 4,
        minCellHeight: 10),
  );
  y += 4;

  // Date of Inspection / Position of the belt
  page.text('Date of Inspection:', margin, y, size: 8, style: 'normal');
  final dateValX = margin + 34;
  drawDotLine(page, dateValX, y + 0.5, 36);
  if (data.dateOfInspection.isNotEmpty) {
    page.text(data.dateOfInspection, dateValX + 1, y,
        size: 8, style: 'normal');
  }
  page.text('Position of the belt:', margin + 76, y,
      size: 8, style: 'normal');
  final posValX = margin + 76 + 38;
  drawDotLine(page, posValX, y + 0.5, rightEdge - posValX);
  if (data.positionOfBelt.isNotEmpty) {
    page.text(data.positionOfBelt, posValX + 1, y,
        size: 8, style: 'normal');
  }
  y += 8.5;

  // Section A: Walkways Conditions
  y = _drawSectionTitle(page, y, contentWidth, 'Walkways Conditions');
  y = _drawItemsTable(
    page,
    y,
    contentWidth,
    _walkwayLabels.map((l) => (num: 0, label: l)).toList(),
    data.walkwayItems,
    numberOverride: (i) => '${i + 1}',
  );
  y += 4;

  // Section B: Belt Condition
  y = _drawSectionTitle(page, y, contentWidth, 'Belt Condition');
  _drawItemsTable(
    page,
    y,
    contentWidth,
    _beltLabels,
    data.beltConditionItems,
    numberOverride: (i) => '${_beltLabels[i].num}',
  );

  // Signature row — placed near the bottom of the page so it's predictable.
  const sigY = 230.0;
  page.text('Signatures:', margin, sigY, size: 8, style: 'bold');
  var sy = sigY + 5.5 + 3;

  drawDotLine(page, margin, sy + 0.5, 55);
  _drawSig(page, data.shiftBossSignature, margin + 1, sy - 6, 53, 5);
  page.text('Shift Boss', margin + 57, sy, size: 8, style: 'normal');
  page.text('Date:', margin + 95, sy, size: 8, style: 'normal');
  drawDotLine(page, margin + 104, sy + 0.5, rightEdge - margin - 104);
  if (data.shiftBossDate.isNotEmpty) {
    page.text(data.shiftBossDate, margin + 105, sy,
        size: 8, style: 'normal');
  }
  sy += 5.5 + 7;

  drawDotLine(page, margin, sy + 0.5, 55);
  _drawSig(page, data.mineManagerOverseerSignature, margin + 1, sy - 6, 53, 5);
  page.text('Mine Manager/Mine Overseer', margin + 57, sy,
      size: 8, style: 'normal');
  page.text('Date:', margin + 120, sy, size: 8, style: 'normal');
  drawDotLine(page, margin + 129, sy + 0.5, rightEdge - margin - 129);
  if (data.mineManagerOverseerDate.isNotEmpty) {
    page.text(data.mineManagerOverseerDate, margin + 130, sy,
        size: 8, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 67 of 84');
}

double _drawSectionTitle(
    PageCtx page, double y, double contentWidth, String title) {
  return drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _sectionTitleFill),
    ],
    body: [
      [title],
    ],
    style: const GridStyle(
      fontSize: 9,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
}

double _drawItemsTable(
  PageCtx page,
  double y,
  double contentWidth,
  List<({int num, String label})> labels,
  List<InspectionItem> items, {
  required String Function(int) numberOverride,
}) {
  const noColW = 10.0;
  const itemColW = 88.0;
  const yesNoColW = 22.0;
  final remedialColW = contentWidth - noColW - itemColW - yesNoColW;

  final body = <List<String>>[];
  for (var i = 0; i < labels.length; i++) {
    final item = i < items.length ? items[i] : InspectionItem();
    body.add([numberOverride(i), labels[i].label, item.yesNo, item.remedialAction]);
  }

  return drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: noColW, halign: 'center'),
      const GridColumn(cellWidth: itemColW),
      const GridColumn(cellWidth: yesNoColW, halign: 'center'),
      GridColumn(cellWidth: remedialColW),
    ],
    head: const [
      GridHeader(
          text: 'No.', fillColor: _headerFill, fontStyle: 'bold'),
      GridHeader(
          text: 'Item',
          fillColor: _headerFill,
          fontStyle: 'bold',
          halign: 'left'),
      GridHeader(
          text: 'Yes/No', fillColor: _headerFill, fontStyle: 'bold'),
      GridHeader(
          text: 'Remedial action taken',
          fillColor: _headerFill,
          fontStyle: 'bold',
          halign: 'left'),
    ],
    body: body,
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 5.5,
    ),
  );
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
