// Port of `generateWaitingPlaceInspectionPDF` in src/utils/pdfGenerator.ts (2353-2598).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _headFill = PdfColor.fromInt(0xff505050);
const PdfColor _sectionFill = PdfColor.fromInt(0xffd2d2d2);

const List<String> _itemLabels = [
  'Is the waiting place sign posted?',
  'Is the dustbin sign posted?',
  'Is the waiting place clean?',
  'Is the waiting place illuminated?',
  'Is the waiting place disinfectant available and disinfected?',
  'Are the seating available?',
  'Are the seating secured and safe?',
  'Are the ticket boards/box available and posted?',
  'Are the ticket boards/box locked?',
  'Are clothing racks available and secured?',
  'Is the waiting place whitewashed?',
  'Are the roofbolts installed in the hangingwall as per mine standard?',
  'Are the geological features demarcated?',
  'Are the geological features supported as per the mine standard?',
  'Are the sidewalls secured?',
  'Are the sidewalls and the hangingwall barred down to solid?',
  'Is the waiting place ventilated?',
  'Good housekeeping?',
  'Is the noticeboard banners posted secured and updated?',
  'Is the entry examination board available, posted and secured?',
  'Is the waiting place barricade available? (Entry to workings)',
  'Are the signs posted?',
  'Level and secured?',
  'Toilets lockable?',
  'Is the toilet clean and disinfected?',
  'Is the area illuminated?',
  'Is the area ventilated?',
  'Is the wash water available?',
  'Is there a good housekeeping in the area?',
];

Future<pw.Document> generateWaitingPlaceInspectionPdf(
    WaitingPlaceInspectionFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Waiting Place Inspection',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(
    PageCtx page, WaitingPlaceInspectionFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Waiting Place Inspection Record'],
    ],
    style: const GridStyle(
      fontSize: 16,
      cellPaddingTop: 4,
      cellPaddingBottom: 4,
      minCellHeight: 11,
    ),
  );
  y += 5;

  // Section / Miner / Date
  page.text('Section:', margin, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 14, y + 0.5, 48);
  page.text('Miner:', margin + 68, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 79, y + 0.5, 36);
  page.text('Date:', margin + 121, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 130, y + 0.5, rightEdge - (margin + 130));
  if (data.section.isNotEmpty) {
    page.text(data.section, margin + 15, y, size: 8, style: 'normal');
  }
  if (data.miner.isNotEmpty) {
    page.text(data.miner, margin + 80, y, size: 8, style: 'normal');
  }
  if (data.date.isNotEmpty) {
    page.text(data.date, margin + 131, y, size: 8, style: 'normal');
  }
  y += 8.5;

  // Build the items table column definitions (same for both sub-tables).
  final cols = [
    const GridColumn(cellWidth: 10, halign: 'center', fontStyle: 'bold'),
    const GridColumn(cellWidth: 100),
    const GridColumn(cellWidth: 12, halign: 'center', fontStyle: 'bold'),
    const GridColumn(cellWidth: 12, halign: 'center', fontStyle: 'bold'),
    GridColumn(cellWidth: contentWidth - 134),
  ];

  // Items 1-21
  final rows1 = <List<String>>[];
  for (var i = 0; i < 21; i++) {
    final item = i < data.items.length ? data.items[i] : WaitingPlaceCheckItem();
    rows1.add([
      '${i + 1}',
      _itemLabels[i],
      item.yes ? '✓' : '',
      item.no ? '✓' : '',
      item.remarks,
    ]);
  }
  y = drawAutoTable(
    page,
    startY: y,
    columns: cols,
    head: const [
      GridHeader(text: 'No.', fillColor: _headFill, textColor: PdfColors.white),
      GridHeader(
          text: 'Items Checked',
          fillColor: _headFill,
          textColor: PdfColors.white,
          halign: 'left'),
      GridHeader(text: 'Yes', fillColor: _headFill, textColor: PdfColors.white),
      GridHeader(text: 'No', fillColor: _headFill, textColor: PdfColors.white),
      GridHeader(
          text: 'Remarks',
          fillColor: _headFill,
          textColor: PdfColors.white,
          halign: 'left'),
    ],
    body: rows1,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 4.5,
    ),
  );

  // Mid-table section divider (full-width grey title row)
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(
          cellWidth: contentWidth, halign: 'center', fillColor: _sectionFill),
    ],
    body: const [
      ['UNDERGROUND PORTABLE TOILETS'],
    ],
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 5,
    ),
  );

  // Items 22-29 (no header repeat)
  final rows2 = <List<String>>[];
  for (var i = 21; i < 29; i++) {
    final item = i < data.items.length ? data.items[i] : WaitingPlaceCheckItem();
    rows2.add([
      '${i + 1}',
      _itemLabels[i],
      item.yes ? '✓' : '',
      item.no ? '✓' : '',
      item.remarks,
    ]);
  }
  y = drawAutoTable(
    page,
    startY: y,
    columns: cols,
    body: rows2,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 4.5,
    ),
  );
  y += 6;

  // Special instructions — first line beside label, 2 continuation dotted lines
  const fs = 8.0;
  const lineH = 5.5;
  page.text('Special instructions given:', margin, y,
      size: fs, style: 'bold');
  const specTextX = margin + 49.0;
  if (data.specialInstructions.isNotEmpty) {
    final lines = page.splitTextToSize(
        data.specialInstructions, rightEdge - specTextX, fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, specTextX, y, size: fs, style: 'normal');
    }
  }
  drawDotLine(page, specTextX, y + 0.5, rightEdge - specTextX);
  y += lineH;
  drawDotLine(page, margin, y + 0.5, contentWidth);
  y += lineH;
  drawDotLine(page, margin, y + 0.5, contentWidth);
  y += lineH + 6;

  // Signatures
  page.text('Signature:', margin, y, size: fs, style: 'bold');
  y += lineH + 2;

  page.text('Shift Boss:', margin, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 22, y + 0.5, 62);
  page.text('Date:', margin + 91, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 101, y + 0.5, rightEdge - (margin + 101));
  _drawSig(page, data.shiftBossSignature, margin + 23, y - 6, 60, 5);
  if (data.shiftBossDate.isNotEmpty) {
    page.text(data.shiftBossDate, margin + 102, y,
        size: fs, style: 'normal');
  }
  y += lineH + 6;

  page.text('Mine Overseer:', margin, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 29, y + 0.5, 55);
  page.text('Date:', margin + 91, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 101, y + 0.5, rightEdge - (margin + 101));
  _drawSig(page, data.mineOverseerSignature, margin + 30, y - 6, 53, 5);
  if (data.mineOverseerDate.isNotEmpty) {
    page.text(data.mineOverseerDate, margin + 102, y,
        size: fs, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 63 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
