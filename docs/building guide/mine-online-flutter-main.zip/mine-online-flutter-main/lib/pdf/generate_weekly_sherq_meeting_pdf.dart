// Port of `generateWeeklySherqMeetingPDF` in src/utils/pdfGenerator.ts (1558-1840).

import 'dart:math' as math;
import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _greyBg = PdfColor.fromInt(0xffc0c0c0);

Future<pw.Document> generateWeeklySherqMeetingPdf(
    WeeklySherqMeetingFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Weekly SHERQ Meeting',
    draw: (page) => _draw(page, formData, logoBytes),
  );
}

void _draw(
    PageCtx page, WeeklySherqMeetingFormData data, Uint8List? logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3.5;

  // Title bar (bordered grey strip)
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: const [
      GridHeader(text: 'Weekly SHERQ Meeting', fillColor: _greyBg),
    ],
    body: const [],
    style: const GridStyle(
      fontSize: 16,
      cellPaddingTop: 5,
      cellPaddingBottom: 5,
      minCellHeight: 14,
    ),
  );
  y += 4;

  // Meeting details — 3 rows × 4 cols, alternating label/value
  final half = contentWidth / 2;
  final labelW = half * 0.36;
  final valueW = half * 0.64;
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: labelW, fontStyle: 'bold', fillColor: _greyBg),
      GridColumn(cellWidth: valueW),
      GridColumn(cellWidth: labelW, fontStyle: 'bold', fillColor: _greyBg),
      GridColumn(cellWidth: valueW),
    ],
    body: [
      ['Date', data.date, 'Time', data.time],
      ['Workplace', data.workplace, 'Duration', data.duration],
      [
        'Supervisor Coy No.',
        data.supervisorCoyNo,
        'SHE REP Coy No.',
        data.sheRepCoyNo
      ],
    ],
    style: const GridStyle(
      fontSize: 9,
      cellPaddingTop: 2.5,
      cellPaddingBottom: 2.5,
      minCellHeight: 7,
    ),
  );
  y += 4;

  // GUIDE line
  page.text('GUIDE', margin + 40, y, size: 9, style: 'bold');
  page.text(': the following points were discussed at the meeting',
      margin + 52, y, size: 9, style: 'normal');
  y += 3;

  String tick(bool v) => v ? 'X' : '';
  final t = data.topics;
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth * 0.12, halign: 'center'),
      GridColumn(cellWidth: contentWidth * 0.17, halign: 'center'),
      GridColumn(cellWidth: contentWidth * 0.06, halign: 'center'),
      GridColumn(cellWidth: contentWidth * 0.14, halign: 'center'),
      GridColumn(cellWidth: contentWidth * 0.06, halign: 'center'),
      GridColumn(cellWidth: contentWidth * 0.22, halign: 'center'),
      GridColumn(cellWidth: contentWidth * 0.06, halign: 'center'),
    ],
    body: [
      [
        'Topics',
        'Standards',
        tick(t.standards),
        'Incident',
        tick(t.incident),
        'Emergency Preparedness',
        tick(t.emergencyPreparedness)
      ],
      [
        'S/O Report',
        'Instruction',
        tick(t.instruction),
        '',
        tick(t.soReport),
        'Rock mechanic Report',
        tick(t.rockMechanicReport)
      ],
      [
        'PPE',
        'SHE REP Report',
        tick(t.sheRepReport),
        'Procedures',
        tick(t.procedures),
        'Vent Report',
        tick(t.ventReport)
      ],
    ],
    style: const GridStyle(
      fontSize: 9,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );

  y = _drawDescriptionBlock(page, y, contentWidth,
      'Short Description of Matters Discussed', data.mattersDiscussed);
  y = _drawDescriptionBlock(page, y, contentWidth,
      'Short Description of Feedback from Crew', data.feedbackFromCrew);

  // Attendance grid (5 rows × 4 cols)
  final attendRows = <List<String>>[];
  for (var i = 0; i < 5; i++) {
    final left = i * 2 < data.attendance.length
        ? data.attendance[i * 2]
        : AttendanceEntry();
    final right = i * 2 + 1 < data.attendance.length
        ? data.attendance[i * 2 + 1]
        : AttendanceEntry();
    attendRows.add(
        [left.coyNo, left.signature, right.coyNo, right.signature]);
  }
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth / 4),
      GridColumn(cellWidth: contentWidth / 4),
      GridColumn(cellWidth: contentWidth / 4),
      GridColumn(cellWidth: contentWidth / 4),
    ],
    head: const [
      GridHeader(text: 'Coy No.', fillColor: _greyBg, fontStyle: 'bold'),
      GridHeader(text: 'Signature', fillColor: _greyBg, fontStyle: 'bold'),
      GridHeader(text: 'Coy No.', fillColor: _greyBg, fontStyle: 'bold'),
      GridHeader(text: 'Signature', fillColor: _greyBg, fontStyle: 'bold'),
    ],
    body: attendRows,
    style: const GridStyle(
      fontSize: 8,
      cellPaddingTop: 2.5,
      cellPaddingBottom: 2.5,
      minCellHeight: 8,
    ),
  );

  // Supervisor + SHE Rep signature row
  final supervisorBytes = decodeSignatureBytes(data.supervisorSignature);
  final sheRepBytes = decodeSignatureBytes(data.sheRepSignature);
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(
          cellWidth: contentWidth / 4, fontStyle: 'bold', fillColor: _greyBg),
      GridColumn(cellWidth: contentWidth / 4),
      GridColumn(
          cellWidth: contentWidth / 4, fontStyle: 'bold', fillColor: _greyBg),
      GridColumn(cellWidth: contentWidth / 4),
    ],
    body: const [
      ['Supervisor Signature', '', 'SHE Rep Signature', ''],
    ],
    cellSignature: (row, col) {
      if (row != 0) return null;
      if (col == 1) return supervisorBytes;
      if (col == 3) return sheRepBytes;
      return null;
    },
    style: const GridStyle(
      fontSize: 9,
      cellPaddingTop: 2.5,
      cellPaddingBottom: 2.5,
      minCellHeight: 14,
    ),
  );
  y += 8;

  // Final shift-boss / mine-overseer signature lines with dotted underline
  page.text('Shift Boss Signature:', margin, y, size: 9, style: 'normal');
  drawDotLine(page, margin + 36, y + 1, 55);
  _drawSig(page, data.shiftBossSignature, margin + 37, y - 7, 53, 6);

  final overseerLabelX = margin + contentWidth / 2;
  page.text('Mine Overseer Signature:', overseerLabelX, y,
      size: 9, style: 'normal');
  drawDotLine(page, overseerLabelX + 44, y + 1, contentWidth / 2 - 44);
  _drawSig(page, data.mineOverseerSignature, overseerLabelX + 45, y - 7,
      contentWidth / 2 - 46, 6);

  drawInspectionFooter(page, pageNum: 'Page 57 of 84');
}

double _drawDescriptionBlock(
    PageCtx page, double y, double contentWidth, String title, String text) {
  // Single-cell title row
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: [
      GridHeader(
          text: title, fillColor: _greyBg, fontStyle: 'bold'),
    ],
    body: const [],
    style: const GridStyle(fontSize: 9, minCellHeight: 7),
  );

  // 3 body rows with [10mm gutter] + [remaining]
  final rows = <List<String>>[];
  rows.add([
    '',
    text.length > 100 ? text.substring(0, 100) : (text.isEmpty ? '' : text)
  ]);
  rows.add([
    '',
    text.length > 100
        ? text.substring(100, math.min(200, text.length))
        : ''
  ]);
  rows.add(['', text.length > 200 ? text.substring(200) : '']);
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 10),
      GridColumn(cellWidth: contentWidth - 10),
    ],
    body: rows,
    style: const GridStyle(fontSize: 8, minCellHeight: 7),
  );
  return y;
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
