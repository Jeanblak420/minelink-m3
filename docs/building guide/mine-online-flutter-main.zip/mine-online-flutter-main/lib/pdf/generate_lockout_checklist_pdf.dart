// Port of `generateLockoutLockScissorChecklistPDF`
// in src/utils/pdfGenerator.ts (4487-4530).

import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _warnFill = PdfColor.fromInt(0xfffac800);
const PdfColor _warnText = PdfColor.fromInt(0xff643200);
const PdfColor _headerFill = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _rowHeaderFill = PdfColor.fromInt(0xffe6e6e6);

Future<pw.Document> generateLockoutChecklistPdf(
    LockoutLockScissorChecklistFormData formData) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Lockout Lock Scissor Checklist',
    draw: (page) => _draw(page, formData, logoBytes),
  );
}

void _draw(PageCtx page, LockoutLockScissorChecklistFormData data,
    Uint8List? logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: const [
      GridHeader(
        text:
            'Monthly Lock-out Lock and Scissor Checklist for the Drill Rig /\nBolter Operator / Assistant',
        fillColor: _headerFill,
      ),
    ],
    body: const [],
    style: const GridStyle(fontSize: 11.7, minCellHeight: 11.5),
  );
  y += 3;

  // Main grid: header + sub-header (YES/NO row) + entries
  final body = <List<String>>[
    // Sub-header row uses empty columns where the entry rows have name/operator/workplace
    ['', '', '', 'YES/NO', 'YES/NO', 'YES/NO', '', ''],
    for (final entry in data.entries)
      [
        entry.nameSurname,
        entry.operatorAssistant,
        entry.workplace,
        entry.trainedOnLockOut,
        entry.lockAvailable,
        entry.scissorAvailable,
        entry.date,
        entry.signature,
      ],
  ];

  // Calculate signature column width to fill remaining space
  final fixedW = 40.0 + 30.0 + 28.0 + 22.0 + 22.0 + 22.0 + 22.0;
  final sigW = contentWidth - fixedW;

  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 40),
      const GridColumn(cellWidth: 30),
      const GridColumn(cellWidth: 28),
      const GridColumn(cellWidth: 22, halign: 'center'),
      const GridColumn(cellWidth: 22, halign: 'center'),
      const GridColumn(cellWidth: 22, halign: 'center'),
      const GridColumn(cellWidth: 22),
      GridColumn(cellWidth: sigW > 0 ? sigW : 50),
    ],
    head: const [
      GridHeader(text: 'Name & Surname', fillColor: _rowHeaderFill),
      GridHeader(text: 'Operator/Assistant', fillColor: _rowHeaderFill),
      GridHeader(text: 'Workplace', fillColor: _rowHeaderFill),
      GridHeader(text: 'Trained\non Lock\nOut', fillColor: _rowHeaderFill),
      GridHeader(text: 'Lock\nAvailable', fillColor: _rowHeaderFill),
      GridHeader(text: 'Scissor\nAvailable', fillColor: _rowHeaderFill),
      GridHeader(text: 'Date:', fillColor: _rowHeaderFill),
      GridHeader(text: 'Signature', fillColor: _rowHeaderFill),
    ],
    body: body,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      cellPaddingLeft: 1.5,
      cellPaddingRight: 1.5,
      minCellHeight: 6.2,
      lineWidth: 0.3,
    ),
  );
  y += 2;

  // Warning banner
  y = drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth, halign: 'center')],
    head: const [
      GridHeader(
        text:
            'UNDER NO CIRCUMSTANCES may an Operator / Assistant perform work without lock-out equipment!!',
        fillColor: _warnFill,
        textColor: _warnText,
      ),
    ],
    body: const [],
    style: const GridStyle(
      fontSize: 8.4,
      minCellHeight: 8.5,
      lineWidth: 0.3,
    ),
  );
  y += 4.5;

  page.text('Shift Boss Signature:', margin, y,
      size: 8, style: 'normal');
  drawDotLine(page, margin + 34, y + 0.5, 60);

  drawFittedSignature(
    page,
    data.shiftBossSignature,
    cellX: margin + 35,
    cellY: y - 6,
    cellW: 58,
    cellH: 6,
  );

  drawInspectionFooter(page, pageNum: 'Page 84 of 84');
}
