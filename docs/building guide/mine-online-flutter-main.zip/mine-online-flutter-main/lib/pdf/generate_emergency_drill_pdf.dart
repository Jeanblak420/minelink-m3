// Port of `buildEmergencyDrillPDF` in src/utils/pdfGenerator.ts (4273-4316).
// Shared between verbal and physical emergency drill forms.

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _subTitleBg = PdfColor.fromInt(0xffdcdcdc);

Future<pw.Document> generateEmergencyDrillPdf(
  EmergencyDrillFormData data, {
  required String title,
  required String pageNum,
  required String subject,
}) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: subject,
    draw: (page) => _draw(page, data, logoBytes, title, pageNum),
  );
}

void _draw(PageCtx page, EmergencyDrillFormData data, dynamic logo,
    String title, String pageNum) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: [
      [title],
    ],
    style: const GridStyle(
      fontSize: 13.2,
      cellPaddingTop: 2.1,
      cellPaddingBottom: 2.1,
      minCellHeight: 9,
    ),
  );
  y += 3;

  // Instruction paragraph
  final intro = page.splitTextToSize(
      'Record one complete Emergency Drill carried out by the Team to find out if they know the escape routes and procedures. Explain what Emergency Drill was performed',
      contentWidth,
      8,
      'normal');
  for (final line in intro) {
    page.text(line, margin, y, size: 8, style: 'normal');
    y += 3.4;
  }
  y += 3;

  // Section banner
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['This must be checked Monthly'],
    ],
    style: const GridStyle(
      fontSize: 9.2,
      cellPaddingTop: 2.2,
      cellPaddingBottom: 2.2,
      minCellHeight: 7,
    ),
  );

  // 4-col row: Date / value / Refuge Bay No / value
  final labelW = 40.0;
  final smallLabelW = 35.0;
  final valueW = (contentWidth - labelW - smallLabelW) / 2;
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: labelW, fontStyle: 'bold', fillColor: _subTitleBg),
      GridColumn(cellWidth: valueW),
      GridColumn(
          cellWidth: smallLabelW, fontStyle: 'bold', fillColor: _subTitleBg),
      GridColumn(cellWidth: valueW),
    ],
    body: [
      ['Date', data.date, 'Refuge Bay No:', data.refugeBayNo],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 6,
    ),
  );

  // 2-col rows
  final labeledCols = [
    GridColumn(cellWidth: labelW, fontStyle: 'bold', fillColor: _subTitleBg),
    GridColumn(cellWidth: contentWidth - labelW),
  ];
  y = drawAutoTable(
    page,
    startY: y,
    columns: labeledCols,
    body: [
      ['Working place', data.workingPlace],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 6,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: labeledCols,
    body: [
      ['Emergency Drill performed', data.emergencyDrillPerformed],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 16,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: labeledCols,
    body: [
      ['Deficiencies observed', data.deficienciesObserved],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 20,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: labeledCols,
    body: [
      ['Recommended Improvements', data.recommendedImprovements],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 20,
    ),
  );
  y = drawAutoTable(
    page,
    startY: y,
    columns: labeledCols,
    body: [
      ['Refuge Bay situated at', data.refugeBaySituatedAt],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 6,
    ),
  );

  // Employees attended banner
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(
          cellWidth: contentWidth, halign: 'center', fillColor: _subTitleBg),
    ],
    body: const [
      ['The following employees attended the Drill Meeting'],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.7,
      cellPaddingBottom: 1.7,
      minCellHeight: 6,
    ),
  );

  // Employees 3-col grid
  final empColW = contentWidth / 3;
  drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: empColW),
      GridColumn(cellWidth: empColW),
      GridColumn(cellWidth: empColW),
    ],
    body: data.employees.map((e) => [e.col1, e.col2, e.col3]).toList(),
    style: const GridStyle(
      fontSize: 7.4,
      cellPaddingTop: 1.8,
      cellPaddingBottom: 1.8,
      minCellHeight: 6.2,
    ),
  );

  drawInspectionFooter(page, pageNum: pageNum);
}
