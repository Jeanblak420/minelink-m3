// Mirrors `buildSimpleInspectionDoc` in src/utils/pdfGenerator.ts (lines 3616-3718).
// Provides the shared "Logbook - Shift Boss" header + footer used by most forms
// other than the Shift Boss appointment itself.

import 'dart:typed_data';

import 'package:pdf/pdf.dart';

import 'pdf_runtime.dart';

class InspectionDocFrame {
  InspectionDocFrame({required this.margin, required this.contentWidth});
  final double margin;
  final double contentWidth;
}

/// Draws the standard Mine Online header for an inspection-style form and
/// returns the Y position where body content can start. Mirrors `drawHeader`.
double drawInspectionHeader(
  PageCtx page, {
  required double startY,
  Uint8List? logoBytes,
}) {
  final pageWidthMm = page.pageWidth;
  const margin = 10.5;
  final contentWidth = pageWidthMm - 2 * margin;
  final headerTop = startY + 1.1;
  const headerHeight = 33.1;
  const logoColWidth = 37.0;
  const labelColWidth = 16.2;
  const valueColWidth = 19.1;
  final centerColWidth = contentWidth - logoColWidth - labelColWidth - valueColWidth;
  final centerX = margin + logoColWidth + centerColWidth / 2;
  final headerRightX = margin + logoColWidth + centerColWidth;
  final metaRowHeight = headerHeight / 3;

  page.setLineWidth(0.35);
  page.setDrawColor(borderColor);
  page.rectStroke(margin, headerTop, contentWidth, headerHeight);
  page.line(margin + logoColWidth, headerTop, margin + logoColWidth,
      headerTop + headerHeight);
  page.line(headerRightX, headerTop, headerRightX, headerTop + headerHeight);
  page.line(headerRightX + labelColWidth, headerTop,
      headerRightX + labelColWidth, headerTop + headerHeight);
  page.line(headerRightX, headerTop + metaRowHeight, margin + contentWidth,
      headerTop + metaRowHeight);
  page.line(headerRightX, headerTop + metaRowHeight * 2, margin + contentWidth,
      headerTop + metaRowHeight * 2);

  if (logoBytes != null) {
    final logo = page.imageFromBytes(logoBytes);
    page.drawImage(logo, margin + 1.9, headerTop + 2.4, logoColWidth - 4, 18.6);
  }

  page.text('BLACK ROCK MINE OPERATIONS', margin + logoColWidth / 2,
      headerTop + headerHeight - 5.8,
      size: 6, style: 'normal', align: 'center');

  page.text('ASSMANG (PTY) LIMITED', centerX, headerTop + 5.9,
      size: 15.8, style: 'bold', align: 'center');
  page.text('FORM', centerX, headerTop + 13.3,
      size: 10.2, style: 'bold', align: 'center');
  page.text('Logbook - Shift Boss', centerX, headerTop + 20.4,
      size: 10.8, style: 'boldItalic', align: 'center');
  page.text('Document No: FOR-MIN-PROD-GEN-U-2518', centerX, headerTop + 27.7,
      size: 9.1, style: 'bold', align: 'center');

  page.text('Revision', headerRightX + 1.2, headerTop + 3.1,
      size: 7.9, style: 'bold');
  page.text('No.:', headerRightX + 1.2, headerTop + 6.1,
      size: 7.9, style: 'bold');
  page.text('Next', headerRightX + 1.2, headerTop + metaRowHeight + 2.6,
      size: 7.9, style: 'bold');
  page.text('Revision', headerRightX + 1.2, headerTop + metaRowHeight + 5.6,
      size: 7.9, style: 'bold');
  page.text('Date:', headerRightX + 1.2, headerTop + metaRowHeight + 8.6,
      size: 7.9, style: 'bold');
  page.text('Effective', headerRightX + 1.2,
      headerTop + metaRowHeight * 2 + 3.1,
      size: 7.9, style: 'bold');
  page.text('Date:', headerRightX + 1.2, headerTop + metaRowHeight * 2 + 6.1,
      size: 7.9, style: 'bold');

  page.text('6.0', margin + contentWidth - 1.8, headerTop + 3.6,
      size: 7.8, style: 'normal', align: 'right');
  page.text('16/08/2026', margin + contentWidth - 1.8,
      headerTop + metaRowHeight + 7.2,
      size: 7.8, style: 'normal', align: 'right');
  page.text('16/08/2023', margin + contentWidth - 1.8,
      headerTop + metaRowHeight * 2 + 7.1,
      size: 7.8, style: 'normal', align: 'right');

  return headerTop + headerHeight;
}

/// Draws the standard inspection footer with the configurable page number.
void drawInspectionFooter(
  PageCtx page, {
  required String pageNum,
}) {
  final pageWidth = page.pageWidth;
  final pageHeight = page.pageHeight;
  const margin = 10.5;
  final contentWidth = pageWidth - 2 * margin;
  final footerLineY = pageHeight - 29.4;

  page.setLineWidth(0.4);
  page.line(margin, footerLineY, pageWidth - margin, footerLineY);
  page.text('NOTE:', margin, footerLineY + 3.2, size: 6.2, style: 'bold');
  page.text(
    'Uncontrolled Copy - This document is only valid if same as Master Document on DMMA',
    margin + 9.5,
    footerLineY + 3.2,
    size: 6.2,
    style: 'normal',
  );
  page.text(pageNum, pageWidth - margin, footerLineY + 3.2,
      size: 6.2, style: 'bold', align: 'right');

  const popiText =
      'POPI ACT: BRMO guarantees to keep and use your Information only for the purpose it was collected for. When that purpose is no longer effective, the Information will be destroyed beyond reconstruction, except when there is a statutory or regulatory obligation that requires BRMO to keep your Information for a specific period that is longer than the purpose for which it was received.';
  final popiLines =
      page.splitTextToSize(popiText, contentWidth - 8, 5.15, 'italic');
  var popiY = footerLineY + 6.6;
  for (final line in popiLines) {
    page.text(line, pageWidth / 2, popiY,
        size: 5.15, style: 'italic', align: 'center');
    popiY += 1.9;
  }
  page.text('©Assmang (Pty) Limited, P O Box 187, Santoy, 8491',
      pageWidth / 2, pageHeight - 3.6,
      size: 6.15, style: 'normal', align: 'center');
}

/// Dotted horizontal line — mirrors `drawDotLine`. Simplified to a regular
/// thin line because the pdf package's dashed support is awkward for short
/// runs; visually the difference is negligible.
void drawDotLine(PageCtx page, double x, double y, double w) {
  page.canvas.setLineWidth(0.2);
  page.line(x, y, x + w, y);
}

/// Minimal autoTable-style grid renderer. Supports:
/// * single header row (optional)
/// * uniform fontSize / cellPadding / minCellHeight
/// * per-column cellWidth, fontStyle, fillColor, halign
/// * per-cell signature image via `cellSignature(row, col)`
/// Returns the Y after the last drawn row (mirrors `lastAutoTable.finalY`).
class GridStyle {
  final double fontSize;
  final double cellPaddingTop;
  final double cellPaddingBottom;
  final double cellPaddingLeft;
  final double cellPaddingRight;
  final double minCellHeight;
  final double lineWidth;
  final PdfColor lineColor;
  const GridStyle({
    this.fontSize = 7.5,
    this.cellPaddingTop = 1.2,
    this.cellPaddingBottom = 1.2,
    this.cellPaddingLeft = 2.0,
    this.cellPaddingRight = 2.0,
    this.minCellHeight = 5.0,
    this.lineWidth = 0.35,
    this.lineColor = borderColor,
  });
}

class GridColumn {
  final double cellWidth;
  final String fontStyle; // 'normal' | 'bold' | 'italic' | 'boldItalic'
  final PdfColor? fillColor;
  final String halign; // 'left' | 'center' | 'right'
  const GridColumn({
    required this.cellWidth,
    this.fontStyle = 'normal',
    this.fillColor,
    this.halign = 'left',
  });
}

class GridHeader {
  final String text;
  final PdfColor fillColor;
  final PdfColor textColor;
  final String fontStyle;
  final String halign;
  const GridHeader({
    required this.text,
    this.fillColor = lightFill,
    this.textColor = PdfColors.black,
    this.fontStyle = 'bold',
    this.halign = 'center',
  });
}

double drawAutoTable(
  PageCtx page, {
  required double startY,
  required List<GridColumn> columns,
  required List<List<String>> body,
  List<GridHeader>? head,
  GridStyle style = const GridStyle(),
  Uint8List? Function(int row, int col)? cellSignature,
  String headFontStyle = 'bold',
}) {
  const margin = 10.5;
  page.setLineWidth(style.lineWidth);

  double y = startY;
  // Header
  if (head != null && head.isNotEmpty) {
    final headerHeight = style.minCellHeight;
    double x = margin;
    for (var c = 0; c < head.length; c++) {
      final col = head[c];
      page.rectFillStroke(x, y, columns[c].cellWidth, headerHeight, col.fillColor);
      // Split header text by newline
      final lines = col.text.split('\n');
      final lineHeight = style.fontSize * 0.45;
      final totalH = lineHeight * lines.length;
      var ty = y + (headerHeight - totalH) / 2 + lineHeight;
      for (final line in lines) {
        final tx = _alignX(x, columns[c].cellWidth, col.halign,
            style.cellPaddingLeft, style.cellPaddingRight);
        page.text(line, tx, ty,
            size: style.fontSize,
            style: col.fontStyle,
            align: col.halign,
            color: col.textColor);
        ty += lineHeight;
      }
      x += columns[c].cellWidth;
    }
    y += headerHeight;
  }

  // Body
  for (var r = 0; r < body.length; r++) {
    final row = body[r];
    // Compute row height = max of (minCellHeight) and (text height per cell)
    double rowHeight = style.minCellHeight;
    final wrappedCells = <List<String>>[];
    for (var c = 0; c < row.length && c < columns.length; c++) {
      final col = columns[c];
      final innerWidth =
          col.cellWidth - style.cellPaddingLeft - style.cellPaddingRight;
      final wrapped = page.splitTextToSize(
          row[c], innerWidth, style.fontSize, col.fontStyle);
      wrappedCells.add(wrapped);
      final neededH = style.cellPaddingTop +
          style.cellPaddingBottom +
          wrapped.length * (style.fontSize * 0.45);
      if (neededH > rowHeight) rowHeight = neededH;
    }

    double x = margin;
    for (var c = 0; c < row.length && c < columns.length; c++) {
      final col = columns[c];
      if (col.fillColor != null) {
        page.rectFillStroke(x, y, col.cellWidth, rowHeight, col.fillColor!);
      } else {
        page.rectStroke(x, y, col.cellWidth, rowHeight);
      }

      final sig = cellSignature?.call(r, c);
      if (sig != null && sig.isNotEmpty) {
        const pad = 2.0;
        drawFittedSignatureBytes(
          page,
          sig,
          cellX: x + pad,
          cellY: y + pad,
          cellW: col.cellWidth - pad * 2,
          cellH: rowHeight - pad * 2,
        );
      } else {
        final lineHeight = style.fontSize * 0.45;
        var ty = y + style.cellPaddingTop + lineHeight;
        for (final line in wrappedCells[c]) {
          final tx = _alignX(x, col.cellWidth, col.halign,
              style.cellPaddingLeft, style.cellPaddingRight);
          page.text(line, tx, ty,
              size: style.fontSize, style: col.fontStyle, align: col.halign);
          ty += lineHeight;
        }
      }

      x += col.cellWidth;
    }
    y += rowHeight;
  }

  return y;
}

double _alignX(
    double cellX, double cellW, String halign, double padL, double padR) {
  switch (halign) {
    case 'center':
      return cellX + cellW / 2;
    case 'right':
      return cellX + cellW - padR;
    default:
      return cellX + padL;
  }
}

/// Cell descriptor for [drawSpanningHeader] — supports rowSpan / colSpan
/// (mirrors jsPDF-autotable head-row cell objects).
class SpanCell {
  final String text;
  final int colSpan;
  final int rowSpan;
  final PdfColor fillColor;
  final PdfColor textColor;
  final String fontStyle;
  final String halign;
  final double fontSize;

  const SpanCell({
    required this.text,
    this.colSpan = 1,
    this.rowSpan = 1,
    this.fillColor = lightFill,
    this.textColor = borderColor,
    this.fontStyle = 'bold',
    this.halign = 'center',
    this.fontSize = 7,
  });
}

/// Draws a multi-row header where cells can span columns / rows. Caller
/// supplies the per-column widths so the header lines up with the body that
/// follows. Returns the Y after the header band.
double drawSpanningHeader(
  PageCtx page, {
  required double startY,
  required double leftX,
  required List<double> columnWidths,
  required List<List<SpanCell>> rows,
  double rowHeight = 6,
  double lineWidth = 0.35,
}) {
  page.setLineWidth(lineWidth);

  final cumX = <double>[leftX];
  for (final w in columnWidths) {
    cumX.add(cumX.last + w);
  }

  // Grid of (row, col) cells already painted by an earlier rowSpan.
  final occupied = <int>{};
  int key(int r, int c) => r * 1000 + c;

  for (var r = 0; r < rows.length; r++) {
    var c = 0;
    for (final cell in rows[r]) {
      while (occupied.contains(key(r, c))) {
        c++;
      }
      final x = cumX[c];
      var w = 0.0;
      for (var i = 0; i < cell.colSpan; i++) {
        w += columnWidths[c + i];
      }
      final h = cell.rowSpan * rowHeight;
      final y = startY + r * rowHeight;
      page.rectFillStroke(x, y, w, h, cell.fillColor);

      final lines = cell.text.split('\n');
      final lineH = cell.fontSize * 0.45;
      final totalH = lineH * lines.length;
      var ty = y + (h - totalH) / 2 + lineH;
      for (final line in lines) {
        final tx = _alignX(x, w, cell.halign, 1, 1);
        page.text(line, tx, ty,
            size: cell.fontSize,
            style: cell.fontStyle,
            align: cell.halign,
            color: cell.textColor);
        ty += lineH;
      }

      for (var dr = 0; dr < cell.rowSpan; dr++) {
        for (var dc = 0; dc < cell.colSpan; dc++) {
          occupied.add(key(r + dr, c + dc));
        }
      }
      c += cell.colSpan;
    }
  }

  return startY + rows.length * rowHeight;
}
