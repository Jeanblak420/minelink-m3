// SP8 Reports — flowing PDF (pw.MultiPage, auto-pagination) for a period
// compliance report: KPI summary, breakdown tables, and the submission
// register. Mirrors generate_custom_form_pdf.dart for fonts/format.

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../utils/analytics_data.dart' show sortedDesc;
import '../utils/report_data.dart';

const _periodTitle = {
  ReportPeriod.daily: 'Daily Report',
  ReportPeriod.weekly: 'Weekly Report',
  ReportPeriod.monthly: 'Monthly Report',
};

String _d(DateTime s) =>
    '${s.year}-${s.month.toString().padLeft(2, '0')}-${s.day.toString().padLeft(2, '0')}';

Future<pw.Document> generateReportPdf(
  ReportSummary s, {
  DateTime? generatedAt,
}) async {
  final base = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Regular.ttf'),
  );
  final bold = pw.Font.ttf(
    await rootBundle.load('assets/fonts/Roboto-Bold.ttf'),
  );
  final theme = pw.ThemeData.withFont(base: base, bold: bold);
  final stamp = generatedAt ?? DateTime.now();
  final doc = pw.Document(
    creator: 'Mine Online',
    subject: _periodTitle[s.period],
  );

  final kpis = <List<String>>[
    ['Submissions', '${s.submissions}'],
    ['Fully signed', '${s.fullySigned}'],
    ['Pending in chain', '${s.pendingInChain}'],
    ['Safety incidents', '${s.incidents}'],
    ['Appointments issued', '${s.appointmentsIssued}'],
    ['Appointments accepted', '${s.appointmentsAccepted}'],
    ['Signature completion', '${(s.signatureCompletionRate * 100).round()}%'],
  ];

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.letter,
      theme: theme,
      margin: const pw.EdgeInsets.fromLTRB(36, 36, 36, 36),
      header: (ctx) => ctx.pageNumber == 1
          ? _header(_periodTitle[s.period]!, s.window.label, stamp)
          : pw.SizedBox(),
      footer: (ctx) => pw.Container(
        alignment: pw.Alignment.centerRight,
        margin: const pw.EdgeInsets.only(top: 8),
        child: pw.Text(
          'Page ${ctx.pageNumber} of ${ctx.pagesCount}',
          style: pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
        ),
      ),
      build: (ctx) => [
        _sectionTitle('Summary'),
        _kvTable(kpis),
        _sectionTitle('By form'),
        _countTable(sortedDesc(s.byFormType)),
        _sectionTitle('By workflow status'),
        _countTable(sortedDesc(s.byStatus)),
        _sectionTitle('Submission register (${s.register.length})'),
        _registerTable(s.register),
      ],
    ),
  );
  return doc;
}

pw.Widget _header(String title, String period, DateTime stamp) => pw.Container(
  margin: const pw.EdgeInsets.only(bottom: 12),
  padding: const pw.EdgeInsets.only(bottom: 8),
  decoration: const pw.BoxDecoration(
    border: pw.Border(bottom: pw.BorderSide(width: 1)),
  ),
  child: pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [
      pw.Text(
        'Mine Online',
        style: pw.TextStyle(fontSize: 11, color: PdfColors.grey700),
      ),
      pw.SizedBox(height: 2),
      pw.Text(
        title,
        style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
      ),
      pw.SizedBox(height: 2),
      pw.Text(period, style: const pw.TextStyle(fontSize: 11)),
      pw.SizedBox(height: 2),
      pw.Text(
        'Generated: ${_d(stamp)}',
        style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
      ),
    ],
  ),
);

pw.Widget _sectionTitle(String t) => pw.Padding(
  padding: const pw.EdgeInsets.only(top: 14, bottom: 6),
  child: pw.Text(
    t,
    style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold),
  ),
);

pw.Widget _kvTable(List<List<String>> rows) => pw.Table(
  columnWidths: const {0: pw.FlexColumnWidth(3), 1: pw.FlexColumnWidth(1)},
  children: [
    for (final r in rows)
      pw.TableRow(
        children: [
          _cell(r[0]),
          _cell(r[1], align: pw.TextAlign.right),
        ],
      ),
  ],
);

pw.Widget _countTable(List<MapEntry<String, int>> entries) {
  if (entries.isEmpty) {
    return pw.Text('None', style: const pw.TextStyle(fontSize: 10));
  }
  return pw.Table(
    columnWidths: const {0: pw.FlexColumnWidth(3), 1: pw.FlexColumnWidth(1)},
    children: [
      for (final e in entries)
        pw.TableRow(
          children: [
            _cell(e.key),
            _cell('${e.value}', align: pw.TextAlign.right),
          ],
        ),
    ],
  );
}

pw.Widget _registerTable(List<ReportRow> rows) {
  pw.Widget hc(String t) => pw.Padding(
    padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
    child: pw.Text(
      t,
      style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold),
    ),
  );
  return pw.Table(
    border: pw.TableBorder.all(width: 0.5, color: PdfColors.grey600),
    columnWidths: const {
      0: pw.FlexColumnWidth(1.4),
      1: pw.FlexColumnWidth(2.6),
      2: pw.FlexColumnWidth(2.2),
      3: pw.FlexColumnWidth(1.8),
    },
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(color: PdfColors.grey300),
        children: [hc('Date'), hc('Form'), hc('Submitter'), hc('Status')],
      ),
      if (rows.isEmpty)
        pw.TableRow(children: [_cell('—'), _cell(''), _cell(''), _cell('')])
      else
        for (final r in rows)
          pw.TableRow(
            children: [
              _cell(r.date == null ? '—' : _d(r.date!)),
              _cell(r.formLabel),
              _cell(r.submitter),
              _cell(r.status),
            ],
          ),
    ],
  );
}

pw.Widget _cell(String text, {pw.TextAlign align = pw.TextAlign.left}) =>
    pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      child: pw.Text(
        text,
        textAlign: align,
        style: const pw.TextStyle(fontSize: 9),
      ),
    );
