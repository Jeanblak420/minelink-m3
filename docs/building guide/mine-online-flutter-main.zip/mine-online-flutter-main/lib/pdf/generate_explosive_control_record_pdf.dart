// Port of `generateExplosiveControlRecordPDF` in src/utils/pdfGenerator.ts (2600-2834).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);

Future<pw.Document> generateExplosiveControlRecordPdf(
    ExplosiveControlRecordFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Explosive Control Record',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(
    PageCtx page, ExplosiveControlRecordFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Explosive Control Record'],
    ],
    style: const GridStyle(
      fontSize: 18,
      cellPaddingTop: 4,
      cellPaddingBottom: 4,
      minCellHeight: 12,
    ),
  );
  y += 6;

  const fs = 8.0;
  const lineH = 5.5;

  // Section / Strike / Date
  page.text('Section:', margin, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 14, y + 0.5, 54);
  page.text('Strike:', margin + 74, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 84, y + 0.5, 36);
  page.text('Date:', margin + 126, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 135, y + 0.5, rightEdge - (margin + 135));
  if (data.section.isNotEmpty) {
    page.text(data.section, margin + 15, y, size: fs, style: 'normal');
  }
  if (data.strike.isNotEmpty) {
    page.text(data.strike, margin + 85, y, size: fs, style: 'normal');
  }
  if (data.date.isNotEmpty) {
    page.text(data.date, margin + 136, y, size: fs, style: 'normal');
  }
  y += lineH + 1;

  // Miner Coy no
  page.text('Miner Coy no:', margin, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 24, y + 0.5, rightEdge - margin - 24);
  if (data.minerCoyNo.isNotEmpty) {
    page.text(data.minerCoyNo, margin + 25, y, size: fs, style: 'normal');
  }
  y += lineH + 2;

  // Entries table (5 cols)
  final entryRows = data.entries
      .map((e) => [
            e.description,
            e.boxNo,
            e.amountInControlBook,
            e.amountObserved,
            e.amountDelivered,
          ])
      .toList();
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 48),
      const GridColumn(cellWidth: 18, halign: 'center'),
      const GridColumn(cellWidth: 30, halign: 'center'),
      const GridColumn(cellWidth: 38, halign: 'center'),
      GridColumn(cellWidth: contentWidth - 134, halign: 'center'),
    ],
    head: const [
      GridHeader(
          text: 'Description of Content',
          fillColor: _titleBg,
          fontStyle: 'bold',
          halign: 'left'),
      GridHeader(text: 'Box No.', fillColor: _titleBg, fontStyle: 'bold'),
      GridHeader(
          text: 'Amount in Miners\nControl Book',
          fillColor: _titleBg,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Amount observed during\nInspection',
          fillColor: _titleBg,
          fontStyle: 'bold'),
      GridHeader(
          text:
              'What amount were\ndelivered yesterday\naccording to Miners\nControl Book?',
          fillColor: _titleBg,
          fontStyle: 'bold'),
    ],
    body: entryRows,
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  );
  y += 4;

  // Bordered Q&A sections
  y = _drawBorderedSection(
    page,
    y,
    contentWidth,
    'Deviations observed?  ${data.deviationsObserved}',
    "If 'yes', give details and remedial actions:",
    data.deviationsDetails,
  );
  y = _drawBorderedSection(
    page,
    y,
    contentWidth,
    'Are the old explosive boxes marked?  ${data.oldBoxesMarked}',
    "If 'NO', Give details and remedial actions:",
    data.oldBoxesMarkedDetails,
  );
  y = _drawBorderedSection(
    page,
    y,
    contentWidth,
    'Are the old explosive boxes locked?  ${data.oldBoxesLocked}',
    "If 'no' Give details and remedial actions:",
    data.oldBoxesLockedDetails,
  );
  y = _drawBorderedSingleRow(page, y, contentWidth,
      'Type of explosive in the box?', data.typeOfExplosiveInBox);
  y = _drawBorderedSingleRow(
      page, y, contentWidth, 'Total in the box', data.totalInBox);
  y = _drawBorderedSection(
    page,
    y,
    contentWidth,
    'Recorded correctly in the miners control book?  ${data.recordedCorrectly}',
    "If 'no' give details and remedial actions:",
    data.recordedDetails,
  );
  y += 2;

  // Special instructions
  page.text('Special instructions given:', margin, y,
      size: fs, style: 'bold');
  if (data.specialInstructions.isNotEmpty) {
    final labelW = page.textWidth('Special instructions given: ', fs, 'bold');
    final lines = page.splitTextToSize(
        data.specialInstructions, rightEdge - margin - labelW - 2, fs, 'normal');
    if (lines.isNotEmpty) {
      page.text(lines.first, margin + labelW + 1, y,
          size: fs, style: 'normal');
    }
  }
  y += lineH;
  drawDotLine(page, margin, y + 0.5, contentWidth);
  y += lineH;
  drawDotLine(page, margin, y + 0.5, contentWidth);
  y += lineH;
  drawDotLine(page, margin, y + 0.5, contentWidth);
  y += lineH + 5;

  // Signatures
  page.text('Signature:', margin, y, size: fs, style: 'bold');
  y += lineH + 3;

  page.text('Shift Boss:', margin, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 20, y + 0.5, 55);
  page.text('Date:', margin + 82, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 91, y + 0.5, 45);
  _drawSig(page, data.shiftBossSignature, margin + 21, y - 6, 53, 5);
  if (data.shiftBossDate.isNotEmpty) {
    page.text(data.shiftBossDate, margin + 92, y, size: fs, style: 'normal');
  }
  y += lineH + 7;

  page.text('Mine Overseer:', margin, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 26, y + 0.5, 49);
  page.text('Date:', margin + 82, y, size: fs, style: 'normal');
  drawDotLine(page, margin + 91, y + 0.5, 45);
  _drawSig(page, data.mineOverseerSignature, margin + 27, y - 6, 47, 5);
  if (data.mineOverseerDate.isNotEmpty) {
    page.text(data.mineOverseerDate, margin + 92, y, size: fs, style: 'normal');
  }

  drawInspectionFooter(page, pageNum: 'Page 62 of 84');
}

double _drawBorderedSection(
  PageCtx page,
  double y,
  double contentWidth,
  String headerText,
  String detailLabel,
  String detailValue,
) {
  return drawAutoTable(
    page,
    startY: y,
    columns: [GridColumn(cellWidth: contentWidth)],
    body: [
      [headerText],
      ['$detailLabel $detailValue'.trim()],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 1.5,
      cellPaddingBottom: 1.5,
      minCellHeight: 5,
    ),
  ) + 1;
}

double _drawBorderedSingleRow(
  PageCtx page,
  double y,
  double contentWidth,
  String label,
  String value,
) {
  return drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 80, fontStyle: 'bold'),
      GridColumn(cellWidth: contentWidth - 80),
    ],
    body: [
      [label, value],
    ],
    style: const GridStyle(
      fontSize: 7.5,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 6,
    ),
  ) + 1;
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
