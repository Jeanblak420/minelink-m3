// Port of `generateActionLogUndergroundVisitsPDF` in src/utils/pdfGenerator.ts (3891-3954).

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import 'inspection_doc_frame.dart';
import 'pdf_runtime.dart';

const PdfColor _titleBg = PdfColor.fromInt(0xffc8c8c8);
const PdfColor _headFill = PdfColor.fromInt(0xffe6e6e6);

Future<pw.Document> generateActionLogUndergroundVisitsPdf(
    ActionLogUndergroundVisitsFormData data) async {
  final logoBytes = await loadAssetBytes('assets/images/assmang-logo.png');
  return buildSinglePageDocument(
    pageFormat: PdfPageFormat.letter,
    subject: 'Action Log Underground Visits',
    draw: (page) => _draw(page, data, logoBytes),
  );
}

void _draw(
    PageCtx page, ActionLogUndergroundVisitsFormData data, dynamic logo) {
  const margin = 10.5;
  final contentWidth = page.pageWidth - margin * 2;
  final rightEdge = margin + contentWidth;
  var y = drawInspectionHeader(page, startY: 8, logoBytes: logo) + 3;

  // Title bar
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      GridColumn(cellWidth: contentWidth, halign: 'center', fillColor: _titleBg),
    ],
    body: const [
      ['Action Log of Senior Official’s Underground Visits'],
    ],
    style: const GridStyle(
      fontSize: 13.2,
      cellPaddingTop: 2.2,
      cellPaddingBottom: 2.2,
      minCellHeight: 9,
    ),
  );
  y += 6;

  // Date / Working place
  page.text('Date:', margin, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 10, y + 0.5, 60);
  if (data.date.isNotEmpty) {
    page.text(data.date, margin + 11, y, size: 8, style: 'normal');
  }
  page.text('Working place visited:', margin + 76, y,
      size: 8, style: 'normal');
  drawDotLine(page, margin + 108, y + 0.5, rightEdge - margin - 108);
  if (data.workingPlaceVisited.isNotEmpty) {
    page.text(data.workingPlaceVisited, margin + 109, y,
        size: 8, style: 'normal');
  }
  y += 5;

  page.text('Name of senior official:', margin, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 40, y + 0.5, 70);
  if (data.nameOfSeniorOfficial.isNotEmpty) {
    page.text(data.nameOfSeniorOfficial, margin + 41, y,
        size: 8, style: 'normal');
  }
  page.text('Designation:', margin + 116, y, size: 8, style: 'normal');
  drawDotLine(page, margin + 136, y + 0.5, rightEdge - margin - 136);
  if (data.designation.isNotEmpty) {
    page.text(data.designation, margin + 137, y,
        size: 8, style: 'normal');
  }
  y += 4;

  // Deviations table
  y = drawAutoTable(
    page,
    startY: y,
    columns: [
      const GridColumn(cellWidth: 46),
      const GridColumn(cellWidth: 46),
      const GridColumn(cellWidth: 30, halign: 'center'),
      const GridColumn(cellWidth: 28, halign: 'center'),
      GridColumn(cellWidth: contentWidth - 150),
    ],
    head: const [
      GridHeader(
          text: 'Deviation Observed',
          fillColor: _headFill,
          fontStyle: 'bold',
          halign: 'left'),
      GridHeader(
          text: 'Remedial action to be taken',
          fillColor: _headFill,
          fontStyle: 'bold',
          halign: 'left'),
      GridHeader(
          text: 'Estimated completion date',
          fillColor: _headFill,
          fontStyle: 'bold'),
      GridHeader(
          text: 'Date completed', fillColor: _headFill, fontStyle: 'bold'),
      GridHeader(
          text: 'Signature',
          fillColor: _headFill,
          fontStyle: 'bold',
          halign: 'left'),
    ],
    body: data.deviations
        .map((d) => [
              d.deviationObserved,
              d.remedialAction,
              d.estimatedCompletionDate,
              d.dateCompleted,
              d.signature,
            ])
        .toList(),
    style: const GridStyle(
      fontSize: 7,
      cellPaddingTop: 2,
      cellPaddingBottom: 2,
      minCellHeight: 7,
    ),
  );
  y += 7;

  // Signature blocks — 3 columns
  page.text('Signatures:', margin, y, size: 8, style: 'bold');
  y += 8;
  final sigW = (contentWidth - 12) / 3;

  drawDotLine(page, margin, y + 0.5, sigW);
  _drawSig(page, data.shiftBossSignature, margin + 1, y - 6, sigW - 2, 6);
  page.text('Shift Boss', margin, y + 5, size: 8, style: 'normal');

  drawDotLine(page, margin + sigW + 6, y + 0.5, sigW);
  _drawSig(page, data.mineOverseerSignature, margin + sigW + 7, y - 6,
      sigW - 2, 6);
  page.text('Mine Overseer', margin + sigW + 6, y + 5,
      size: 8, style: 'normal');

  drawDotLine(page, margin + (sigW + 6) * 2, y + 0.5, sigW);
  _drawSig(page, data.seniorOfficialSignature, margin + (sigW + 6) * 2 + 1,
      y - 6, sigW - 2, 6);
  page.text('Senior Official Signature', margin + (sigW + 6) * 2, y + 5,
      size: 8, style: 'normal');

  drawInspectionFooter(page, pageNum: 'Page 72 of 84');
}

void _drawSig(PageCtx page, String sig, double x, double y, double w, double h) {
  drawFittedSignature(page, sig, cellX: x, cellY: y, cellW: w, cellH: h);
}
