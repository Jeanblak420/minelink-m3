import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../models/user_profile.dart';
import '../utils/device_data.dart';
import '../utils/presence_heartbeat.dart';

class AuthProvider extends ChangeNotifier {
  AuthProvider() {
    _bootstrap();
  }

  Session? _session;
  User? _user;
  UserProfile? _profile;
  bool _loading = true;
  Object? _error;
  String? _lockoutMessage;
  RealtimeChannel? _profileChannel;
  final PresenceHeartbeat _presence = PresenceHeartbeat();
  bool _disposed = false;
  // e-role-2: super-admin "View as: ..." override. When set, [profile]
  // returns a copy of _profile with userAccountType + is_admin + is_super_admin
  // patched to the target role so every UI role gate behaves as that role
  // without changing the real session.
  String? _viewAsAccountType;

  Session? get session => _session;
  User? get user => _user;

  /// Public profile getter — returns the impersonated profile when a
  /// super-admin has switched their "View as" role; otherwise the real
  /// profile. Use this for any UI / role-gate decision.
  UserProfile? get profile {
    final p = _profile;
    if (p == null) return null;
    final viewAs = _viewAsAccountType;
    if (viewAs == null || viewAs.isEmpty) return p;
    if (!p.isSuperAdmin) return p; // safeguard: only super-admins can switch
    return p.copyWith({
      'user_account_type': viewAs,
      'is_admin': viewAs == 'Admin' || viewAs == 'Super Admin',
      'is_super_admin': viewAs == 'Super Admin',
    });
  }

  /// The real underlying profile, unaffected by any "View as" override.
  /// Use this when you need ground truth (e.g. is the user actually a
  /// super-admin so we can show the View-as switcher in the first place).
  UserProfile? get realProfile => _profile;

  /// Current "View as" override, or null if none.
  String? get viewAsAccountType => _viewAsAccountType;

  /// Set when the session was force-ended because the account is disabled.
  /// The login screen reads this to explain the lockout. Cleared on sign-in.
  String? get lockoutMessage => _lockoutMessage;

  /// If the freshly-loaded/updated profile is disabled, lock the session out.
  /// Returns true if a lockout sign-out was triggered.
  bool _enforceDisabled() {
    if (_user != null && _profile != null && _profile!.disabled) {
      _lockoutMessage =
          'Your account has been disabled. Contact an administrator.';
      // Fire-and-forget; the auth state listener clears _user/_profile.
      supabase.auth.signOut();
      return true;
    }
    return false;
  }

  /// Super-admin only: switch the rendered role without changing the real
  /// session. Pass null (or call [clearViewAs]) to revert.
  void setViewAs(String? accountType) {
    if (accountType != null && _profile?.isSuperAdmin != true) return;
    final next = (accountType == null || accountType.isEmpty)
        ? null
        : accountType;
    if (_viewAsAccountType == next) return;
    _viewAsAccountType = next;
    _safeNotify();
  }

  void clearViewAs() => setViewAs(null);

  bool get loading => _loading;
  Object? get error => _error;

  Future<void> _bootstrap() async {
    final current = supabase.auth.currentSession;
    _session = current;
    _user = current?.user;
    if (_user != null) {
      await _fetchProfile(_user!.id);
      _subscribeToProfile(_user!.id);
      _presence.start(_user!.id);
      _registerDevice();
    }
    _loading = false;
    _safeNotify();

    supabase.auth.onAuthStateChange.listen((event) async {
      final newSession = event.session;
      _session = newSession;
      _user = newSession?.user;
      if (newSession?.user != null) {
        await _fetchProfile(newSession!.user.id);
        _subscribeToProfile(newSession.user.id);
        _presence.start(newSession.user.id);
        _registerDevice();
      } else {
        _profile = null;
        _viewAsAccountType = null;
        await _profileChannel?.unsubscribe();
        _profileChannel = null;
        _presence.stop();
      }
      _safeNotify();
    });
  }

  /// Best-effort device auto-registration (SP6). Never blocks sign-in or throws.
  void _registerDevice() {
    final p = _profile;
    if (p == null) return;
    registerCurrentDevice(p).catchError((_) {});
  }

  Future<void> _fetchProfile(String userId) async {
    try {
      _error = null;
      final data = await supabase
          .from('profiles')
          .select()
          .eq('id', userId)
          .maybeSingle();
      _profile = data == null ? null : UserProfile.fromMap(data);
      _enforceDisabled();
    } catch (err) {
      _error = err;
      _profile = null;
    }
  }

  void _subscribeToProfile(String userId) {
    _profileChannel?.unsubscribe();
    _profileChannel = supabase
        .channel('profile:$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'profiles',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: userId,
          ),
          callback: (payload) {
            if (payload.eventType == PostgresChangeEvent.update &&
                payload.newRecord.isNotEmpty) {
              _profile = UserProfile.fromMap(payload.newRecord);
              _enforceDisabled();
              _safeNotify();
            }
          },
        )
        .subscribe();
  }

  Future<AuthResponse> signIn(String email, String password) async {
    _lockoutMessage = null;
    return supabase.auth.signInWithPassword(email: email, password: password);
  }

  Future<AuthResponse> signUp(String email, String password) async {
    return supabase.auth.signUp(
      email: email,
      password: password,
      data: {'full_name': email.split('@').first},
    );
  }

  Future<void> signOut() async {
    await supabase.auth.signOut();
  }

  Future<void> refreshProfile() async {
    if (_user != null) {
      await _fetchProfile(_user!.id);
      _safeNotify();
    }
  }

  Future<void> updateProfile(Map<String, dynamic> updates) async {
    final id = _user?.id;
    if (id == null) {
      throw StateError('No user logged in');
    }
    await supabase.from('profiles').update(updates).eq('id', id);
    if (_profile != null) {
      _profile = _profile!.copyWith(updates);
      _safeNotify();
    }
  }

  void _safeNotify() {
    if (_disposed) return;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _profileChannel?.unsubscribe();
    _presence.stop();
    super.dispose();
  }
}
