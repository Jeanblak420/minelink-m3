import 'package:flutter/material.dart';

import '../models/user_profile.dart';
import 'auth_provider.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider(this._auth) {
    _auth.addListener(_onAuthChanged);
  }
  // ignore_for_file: use_null_aware_elements

  final AuthProvider _auth;

  // Settings/picker previews — set via [preview] without touching the DB.
  // Takes precedence over the profile-backed values until [commit] writes
  // them to the server (or [clearPreview] discards them).
  String? _previewMode;
  String? _previewColor;

  String get themeMode {
    return _previewMode ?? _auth.profile?.themeMode ?? 'light';
  }

  String get customThemeColor {
    return _previewColor ?? _auth.profile?.customThemeColor ?? '#6750A4';
  }

  bool get hasPreview => _previewMode != null || _previewColor != null;

  ColorScheme get colorScheme {
    switch (themeMode) {
      case 'dark':
        return _darkScheme;
      case 'custom':
        return _customScheme(customThemeColor, Brightness.light);
      case 'custom_dark':
        return _customScheme(customThemeColor, Brightness.dark);
      default:
        return _lightScheme;
    }
  }

  ThemeData get themeData => _buildTheme(colorScheme);

  Brightness get brightness =>
      (themeMode == 'dark' || themeMode == 'custom_dark')
          ? Brightness.dark
          : Brightness.light;

  /// Apply a preview locally — the app re-renders immediately with the new
  /// theme, but nothing is persisted. Used by the Settings picker.
  void preview({String? mode, String? color}) {
    if (mode != null) _previewMode = mode;
    if (color != null) _previewColor = color;
    notifyListeners();
  }

  /// Discard any active preview and fall back to the profile-backed values.
  void clearPreview() {
    if (_previewMode == null && _previewColor == null) return;
    _previewMode = null;
    _previewColor = null;
    notifyListeners();
  }

  /// Persist [mode] / [color] to profiles.theme_mode / custom_theme_color
  /// and clear any local preview. The realtime profile channel pushes the
  /// new values back, so cross-device sync still works.
  Future<void> commit(String mode, [String? color]) async {
    await _auth.updateProfile({
      'theme_mode': mode,
      if (color != null) 'custom_theme_color': color,
    });
    _previewMode = null;
    _previewColor = null;
    notifyListeners();
  }

  /// Convenience for callers that don't care about preview-vs-save semantics
  /// — applies a preview AND persists in one step.
  Future<void> setTheme(String mode, [String? customColor]) =>
      commit(mode, customColor);

  void _onAuthChanged() {
    notifyListeners();
  }

  @override
  void dispose() {
    _auth.removeListener(_onAuthChanged);
    super.dispose();
  }
}

// Hex values copied directly from src/context/ThemeContext.tsx
const ColorScheme _lightScheme = ColorScheme(
  brightness: Brightness.light,
  primary: Color(0xFF6750A4),
  onPrimary: Color(0xFFFFFFFF),
  primaryContainer: Color(0xFFEADDFF),
  onPrimaryContainer: Color(0xFF21005D),
  secondary: Color(0xFF625B71),
  onSecondary: Color(0xFFFFFFFF),
  secondaryContainer: Color(0xFFE8DEF8),
  onSecondaryContainer: Color(0xFF1D192B),
  tertiary: Color(0xFF7D5260),
  onTertiary: Color(0xFFFFFFFF),
  tertiaryContainer: Color(0xFFFFD8E4),
  onTertiaryContainer: Color(0xFF31111D),
  error: Color(0xFFB3261E),
  onError: Color(0xFFFFFFFF),
  errorContainer: Color(0xFFF9DEDC),
  onErrorContainer: Color(0xFF410E0B),
  surface: Color(0xFFFFFBFE),
  onSurface: Color(0xFF1C1B1F),
  surfaceContainerHighest: Color(0xFFE7E0EC),
  onSurfaceVariant: Color(0xFF49454F),
  outline: Color(0xFF79747E),
  outlineVariant: Color(0xFFCAC4D0),
  inverseSurface: Color(0xFF313033),
  onInverseSurface: Color(0xFFF4EFF4),
  inversePrimary: Color(0xFFD0BCFF),
);

const ColorScheme _darkScheme = ColorScheme(
  brightness: Brightness.dark,
  primary: Color(0xFFD0BCFF),
  onPrimary: Color(0xFF381E72),
  primaryContainer: Color(0xFF4F378B),
  onPrimaryContainer: Color(0xFFEADDFF),
  secondary: Color(0xFFCCC2DC),
  onSecondary: Color(0xFF332D41),
  secondaryContainer: Color(0xFF4A4458),
  onSecondaryContainer: Color(0xFFE8DEF8),
  tertiary: Color(0xFFEFB8C8),
  onTertiary: Color(0xFF492532),
  tertiaryContainer: Color(0xFF633B48),
  onTertiaryContainer: Color(0xFFFFD8E4),
  error: Color(0xFFF2B8B5),
  onError: Color(0xFF601410),
  errorContainer: Color(0xFF8C1D18),
  onErrorContainer: Color(0xFFF9DEDC),
  surface: Color(0xFF1C1B1F),
  onSurface: Color(0xFFE6E1E5),
  surfaceContainerHighest: Color(0xFF49454F),
  onSurfaceVariant: Color(0xFFCAC4D0),
  outline: Color(0xFF938F99),
  outlineVariant: Color(0xFF49454F),
  inverseSurface: Color(0xFFE6E1E5),
  onInverseSurface: Color(0xFF313033),
  inversePrimary: Color(0xFF6750A4),
);

// Custom-mode scheme: derive container/tint/on-colors from the seed using
// the UI-kit's mix() approach (Tokens.jsx → buildCustomLight). Keeps the
// custom theme visually identical between web/UI-kit and Flutter.
ColorScheme _customScheme(String hex, Brightness brightness) {
  final seed = _parseHex(hex);
  if (brightness == Brightness.dark) {
    // Lighten the seed so it reads as a primary on dark surfaces.
    final primary = _mix(seed, const Color(0xFFFFFFFF), 0.30);
    final container = _mix(seed, const Color(0xFF000000), 0.45);
    return _darkScheme.copyWith(
      primary: primary,
      onPrimary: _luminance(primary) > 0.5
          ? const Color(0xFF1F1F1F)
          : const Color(0xFFFFFFFF),
      primaryContainer: container,
      onPrimaryContainer: _mix(seed, const Color(0xFFFFFFFF), 0.85),
      inversePrimary: seed,
    );
  }
  final container = _mix(seed, const Color(0xFFFFFFFF), 0.78);
  final tint = _mix(seed, const Color(0xFFFFFFFF), 0.92);
  final onContainer = _mix(seed, const Color(0xFF000000), 0.55);
  final onPrimary = _luminance(seed) > 0.5
      ? const Color(0xFF1F1F1F)
      : const Color(0xFFFFFFFF);

  return ColorScheme(
    brightness: Brightness.light,
    primary: seed,
    onPrimary: onPrimary,
    primaryContainer: container,
    onPrimaryContainer: onContainer,
    secondary: const Color(0xFF625B71),
    onSecondary: const Color(0xFFFFFFFF),
    secondaryContainer: const Color(0xFFE8DEF8),
    onSecondaryContainer: const Color(0xFF1D192B),
    tertiary: const Color(0xFF7D5260),
    onTertiary: const Color(0xFFFFFFFF),
    tertiaryContainer: const Color(0xFFFFD8E4),
    onTertiaryContainer: const Color(0xFF31111D),
    error: const Color(0xFFB3261E),
    onError: const Color(0xFFFFFFFF),
    errorContainer: const Color(0xFFF9DEDC),
    onErrorContainer: const Color(0xFF410E0B),
    surface: const Color(0xFFFFFBFE),
    onSurface: const Color(0xFF1C1B1F),
    surfaceContainerHighest: tint,
    onSurfaceVariant: const Color(0xFF49454F),
    outline: const Color(0xFF79747E),
    outlineVariant: const Color(0xFFCAC4D0),
    inverseSurface: const Color(0xFF313033),
    onInverseSurface: const Color(0xFFF4EFF4),
    inversePrimary: container,
  );
}

Color _parseHex(String hex) {
  final normalized = RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(hex)
      ? hex
      : '#6750A4';
  final value = int.parse(normalized.substring(1), radix: 16);
  return Color(0xFF000000 | value);
}

Color _mix(Color a, Color b, double ratio) {
  // ratio = how much of `b` to mix in (0 = pure a, 1 = pure b).
  final clamped = ratio.clamp(0.0, 1.0);
  final ar = ((a.r * 255).round()) & 0xff;
  final ag = ((a.g * 255).round()) & 0xff;
  final ab = ((a.b * 255).round()) & 0xff;
  final br = ((b.r * 255).round()) & 0xff;
  final bg = ((b.g * 255).round()) & 0xff;
  final bb = ((b.b * 255).round()) & 0xff;
  final r = (ar * (1 - clamped) + br * clamped).round();
  final g = (ag * (1 - clamped) + bg * clamped).round();
  final c = (ab * (1 - clamped) + bb * clamped).round();
  return Color.fromARGB(0xff, r, g, c);
}

double _luminance(Color color) {
  // Matches Tokens.jsx → luminance() (linear; not gamma-corrected, by design).
  final r = (color.r * 255).round() & 0xff;
  final g = (color.g * 255).round() & 0xff;
  final b = (color.b * 255).round() & 0xff;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;
}

ThemeData _buildTheme(ColorScheme scheme) {
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    // Roboto bundled in assets/fonts/ via pubspec.yaml. Setting fontFamily
    // here makes the Windows build use Roboto instead of the Segoe UI
    // fallback. Mirrors the brand spec in mine-online-design-system/README.md
    // ("Roboto everywhere, bundled in fonts/").
    fontFamily: 'Roboto',
    scaffoldBackgroundColor: scheme.surface,
    appBarTheme: AppBarTheme(
      backgroundColor: scheme.surface,
      foregroundColor: scheme.onSurface,
      elevation: 0,
      // 1 px hairline that fades in when content scrolls under (sticky app
      // bar treatment per e-misc-3). M3's scrolledUnderElevation handles the
      // tint+hairline animation for free.
      scrolledUnderElevation: 2,
      surfaceTintColor: scheme.primary,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: scheme.surfaceContainerHighest,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.outline),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.outline),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.primary, width: 2),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      ),
    ),
    cardTheme: CardThemeData(
      color: scheme.surface,
      surfaceTintColor: scheme.surface,
      elevation: 1,
      // Hairline outline so cards stay visible/distinguishable on every
      // surface and seed colour (light / dark / custom).
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: scheme.outlineVariant),
      ),
    ),
  );
}

extension UserProfileThemeX on UserProfile? {
  String get safeThemeMode => this?.themeMode ?? 'light';
}
