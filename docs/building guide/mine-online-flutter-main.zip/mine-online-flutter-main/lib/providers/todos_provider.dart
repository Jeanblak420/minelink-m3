// Loads, mutates, and exposes the shared `todos` table.
// Realtime sync (postgres_changes subscription) lands in e-todos-5; this
// provider currently reloads after every mutation.

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../models/todo.dart';

class TodosProvider extends ChangeNotifier {
  TodosProvider() {
    _subscribeToAuth();
    _load();
  }

  List<Todo> _todos = const [];
  bool _loading = true;
  String? _error;
  StreamSubscription<dynamic>? _authSub;
  RealtimeChannel? _channel;

  List<Todo> get todos => _todos;
  List<Todo> get engTodos =>
      _todos.where((t) => t.kind == 'eng').toList(growable: false);
  List<Todo> get userTodos =>
      _todos.where((t) => t.kind == 'user').toList(growable: false);
  bool get loading => _loading;
  String? get error => _error;

  @override
  void dispose() {
    _authSub?.cancel();
    _channel?.unsubscribe();
    super.dispose();
  }

  void _subscribeToAuth() {
    _authSub = supabase.auth.onAuthStateChange.listen((_) => _load());
  }

  void _resubscribe() {
    _channel?.unsubscribe();
    _channel = supabase
        .channel('public:todos')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'todos',
          callback: _onInsert,
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'todos',
          callback: _onUpdate,
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'todos',
          callback: _onDelete,
        )
        .subscribe();
  }

  void _onInsert(PostgresChangePayload payload) {
    final row = payload.newRecord;
    final todo = Todo.fromRow(row);
    if (_todos.any((t) => t.id == todo.id)) return;
    _todos = [todo, ..._todos];
    notifyListeners();
  }

  void _onUpdate(PostgresChangePayload payload) {
    final row = payload.newRecord;
    final todo = Todo.fromRow(row);
    final idx = _todos.indexWhere((t) => t.id == todo.id);
    if (idx == -1) {
      _todos = [todo, ..._todos];
    } else {
      final next = List<Todo>.from(_todos);
      next[idx] = todo;
      _todos = next;
    }
    notifyListeners();
  }

  void _onDelete(PostgresChangePayload payload) {
    final id = payload.oldRecord['id'] as String?;
    if (id == null) return;
    final before = _todos.length;
    _todos = _todos.where((t) => t.id != id).toList(growable: false);
    if (_todos.length != before) notifyListeners();
  }

  Future<void> reload() => _load();

  Future<void> _load() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      _todos = const [];
      _loading = false;
      _error = null;
      notifyListeners();
      _channel?.unsubscribe();
      _channel = null;
      return;
    }
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final rows = await supabase
          .from('todos')
          .select()
          .order('created_at', ascending: false);
      _todos = (rows as List)
          .cast<Map<String, dynamic>>()
          .map(Todo.fromRow)
          .toList(growable: false);
    } catch (err) {
      _error = err.toString();
      if (kDebugMode) {
        debugPrint('Todos load failed: $err');
      }
    }
    _loading = false;
    notifyListeners();
    _resubscribe();
  }

  Future<void> setStatus(String id, String status) async {
    _todos = _todos
        .map((t) => t.id == id ? t.copyWith(status: status) : t)
        .toList(growable: false);
    notifyListeners();
    try {
      await supabase
          .from('todos')
          .update({'status': status}).eq('id', id);
    } catch (err) {
      if (kDebugMode) debugPrint('Todos setStatus failed: $err');
      await _load();
    }
  }

  Future<void> toggleDone(String id) async {
    final t = _todos.firstWhere(
      (t) => t.id == id,
      orElse: () => throw StateError('Todo $id not found'),
    );
    await setStatus(id, t.status == 'done' ? 'planned' : 'done');
  }

  Future<void> deleteTodo(String id) async {
    final prev = _todos;
    _todos = _todos.where((t) => t.id != id).toList(growable: false);
    notifyListeners();
    try {
      await supabase.from('todos').delete().eq('id', id);
    } catch (err) {
      if (kDebugMode) debugPrint('Todos delete failed: $err');
      _todos = prev;
      notifyListeners();
    }
  }

  Future<Todo?> insertUserRequest({
    required String title,
    required String submitterName,
    required String urgency,
    required String summary,
    String? imageStoragePath,
    String? imageNotes,
  }) async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;
    try {
      final inserted = await supabase
          .from('todos')
          .insert({
            'kind': 'user',
            'title': title,
            'summary': summary,
            'urgency': urgency,
            'submitter_name': submitterName,
            'submitter_id': user.id,
            'author_id': user.id,
            'author_name': submitterName,
            'image_storage_path': imageStoragePath,
            'image_notes': imageNotes,
          })
          .select()
          .single();
      final todo = Todo.fromRow(inserted);
      _todos = [todo, ..._todos];
      notifyListeners();
      return todo;
    } catch (err) {
      if (kDebugMode) debugPrint('Todos insertUserRequest failed: $err');
      _error = err.toString();
      notifyListeners();
      return null;
    }
  }
}
