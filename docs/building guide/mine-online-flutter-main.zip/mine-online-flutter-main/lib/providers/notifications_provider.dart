// Mirrors src/hooks/useNotifications.ts: load, realtime subscribe, mark-read.

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../models/app_notification.dart';

class NotificationsProvider extends ChangeNotifier {
  NotificationsProvider() {
    _subscribeToAuth();
    _load();
  }

  List<AppNotification> _notifications = const [];
  bool _loading = true;
  RealtimeChannel? _channel;
  String? _currentUserId;
  StreamSubscription<AuthState>? _authSub;

  List<AppNotification> get notifications => _notifications;
  bool get loading => _loading;
  int get unreadCount =>
      _notifications.where((n) => !n.read).length;

  @override
  void dispose() {
    _authSub?.cancel();
    _channel?.unsubscribe();
    super.dispose();
  }

  void _subscribeToAuth() {
    _authSub = supabase.auth.onAuthStateChange.listen((event) {
      final id = event.session?.user.id;
      if (id != _currentUserId) {
        _currentUserId = id;
        _load();
      }
    });
  }

  Future<void> _load() async {
    final user = supabase.auth.currentUser;
    _currentUserId = user?.id;
    if (user == null) {
      _notifications = const [];
      _loading = false;
      notifyListeners();
      _channel?.unsubscribe();
      _channel = null;
      return;
    }

    _loading = true;
    notifyListeners();
    try {
      final rows = await supabase
          .from('notifications')
          .select('id,type,title,body,read_at,created_at,action_url,metadata')
          .eq('user_id', user.id)
          .isFilter('archived_at', null)
          .order('created_at', ascending: false)
          .limit(30);
      _notifications = (rows as List)
          .cast<Map<String, dynamic>>()
          .map(AppNotification.fromRow)
          .toList(growable: false);
    } catch (err) {
      if (kDebugMode) {
        // ignore: avoid_print
        print('Notifications query failed: $err');
      }
      _notifications = const [];
    }
    _loading = false;
    notifyListeners();
    _resubscribe(user.id);
  }

  void _resubscribe(String userId) {
    _channel?.unsubscribe();
    _channel = supabase
        .channel('notifications:$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (_) => _load(),
        )
        .subscribe();
  }

  Future<void> reload() => _load();

  Future<void> markAsRead(String id) async {
    _notifications = _notifications
        .map((n) => n.id == id ? n.copyWith(read: true) : n)
        .toList(growable: false);
    notifyListeners();
    try {
      await supabase
          .from('notifications')
          .update({'read_at': DateTime.now().toIso8601String()}).eq('id', id);
    } catch (_) {/* swallow */}
  }

  Future<void> markAllAsRead() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    _notifications =
        _notifications.map((n) => n.copyWith(read: true)).toList(growable: false);
    notifyListeners();
    try {
      await supabase
          .from('notifications')
          .update({'read_at': DateTime.now().toIso8601String()})
          .eq('user_id', user.id)
          .isFilter('read_at', null);
    } catch (_) {/* swallow */}
  }
}
