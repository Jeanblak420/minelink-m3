// SP4.5: a registry of every current (built-in) form so the full-edit builder can
// list them for editing. form_type matches buildFormView/generatePdfForFormType
// and the overlay key; route matches router.dart for preview navigation.

class FormMetadata {
  const FormMetadata({
    required this.formType,
    required this.title,
    required this.route,
    required this.category,
    this.isAppointmentForm = false,
  });

  final String formType;
  final String title;
  final String route;
  final String category;
  final bool isAppointmentForm;
}

/// Groups forms by `category`, preserving first-seen category order and the
/// within-category order of [forms].
Map<String, List<FormMetadata>> groupFormsByCategory(List<FormMetadata> forms) {
  final out = <String, List<FormMetadata>>{};
  for (final f in forms) {
    (out[f.category] ??= <FormMetadata>[]).add(f);
  }
  return out;
}

/// Every current form, grouped by category. Appointment forms are flagged.
const List<FormMetadata> kFormMetadataRegistry = [
  // Appointments
  FormMetadata(
    formType: 'shift_boss_appointment',
    title: 'Shift Boss Appointment',
    route: '/shift-boss',
    category: 'Appointments',
    isAppointmentForm: true,
  ),
  FormMetadata(
    formType: 'miner_appointment',
    title: 'Miner Appointment',
    route: '/miner-appointment',
    category: 'Appointments',
    isAppointmentForm: true,
  ),
  FormMetadata(
    formType: 'relieving_miner_appointment',
    title: 'Relieving Miner Appointment',
    route: '/relieving-miner',
    category: 'Appointments',
    isAppointmentForm: true,
  ),
  FormMetadata(
    formType: 'safety_health_rep',
    title: 'Safety & Health Representative Appointment',
    route: '/safety-health-rep',
    category: 'Appointments',
    isAppointmentForm: true,
  ),
  FormMetadata(
    formType: 'machinery_operators_appointment',
    title: 'Machinery Operators Appointment',
    route: '/machinery-operators',
    category: 'Appointments',
    isAppointmentForm: true,
  ),
  // Records & reports
  FormMetadata(
    formType: 'shift_boss_daily_report',
    title: 'Shift Boss Daily Report',
    route: '/shift-boss-daily-report',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'gassing_incident',
    title: 'Gassing / Smoke / Dust / Incident Record',
    route: '/gassing-incident',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'weekly_sherq_meeting',
    title: 'Weekly SHERQ Meeting',
    route: '/weekly-sherq-meeting',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'early_shift_record',
    title: 'Early Shift Record',
    route: '/early-shift-record',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'late_shift_record',
    title: 'Late Shift Record',
    route: '/late-shift-record',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'explosive_control_record',
    title: 'Explosive Control Record',
    route: '/explosive-control-record',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'action_log_underground_visits',
    title: "Action Log of Senior Official's Underground Visits",
    route: '/action-log-underground-visits',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'special_instruction',
    title: 'Special Instruction',
    route: '/special-instruction',
    category: 'Records & Reports',
  ),
  FormMetadata(
    formType: 'special_brief_instruction_register',
    title: 'Special Brief / Instruction Register',
    route: '/special-brief-instruction-register',
    category: 'Records & Reports',
  ),
  // Inspections
  FormMetadata(
    formType: 'waiting_place_inspection',
    title: 'Waiting Place Inspection Record',
    route: '/waiting-place-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'refuge_bay_inspection',
    title: 'Refuge Bay Inspection Record',
    route: '/refuge-bay-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'trackless_machinery_inspection',
    title: 'Weekly Trackless Mobile Machinery Over-Inspection',
    route: '/trackless-machinery-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'conveyor_belt_inspection',
    title: 'Weekly Strike Conveyor Belt Inspection',
    route: '/conveyor-belt-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'rock_breaker_inspection',
    title: 'Weekly Rock Breaker Inspection',
    route: '/rock-breaker-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'belt_tip_area_inspection',
    title: 'Weekly Belt Tip Area Inspection',
    route: '/belt-tip-area-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'inspection_control_sheet',
    title: 'Inspection Control Sheet',
    route: '/inspection-control-sheet',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'planned_task_observation',
    title: 'Control Sheet - Planned Task Observation',
    route: '/planned-task-observation',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'monthly_fire_fighting_inspection',
    title: 'Monthly Fire Fighting Equipment Inspection Report',
    route: '/monthly-fire-fighting-inspection',
    category: 'Inspections',
  ),
  FormMetadata(
    formType: 'lockout_lock_scissor_checklist',
    title: 'Monthly Lock-out Lock and Scissor Checklist',
    route: '/lockout-lock-scissor-checklist',
    category: 'Inspections',
  ),
  // Emergency drills
  FormMetadata(
    formType: 'verbal_emergency_drills',
    title: 'Verbal Emergency Drills',
    route: '/verbal-emergency-drills',
    category: 'Emergency Drills',
  ),
  FormMetadata(
    formType: 'physical_emergency_drills',
    title: 'Physical Emergency Drills',
    route: '/physical-emergency-drills',
    category: 'Emergency Drills',
  ),
  FormMetadata(
    formType: 'emergency_drill_exercise',
    title: 'Emergency Drill Exercise (Fire or Event)',
    route: '/emergency-drill-exercise',
    category: 'Emergency Drills',
  ),
];

FormMetadata? formMetadataByType(String formType) {
  for (final m in kFormMetadataRegistry) {
    if (m.formType == formType) return m;
  }
  return null;
}
