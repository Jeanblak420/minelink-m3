// Supabase data access for the appointments lifecycle (SP4). Co-signing reuses
// saveFormSubmissionAndStartWorkflow + the signature-workflow edge function, so
// the chain itself is unchanged — this layer only manages the lifecycle record.

import '../config/supabase_client.dart';
import '../models/appointment.dart';
import '../models/appointment_template.dart';
import '../models/user_profile.dart';
import 'dynamic_form_payload.dart'
    show applyCustomChainSignatureFields, buildSubmissionPayload;
import 'signature_workflow.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();
String _dateOnly(DateTime d) => d.toIso8601String().substring(0, 10);

Future<List<Appointment>> loadAllAppointments() async {
  final rows = await supabase
      .from('appointments')
      .select()
      .order('issued_at', ascending: false);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(Appointment.fromMap)
      .toList();
}

Future<List<Appointment>> loadMyAppointments() async {
  final uid = supabase.auth.currentUser?.id;
  if (uid == null) return const [];
  final rows = await supabase
      .from('appointments')
      .select()
      .eq('appointee_id', uid)
      .order('issued_at', ascending: false);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(Appointment.fromMap)
      .toList();
}

/// Returns a human-readable message if the appointee already has a live
/// appointment for this role + shaft in the same calendar month, else null.
Future<String?> appointmentUniquenessConflict({
  required String appointeeId,
  required String roleCode,
  required String? shaftId,
  required DateTime effectiveDate,
}) async {
  final periodStart = DateTime(effectiveDate.year, effectiveDate.month, 1);
  final periodEnd = DateTime(effectiveDate.year, effectiveDate.month + 1, 1);
  var q = supabase
      .from('appointments')
      .select('id')
      .eq('appointee_id', appointeeId)
      .eq('role_code', roleCode)
      .inFilter('status', ['pending_acceptance', 'pending_signoff', 'active'])
      .gte('effective_date', _dateOnly(periodStart))
      .lt('effective_date', _dateOnly(periodEnd));
  if (shaftId != null) q = q.eq('shaft_id', shaftId);
  final rows = await q.limit(1);
  if ((rows as List).isNotEmpty) {
    return 'This person already has a live "$roleCode" appointment for this '
        'shaft this month.';
  }
  return null;
}

/// Standard letter tokens resolved from the appointee profile + issue context.
Map<String, String> standardLetterTokens(
  UserProfile p, {
  String? section,
  required DateTime effectiveDate,
}) {
  final full = p.fullName.trim();
  final first = p.firstName.trim();
  final last = (first.isNotEmpty && full.startsWith(first))
      ? full.substring(first.length).trim()
      : '';
  return {
    'full_name': full,
    'first_name': first,
    'last_name': last,
    'employee_number': p.employeeNumber ?? '',
    'id_number': p.saIdNumber ?? '',
    'occupation': p.occupation ?? '',
    'section': section ?? p.sectionShaft ?? '',
    'company': p.company ?? '',
    'date': _dateOnly(effectiveDate),
  };
}

/// Issues an appointment. Pass [template] for an SP3 dynamic template (the admin
/// fills [fieldValues] now), or leave it null for a built-in appointment form
/// (the appointee fills the real form at acceptance — [fieldValues] is ignored).
/// [formType] is the submission/render form_type (template `code` for dynamic,
/// the built-in code otherwise).
Future<void> issueAppointment({
  required String formType,
  AppointmentTemplate? template,
  required String? roleId,
  required String roleCode,
  required UserProfile appointee,
  required String? shaftId,
  String? section,
  String? cycle,
  required DateTime effectiveDate,
  required Map<String, dynamic> fieldValues,
}) async {
  final standard = standardLetterTokens(
    appointee,
    section: section,
    effectiveDate: effectiveDate,
  );
  Map<String, dynamic> payload;
  if (template != null) {
    final fieldPayload = buildSubmissionPayload(template.fields, fieldValues);
    final fieldStrings = <String, String>{
      for (final e in fieldPayload.entries) e.key: '${e.value}',
    };
    payload = <String, dynamic>{
      'fields': fieldPayload,
      'letterValues': mergeLetterValues(standard, fieldStrings),
      'signatures': <String, dynamic>{},
    };
  } else {
    // Built-in form: only the lifecycle shell; the appointee fills it on accept.
    payload = <String, dynamic>{
      'letterValues': standard,
      'signatures': <String, dynamic>{},
    };
  }
  await supabase.from('appointments').insert({
    'template_id': template?.id,
    'form_type': formType,
    'role_id': roleId,
    'role_code': roleCode,
    'appointee_id': appointee.id,
    'issued_by': supabase.auth.currentUser?.id,
    'shaft_id': shaftId,
    'section': section,
    'cycle': cycle,
    'effective_date': _dateOnly(effectiveDate),
    'status': 'pending_acceptance',
    'payload': payload,
  });
}

/// Links a built-in appointment form's submission to its appointment after the
/// appointee completes + submits the form. Moves it to pending_signoff (when the
/// form has a co-sign chain) or active.
Future<void> linkAppointmentSubmission(
  Appointment appt,
  String submissionId, {
  required bool hasChain,
}) async {
  await supabase
      .from('appointments')
      .update({
        'submission_id': submissionId,
        'accepted_at': _nowUtc(),
        'status': hasChain ? 'pending_signoff' : 'active',
        if (!hasChain) 'activated_at': _nowUtc(),
        'updated_at': _nowUtc(),
      })
      .eq('id', appt.id);
}

/// The appointee accepts and signs. With no required co-signers the appointment
/// goes active immediately; otherwise we persist a co-sign submission and start
/// the existing Mine Overseer / Mine Manager chain — a DB trigger flips the
/// appointment to active when that submission is fully signed.
Future<void> acceptAppointment({
  required Appointment appt,
  required AppointmentTemplate template,
  required UserProfile me,
  required String signature,
}) async {
  final payload = Map<String, dynamic>.from(appt.payload);
  final sig = (payload['signatures'] is Map)
      ? Map<String, dynamic>.from(payload['signatures'] as Map)
      : <String, dynamic>{};
  sig['appointeeSignature'] = signature;
  sig['appointeeDate'] = _dateOnly(DateTime.now());
  payload['signatures'] = sig;

  final hasCosign = applyCustomChainSignatureFields(
    template.requiredSigners,
    payload,
  );

  if (!hasCosign) {
    await supabase
        .from('appointments')
        .update({
          'status': 'active',
          'payload': payload,
          'accepted_at': _nowUtc(),
          'activated_at': _nowUtc(),
          'updated_at': _nowUtc(),
        })
        .eq('id', appt.id);
    return;
  }

  final title = 'Appointment: ${appt.roleCode} — ${me.fullName}';
  final submissionId = await saveFormSubmissionAndStartWorkflow(
    template.code,
    title,
    payload,
    profile: me,
  );
  await supabase
      .from('appointments')
      .update({
        'status': 'pending_signoff',
        'payload': payload,
        'submission_id': submissionId,
        'accepted_at': _nowUtc(),
        'updated_at': _nowUtc(),
      })
      .eq('id', appt.id);
}

Future<void> declineAppointment(Appointment appt) async {
  await supabase
      .from('appointments')
      .update({
        'status': 'declined',
        'declined_at': _nowUtc(),
        'updated_at': _nowUtc(),
      })
      .eq('id', appt.id);
}

Future<void> resignAppointment(Appointment appt, String reason) async {
  await supabase
      .from('appointments')
      .update({
        'status': 'resigned',
        'resigned_at': _nowUtc(),
        'resign_reason': reason,
        'updated_at': _nowUtc(),
      })
      .eq('id', appt.id);
}
