// Supabase data access for appointment roles + templates (SP3). Mirrors
// custom_form_data.dart / org_data.dart: read-active by default, admin-write,
// soft-delete via is_active, version bump on update.

import '../config/supabase_client.dart';
import '../models/appointment_template.dart';
import '../models/custom_form_template.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();

/// Lowercase slug + short suffix → a stable, unique appointment template code.
/// e.g. appointmentTemplateCode('Shift Boss', 'a1b2') -> 'appt_shift_boss_a1b2'.
String appointmentTemplateCode(String name, String suffix) {
  final slug = name
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_+|_+$'), '');
  final base = slug.isEmpty ? 'appointment' : slug;
  return 'appt_${base}_$suffix';
}

// ---------------------------------------------------------------------------
// Roles
// ---------------------------------------------------------------------------

Future<List<AppointmentRole>> loadAppointmentRoles({
  bool includeArchived = false,
}) async {
  var query = supabase.from('appointment_roles').select();
  if (!includeArchived) query = query.eq('is_active', true);
  final rows = await query.order('sort_order', ascending: true);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(AppointmentRole.fromMap)
      .toList();
}

Future<void> saveAppointmentRole({
  String? id,
  String? code,
  required String label,
  String? description,
  required bool isMandatory,
  required int sortOrder,
}) async {
  final payload = <String, dynamic>{
    'code': (code == null || code.trim().isEmpty) ? null : code.trim(),
    'label': label.trim(),
    'description': (description == null || description.trim().isEmpty)
        ? null
        : description.trim(),
    'is_mandatory': isMandatory,
    'sort_order': sortOrder,
  };
  if (id == null) {
    await supabase.from('appointment_roles').insert(payload);
  } else {
    payload['updated_at'] = _nowUtc();
    await supabase.from('appointment_roles').update(payload).eq('id', id);
  }
}

Future<void> setAppointmentRoleActive(String id, bool active) async {
  await supabase
      .from('appointment_roles')
      .update({'is_active': active, 'updated_at': _nowUtc()})
      .eq('id', id);
}

// ---------------------------------------------------------------------------
// Templates
// ---------------------------------------------------------------------------

Future<List<AppointmentTemplate>> loadAppointmentTemplates({
  bool includeArchived = false,
}) async {
  var query = supabase.from('appointment_templates').select();
  if (!includeArchived) query = query.eq('is_active', true);
  final rows = await query.order('updated_at', ascending: false);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(AppointmentTemplate.fromMap)
      .toList();
}

/// Inserts a new template (when [id] is null) or updates an existing one.
/// Returns the saved row's id. On update, bumps version and sets updated_at.
Future<String> saveAppointmentTemplate({
  String? id,
  required String code,
  required String name,
  String? description,
  String? roleId,
  required String language,
  required List<FormFieldDef> fields,
  required String letterBody,
  required List<String> requiredSigners,
  required int version,
}) async {
  final user = supabase.auth.currentUser;
  final payload = <String, dynamic>{
    'code': code,
    'name': name,
    'description': description,
    'role_id': roleId,
    'language': language,
    'fields': fields.map((f) => f.toMap()).toList(),
    'letter_body': letterBody,
    'required_signers': requiredSigners,
  };
  if (id == null) {
    payload['version'] = 1;
    if (user != null) payload['created_by'] = user.id;
    final inserted = await supabase
        .from('appointment_templates')
        .insert(payload)
        .select('id')
        .single();
    return inserted['id'] as String;
  } else {
    payload['version'] = version + 1;
    payload['updated_at'] = _nowUtc();
    await supabase.from('appointment_templates').update(payload).eq('id', id);
    return id;
  }
}

Future<void> setAppointmentTemplateActive(String id, bool active) async {
  await supabase
      .from('appointment_templates')
      .update({'is_active': active, 'updated_at': _nowUtc()})
      .eq('id', id);
}

/// Loads a single template by its `code` (the appointment submission form_type),
/// or null if none exists. Used to regenerate the letter PDF for an appointment.
Future<AppointmentTemplate?> loadAppointmentTemplateByCode(String code) async {
  final rows = await supabase
      .from('appointment_templates')
      .select()
      .eq('code', code)
      .limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  return list.isEmpty ? null : AppointmentTemplate.fromMap(list.first);
}
