import '../models/user_profile.dart';

bool isAdminProfile(UserProfile? profile) {
  if (profile == null) return false;
  return profile.isAdmin ||
      profile.isSuperAdmin ||
      profile.userAccountType == 'Admin' ||
      profile.userAccountType == 'Super Admin';
}

bool isSuperAdminProfile(UserProfile? profile) {
  if (profile == null) return false;
  return profile.isSuperAdmin || profile.userAccountType == 'Super Admin';
}

bool occupationContainsWords(String? occupation, List<String> words) {
  final normalized = (occupation ?? '').toLowerCase();
  return words.every((word) => normalized.contains(word.toLowerCase()));
}

bool isShiftBossProfile(UserProfile? profile) {
  if (profile == null) return false;
  return profile.userAccountType == 'Shift Boss' ||
      occupationContainsWords(profile.occupation, ['shift', 'boss']);
}

bool isMineOverseerProfile(UserProfile? profile) {
  if (profile == null) return false;
  return profile.userAccountType == 'Mine Overseer' ||
      occupationContainsWords(profile.occupation, ['mine', 'overseer']);
}

bool isMineManagerProfile(UserProfile? profile) {
  if (profile == null) return false;
  return profile.userAccountType == 'Mine Manager' ||
      occupationContainsWords(profile.occupation, ['mine', 'manager']);
}

bool canAccessShiftBossDocuments(UserProfile? profile) {
  return isAdminProfile(profile) || isShiftBossProfile(profile);
}
