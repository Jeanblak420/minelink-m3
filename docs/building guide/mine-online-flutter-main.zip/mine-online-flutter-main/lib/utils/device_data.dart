// SP6: Supabase access for the device registry. Auto-registration upserts the
// current install's device; admins approve/revoke. Mirrors org_data.dart.

import '../config/supabase_client.dart';
import '../models/device.dart';
import '../models/user_profile.dart';
import 'device_identity.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();

/// Upserts this install's device row (pending until an admin approves). Refreshes
/// last_seen each call. Best-effort: callers must not block on failure.
Future<void> registerCurrentDevice(UserProfile me) async {
  final id = await currentDeviceId();
  await supabase.from('devices').upsert({
    'id': id,
    'user_id': me.id,
    'device_name': defaultDeviceName(),
    'platform': currentPlatform(),
    'last_seen_at': _nowUtc(),
  }, onConflict: 'id');
}

/// All devices (admin view), newest first.
Future<List<Device>> loadDevices() async {
  final rows = await supabase
      .from('devices')
      .select()
      .order('created_at', ascending: false);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(Device.fromMap)
      .toList();
}

Future<void> setDeviceApproved(String id, bool approved) async {
  await supabase
      .from('devices')
      .update({
        'approved': approved,
        'approved_at': approved ? _nowUtc() : null,
        'approved_by': approved ? supabase.auth.currentUser?.id : null,
        'updated_at': _nowUtc(),
      })
      .eq('id', id);
}

Future<void> setDeviceActive(String id, bool active) async {
  await supabase
      .from('devices')
      .update({'is_active': active, 'updated_at': _nowUtc()})
      .eq('id', id);
}
