// Flutter port of `src/hooks/useFormApproval.ts` + the relevant slice of
// `src/utils/formRegistry.ts` (the `signaturePaths.shiftBoss` map).
//
// At submit time, every chain form should stamp the submitter's profile
// signature and the current timestamp into its own Shift Boss slot — the
// edge function then takes over and routes the submission through Mine
// Overseer / Mine Manager. Different forms use different payload shapes
// (some nest under `signatures.*`, some are flat, some use a `shiftboss`
// camelCase variant), so this registry mirrors the web app's exact paths
// so both clients write the same JSON.

import 'package:intl/intl.dart';

import '../models/user_profile.dart';

/// Pair of dot-paths inside a form payload — the path that stores the
/// signature data URL, and the path that stores the matching display date.
class SigPath {
  const SigPath({required this.signature, required this.date});
  final String signature;
  final String date;
}

/// Per-form Shift Boss slot paths. Mirrors `FORM_REGISTRATIONS[*].signaturePaths.shiftBoss`
/// in `src/utils/formRegistry.ts`. Forms not in this map have no chain Shift
/// Boss slot (either non-chain forms or chain forms whose first signer isn't
/// the submitter).
const Map<String, SigPath> kShiftBossSignaturePathByFormType = {
  'shift_boss_appointment': SigPath(
    signature: 'signatures.shiftBossSignature',
    date: 'signatures.shiftBossDate',
  ),
  'miner_appointment': SigPath(
    signature: 'signatures.shiftBossSignature',
    date: 'signatures.shiftBossDate',
  ),
  'relieving_miner_appointment': SigPath(
    signature: 'signatures.shiftBossSignature',
    date: 'signatures.shiftBossDate',
  ),
  'gassing_incident': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossDate',
  ),
  'weekly_sherq_meeting': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossDate',
  ),
  'early_shift_record': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossSignatureDate',
  ),
  'late_shift_record': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossSignatureDate',
  ),
  'explosive_control_record': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossDate',
  ),
  'waiting_place_inspection': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossDate',
  ),
  'trackless_machinery_inspection': SigPath(
    signature: 'shiftbossSignature',
    date: 'shiftbossSignatureDate',
  ),
  'action_log_underground_visits': SigPath(
    signature: 'shiftBossSignature',
    date: 'shiftBossDate',
  ),
};

/// Thrown by [applyShiftBossAutoStamp] when the submitter has no saved
/// profile signature *and* the form needs the Shift Boss slot filled. The
/// caller is expected to surface the message to the user.
class MissingProfileSignatureException implements Exception {
  const MissingProfileSignatureException();
  static const String message =
      'Please save a signature in your profile before submitting this form.';
  @override
  String toString() => message;
}

/// Walks `path` (`a.b.c`) on `target`, creating intermediate maps as needed,
/// and writes `value` at the leaf. Mirrors `setPathValue` in
/// `src/utils/formRegistry.ts`.
void setPathValue(Map<String, dynamic> target, String path, Object? value) {
  final parts = path.split('.');
  Map<String, dynamic> current = target;
  for (var i = 0; i < parts.length - 1; i++) {
    final next = current[parts[i]];
    if (next is Map<String, dynamic>) {
      current = next;
    } else {
      final fresh = <String, dynamic>{};
      current[parts[i]] = fresh;
      current = fresh;
    }
  }
  current[parts.last] = value;
}

/// Walks `path` and returns the leaf value, or `null` for missing paths.
/// Mirrors `getPathValue` in `src/utils/formRegistry.ts`.
Object? getPathValue(Map<String, dynamic> source, String path) {
  Object? current = source;
  for (final part in path.split('.')) {
    if (current is Map<String, dynamic> && current.containsKey(part)) {
      current = current[part];
    } else {
      return null;
    }
  }
  return current;
}

/// Africa/Johannesburg "medium date, short time" formatter — matches the
/// web app's `formatTimestamp` (`new Intl.DateTimeFormat('en-ZA', { dateStyle:
/// 'medium', timeStyle: 'short', timeZone: 'Africa/Johannesburg' })`). Both
/// clients live in SAST so we just format the local time without converting.
final DateFormat _approvalTimestampFormat = DateFormat('d MMM y, HH:mm');

String _formatApprovalTimestamp(DateTime now) =>
    _approvalTimestampFormat.format(now);

/// Stamps the submitter's profile signature + current timestamp into the
/// payload's Shift Boss slot when the form has one and the slot is empty.
/// Returns the (possibly modified) payload. Throws
/// [MissingProfileSignatureException] when the form expects a Shift Boss
/// stamp but the submitter has no saved profile signature.
Map<String, dynamic> applyShiftBossAutoStamp({
  required String formType,
  required Map<String, dynamic> payload,
  required UserProfile? profile,
  DateTime? now,
}) {
  final slot = kShiftBossSignaturePathByFormType[formType];
  if (slot == null) return payload;

  final existingSignature = getPathValue(payload, slot.signature);
  final hasExistingSignature =
      existingSignature is String && existingSignature.trim().isNotEmpty;

  if (!hasExistingSignature) {
    final savedSignature = profile?.signatureData?.trim() ?? '';
    if (savedSignature.isEmpty) {
      throw const MissingProfileSignatureException();
    }
    setPathValue(payload, slot.signature, savedSignature);
  }

  final existingDate = getPathValue(payload, slot.date);
  final hasExistingDate =
      existingDate is String && existingDate.trim().isNotEmpty;
  if (!hasExistingDate) {
    setPathValue(payload, slot.date, _formatApprovalTimestamp(now ?? DateTime.now()));
  }

  return payload;
}
