import '../models/user_profile.dart';

String getProfileSectionOrShaft(UserProfile? profile) {
  if (profile == null) return '';
  if ((profile.sectionShaft ?? '').isNotEmpty) return profile.sectionShaft!;
  if ((profile.workArea ?? '').isNotEmpty) return profile.workArea!;
  if ((profile.department ?? '').isNotEmpty) return profile.department!;
  if ((profile.location ?? '').isNotEmpty) return profile.location!;
  return '';
}

String getProfileSection(UserProfile? profile) {
  if (profile == null) return '';
  if ((profile.workArea ?? '').isNotEmpty) return profile.workArea!;
  if ((profile.department ?? '').isNotEmpty) return profile.department!;
  if (profile.costCentre.isNotEmpty) return profile.costCentre;
  if ((profile.sectionShaft ?? '').isNotEmpty) return profile.sectionShaft!;
  return '';
}

class ProfilePersonalDetails {
  final String title;
  final String name;
  final String identityNumber;
  final String companyNumber;
  final String sectionShaft;
  final String shaft;
  final String section;
  final String signature;
  final String location;

  const ProfilePersonalDetails({
    required this.title,
    required this.name,
    required this.identityNumber,
    required this.companyNumber,
    required this.sectionShaft,
    required this.shaft,
    required this.section,
    required this.signature,
    required this.location,
  });
}

ProfilePersonalDetails getProfilePersonalDetails(UserProfile? profile) {
  final shaftLike = getProfileSectionOrShaft(profile);
  return ProfilePersonalDetails(
    title: profile?.title ?? '',
    name: (profile?.fullName.isNotEmpty ?? false)
        ? profile!.fullName
        : (profile?.firstName ?? ''),
    identityNumber: profile?.saIdNumber ?? '',
    companyNumber: (profile?.companyNumber ?? '').isNotEmpty
        ? profile!.companyNumber!
        : (profile?.employeeNumber ?? ''),
    sectionShaft: shaftLike,
    shaft: shaftLike,
    section: getProfileSection(profile),
    signature: profile?.signatureData ?? '',
    location: profile?.location ?? '',
  );
}
