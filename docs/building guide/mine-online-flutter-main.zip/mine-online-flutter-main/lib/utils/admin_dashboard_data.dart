// Data layer for the admin dashboard. Pure `computeAdminDashboard` derives the
// KPI counts + activity feed from already-fetched rows (unit tested);
// `loadAdminDashboard` performs the Supabase reads. Mirrors the query pattern
// in admin_appointments_logbook_screen.dart.

import '../config/supabase_client.dart';

/// Form types treated as appointments (legacy "appointments" table).
const Set<String> kAppointmentFormTypes = {
  'shift_boss_appointment',
  'miner_appointment',
  'relieving_miner',
};

/// Form types treated as safety incidents.
const Set<String> kIncidentFormTypes = {'gassing_incident'};

/// Workflow statuses that count as a form still pending in the chain.
const Set<String> kPendingWorkflowStatuses = {'submitted', 'pending_signature'};

class AppointmentActivityItem {
  const AppointmentActivityItem({
    required this.submissionId,
    required this.name,
    required this.subtitle,
    required this.date,
    required this.workflowStatus,
    required this.currentSignatureRole,
    required this.row,
  });

  final String submissionId;
  final String name;
  final String subtitle;
  final DateTime? date;
  final String? workflowStatus;
  final String? currentSignatureRole;

  /// The raw `form_submissions` row — passed to SubmissionViewerDialog when the
  /// activity entry is tapped.
  final Map<String, dynamic> row;
}

class AdminDashboardData {
  const AdminDashboardData({
    required this.totalEmployees,
    required this.activeAppointments,
    required this.pendingForms,
    required this.safetyIncidents,
    required this.recentActivity,
  });

  final int totalEmployees;
  final int activeAppointments;
  final int pendingForms;
  final int safetyIncidents;
  final List<AppointmentActivityItem> recentActivity;

  static const empty = AdminDashboardData(
    totalEmployees: 0,
    activeAppointments: 0,
    pendingForms: 0,
    safetyIncidents: 0,
    recentActivity: [],
  );
}

String _displayName(Map<String, dynamic>? p) {
  final full = (p?['full_name'] as String?)?.trim() ?? '';
  if (full.isNotEmpty) return full;
  final email = (p?['email'] as String?)?.trim() ?? '';
  if (email.isNotEmpty) return email;
  return 'Unknown user';
}

String _subtitle(Map<String, dynamic>? p) {
  final occ = ((p?['occupation'] as String?)?.trim().isNotEmpty == true)
      ? (p!['occupation'] as String).trim()
      : ((p?['job_title'] as String?)?.trim() ?? '');
  final loc = (p?['location'] as String?)?.trim() ?? '';
  return [occ, loc].where((s) => s.isNotEmpty).join(' • ');
}

/// Pure: derive the dashboard from already-fetched rows. `submissions` is
/// assumed to be ordered newest-first (the feed preserves that order).
AdminDashboardData computeAdminDashboard({
  required int profileCount,
  required List<Map<String, dynamic>> submissions,
  required Map<String, Map<String, dynamic>> profiles,
  int activityLimit = 6,
}) {
  var active = 0;
  var pending = 0;
  var incidents = 0;
  final apptRows = <Map<String, dynamic>>[];

  for (final r in submissions) {
    final type = r['form_type'] as String?;
    final status = r['workflow_status'] as String?;
    final isAppt = type != null && kAppointmentFormTypes.contains(type);
    if (isAppt && status == 'fully_signed') active++;
    if (status != null && kPendingWorkflowStatuses.contains(status)) pending++;
    if (type != null && kIncidentFormTypes.contains(type)) incidents++;
    if (isAppt) apptRows.add(r);
  }

  final recent = apptRows.take(activityLimit).map((r) {
    final uid = r['user_id'] as String?;
    final p = uid == null ? null : profiles[uid];
    final dateStr = r['created_at'] as String?;
    return AppointmentActivityItem(
      submissionId: r['id'] as String? ?? '',
      name: _displayName(p),
      subtitle: _subtitle(p),
      date: dateStr == null ? null : DateTime.tryParse(dateStr),
      workflowStatus: r['workflow_status'] as String?,
      currentSignatureRole: r['current_signature_role'] as String?,
      row: r,
    );
  }).toList();

  return AdminDashboardData(
    totalEmployees: profileCount,
    activeAppointments: active,
    pendingForms: pending,
    safetyIncidents: incidents,
    recentActivity: recent,
  );
}

/// Loads the dashboard data from Supabase.
Future<AdminDashboardData> loadAdminDashboard() async {
  final profileRows = await supabase.from('profiles').select('id');
  final profileCount = (profileRows as List).length;

  final subRows = await supabase
      .from('form_submissions')
      .select(
        'id,user_id,form_type,title,payload,workflow_status,current_signature_role,completed_at,created_at,updated_at',
      )
      .order('created_at', ascending: false, nullsFirst: false)
      .limit(500);
  final submissions = (subRows as List).cast<Map<String, dynamic>>();

  final apptUserIds = submissions
      .where((r) => kAppointmentFormTypes.contains(r['form_type']))
      .map((r) => r['user_id'] as String?)
      .whereType<String>()
      .toSet()
      .toList();

  final profiles = <String, Map<String, dynamic>>{};
  if (apptUserIds.isNotEmpty) {
    final pr = await supabase
        .from('profiles')
        .select('id,full_name,email,occupation,job_title,location')
        .inFilter('id', apptUserIds);
    for (final row in (pr as List).cast<Map<String, dynamic>>()) {
      profiles[row['id'] as String] = row;
    }
  }

  return computeAdminDashboard(
    profileCount: profileCount,
    submissions: submissions,
    profiles: profiles,
  );
}
