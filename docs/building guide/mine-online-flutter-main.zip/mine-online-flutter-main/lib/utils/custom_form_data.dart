// Supabase data access for custom form templates. Mirrors the query/cast
// pattern used elsewhere (admin_appointments_logbook_screen.dart).

import '../config/supabase_client.dart';
import '../models/custom_form_template.dart';

/// Lowercase slug + short suffix → a stable, unique-ish form_type code.
/// e.g. slugifyCode('Daily Safety Check', '1a2b') -> 'custom_daily_safety_check_1a2b'.
String slugifyCode(String name, String suffix) {
  final slug = name
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_+|_+$'), '');
  final base = slug.isEmpty ? 'form' : slug;
  return 'custom_${base}_$suffix';
}

/// Loads templates. [includeArchived] = true returns inactive ones too
/// (admin builder view); false returns only active.
Future<List<CustomFormTemplate>> loadTemplates({
  bool includeArchived = false,
}) async {
  var query = supabase.from('custom_form_templates').select();
  if (!includeArchived) {
    query = query.eq('is_active', true);
  }
  final rows = await query.order('updated_at', ascending: false);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(CustomFormTemplate.fromMap)
      .toList();
}

/// Inserts a new template (when [id] is null) or updates an existing one.
/// Returns the saved row's id. On update, bumps version and sets updated_at.
Future<String> saveTemplate({
  String? id,
  required String code,
  required String name,
  String? description,
  String? category,
  required List<FormFieldDef> fields,
  required List<String> audience,
  required List<String> requiredSigners,
  required int version,
}) async {
  final user = supabase.auth.currentUser;
  final payload = <String, dynamic>{
    'code': code,
    'name': name,
    'description': description,
    'category': category,
    'fields': fields.map((f) => f.toMap()).toList(),
    'audience': audience,
    'required_signers': requiredSigners,
  };
  if (id == null) {
    payload['version'] = 1;
    if (user != null) payload['created_by'] = user.id;
    final inserted = await supabase
        .from('custom_form_templates')
        .insert(payload)
        .select('id')
        .single();
    return inserted['id'] as String;
  } else {
    payload['version'] = version + 1;
    payload['updated_at'] = DateTime.now().toUtc().toIso8601String();
    await supabase.from('custom_form_templates').update(payload).eq('id', id);
    return id;
  }
}

/// Loads a single template by its `code` (the form_submissions.form_type), or
/// null if none exists. Used when regenerating a PDF for a custom submission.
Future<CustomFormTemplate?> loadTemplateByCode(String code) async {
  final rows = await supabase
      .from('custom_form_templates')
      .select()
      .eq('code', code)
      .limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  return list.isEmpty ? null : CustomFormTemplate.fromMap(list.first);
}

Future<void> setTemplateActive(String id, bool active) async {
  await supabase
      .from('custom_form_templates')
      .update({
        'is_active': active,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      })
      .eq('id', id);
}
