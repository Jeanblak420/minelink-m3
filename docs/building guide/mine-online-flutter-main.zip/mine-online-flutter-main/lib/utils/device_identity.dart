// SP6: stable per-install device identity. A uuid is generated once and persisted
// locally (shared_preferences); the platform is detected via dart:io. The cached
// id is read synchronously by the submission persist path for audit stamping.

import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

const _kDeviceIdKey = 'device_id';
String? _cached;

/// In-memory device id (null until [currentDeviceId] has run once this session).
String? get cachedDeviceId => _cached;

/// Get-or-create the stable per-install device id.
Future<String> currentDeviceId() async {
  if (_cached != null) return _cached!;
  final prefs = await SharedPreferences.getInstance();
  var id = prefs.getString(_kDeviceIdKey);
  if (id == null || id.isEmpty) {
    id = const Uuid().v4();
    await prefs.setString(_kDeviceIdKey, id);
  }
  _cached = id;
  return id;
}

/// 'windows' | 'android' | 'other'.
String currentPlatform() {
  if (Platform.isWindows) return 'windows';
  if (Platform.isAndroid) return 'android';
  return 'other';
}

/// A friendly default device name, e.g. "Windows (10.0.26200)".
String defaultDeviceName() {
  final p = currentPlatform();
  final v = Platform.operatingSystemVersion.trim();
  final label = p == 'windows'
      ? 'Windows'
      : (p == 'android' ? 'Android' : 'Device');
  return v.isEmpty ? label : '$label ($v)';
}
