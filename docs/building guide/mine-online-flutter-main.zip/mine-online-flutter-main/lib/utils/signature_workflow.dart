import 'dart:convert';

import '../config/supabase_client.dart';
import '../models/user_profile.dart';
import 'device_identity.dart';
import 'form_approval.dart';

/// When true, a Form Studio "Test" form is open: submissions are NOT written —
/// the persist helpers return a fake id so the fill+sign flow completes for
/// testing without touching real data. Set/reset by the Studio around a Test push.
bool formTestMode = false;

class SignatureWorkflowResult {
  final String? error;
  final bool? success;
  final List<Map<String, dynamic>>? requests;

  SignatureWorkflowResult({this.error, this.success, this.requests});
}

Future<SignatureWorkflowResult> _invoke(Map<String, dynamic> body) async {
  final session = supabase.auth.currentSession;
  if (session == null) {
    return SignatureWorkflowResult(
      error: 'Not authenticated. Please log in again.',
    );
  }

  try {
    final response = await supabase.functions.invoke(
      'signature-workflow',
      body: body,
    );

    if (response.status >= 200 && response.status < 300) {
      final data = response.data;
      if (data is Map<String, dynamic>) {
        if (data['error'] != null) {
          return SignatureWorkflowResult(error: data['error'] as String);
        }
        final requestsRaw = data['requests'];
        return SignatureWorkflowResult(
          success: data['success'] as bool?,
          requests: requestsRaw is List
              ? requestsRaw.whereType<Map<String, dynamic>>().toList(
                  growable: false,
                )
              : null,
        );
      }
      // Some Supabase function clients return a JSON string.
      if (data is String) {
        try {
          final parsed = jsonDecode(data) as Map<String, dynamic>;
          if (parsed['error'] != null) {
            return SignatureWorkflowResult(error: parsed['error'] as String);
          }
          return SignatureWorkflowResult(success: parsed['success'] as bool?);
        } catch (_) {
          return SignatureWorkflowResult(error: data);
        }
      }
      return SignatureWorkflowResult(success: true);
    }
    return SignatureWorkflowResult(
      error: 'Signature workflow server error: ${response.status}',
    );
  } catch (err) {
    return SignatureWorkflowResult(error: err.toString());
  }
}

/// Inserts a form submission without starting a signature workflow.
/// Mirrors the web app's `persistFormSubmission` used by Generate-PDF-only forms.
Future<String?> persistFormSubmission(
  String formType,
  String title,
  Map<String, dynamic> payload,
) async {
  if (formTestMode) return 'test-${DateTime.now().microsecondsSinceEpoch}';
  final user = supabase.auth.currentUser;
  if (user == null) return null;
  try {
    final inserted = await supabase
        .from('form_submissions')
        .insert({
          'user_id': user.id,
          'form_type': formType,
          'title': title,
          'payload': payload,
          if (cachedDeviceId != null) 'device_id': cachedDeviceId,
        })
        .select('id')
        .single();
    return inserted['id'] as String?;
  } catch (err) {
    // ignore: avoid_print
    print('$title could not be saved to the database: $err');
    return null;
  }
}

/// Persists a form submission and starts the approval workflow. Mirrors the
/// web app's `useFormApproval.submit`: before insert, stamps the submitter's
/// profile signature + timestamp into the form's Shift Boss slot (per the
/// per-form map in [kShiftBossSignaturePathByFormType]) when the slot is
/// empty. Throws [MissingProfileSignatureException] when the form needs a
/// Shift Boss stamp but the submitter has no saved profile signature — the
/// caller should surface that to the user instead of writing a half-signed
/// submission.
Future<String?> saveFormSubmissionAndStartWorkflow(
  String formType,
  String title,
  Map<String, dynamic> payload, {
  UserProfile? profile,
}) async {
  if (formTestMode) return 'test-${DateTime.now().microsecondsSinceEpoch}';
  final user = supabase.auth.currentUser;
  if (user == null) return null;

  applyShiftBossAutoStamp(
    formType: formType,
    payload: payload,
    profile: profile,
  );

  try {
    final inserted = await supabase
        .from('form_submissions')
        .insert({
          'user_id': user.id,
          'form_type': formType,
          'title': title,
          'payload': payload,
          if (cachedDeviceId != null) 'device_id': cachedDeviceId,
        })
        .select('id')
        .single();
    final submissionId = inserted['id'] as String?;
    if (submissionId == null) return null;

    final workflow = await _invoke({
      'action': 'start_workflow',
      'submissionId': submissionId,
    });
    if (workflow.error != null) {
      // Match the web app's behaviour: log but still return the submission id.
      // ignore: avoid_print
      print(
        '$title signature workflow could not be started: ${workflow.error}',
      );
    }
    return submissionId;
  } catch (err) {
    // ignore: avoid_print
    print('$title could not be saved to the database: $err');
    return null;
  }
}

Future<List<Map<String, dynamic>>> listSignatureRequests({
  String status = 'pending',
}) async {
  final result = await _invoke({'action': 'list_requests', 'status': status});
  if (result.error != null) {
    throw Exception(result.error);
  }
  return result.requests ?? const <Map<String, dynamic>>[];
}

Future<void> signSignatureRequest(String requestId, String signature) async {
  final result = await _invoke({
    'action': 'sign_request',
    'requestId': requestId,
    'signature': signature,
  });
  if (result.error != null) {
    throw Exception(result.error);
  }
}

/// Roll the workflow back one step. The current signer's pending request is
/// cancelled, the previously signed step (if any) is reset to pending so its
/// signer can re-sign, and that signer + the submitter are notified.
Future<void> sendBackSignatureRequest(
  String requestId, {
  String? reason,
}) async {
  final result = await _invoke({
    'action': 'send_back',
    'requestId': requestId,
    if (reason != null && reason.isNotEmpty) 'reason': reason,
  });
  if (result.error != null) {
    throw Exception(result.error);
  }
}
