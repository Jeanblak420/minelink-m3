// SP4.5 Phase B: a catalog of an existing form's EDITABLE bespoke fields, so the
// builder can offer hide/relabel of them. Keyed by form_type; each entry is the
// stable field id (matches the id passed to the screen's _tf/_yn helpers) + its
// default on-screen label. Only forms instrumented for Phase B appear here.

class FormFieldRef {
  const FormFieldRef(this.id, this.label);
  final String id;
  final String label;
}

/// Per-form ordered list of fields the overlay editor can drag-reorder (a
/// bounded, contiguous, no-conditional block). Single source of truth for the
/// screen's natural id order and the editor's reorder list. SP10b pilot.
const Map<String, List<FormFieldRef>> kReorderableBlocks = {
  'early_shift_record': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('strike', 'Strike'),
    FormFieldRef('date', 'Date'),
    FormFieldRef('wentUndergroundAt', 'Went underground at (am/pm)'),
    FormFieldRef(
      'arrivedAtWaitingPlace',
      'Arrived at waiting place at (am/pm)',
    ),
    FormFieldRef('minerArrivedAt', 'Miner arrived at (am/pm)'),
    FormFieldRef('minerCoyNo', 'Miner Coy No.'),
    FormFieldRef('waitingPlaceLocation', 'Waiting place location'),
  ],
};

/// The reorderable block for [formType] (empty when none).
List<FormFieldRef> reorderableBlockFor(String formType) =>
    kReorderableBlocks[formType] ?? const [];

const Map<String, List<FormFieldRef>> kFormFieldCatalog = {
  // Pilot: the free-text fields of Early Shift Record. (Yes/No checks + other
  // forms are catalogued during the full Phase B rollout.)
  'early_shift_record': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('strike', 'Strike'),
    FormFieldRef('wentUndergroundAt', 'Went underground at (am/pm)'),
    FormFieldRef(
      'arrivedAtWaitingPlace',
      'Arrived at waiting place at (am/pm)',
    ),
    FormFieldRef('minerArrivedAt', 'Miner arrived at (am/pm)'),
    FormFieldRef('minerCoyNo', 'Miner Coy No.'),
    FormFieldRef('waitingPlaceLocation', 'Waiting place location'),
    FormFieldRef('specialInstruction', 'Special instruction given'),
    FormFieldRef('additionalRemarks', 'Additional remarks'),
  ],
  'late_shift_record': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('strike', 'Strike'),
    FormFieldRef('minerInChargeCoyNo', 'Miner in charge Coy No.'),
    FormFieldRef('chargesCorrectlyPrepared', 'Charges correctly prepared?'),
    FormFieldRef('chargingUpDevEndNo', 'Charging up development end no.'),
    FormFieldRef('ventHolingNo', 'Vent holing no.'),
    FormFieldRef(
      'explosiveCorrectlyTransported',
      'Explosive correctly transported to the face?',
    ),
    FormFieldRef(
      'testedForFlammableGas',
      'Tested for flammable gas and CO gas with a GDI?',
    ),
    FormFieldRef('gdiNo', 'GDI No.'),
    FormFieldRef(
      'chargingUnderDirectSupervision',
      'Was charging done under direct supervision of Miner?',
    ),
    FormFieldRef('typeOfExplosivesUsed', 'Type of explosives used'),
    FormFieldRef('typeOfFuseUsed', 'Type of fuse used'),
    FormFieldRef('fuseLength', 'Fuse length'),
    FormFieldRef('amountOfFusesUsed', 'Amount of fuses used'),
    FormFieldRef('holesDislodgedCorrectly', 'Where holes dislodged correctly?'),
    FormFieldRef('lengthOfDrillHoles', 'Length of drill holes'),
    FormFieldRef('lengthOfBlowPipe', 'Length of blow pipe'),
    FormFieldRef(
      'blastingCableToStandard',
      'Blasting cable installed to standard?',
    ),
    FormFieldRef('circuitTested', 'Circuit tested?'),
    FormFieldRef(
      'blastingCableConnectedToTerminalBox',
      'Blasting cable connected correctly to terminal box?',
    ),
    FormFieldRef(
      'distributionOfOldExplosivesObserved',
      'Distribution of old explosives observed?',
    ),
    FormFieldRef(
      'distributionOfOldExplosivesDiscussed',
      'Distribution of old explosives discussed?',
    ),
    FormFieldRef(
      'workingPlaceBarricadeInPosition',
      'Working place barricade in position?',
    ),
    FormFieldRef('explosiveBoxesLocked', 'Explosive boxes locked?'),
    FormFieldRef('idCardsCorrectlyIssued', 'Were ID cards correctly issued?'),
    FormFieldRef('airAndWaterHosesClosed', 'Air and water hoses closed?'),
    FormFieldRef(
      'anyIncidentInjuriesReported',
      'Any incident /injuries reported?',
    ),
    FormFieldRef('arrivedOnSurfaceAt', 'Arrived on surface at (am/pm)'),
    FormFieldRef('specialInstructionsGiven', 'Special instructions given'),
    FormFieldRef('additionalRemarks', 'Additional remarks'),
  ],
  'explosive_control_record': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('strike', 'Strike'),
    FormFieldRef('minerCoyNo', 'Miner Coy No.'),
    FormFieldRef('deviationsObserved', 'Deviations observed?'),
    FormFieldRef(
      'deviationsDetails',
      "If 'yes', give details and remedial actions",
    ),
    FormFieldRef('oldBoxesMarked', 'Are the old explosive boxes marked?'),
    FormFieldRef(
      'oldBoxesMarkedDetails',
      "If 'NO', give details and remedial actions",
    ),
    FormFieldRef('oldBoxesLocked', 'Are the old explosive boxes locked?'),
    FormFieldRef(
      'oldBoxesLockedDetails',
      "If 'no' give details and remedial actions",
    ),
    FormFieldRef('typeOfExplosiveInBox', 'Type of explosive in the box?'),
    FormFieldRef('totalInBox', 'Total in the box'),
    FormFieldRef(
      'recordedCorrectly',
      'Recorded correctly in the miners control book?',
    ),
    FormFieldRef(
      'recordedDetails',
      "If 'no' give details and remedial actions",
    ),
    FormFieldRef('specialInstructions', 'Special instructions given'),
  ],
  'gassing_incident': [
    FormFieldRef('coyNoOfInjured', 'Coy No. of Injured'),
    FormFieldRef('time', 'Time'),
    FormFieldRef('workingPlace', 'Working Place'),
    FormFieldRef('severity', 'Severity'),
    FormFieldRef('description', 'Description'),
    FormFieldRef('injuries', 'Injuries'),
  ],
  'weekly_sherq_meeting': [
    FormFieldRef('time', 'Time'),
    FormFieldRef('workplace', 'Workplace'),
    FormFieldRef('duration', 'Duration'),
    FormFieldRef('supervisorCoyNo', 'Supervisor Coy No.'),
    FormFieldRef('sheRepCoyNo', 'SHE REP Coy No.'),
    FormFieldRef('mattersDiscussed', 'Matters Discussed'),
    FormFieldRef('feedbackFromCrew', 'Feedback from Crew'),
  ],
  'shift_boss_daily_report': [
    FormFieldRef('ventilationFlowReading', 'Ventilation flow (>0.5 m/s)'),
    FormFieldRef('temperatureWBReading', 'Temperature WB (<27.5 C)'),
    FormFieldRef('temperatureDBReading', 'Temperature DB (<32.5 C)'),
    FormFieldRef('general', 'General'),
    FormFieldRef(
      'mineOverseerComments',
      'Mine Overseer Comments / Instruction',
    ),
  ],
  'shift_boss_appointment': [
    FormFieldRef('title', 'Title (Mr/Mrs/Miss)'),
    FormFieldRef('name', 'Full Name'),
    FormFieldRef('identityNumber', 'Identity Number'),
    FormFieldRef('companyNumber', 'Company Number'),
    FormFieldRef('shaft', 'Shaft'),
    FormFieldRef('stopes', 'Stopes/Working places'),
    FormFieldRef('developmentEnds', 'Development ends / Vent Holings'),
    FormFieldRef('declines', 'Declines'),
    FormFieldRef('loadAndHaul', 'Load and Haul / Roadway'),
    FormFieldRef('travellingWay', 'Travelling way'),
    FormFieldRef('refugeBay', 'Refuge Bay'),
    FormFieldRef('store', 'Store'),
    FormFieldRef('waitingPlace', 'Waiting place'),
    FormFieldRef('conveyorBelts', 'Conveyor belts / Tipping area'),
    FormFieldRef('otherWorkplaces', 'Any other workplaces specified'),
  ],
  'miner_appointment': [
    FormFieldRef('title', 'Title'),
    FormFieldRef('name', 'Full Name'),
    FormFieldRef('identityNumber', 'Identity Number'),
    FormFieldRef('companyNumber', 'Company Number'),
    FormFieldRef('sectionShaft', 'Section/Shaft'),
    FormFieldRef('workplaces.stopes', 'Stopes/Working places'),
    FormFieldRef(
      'workplaces.developmentEnds',
      'Development ends / Vent Holings',
    ),
    FormFieldRef('workplaces.declines', 'Declines'),
    FormFieldRef('workplaces.loadAndHaul', 'Load and Haul / Roadway'),
    FormFieldRef('workplaces.travellingWay', 'Travelling way'),
    FormFieldRef('workplaces.refugeBay', 'Refuge Bay'),
    FormFieldRef('workplaces.store', 'Store'),
    FormFieldRef('workplaces.waitingPlace', 'Waiting place'),
    FormFieldRef('workplaces.conveyorBelts', 'Conveyor belts / Tipping area'),
    FormFieldRef(
      'workplaces.otherWorkplaces',
      'Any other workplaces specified',
    ),
  ],
  'relieving_miner_appointment': [
    FormFieldRef('title', 'Title'),
    FormFieldRef('name', 'Full Name'),
    FormFieldRef('identityNumber', 'Identity Number'),
    FormFieldRef('companyNumber', 'Company Number'),
    FormFieldRef('sectionShaft', 'Section/Shaft'),
    FormFieldRef('workplaces_stopes', 'Stopes/Working places'),
    FormFieldRef(
      'workplaces_developmentEnds',
      'Development ends / Vent Holings',
    ),
    FormFieldRef('workplaces_declines', 'Declines'),
    FormFieldRef('workplaces_loadAndHaul', 'Load and Haul / Roadway'),
    FormFieldRef('workplaces_travellingWay', 'Travelling way'),
    FormFieldRef('workplaces_refugeBay', 'Refuge Bay'),
    FormFieldRef('workplaces_store', 'Store'),
    FormFieldRef('workplaces_waitingPlace', 'Waiting place'),
    FormFieldRef('workplaces_conveyorBelts', 'Conveyor belts / Tipping area'),
    FormFieldRef(
      'workplaces_otherWorkplaces',
      'Any other workplaces specified',
    ),
  ],
  'safety_health_rep': [
    FormFieldRef('primary.name', 'Name'),
    FormFieldRef('primary.companyNumber', 'Coy No.'),
    FormFieldRef('primary.shaft', 'Shaft'),
    FormFieldRef('primary.section', 'Section'),
    FormFieldRef('primary.signatures.managerWitness', 'Manager Witness'),
    FormFieldRef('primary.signatures.acceptedWitness', 'Accepted Witness'),
    FormFieldRef('alternative.name', 'Name'),
    FormFieldRef('alternative.companyNumber', 'Coy No.'),
    FormFieldRef('alternative.shaft', 'Shaft'),
    FormFieldRef('alternative.section', 'Section'),
    FormFieldRef('alternative.signatures.managerWitness', 'Manager Witness'),
    FormFieldRef('alternative.signatures.acceptedWitness', 'Accepted Witness'),
  ],
  'action_log_underground_visits': [
    FormFieldRef('workingPlaceVisited', 'Working place visited'),
    FormFieldRef('nameOfSeniorOfficial', 'Name of senior official'),
    FormFieldRef('designation', 'Designation'),
  ],
  'special_instruction': [
    FormFieldRef('section1.time', 'Time'),
    FormFieldRef('section1.instructionTo', 'Instruction to'),
    FormFieldRef('section1.detailOfInstruction', 'Detail of instruction'),
    FormFieldRef('section1.remedialAction', 'Remedial action'),
    FormFieldRef('section2.time', 'Time'),
    FormFieldRef('section2.instructionTo', 'Instruction to'),
    FormFieldRef('section2.detailOfInstruction', 'Detail of instruction'),
    FormFieldRef('section2.remedialAction', 'Remedial action'),
  ],
  'special_brief_instruction_register': [
    FormFieldRef('intro', 'Register intro instruction'),
  ],
  'inspection_control_sheet': [
    FormFieldRef('monthFrom', 'Month from'),
    FormFieldRef('monthTo', 'Month to'),
  ],
  'waiting_place_inspection': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('miner', 'Miner'),
    FormFieldRef('specialInstructions', 'Special instructions given'),
  ],
  'refuge_bay_inspection': [
    FormFieldRef('shaft', 'Shaft'),
    FormFieldRef('observer', 'Observer'),
    FormFieldRef('refugeBayNo', 'Refuge Bay No.'),
    FormFieldRef('mineOverseer', 'Mine Overseer'),
    FormFieldRef('section', 'Section'),
    FormFieldRef('isLifeSustainable', 'Is this Refuge Bay life sustainable?'),
  ],
  'conveyor_belt_inspection': [
    FormFieldRef('positionOfBelt', 'Position of belt'),
  ],
  'rock_breaker_inspection': [
    FormFieldRef('positionOfRockBreaker', 'Position of rock breaker'),
  ],
  'belt_tip_area_inspection': [
    FormFieldRef('positionOfTip', 'Position of tip'),
  ],
  'monthly_fire_fighting_inspection': [
    FormFieldRef('department', 'Department'),
    FormFieldRef('area', 'Area'),
    FormFieldRef('name', 'Name'),
    FormFieldRef('designation', 'Designation'),
    FormFieldRef('inspectorName', 'Inspector name'),
    FormFieldRef('sectionHeadName', 'Section head name'),
  ],
  'emergency_drill_exercise': [
    FormFieldRef('shiftBoss', 'Shift Boss'),
    FormFieldRef('workingPlace', 'Working place'),
    FormFieldRef('typeOfEmergency', 'Type of emergency'),
    FormFieldRef('alarmMadeAt', 'Alarm made at'),
    FormFieldRef('allPersonsEvacuatedBy', 'All persons evacuated by'),
    FormFieldRef('routesTaken', 'Routes taken'),
    FormFieldRef('procedureA', 'Procedure A'),
    FormFieldRef('procedureB', 'Procedure B'),
    FormFieldRef('procedureC', 'Procedure C'),
    FormFieldRef('procedureD', 'Procedure D'),
    FormFieldRef('procedureE', 'Procedure E'),
    FormFieldRef('procedureF', 'Procedure F'),
    FormFieldRef('rescuingInjuredWorkers', 'Rescuing injured workers'),
    FormFieldRef('extinguishingFire', 'Extinguishing fire'),
    FormFieldRef('majorFireOrExplosion', 'Major fire or explosion'),
    FormFieldRef('generalRemarks', 'General remarks'),
  ],
  // Shared screen (emergency_drill_form_screen) — same fields for both types.
  'verbal_emergency_drills': [
    FormFieldRef('refugeBayNo', 'Refuge Bay No.'),
    FormFieldRef('workingPlace', 'Working place'),
    FormFieldRef('emergencyDrillPerformed', 'Emergency Drill performed'),
    FormFieldRef('deficienciesObserved', 'Deficiencies observed'),
    FormFieldRef('recommendedImprovements', 'Recommended Improvements'),
    FormFieldRef('refugeBaySituatedAt', 'Refuge Bay situated at'),
  ],
  'physical_emergency_drills': [
    FormFieldRef('refugeBayNo', 'Refuge Bay No.'),
    FormFieldRef('workingPlace', 'Working place'),
    FormFieldRef('emergencyDrillPerformed', 'Emergency Drill performed'),
    FormFieldRef('deficienciesObserved', 'Deficiencies observed'),
    FormFieldRef('recommendedImprovements', 'Recommended Improvements'),
    FormFieldRef('refugeBaySituatedAt', 'Refuge Bay situated at'),
  ],
};

List<FormFieldRef> catalogFor(String formType) =>
    kFormFieldCatalog[formType] ?? const [];
