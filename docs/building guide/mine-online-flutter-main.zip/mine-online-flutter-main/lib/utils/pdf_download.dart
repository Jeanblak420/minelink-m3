// Save a generated PDF directly to disk via the system "save file" dialog,
// instead of routing through the print-preview overlay.
//
// On Windows/macOS/Linux `file_picker` returns the absolute path the user
// chose, and we write the bytes ourselves. On Android/iOS `file_picker`
// writes the bytes itself via the Storage Access Framework when `bytes` is
// supplied, and returns the resulting path/URI.

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';

class PdfSaveResult {
  const PdfSaveResult({required this.saved, this.path, this.error});

  /// `true` if the file was written. `false` if the user cancelled the dialog
  /// or an error occurred (in which case [error] is populated).
  final bool saved;
  final String? path;
  final String? error;
}

String _safeStem(String name) {
  final stripped =
      name.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), '');
  final cleaned = stripped
      .replaceAll(RegExp(r'[^A-Za-z0-9_\- ]+'), '_')
      .replaceAll(RegExp(r'^[_\s]+|[_\s]+$'), '')
      .replaceAll(RegExp(r'\s+'), '_');
  return cleaned.isEmpty ? 'submission' : cleaned;
}

Future<PdfSaveResult> savePdfBytes({
  required Uint8List bytes,
  required String suggestedName,
}) async {
  final defaultName = '${_safeStem(suggestedName)}.pdf';
  try {
    final path = await FilePicker.saveFile(
      dialogTitle: 'Save PDF',
      fileName: defaultName,
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
      bytes: bytes,
    );
    if (path == null) return const PdfSaveResult(saved: false);

    if (!kIsWeb &&
        (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      await File(path).writeAsBytes(bytes, flush: true);
    }
    return PdfSaveResult(saved: true, path: path);
  } catch (err) {
    return PdfSaveResult(saved: false, error: err.toString());
  }
}
