// SP7 Analytics — client-side aggregation over existing tables. The pure
// computeAnalytics() is unit-tested; loadAnalytics() fetches the date-windowed
// rows and delegates. Mirrors admin_dashboard_data.dart (no SQL views/RPCs).

import '../config/supabase_client.dart';

/// Map entries sorted by value descending.
List<MapEntry<String, int>> sortedDesc(Map<String, int> m) {
  final entries = m.entries.toList();
  entries.sort((a, b) => b.value.compareTo(a.value));
  return entries;
}

class AnalyticsSummary {
  const AnalyticsSummary({
    required this.formsTotal,
    required this.formsChangePct,
    required this.formsByType,
    required this.formsByStatus,
    required this.formsPerDay,
    required this.apptTotal,
    required this.apptByStatus,
    required this.apptByRole,
    required this.apptAcceptanceRate,
    required this.profilesByAccountType,
    required this.devicesTotal,
    required this.devicesByPlatform,
    required this.devicesPending,
    required this.sigPendingByRole,
    required this.sigCompletionRate,
  });

  final int formsTotal;
  final num? formsChangePct;
  final Map<String, int> formsByType;
  final Map<String, int> formsByStatus;
  final List<int> formsPerDay;

  final int apptTotal;
  final Map<String, int> apptByStatus;
  final Map<String, int> apptByRole;
  final double apptAcceptanceRate;

  final Map<String, int> profilesByAccountType;

  final int devicesTotal;
  final Map<String, int> devicesByPlatform;
  final int devicesPending;

  final Map<String, int> sigPendingByRole;
  final double sigCompletionRate;
}

void _bump(Map<String, int> m, String? key, {String fallback = '(none)'}) {
  final k = (key == null || key.isEmpty) ? fallback : key;
  m[k] = (m[k] ?? 0) + 1;
}

DateTime? _parse(dynamic v) {
  if (v is! String || v.isEmpty) return null;
  try {
    return DateTime.parse(v).toUtc();
  } catch (_) {
    return null;
  }
}

AnalyticsSummary computeAnalytics({
  required DateTime now,
  required int days,
  required List<Map<String, dynamic>> submissions,
  required int priorSubmissionsCount,
  required List<Map<String, dynamic>> appointments,
  required List<Map<String, dynamic>> profiles,
  required List<Map<String, dynamic>> devices,
  required List<Map<String, dynamic>> signatureRequests,
}) {
  // Forms
  final byType = <String, int>{};
  final byStatus = <String, int>{};
  final perDay = List<int>.filled(days, 0); // index 0 = oldest, last = today
  final nowUtc = now.toUtc();
  for (final r in submissions) {
    _bump(byType, r['form_type'] as String?, fallback: '(unknown)');
    _bump(byStatus, r['workflow_status'] as String?, fallback: '(none)');
    final created = _parse(r['created_at']);
    if (created != null) {
      final ago = nowUtc.difference(created).inDays;
      if (ago >= 0 && ago < days) perDay[days - 1 - ago]++;
    }
  }
  final formsTotal = submissions.length;
  final num? changePct = priorSubmissionsCount == 0
      ? null
      : ((formsTotal - priorSubmissionsCount) / priorSubmissionsCount) * 100;

  // Appointments
  final apptByStatus = <String, int>{};
  final apptByRole = <String, int>{};
  var accepted = 0;
  for (final r in appointments) {
    _bump(apptByStatus, r['status'] as String?);
    _bump(apptByRole, r['role_code'] as String?, fallback: '(no role)');
    if (r['accepted_at'] != null) accepted++;
  }
  final apptTotal = appointments.length;
  final acceptanceRate = apptTotal == 0 ? 0.0 : accepted / apptTotal;

  // Profiles
  final profilesByType = <String, int>{};
  for (final r in profiles) {
    _bump(
      profilesByType,
      r['user_account_type'] as String?,
      fallback: 'Unassigned',
    );
  }

  // Devices
  final devicesByPlatform = <String, int>{};
  var devicesPending = 0;
  for (final r in devices) {
    _bump(devicesByPlatform, r['platform'] as String?, fallback: 'other');
    final approved = (r['approved'] ?? false) as bool;
    final active = (r['is_active'] ?? true) as bool;
    if (active && !approved) devicesPending++;
  }

  // Signatures
  final sigPendingByRole = <String, int>{};
  var sigSigned = 0;
  for (final r in signatureRequests) {
    final status = r['status'] as String?;
    if (status == 'signed') sigSigned++;
    if (status == 'pending') {
      _bump(
        sigPendingByRole,
        r['requested_role'] as String?,
        fallback: '(role)',
      );
    }
  }
  final sigTotal = signatureRequests.length;
  final sigCompletion = sigTotal == 0 ? 0.0 : sigSigned / sigTotal;

  return AnalyticsSummary(
    formsTotal: formsTotal,
    formsChangePct: changePct,
    formsByType: byType,
    formsByStatus: byStatus,
    formsPerDay: perDay,
    apptTotal: apptTotal,
    apptByStatus: apptByStatus,
    apptByRole: apptByRole,
    apptAcceptanceRate: acceptanceRate,
    profilesByAccountType: profilesByType,
    devicesTotal: devices.length,
    devicesByPlatform: devicesByPlatform,
    devicesPending: devicesPending,
    sigPendingByRole: sigPendingByRole,
    sigCompletionRate: sigCompletion,
  );
}

String _iso(DateTime d) => d.toUtc().toIso8601String();

/// Fetches the date-windowed rows and computes the summary.
Future<AnalyticsSummary> loadAnalytics({int days = 30}) async {
  final now = DateTime.now().toUtc();
  final from = now.subtract(Duration(days: days));
  final priorFrom = now.subtract(Duration(days: days * 2));

  final submissions =
      (await supabase
              .from('form_submissions')
              .select('form_type, workflow_status, created_at')
              .gte('created_at', _iso(from))
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final priorRows =
      (await supabase
              .from('form_submissions')
              .select('id')
              .gte('created_at', _iso(priorFrom))
              .lt('created_at', _iso(from))
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final appointments =
      (await supabase
              .from('appointments')
              .select('status, role_code, accepted_at, issued_at')
              .gte('issued_at', _iso(from))
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final profiles =
      (await supabase.from('profiles').select('user_account_type').limit(5000))
          .cast<Map<String, dynamic>>();

  final devices =
      (await supabase
              .from('devices')
              .select('platform, approved, is_active')
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final signatureRequests =
      (await supabase
              .from('signature_requests')
              .select('requested_role, status, created_at')
              .gte('created_at', _iso(from))
              .limit(5000))
          .cast<Map<String, dynamic>>();

  return computeAnalytics(
    now: now,
    days: days,
    submissions: submissions,
    priorSubmissionsCount: priorRows.length,
    appointments: appointments,
    profiles: profiles,
    devices: devices,
    signatureRequests: signatureRequests,
  );
}
