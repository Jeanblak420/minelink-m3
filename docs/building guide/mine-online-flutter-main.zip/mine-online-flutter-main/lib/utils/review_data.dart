// SP9b Submission review — reads form_submissions for the admin queue, writes
// reviews through the set_submission_review RPC. reviewStatusLabel is pure.

import '../config/supabase_client.dart';
import 'form_metadata.dart' show kFormMetadataRegistry;

final Map<String, String> _labels = {
  for (final m in kFormMetadataRegistry) m.formType: m.title,
};

String _formLabel(String formType) => _labels[formType] ?? formType;

/// Pure: human label for a review_status (null/empty/pending → Pending).
String reviewStatusLabel(String? status) {
  switch ((status ?? '').isEmpty ? 'pending' : status) {
    case 'pending':
      return 'Pending';
    case 'approved':
      return 'Approved';
    case 'rejected':
      return 'Rejected';
    case 'flagged':
      return 'Flagged';
    default:
      return status!;
  }
}

class ReviewSubmission {
  const ReviewSubmission({
    required this.id,
    required this.userId,
    required this.formType,
    required this.formLabel,
    required this.title,
    required this.submitter,
    required this.createdAt,
    required this.workflowStatus,
    required this.reviewStatus,
    required this.reviewNote,
    required this.raw,
  });

  final String id;
  final String? userId;
  final String formType;
  final String formLabel;
  final String title;
  final String submitter;
  final DateTime? createdAt;
  final String? workflowStatus;
  final String reviewStatus;
  final String? reviewNote;
  final Map<String, dynamic> raw;
}

Future<List<ReviewSubmission>> loadReviewQueue({String? status}) async {
  var query = supabase
      .from('form_submissions')
      .select(
        'id, user_id, form_type, title, payload, workflow_status, '
        'current_signature_role, review_status, review_note, created_at',
      );
  if (status != null && status.isNotEmpty) {
    query = query.eq('review_status', status);
  }
  final rows = (await query.order('created_at', ascending: false).limit(1000))
      .cast<Map<String, dynamic>>();

  final userIds = rows
      .map((r) => r['user_id'] as String?)
      .whereType<String>()
      .toSet()
      .toList();
  final names = <String, String>{};
  if (userIds.isNotEmpty) {
    final pr =
        (await supabase
                .from('profiles')
                .select('id, full_name, email')
                .inFilter('id', userIds))
            .cast<Map<String, dynamic>>();
    for (final p in pr) {
      final n = ((p['full_name'] as String?)?.trim().isNotEmpty == true)
          ? (p['full_name'] as String).trim()
          : (p['email'] as String? ?? '').trim();
      if (n.isNotEmpty) names[p['id'] as String] = n;
    }
  }

  return rows.map((r) {
    final type = r['form_type'] as String? ?? '';
    final uid = r['user_id'] as String?;
    return ReviewSubmission(
      id: r['id'] as String? ?? '',
      userId: uid,
      formType: type,
      formLabel: _formLabel(type),
      title: (r['title'] as String?)?.trim().isNotEmpty == true
          ? r['title'] as String
          : _formLabel(type),
      submitter: (uid != null ? names[uid] : null) ?? 'Unknown user',
      createdAt: r['created_at'] is String
          ? DateTime.tryParse(r['created_at'] as String)
          : null,
      workflowStatus: r['workflow_status'] as String?,
      reviewStatus: (r['review_status'] as String?) ?? 'pending',
      reviewNote: r['review_note'] as String?,
      raw: r,
    );
  }).toList();
}

Future<void> setSubmissionReview({
  required String id,
  required String status,
  String? note,
}) async {
  await supabase.rpc(
    'set_submission_review',
    params: {
      'p_submission_id': id,
      'p_status': status,
      'p_note': (note != null && note.trim().isNotEmpty) ? note.trim() : null,
    },
  );
}
