import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';

const _bucketId = 'todo-attachments';

class TodoAttachmentUploadResult {
  const TodoAttachmentUploadResult({
    required this.path,
    required this.publicUrl,
  });

  final String path;
  final String publicUrl;
}

String _safeFilename(String name) {
  final cleaned = name
      .replaceAll(RegExp(r'[^A-Za-z0-9._-]+'), '_')
      .replaceAll(RegExp(r'^[._]+|[._]+$'), '');
  return cleaned.isEmpty ? 'attachment.png' : cleaned;
}

String _extensionFor(String contentType, String filename) {
  switch (contentType) {
    case 'image/png':
      return '.png';
    case 'image/jpeg':
      return '.jpg';
    case 'image/webp':
      return '.webp';
    case 'image/gif':
      return '.gif';
  }
  final dot = filename.lastIndexOf('.');
  return dot > 0 ? filename.substring(dot).toLowerCase() : '';
}

Future<TodoAttachmentUploadResult> uploadTodoAttachment({
  required Uint8List bytes,
  required String userId,
  required String filename,
  String contentType = 'image/png',
}) async {
  final ts = DateTime.now().millisecondsSinceEpoch;
  final ext = _extensionFor(contentType, filename);
  final safe = _safeFilename(
    filename.endsWith(ext) ? filename : '$filename$ext',
  );
  final path = '$userId/$ts-$safe';

  await supabase.storage.from(_bucketId).uploadBinary(
        path,
        bytes,
        fileOptions: FileOptions(
          contentType: contentType,
          upsert: false,
        ),
      );

  final publicUrl = supabase.storage.from(_bucketId).getPublicUrl(path);
  return TodoAttachmentUploadResult(path: path, publicUrl: publicUrl);
}

String todoAttachmentPublicUrl(String storagePath) {
  return supabase.storage.from(_bucketId).getPublicUrl(storagePath);
}

Future<void> deleteTodoAttachment(String storagePath) async {
  try {
    await supabase.storage.from(_bucketId).remove([storagePath]);
  } catch (e) {
    if (kDebugMode) {
      debugPrint('deleteTodoAttachment failed for $storagePath: $e');
    }
  }
}
