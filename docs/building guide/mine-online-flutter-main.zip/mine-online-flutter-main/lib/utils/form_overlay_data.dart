// FS1 Form Template Studio: an overlay draft is a custom_form_templates row with
// base_form_type set + its own overlay + an is_active flag. At most one active
// draft per base form (DB index); the active draft drives the real form via
// loadFormOverlay(). No active draft -> the bespoke original is the fallback.

import '../config/supabase_client.dart';
import '../models/form_overlay.dart';

class OverlayDraft {
  const OverlayDraft({
    required this.id,
    required this.baseFormType,
    required this.name,
    required this.isActive,
    required this.overlay,
  });

  final String id;
  final String baseFormType;
  final String name;
  final bool isActive;
  final FormOverlay overlay;

  factory OverlayDraft.fromRow(Map<String, dynamic> r) => OverlayDraft(
    id: r['id'] as String,
    baseFormType: r['base_form_type'] as String? ?? '',
    name: (r['name'] as String?) ?? 'Untitled',
    isActive: (r['is_active'] as bool?) ?? false,
    overlay: r['overlay'] is Map
        ? FormOverlay.fromMap((r['overlay'] as Map).cast<String, dynamic>())
        : const FormOverlay(
            addedFields: [],
            addedPages: [],
            fieldOverrides: {},
          ),
  );
}

/// Pure: the active draft's name for [baseFormType], or null.
String? activeDraftName(List<OverlayDraft> drafts, String baseFormType) {
  for (final d in drafts) {
    if (d.baseFormType == baseFormType && d.isActive) return d.name;
  }
  return null;
}

/// Loads just the per-field overrides for the active draft (empty when none).
/// Used by bespoke screens to hide/relabel their existing fields.
Future<Map<String, FieldOverride>> loadFieldOverrides(String formType) async {
  final overlay = await loadFormOverlay(formType);
  return overlay?.fieldOverrides ?? const {};
}

/// The ACTIVE overlay draft for [formType], or null (original = fallback).
Future<FormOverlay?> loadFormOverlay(String formType) async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('overlay')
      .eq('base_form_type', formType)
      .eq('is_active', true)
      .limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  if (list.isEmpty) return null;
  final raw = list.first['overlay'];
  if (raw is! Map) return null;
  return FormOverlay.fromMap(raw.cast<String, dynamic>());
}

/// All overlay drafts (edited copies of built-in forms), ordered by form + name.
Future<List<OverlayDraft>> listOverlayDrafts() async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('id, base_form_type, name, is_active, overlay')
      .not('base_form_type', 'is', null)
      .order('base_form_type')
      .order('name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(OverlayDraft.fromRow)
      .toList();
}

/// Loads a single draft by id (for the editor).
Future<OverlayDraft?> loadOverlayDraft(String id) async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('id, base_form_type, name, is_active, overlay')
      .eq('id', id)
      .limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  return list.isEmpty ? null : OverlayDraft.fromRow(list.first);
}

/// Creates a new (inactive) editable copy of [baseFormType]. Empty overlay ->
/// the draft renders identically to the original until edited.
Future<String> createOverlayDraft(String baseFormType, String name) async {
  final user = supabase.auth.currentUser;
  final row = await supabase
      .from('custom_form_templates')
      .insert({
        'code': 'ov_${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}',
        'name': name,
        'base_form_type': baseFormType,
        'fields': <dynamic>[],
        'overlay': const <String, dynamic>{},
        'is_active': false,
        if (user != null) 'created_by': user.id,
      })
      .select('id')
      .single();
  return row['id'] as String;
}

Future<void> saveOverlayDraft(
  String id, {
  required String name,
  required FormOverlay overlay,
}) async {
  await supabase
      .from('custom_form_templates')
      .update({
        'name': name,
        'overlay': overlay.toMap(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      })
      .eq('id', id);
}

Future<void> deleteOverlayDraft(String id) async {
  await supabase.from('custom_form_templates').delete().eq('id', id);
}

/// Activates [id] for [baseFormType], deactivating any sibling drafts first
/// (the DB index allows only one active per form).
Future<void> setOverlayDraftActive(String id, String baseFormType) async {
  await supabase
      .from('custom_form_templates')
      .update({'is_active': false})
      .eq('base_form_type', baseFormType);
  await supabase
      .from('custom_form_templates')
      .update({'is_active': true})
      .eq('id', id);
}

/// Reverts [baseFormType] to its original by deactivating every draft for it.
Future<void> deactivateOverlayForForm(String baseFormType) async {
  await supabase
      .from('custom_form_templates')
      .update({'is_active': false})
      .eq('base_form_type', baseFormType);
}
