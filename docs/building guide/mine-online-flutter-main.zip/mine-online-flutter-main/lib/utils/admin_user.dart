// Wraps the `admin-create-user` Supabase edge function. Mirrors the `callAdmin`
// helper in `src/components/UserProfiles.tsx` (lines 236-259). The function
// runs with the project's service-role key, which is why creating users from
// the client is gated behind it instead of `supabase.auth.signUp`.

import '../config/supabase_client.dart';

class AdminUserResult {
  const AdminUserResult({this.userId, this.error});
  final String? userId;
  final String? error;

  bool get success => error == null;
}

Future<AdminUserResult> _invoke(Map<String, dynamic> body) async {
  final session = supabase.auth.currentSession;
  if (session == null) {
    return const AdminUserResult(
      error: 'Not authenticated. Please log in again.',
    );
  }
  try {
    final response = await supabase.functions.invoke(
      'admin-create-user',
      body: body,
    );
    final data = response.data;
    if (response.status >= 200 && response.status < 300) {
      if (data is Map<String, dynamic>) {
        final err = data['error'];
        if (err is String && err.isNotEmpty) {
          return AdminUserResult(error: _stripErrorPrefix(err));
        }
        final user = data['user'];
        final userId = user is Map<String, dynamic>
            ? user['id'] as String?
            : null;
        return AdminUserResult(userId: userId);
      }
      return const AdminUserResult();
    }
    if (data is Map<String, dynamic> && data['error'] is String) {
      return AdminUserResult(error: _stripErrorPrefix(data['error']));
    }
    return AdminUserResult(error: 'Server error: ${response.status}');
  } catch (err) {
    return AdminUserResult(error: err.toString());
  }
}

String _stripErrorPrefix(String value) =>
    value.replaceFirst(RegExp(r'^Error:\s*'), '');

/// Create a new auth user. Returns the new user id on success.
Future<AdminUserResult> adminCreateUser({
  required String email,
  required String password,
}) => _invoke({'action': 'create', 'email': email, 'password': password});

/// Update an existing user's password.
Future<AdminUserResult> adminUpdatePassword({
  required String userId,
  required String password,
}) => _invoke({
  'action': 'update_password',
  'userId': userId,
  'password': password,
});

/// Hard-delete an auth user (also cascades the profile row).
Future<AdminUserResult> adminDeleteUser({required String userId}) =>
    _invoke({'action': 'delete', 'userId': userId});

/// Disable (ban) or re-enable a user. Server-side bans the auth user, flips
/// `profiles.disabled`, and writes an audit_log entry.
Future<AdminUserResult> adminSetUserDisabled({
  required String userId,
  required bool disabled,
}) =>
    _invoke({'action': 'set_disabled', 'userId': userId, 'disabled': disabled});
