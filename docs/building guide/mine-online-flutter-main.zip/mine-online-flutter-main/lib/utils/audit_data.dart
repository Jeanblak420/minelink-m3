// SP9a Audit trail — reads the existing public.audit_log. describeAuditEntry is
// pure and unit-tested; the loaders fetch rows + resolve actor/target names.

import '../config/supabase_client.dart';

class AuditEntry {
  const AuditEntry({
    required this.id,
    required this.actorId,
    required this.action,
    required this.entityType,
    required this.entityId,
    required this.oldValues,
    required this.newValues,
    required this.createdAt,
  });

  final String id;
  final String? actorId;
  final String action;
  final String? entityType;
  final String? entityId;
  final Map<String, dynamic>? oldValues;
  final Map<String, dynamic>? newValues;
  final DateTime? createdAt;

  factory AuditEntry.fromMap(Map<String, dynamic> m) {
    Map<String, dynamic>? asMap(dynamic v) =>
        v is Map ? v.cast<String, dynamic>() : null;
    DateTime? parse(dynamic v) =>
        v is String && v.isNotEmpty ? DateTime.tryParse(v) : null;
    return AuditEntry(
      id: m['id'] as String? ?? '',
      actorId: m['user_id'] as String?,
      action: m['action'] as String? ?? '',
      entityType: m['entity_type'] as String?,
      entityId: m['entity_id'] as String?,
      oldValues: asMap(m['old_values']),
      newValues: asMap(m['new_values']),
      createdAt: parse(m['created_at']),
    );
  }
}

String _appt(AuditEntry e) {
  final role = (e.newValues?['role_code'] as String?)?.trim();
  return (role == null || role.isEmpty)
      ? 'an appointment'
      : '$role appointment';
}

String _platform(AuditEntry e) {
  final p = (e.newValues?['platform'] as String?)?.trim();
  return (p == null || p.isEmpty) ? 'a device' : 'a device ($p)';
}

/// Pure: a human sentence for an audit entry. Names degrade gracefully.
String describeAuditEntry(
  AuditEntry e, {
  String? actorName,
  String? targetName,
}) {
  final actor = (actorName == null || actorName.trim().isEmpty)
      ? 'An administrator'
      : actorName.trim();
  final target = (targetName == null || targetName.trim().isEmpty)
      ? 'a user'
      : targetName.trim();
  switch (e.action) {
    case 'user.create':
      return '$actor created an account for $target';
    case 'user.delete':
      return "$actor deleted $target's account";
    case 'user.update_password':
      return "$actor reset $target's password";
    case 'user.disable':
      return "$actor disabled $target's account";
    case 'user.enable':
      return "$actor re-enabled $target's account";
    case 'user.role_change':
      final from = e.oldValues?['user_account_type'] as String? ?? '—';
      final to = e.newValues?['user_account_type'] as String? ?? '—';
      return "$actor changed $target's role from $from to $to";
    case 'submission.review':
      final status = e.newValues?['review_status'] as String? ?? 'reviewed';
      final title = (e.newValues?['title'] as String?)?.trim();
      return (title == null || title.isEmpty)
          ? '$actor $status a submission'
          : '$actor $status the submission "$title"';
    case 'appointment.issued':
      final who = (e.newValues?['appointee_name'] as String?)?.trim();
      return '$actor issued a ${_appt(e)} to '
          '${(who == null || who.isEmpty) ? 'an appointee' : who}';
    case 'appointment.accepted':
      return '$actor accepted a ${_appt(e)}';
    case 'appointment.declined':
      return '$actor declined a ${_appt(e)}';
    case 'appointment.resigned':
      return '$actor resigned from a ${_appt(e)}';
    case 'appointment.activated':
      final role = (e.newValues?['role_code'] as String?)?.trim();
      return (role == null || role.isEmpty)
          ? 'An appointment became active'
          : 'A $role appointment became active';
    case 'device.approved':
      return '$actor approved ${_platform(e)}';
    case 'device.revoked':
      return '$actor revoked ${_platform(e)}';
    case 'device.restored':
      return '$actor restored ${_platform(e)}';
    default:
      final ent = e.entityType ?? 'record';
      return '$actor performed ${e.action} on $ent $target';
  }
}

Future<List<AuditEntry>> loadAuditLog({
  int limit = 200,
  List<String>? actions,
}) async {
  var query = supabase
      .from('audit_log')
      .select(
        'id, user_id, action, entity_type, entity_id, '
        'old_values, new_values, created_at',
      );
  if (actions != null && actions.isNotEmpty) {
    query = query.inFilter('action', actions);
  }
  final rows = (await query.order('created_at', ascending: false).limit(limit))
      .cast<Map<String, dynamic>>();
  return rows.map(AuditEntry.fromMap).toList();
}

/// Resolves actor + target ids to display names in one profiles read.
Future<Map<String, String>> loadAuditNames(List<AuditEntry> entries) async {
  final ids = <String>{
    for (final e in entries) ...[
      if (e.actorId != null) e.actorId!,
      if (e.entityId != null) e.entityId!,
    ],
  }.toList();
  if (ids.isEmpty) return {};
  final rows =
      (await supabase
              .from('profiles')
              .select('id, full_name, email')
              .inFilter('id', ids))
          .cast<Map<String, dynamic>>();
  final out = <String, String>{};
  for (final r in rows) {
    final name = ((r['full_name'] as String?)?.trim().isNotEmpty == true)
        ? (r['full_name'] as String).trim()
        : (r['email'] as String? ?? '').trim();
    if (name.isNotEmpty) out[r['id'] as String] = name;
  }
  return out;
}
