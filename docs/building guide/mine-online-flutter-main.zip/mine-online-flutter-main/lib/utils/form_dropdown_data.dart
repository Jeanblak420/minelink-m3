// SP4.6: data-linked ("dynamic") dropdown sources for the legacy-style form
// designer. Options are read from the seeded allowlist tables only (never
// arbitrary SQL); each source's own RLS still applies.

import '../config/supabase_client.dart';

class DropdownSource {
  const DropdownSource({
    required this.key,
    required this.tableName,
    required this.valueColumn,
    required this.labelColumn,
    required this.displayName,
  });

  final String key;
  final String tableName;
  final String valueColumn;
  final String labelColumn;
  final String displayName;

  factory DropdownSource.fromMap(Map<String, dynamic> m) => DropdownSource(
    key: (m['key'] ?? '') as String,
    tableName: (m['table_name'] ?? '') as String,
    valueColumn: (m['value_column'] ?? 'id') as String,
    labelColumn: (m['label_column'] ?? 'name') as String,
    displayName: (m['display_name'] ?? '') as String,
  );
}

/// Active dropdown sources for the field editor's source picker.
Future<List<DropdownSource>> loadDropdownSources() async {
  final rows = await supabase
      .from('form_dropdown_sources')
      .select()
      .eq('is_active', true)
      .order('display_name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(DropdownSource.fromMap)
      .toList();
}

DropdownSource? _byKey(List<DropdownSource> sources, String key) {
  for (final s in sources) {
    if (s.key == key) return s;
  }
  return null;
}

/// Resolves a source key to its `{value, label}` options. Returns empty when the
/// key is unknown/inactive. Capped at 500 rows, ordered by label.
Future<List<({String value, String label})>> loadDropdownOptions(
  String sourceKey,
) async {
  final source = _byKey(await loadDropdownSources(), sourceKey);
  if (source == null) return const [];
  final rows = await supabase
      .from(source.tableName)
      .select('${source.valueColumn}, ${source.labelColumn}')
      .order(source.labelColumn)
      .limit(500);
  return (rows as List).cast<Map<String, dynamic>>().map((m) {
    final v = m[source.valueColumn];
    final l = m[source.labelColumn];
    return (value: '${v ?? ''}', label: '${l ?? v ?? ''}');
  }).toList();
}
