// Maps a Supabase `form_submissions.form_type` string to a Flutter widget
// constructor (for view-mode rendering) and to a PDF generator (for the
// "View PDF" button on /signature-requests). Mirrors
// `src/utils/formRegistry.ts` (lines 62-330).

import 'package:flutter/material.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/form_data.dart';
import '../models/form_data_apply_map.dart';
import '../models/form_view_args.dart';
import '../pdf/generate_custom_form_pdf.dart';
import '../pdf/generate_appointment_letter_pdf.dart';
import '../pdf/pdf_overlay_appendix.dart';
import '../models/appointment_template.dart';
import 'custom_form_data.dart';
import 'appointment_template_data.dart';

import '../pdf/generate_action_log_underground_visits_pdf.dart';
import '../pdf/generate_belt_tip_area_inspection_pdf.dart';
import '../pdf/generate_conveyor_belt_inspection_pdf.dart';
import '../pdf/generate_early_shift_record_pdf.dart';
import '../pdf/generate_emergency_drill_exercise_pdf.dart';
import '../pdf/generate_emergency_drill_pdf.dart';
import '../pdf/generate_explosive_control_record_pdf.dart';
import '../pdf/generate_gassing_incident_pdf.dart';
import '../pdf/generate_inspection_control_sheet_pdf.dart';
import '../pdf/generate_late_shift_record_pdf.dart';
import '../pdf/generate_lockout_checklist_pdf.dart';
import '../pdf/generate_machinery_operators_pdf.dart';
import '../pdf/generate_miner_appointment_pdf.dart';
import '../pdf/generate_monthly_fire_fighting_inspection_pdf.dart';
import '../pdf/generate_planned_task_observation_pdf.dart';
import '../pdf/generate_refuge_bay_inspection_pdf.dart';
import '../pdf/generate_relieving_miner_pdf.dart';
import '../pdf/generate_rock_breaker_inspection_pdf.dart';
import '../pdf/generate_safety_health_rep_pdf.dart';
import '../pdf/generate_shift_boss_daily_report_pdf.dart';
import '../pdf/generate_shift_boss_pdf.dart';
import '../pdf/generate_special_brief_instruction_register_pdf.dart';
import '../pdf/generate_special_instruction_pdf.dart';
import '../pdf/generate_trackless_machinery_pdf.dart';
import '../pdf/generate_waiting_place_inspection_pdf.dart';
import '../pdf/generate_weekly_sherq_meeting_pdf.dart';

import '../screens/action_log_underground_visits_form_screen.dart';
import '../screens/belt_tip_area_inspection_form_screen.dart';
import '../screens/conveyor_belt_inspection_form_screen.dart';
import '../screens/early_shift_record_form_screen.dart';
import '../screens/emergency_drill_exercise_form_screen.dart';
import '../screens/emergency_drill_form_screen.dart';
import '../screens/explosive_control_record_form_screen.dart';
import '../screens/gassing_incident_form_screen.dart';
import '../screens/inspection_control_sheet_form_screen.dart';
import '../screens/late_shift_record_form_screen.dart';
import '../screens/lockout_lock_scissor_checklist_form_screen.dart';
import '../screens/machinery_operators_form_screen.dart';
import '../screens/miner_appointment_form_screen.dart';
import '../screens/monthly_fire_fighting_inspection_form_screen.dart';
import '../screens/planned_task_observation_form_screen.dart';
import '../screens/refuge_bay_inspection_form_screen.dart';
import '../screens/relieving_miner_form_screen.dart';
import '../screens/rock_breaker_inspection_form_screen.dart';
import '../screens/safety_health_rep_form_screen.dart';
import '../screens/shift_boss_daily_report_form_screen.dart';
import '../screens/shift_boss_form_screen.dart';
import '../screens/special_brief_instruction_register_form_screen.dart';
import '../screens/special_instruction_form_screen.dart';
import '../screens/trackless_machinery_inspection_form_screen.dart';
import '../screens/waiting_place_inspection_form_screen.dart';
import '../screens/weekly_sherq_meeting_form_screen.dart';

/// Returns the form screen widget for [formType], constructed with [args],
/// or null if [formType] is unknown.
Widget? buildFormView(String formType, FormViewArgs args) {
  switch (formType) {
    case 'shift_boss_appointment':
      return ShiftBossFormScreen(viewArgs: args);
    case 'miner_appointment':
      return MinerAppointmentFormScreen(viewArgs: args);
    case 'relieving_miner_appointment':
      return RelievingMinerFormScreen(viewArgs: args);
    case 'safety_health_rep':
      return SafetyHealthRepFormScreen(viewArgs: args);
    case 'machinery_operators_appointment':
      return MachineryOperatorsFormScreen(viewArgs: args);
    case 'shift_boss_daily_report':
      return ShiftBossDailyReportFormScreen(viewArgs: args);
    case 'gassing_incident':
      return GassingIncidentFormScreen(viewArgs: args);
    case 'weekly_sherq_meeting':
      return WeeklySherqMeetingFormScreen(viewArgs: args);
    case 'early_shift_record':
      return EarlyShiftRecordFormScreen(viewArgs: args);
    case 'late_shift_record':
      return LateShiftRecordFormScreen(viewArgs: args);
    case 'explosive_control_record':
      return ExplosiveControlRecordFormScreen(viewArgs: args);
    case 'waiting_place_inspection':
      return WaitingPlaceInspectionFormScreen(viewArgs: args);
    case 'refuge_bay_inspection':
      return RefugeBayInspectionFormScreen(viewArgs: args);
    case 'trackless_machinery_inspection':
      return TracklessMachineryInspectionFormScreen(viewArgs: args);
    case 'conveyor_belt_inspection':
      return ConveyorBeltInspectionFormScreen(viewArgs: args);
    case 'rock_breaker_inspection':
      return RockBreakerInspectionFormScreen(viewArgs: args);
    case 'belt_tip_area_inspection':
      return BeltTipAreaInspectionFormScreen(viewArgs: args);
    case 'action_log_underground_visits':
      return ActionLogUndergroundVisitsFormScreen(viewArgs: args);
    case 'special_instruction':
      return SpecialInstructionFormScreen(viewArgs: args);
    case 'inspection_control_sheet':
      return InspectionControlSheetFormScreen(viewArgs: args);
    case 'planned_task_observation':
      return PlannedTaskObservationFormScreen(viewArgs: args);
    case 'special_brief_instruction_register':
      return SpecialBriefInstructionRegisterFormScreen(viewArgs: args);
    case 'verbal_emergency_drills':
      return EmergencyDrillFormScreen(
        viewArgs: args,
        title: 'Verbal Emergency Drills',
        formType: 'verbal_emergency_drills',
        pageNum: 'Page 80 of 84',
      );
    case 'physical_emergency_drills':
      return EmergencyDrillFormScreen(
        viewArgs: args,
        title: 'Physical Emergency Drills',
        formType: 'physical_emergency_drills',
        pageNum: 'Page 81 of 84',
      );
    case 'emergency_drill_exercise':
      return EmergencyDrillExerciseFormScreen(viewArgs: args);
    case 'monthly_fire_fighting_inspection':
      return MonthlyFireFightingInspectionFormScreen(viewArgs: args);
    case 'lockout_lock_scissor_checklist':
      return LockoutLockScissorChecklistFormScreen(viewArgs: args);
  }
  return null;
}

/// Regenerates a PDF document from a payload + form_type. Used by the "View
/// PDF" button on `/signature-requests`. Returns null if [formType] is unknown.
/// For built-in (bespoke) forms, appends the admin's overlay (SP4.5) appendix;
/// custom_ and appt_ documents are returned as-is.
Future<pw.Document?> generatePdfForFormType(
  String formType,
  Map<String, dynamic> payload,
) async {
  final doc = await _corePdfForFormType(formType, payload);
  if (doc == null) return null;
  if (!formType.startsWith('custom_') && !formType.startsWith('appt_')) {
    await appendOverlayToPdf(doc, formType, payload);
  }
  return doc;
}

Future<pw.Document?> _corePdfForFormType(
  String formType,
  Map<String, dynamic> payload,
) async {
  // Custom (Form Builder) submissions: fetch the template by code and render a
  // generic schema-driven PDF. The submission viewer's "Download PDF" calls
  // this, so this is all that's needed to light it up for custom forms.
  if (formType.startsWith('custom_')) {
    final template = await loadTemplateByCode(formType);
    if (template == null) return null;
    return generateCustomFormPdf(template, payload);
  }
  // Appointment submissions (SP4): render the SP3 letter from the stored
  // letterValues snapshot in the payload.
  if (formType.startsWith('appt_')) {
    final template = await loadAppointmentTemplateByCode(formType);
    if (template == null) return null;
    final lv =
        (payload['letterValues'] as Map?)?.cast<String, dynamic>() ??
        const <String, dynamic>{};
    final values = <String, String>{
      for (final e in lv.entries) e.key: '${e.value}',
    };
    AppointmentRole? role;
    if (template.roleId != null) {
      final roles = await loadAppointmentRoles(includeArchived: true);
      for (final r in roles) {
        if (r.id == template.roleId) {
          role = r;
          break;
        }
      }
    }
    return generateAppointmentLetterPdf(template, values, role: role);
  }
  switch (formType) {
    case 'shift_boss_appointment':
      return generateShiftBossPdf(ShiftBossFormData()..applyMap(payload));
    case 'miner_appointment':
      return generateMinerAppointmentPdf(
        MinerAppointmentFormData()..applyMap(payload),
      );
    case 'relieving_miner_appointment':
      return generateRelievingMinerPdf(
        RelievingMinerFormData()..applyMap(payload),
      );
    case 'safety_health_rep':
      return generateSafetyHealthRepPdf(
        SafetyHealthRepFormData()..applyMap(payload),
      );
    case 'machinery_operators_appointment':
      return generateMachineryOperatorsPdf(
        MachineryOperatorsFormData()..applyMap(payload),
      );
    case 'shift_boss_daily_report':
      return generateShiftBossDailyReportPdf(
        ShiftBossDailyReportFormData()..applyMap(payload),
      );
    case 'gassing_incident':
      return generateGassingIncidentPdf(
        GassingIncidentFormData()..applyMap(payload),
      );
    case 'weekly_sherq_meeting':
      return generateWeeklySherqMeetingPdf(
        WeeklySherqMeetingFormData()..applyMap(payload),
      );
    case 'early_shift_record':
      return generateEarlyShiftRecordPdf(
        EarlyShiftRecordFormData()..applyMap(payload),
      );
    case 'late_shift_record':
      return generateLateShiftRecordPdf(
        LateShiftRecordFormData()..applyMap(payload),
      );
    case 'explosive_control_record':
      return generateExplosiveControlRecordPdf(
        ExplosiveControlRecordFormData()..applyMap(payload),
      );
    case 'waiting_place_inspection':
      return generateWaitingPlaceInspectionPdf(
        WaitingPlaceInspectionFormData()..applyMap(payload),
      );
    case 'refuge_bay_inspection':
      return generateRefugeBayInspectionPdf(
        RefugeBayInspectionFormData()..applyMap(payload),
      );
    case 'trackless_machinery_inspection':
      return generateTracklessMachineryPdf(
        TracklessMachineryFormData()..applyMap(payload),
      );
    case 'conveyor_belt_inspection':
      return generateConveyorBeltInspectionPdf(
        ConveyorBeltInspectionFormData()..applyMap(payload),
      );
    case 'rock_breaker_inspection':
      return generateRockBreakerInspectionPdf(
        RockBreakerInspectionFormData()..applyMap(payload),
      );
    case 'belt_tip_area_inspection':
      return generateBeltTipAreaInspectionPdf(
        BeltTipAreaInspectionFormData()..applyMap(payload),
      );
    case 'action_log_underground_visits':
      return generateActionLogUndergroundVisitsPdf(
        ActionLogUndergroundVisitsFormData()..applyMap(payload),
      );
    case 'special_instruction':
      return generateSpecialInstructionPdf(
        SpecialInstructionFormData()..applyMap(payload),
      );
    case 'inspection_control_sheet':
      return generateInspectionControlSheetPdf(
        InspectionControlSheetFormData()..applyMap(payload),
      );
    case 'planned_task_observation':
      return generatePlannedTaskObservationPdf(
        PlannedTaskObservationFormData()..applyMap(payload),
      );
    case 'special_brief_instruction_register':
      return generateSpecialBriefInstructionRegisterPdf(
        SpecialBriefInstructionRegisterFormData()..applyMap(payload),
      );
    case 'verbal_emergency_drills':
      return generateEmergencyDrillPdf(
        EmergencyDrillFormData()..applyMap(payload),
        title: 'Verbal Emergency Drills',
        pageNum: 'Page 80 of 84',
        subject: 'Verbal Emergency Drills',
      );
    case 'physical_emergency_drills':
      return generateEmergencyDrillPdf(
        EmergencyDrillFormData()..applyMap(payload),
        title: 'Physical Emergency Drills',
        pageNum: 'Page 81 of 84',
        subject: 'Physical Emergency Drills',
      );
    case 'emergency_drill_exercise':
      return generateEmergencyDrillExercisePdf(
        EmergencyDrillExerciseFormData()..applyMap(payload),
      );
    case 'monthly_fire_fighting_inspection':
      return generateMonthlyFireFightingInspectionPdf(
        MonthlyFireFightingInspectionFormData()..applyMap(payload),
      );
    case 'lockout_lock_scissor_checklist':
      return generateLockoutChecklistPdf(
        LockoutLockScissorChecklistFormData()..applyMap(payload),
      );
  }
  return null;
}
