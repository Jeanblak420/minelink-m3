// SP8 Reports — client-side period aggregation over existing tables, mirroring
// analytics_data.dart. Pure reportWindow + computeReport are unit-tested;
// loadReport fetches the windowed rows and delegates.

import '../config/supabase_client.dart';
import 'admin_dashboard_data.dart'
    show kIncidentFormTypes, kPendingWorkflowStatuses;
import 'form_metadata.dart' show kFormMetadataRegistry;

enum ReportPeriod { daily, weekly, monthly }

class ReportWindow {
  const ReportWindow({
    required this.start,
    required this.end,
    required this.label,
  });

  /// Inclusive start (local).
  final DateTime start;

  /// Exclusive end (local).
  final DateTime end;

  /// Human-readable period label.
  final String label;
}

const _months = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];
const _weekdays = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

ReportWindow reportWindow(ReportPeriod period, DateTime anchor) {
  final day = DateTime(anchor.year, anchor.month, anchor.day);
  switch (period) {
    case ReportPeriod.daily:
      final end = day.add(const Duration(days: 1));
      final wd = _weekdays[day.weekday - 1];
      return ReportWindow(
        start: day,
        end: end,
        label: '$wd, ${day.day} ${_months[day.month - 1]} ${day.year}',
      );
    case ReportPeriod.weekly:
      final monday = day.subtract(Duration(days: day.weekday - 1));
      final end = monday.add(const Duration(days: 7));
      final last = monday.add(const Duration(days: 6));
      final label = last.month == monday.month
          ? 'Week of ${monday.day}–${last.day} '
                '${_months[monday.month - 1]} ${monday.year}'
          : 'Week of ${monday.day} ${_months[monday.month - 1]} – '
                '${last.day} ${_months[last.month - 1]} ${last.year}';
      return ReportWindow(start: monday, end: end, label: label);
    case ReportPeriod.monthly:
      final start = DateTime(anchor.year, anchor.month, 1);
      final end = DateTime(anchor.year, anchor.month + 1, 1);
      return ReportWindow(
        start: start,
        end: end,
        label: '${_months[start.month - 1]} ${start.year}',
      );
  }
}

final Map<String, String> _formLabels = {
  for (final m in kFormMetadataRegistry) m.formType: m.title,
};

/// Human label for a form_type, falling back to the raw type.
String formLabelFor(String formType) => _formLabels[formType] ?? formType;

class ReportRow {
  const ReportRow({
    required this.date,
    required this.formType,
    required this.formLabel,
    required this.submitter,
    required this.status,
    required this.raw,
  });

  final DateTime? date;
  final String formType;
  final String formLabel;
  final String submitter;
  final String status;
  final Map<String, dynamic> raw;
}

class ReportSummary {
  const ReportSummary({
    required this.period,
    required this.window,
    required this.submissions,
    required this.fullySigned,
    required this.pendingInChain,
    required this.incidents,
    required this.appointmentsIssued,
    required this.appointmentsAccepted,
    required this.signatureCompletionRate,
    required this.byFormType,
    required this.byStatus,
    required this.register,
  });

  final ReportPeriod period;
  final ReportWindow window;
  final int submissions;
  final int fullySigned;
  final int pendingInChain;
  final int incidents;
  final int appointmentsIssued;
  final int appointmentsAccepted;
  final double signatureCompletionRate;
  final Map<String, int> byFormType;
  final Map<String, int> byStatus;
  final List<ReportRow> register;
}

void _bump(Map<String, int> m, String? key, {String fallback = '(none)'}) {
  final k = (key == null || key.isEmpty) ? fallback : key;
  m[k] = (m[k] ?? 0) + 1;
}

DateTime? _parse(dynamic v) {
  if (v is! String || v.isEmpty) return null;
  try {
    return DateTime.parse(v);
  } catch (_) {
    return null;
  }
}

String _submitterName(Map<String, dynamic>? p) {
  final full = (p?['full_name'] as String?)?.trim() ?? '';
  if (full.isNotEmpty) return full;
  final email = (p?['email'] as String?)?.trim() ?? '';
  if (email.isNotEmpty) return email;
  return 'Unknown user';
}

ReportSummary computeReport({
  required ReportPeriod period,
  required ReportWindow window,
  required List<Map<String, dynamic>> submissions,
  required List<Map<String, dynamic>> appointments,
  required List<Map<String, dynamic>> signatureRequests,
  required Map<String, Map<String, dynamic>> profiles,
}) {
  final byFormType = <String, int>{};
  final byStatus = <String, int>{};
  var fullySigned = 0;
  var pending = 0;
  var incidents = 0;
  final register = <ReportRow>[];

  for (final r in submissions) {
    final type = r['form_type'] as String? ?? '';
    final status = r['workflow_status'] as String?;
    _bump(byFormType, formLabelFor(type), fallback: '(unknown)');
    _bump(byStatus, status, fallback: '(none)');
    if (status == 'fully_signed') fullySigned++;
    if (status != null && kPendingWorkflowStatuses.contains(status)) pending++;
    if (kIncidentFormTypes.contains(type)) incidents++;

    final uid = r['user_id'] as String?;
    register.add(
      ReportRow(
        date: _parse(r['created_at']),
        formType: type,
        formLabel: formLabelFor(type),
        submitter: _submitterName(uid == null ? null : profiles[uid]),
        status: (status == null || status.isEmpty) ? '—' : status,
        raw: r,
      ),
    );
  }

  // newest-first; rows with null date sort last.
  register.sort((a, b) {
    if (a.date == null && b.date == null) return 0;
    if (a.date == null) return 1;
    if (b.date == null) return -1;
    return b.date!.compareTo(a.date!);
  });

  var accepted = 0;
  for (final a in appointments) {
    if (a['accepted_at'] != null) accepted++;
  }

  var signed = 0;
  for (final s in signatureRequests) {
    if (s['status'] == 'signed') signed++;
  }
  final sigTotal = signatureRequests.length;

  return ReportSummary(
    period: period,
    window: window,
    submissions: submissions.length,
    fullySigned: fullySigned,
    pendingInChain: pending,
    incidents: incidents,
    appointmentsIssued: appointments.length,
    appointmentsAccepted: accepted,
    signatureCompletionRate: sigTotal == 0 ? 0.0 : signed / sigTotal,
    byFormType: byFormType,
    byStatus: byStatus,
    register: register,
  );
}

String _iso(DateTime d) => d.toUtc().toIso8601String();

/// Fetches the windowed rows and computes the report summary.
Future<ReportSummary> loadReport(ReportPeriod period, DateTime anchor) async {
  final window = reportWindow(period, anchor);
  final fromIso = _iso(window.start);
  final toIso = _iso(window.end);

  final submissions =
      (await supabase
              .from('form_submissions')
              .select(
                'id,user_id,form_type,title,workflow_status,'
                'current_signature_role,created_at',
              )
              .gte('created_at', fromIso)
              .lt('created_at', toIso)
              .order('created_at', ascending: false, nullsFirst: false)
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final appointments =
      (await supabase
              .from('appointments')
              .select('status, accepted_at, issued_at')
              .gte('issued_at', fromIso)
              .lt('issued_at', toIso)
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final signatureRequests =
      (await supabase
              .from('signature_requests')
              .select('status, created_at')
              .gte('created_at', fromIso)
              .lt('created_at', toIso)
              .limit(5000))
          .cast<Map<String, dynamic>>();

  final userIds = submissions
      .map((r) => r['user_id'] as String?)
      .whereType<String>()
      .toSet()
      .toList();

  final profiles = <String, Map<String, dynamic>>{};
  if (userIds.isNotEmpty) {
    final pr =
        (await supabase
                .from('profiles')
                .select('id, full_name, email')
                .inFilter('id', userIds))
            .cast<Map<String, dynamic>>();
    for (final row in pr) {
      profiles[row['id'] as String] = row;
    }
  }

  return computeReport(
    period: period,
    window: window,
    submissions: submissions,
    appointments: appointments,
    signatureRequests: signatureRequests,
    profiles: profiles,
  );
}
