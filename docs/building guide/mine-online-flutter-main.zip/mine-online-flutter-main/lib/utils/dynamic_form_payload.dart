// Pure helpers for filling/submitting custom forms. No Flutter/Supabase deps.

import '../models/custom_form_template.dart';

/// Supported chain signers → the recognized payload signature fields the
/// signature-workflow edge function looks for (under the `signatures` map).
/// Keep these field names in lockstep with the edge function's `signatureRules`.
const Map<String, List<String>> kChainSignerFields = {
  'mine_overseer': ['mineOverseerSignature', 'mineOverseerDate'],
  'mine_manager': ['mineManagerSignature', 'mineManagerDate'],
};

/// Display labels for the supported chain signers (builder UI + PDF).
const Map<String, String> kChainSignerLabels = {
  'mine_overseer': 'Mine Overseer',
  'mine_manager': 'Mine Manager',
};

/// Injects blank recognized signature fields into [payload] (under a
/// `signatures` map) for each supported entry in [requiredSigners], so the
/// signature-workflow edge function drives the chain. Existing signature values
/// are preserved (`putIfAbsent`). Returns true when at least one chain field is
/// present afterwards (i.e. this submission should start the workflow).
bool applyCustomChainSignatureFields(
  List<String> requiredSigners,
  Map<String, dynamic> payload,
) {
  final signers = requiredSigners
      .where(kChainSignerFields.containsKey)
      .toList();
  if (signers.isEmpty) return false;
  final sig = (payload['signatures'] is Map)
      ? (payload['signatures'] as Map).cast<String, dynamic>()
      : <String, dynamic>{};
  for (final s in signers) {
    for (final field in kChainSignerFields[s]!) {
      sig.putIfAbsent(field, () => '');
    }
  }
  payload['signatures'] = sig;
  return true;
}

bool _isEmpty(dynamic v) {
  if (v == null) return true;
  if (v is String) return v.trim().isEmpty;
  if (v is List) return v.isEmpty;
  return false; // numbers, bools (incl. false) count as answered
}

/// Labels of required, non-section fields that have no value in [values].
List<String> missingRequiredFields(
  List<FormFieldDef> fields,
  Map<String, dynamic> values,
) {
  final missing = <String>[];
  for (final f in fields) {
    if (f.type == FormFieldType.section || !f.required) continue;
    if (_isEmpty(values[f.key])) missing.add(f.label);
  }
  return missing;
}

/// Builds the `form_submissions.payload` map: one entry per non-section field,
/// keyed by field key, with type-appropriate defaults for blanks.
Map<String, dynamic> buildSubmissionPayload(
  List<FormFieldDef> fields,
  Map<String, dynamic> values,
) {
  final out = <String, dynamic>{};
  for (final f in fields) {
    if (f.type == FormFieldType.section) continue;
    final v = values[f.key];
    switch (f.type) {
      case FormFieldType.boolean:
        out[f.key] = v == true;
        break;
      case FormFieldType.table:
        out[f.key] = (v is List) ? v : <Map<String, dynamic>>[];
        break;
      default:
        out[f.key] = v ?? '';
    }
  }
  return out;
}
