// Mirrors the web app's `src/hooks/usePresence.ts`: while a user is signed in,
// upsert their `user_presence.last_seen_at` row every 60 seconds so other
// clients can render the user as "online" within the 2-minute window the
// `UserPresenceTracker` widget treats as live.

import 'dart:async';

import '../config/supabase_client.dart';

class PresenceHeartbeat {
  PresenceHeartbeat();

  static const Duration interval = Duration(seconds: 60);

  Timer? _ticker;
  String? _userId;

  void start(String userId) {
    if (_userId == userId && _ticker != null) return;
    stop();
    _userId = userId;
    _beat();
    _ticker = Timer.periodic(interval, (_) => _beat());
  }

  void stop() {
    _ticker?.cancel();
    _ticker = null;
    _userId = null;
  }

  Future<void> _beat() async {
    final id = _userId;
    if (id == null) return;
    try {
      await supabase.from('user_presence').upsert(
        {
          'user_id': id,
          'last_seen_at': DateTime.now().toUtc().toIso8601String(),
        },
        onConflict: 'user_id',
      );
    } catch (_) {
      // Swallow — table may not exist on first deploy.
    }
  }
}
