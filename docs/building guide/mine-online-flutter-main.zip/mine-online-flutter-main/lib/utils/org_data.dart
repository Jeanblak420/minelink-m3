// Supabase data access for the Shaft → Section → Area hierarchy. Mirrors the
// query/cast pattern in custom_form_data.dart. Archive = is_active=false.

import '../config/supabase_client.dart';
import '../models/org_location.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();

Future<List<Shaft>> loadShafts({bool includeArchived = false}) async {
  var q = supabase.from('shafts').select();
  if (!includeArchived) q = q.eq('is_active', true);
  final rows = await q.order('shaft_name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(Shaft.fromMap)
      .toList();
}

Future<List<Section>> loadSections({bool includeArchived = false}) async {
  var q = supabase.from('sections').select();
  if (!includeArchived) q = q.eq('is_active', true);
  final rows = await q.order('name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(Section.fromMap)
      .toList();
}

Future<List<Area>> loadAreas({bool includeArchived = false}) async {
  var q = supabase.from('areas').select();
  if (!includeArchived) q = q.eq('is_active', true);
  final rows = await q.order('name');
  return (rows as List).cast<Map<String, dynamic>>().map(Area.fromMap).toList();
}

Future<void> saveShaft({
  String? id,
  required String name,
  String? description,
}) async {
  final payload = {'shaft_name': name, 'description': description};
  if (id == null) {
    await supabase.from('shafts').insert(payload);
  } else {
    await supabase
        .from('shafts')
        .update({...payload, 'updated_at': _nowUtc()})
        .eq('id', id);
  }
}

Future<void> saveSection({
  String? id,
  required String shaftId,
  required String name,
  String? description,
}) async {
  final payload = {
    'shaft_id': shaftId,
    'name': name,
    'description': description,
  };
  if (id == null) {
    await supabase.from('sections').insert(payload);
  } else {
    await supabase
        .from('sections')
        .update({...payload, 'updated_at': _nowUtc()})
        .eq('id', id);
  }
}

Future<void> saveArea({
  String? id,
  required String sectionId,
  required String name,
  String? description,
}) async {
  final payload = {
    'section_id': sectionId,
    'name': name,
    'description': description,
  };
  if (id == null) {
    await supabase.from('areas').insert(payload);
  } else {
    await supabase
        .from('areas')
        .update({...payload, 'updated_at': _nowUtc()})
        .eq('id', id);
  }
}

Future<void> setLocationActive(String table, String id, bool active) async {
  await supabase
      .from(table)
      .update({'is_active': active, 'updated_at': _nowUtc()})
      .eq('id', id);
}

// --- Shifts ---------------------------------------------------------------

Future<List<Shift>> loadShifts({bool includeArchived = false}) async {
  var q = supabase.from('shifts').select();
  if (!includeArchived) q = q.eq('is_active', true);
  final rows = await q.order('name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(Shift.fromMap)
      .toList();
}

Future<void> saveShift({
  String? id,
  required String name,
  String? startTime,
  String? endTime,
}) async {
  final payload = {'name': name, 'start_time': startTime, 'end_time': endTime};
  if (id == null) {
    await supabase.from('shifts').insert(payload);
  } else {
    await supabase
        .from('shifts')
        .update({...payload, 'updated_at': _nowUtc()})
        .eq('id', id);
  }
}

// --- Gangs ----------------------------------------------------------------

Future<List<Gang>> loadGangs({bool includeArchived = false}) async {
  var q = supabase.from('gangs').select();
  if (!includeArchived) q = q.eq('is_active', true);
  final rows = await q.order('name');
  return (rows as List).cast<Map<String, dynamic>>().map(Gang.fromMap).toList();
}

Future<void> saveGang({
  String? id,
  required String name,
  String? shaftId,
  String? sectionId,
  String? shiftId,
}) async {
  final payload = {
    'name': name,
    'shaft_id': shaftId,
    'section_id': sectionId,
    'shift_id': shiftId,
  };
  if (id == null) {
    await supabase.from('gangs').insert(payload);
  } else {
    await supabase
        .from('gangs')
        .update({...payload, 'updated_at': _nowUtc()})
        .eq('id', id);
  }
}

// --- Gang members ---------------------------------------------------------

Future<List<GangMember>> loadGangMembers(String gangId) async {
  final rows = await supabase
      .from('gang_memberships')
      .select()
      .eq('gang_id', gangId)
      .eq('is_active', true);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(GangMember.fromMap)
      .toList();
}

/// Count of active members per gang id (one query). Used for the gang list.
Future<Map<String, int>> loadGangMemberCounts() async {
  final rows = await supabase
      .from('gang_memberships')
      .select('gang_id')
      .eq('is_active', true);
  final counts = <String, int>{};
  for (final r in (rows as List).cast<Map<String, dynamic>>()) {
    final g = r['gang_id'] as String?;
    if (g != null) counts[g] = (counts[g] ?? 0) + 1;
  }
  return counts;
}

Future<void> addGangMember(String gangId, String userId) async {
  // upsert avoids a duplicate-key error if a (re)added member already exists.
  await supabase.from('gang_memberships').upsert({
    'gang_id': gangId,
    'user_id': userId,
    'is_active': true,
  }, onConflict: 'gang_id,user_id');
}

Future<void> removeGangMember(String id) async {
  await supabase.from('gang_memberships').delete().eq('id', id);
}

/// Loads pickable profiles for the member picker / member display.
Future<List<PickProfile>> loadPickProfiles() async {
  final rows = await supabase
      .from('profiles')
      .select('id,full_name,email')
      .order('full_name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(PickProfile.fromMap)
      .toList();
}
