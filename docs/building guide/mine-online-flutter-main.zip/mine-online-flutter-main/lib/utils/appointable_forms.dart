// SP4: catalog of built-in appointment forms that can be issued through the
// appointments lifecycle (alongside SP3 dynamic templates). Each entry opens the
// existing form screen in fill mode; the appointee completes + submits it, and
// the `onSubmitted` hook links the resulting submission to the appointment.

import 'package:flutter/widgets.dart';

import '../screens/miner_appointment_form_screen.dart';
import '../screens/relieving_miner_form_screen.dart';
import '../screens/shift_boss_form_screen.dart';

class AppointableForm {
  const AppointableForm({
    required this.code,
    required this.label,
    required this.roleLabel,
    required this.hasChain,
    required this.builder,
  });

  /// The form_type written to form_submissions + appointments.form_type.
  final String code;
  final String label;

  /// Human role this form appoints (used as the appointment's role_code).
  final String roleLabel;

  /// Whether submitting the form starts a Mine Overseer / Mine Manager chain.
  /// All three current appointment forms do.
  final bool hasChain;

  /// Builds the form screen wired to call [onSubmitted] with the new submission
  /// id after a successful submit.
  final Widget Function({required ValueChanged<String> onSubmitted}) builder;
}

/// The built-in appointment forms available to the issue flow.
final List<AppointableForm> kAppointableForms = [
  AppointableForm(
    code: 'shift_boss_appointment',
    label: 'Shift Boss Appointment',
    roleLabel: 'Shift Supervisor (Shift Boss)',
    hasChain: true,
    builder: ({required onSubmitted}) =>
        ShiftBossFormScreen(onSubmitted: onSubmitted),
  ),
  AppointableForm(
    code: 'miner_appointment',
    label: 'Miner Appointment',
    roleLabel: 'Miner (Competent A)',
    hasChain: true,
    builder: ({required onSubmitted}) =>
        MinerAppointmentFormScreen(onSubmitted: onSubmitted),
  ),
  AppointableForm(
    code: 'relieving_miner_appointment',
    label: 'Relieving Miner Appointment',
    roleLabel: 'Relieving Miner',
    hasChain: true,
    builder: ({required onSubmitted}) =>
        RelievingMinerFormScreen(onSubmitted: onSubmitted),
  ),
];

AppointableForm? appointableFormByCode(String code) {
  for (final f in kAppointableForms) {
    if (f.code == code) return f;
  }
  return null;
}
