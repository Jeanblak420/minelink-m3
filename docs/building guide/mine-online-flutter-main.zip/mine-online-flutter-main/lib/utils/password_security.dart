import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

const _pwnedRangeUrl = 'https://api.pwnedpasswords.com/range';

const String compromisedPasswordMessage =
    'This password has appeared in a known data breach. Choose a different password.';

const String passwordCheckUnavailableMessage =
    'Password safety check is unavailable right now. Please try again.';

String _sha1HexUppercase(String value) {
  final bytes = utf8.encode(value);
  final digest = sha1.convert(bytes);
  return digest.toString().toUpperCase();
}

Future<int> getPwnedPasswordCount(String password) async {
  final hash = _sha1HexUppercase(password);
  final prefix = hash.substring(0, 5);
  final suffix = hash.substring(5);

  http.Response response;
  try {
    response = await http.get(
      Uri.parse('$_pwnedRangeUrl/$prefix'),
      headers: {'Add-Padding': 'true'},
    );
  } catch (_) {
    throw Exception(passwordCheckUnavailableMessage);
  }

  if (response.statusCode != 200) {
    throw Exception(passwordCheckUnavailableMessage);
  }

  for (final line in response.body.split('\n')) {
    final parts = line.trim().split(':');
    if (parts.length == 2 && parts[0] == suffix) {
      return int.tryParse(parts[1]) ?? 0;
    }
  }
  return 0;
}

Future<void> assertPasswordNotCompromised(String password) async {
  final count = await getPwnedPasswordCount(password);
  if (count > 0) {
    throw Exception(compromisedPasswordMessage);
  }
}
