// Mirrors src/constants/accountTypes.ts.

const List<String> kUserAccountTypes = [
  'Admin',
  'Shift Boss',
  'Super Admin',
  'Mine Overseer',
  'Mine Manager',
  'none of the above',
];

const List<String> kNotificationEnabledAccountTypes = [
  'Shift Boss',
  'Mine Overseer',
  'Mine Manager',
  'Admin',
  'Super Admin',
];

({bool isAdmin, bool isSuperAdmin}) getAccountTypeFlags(String? accountType) {
  return (
    isAdmin: accountType == 'Admin' || accountType == 'Super Admin',
    isSuperAdmin: accountType == 'Super Admin',
  );
}
