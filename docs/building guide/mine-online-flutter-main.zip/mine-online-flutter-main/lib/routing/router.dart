// ignore_for_file: unnecessary_underscores

import 'package:go_router/go_router.dart';

import '../providers/auth_provider.dart';
import '../screens/action_log_underground_visits_form_screen.dart';
import '../screens/admin_appointments_logbook_screen.dart';
import '../screens/admin_screen.dart';
import '../screens/appointments_screen.dart';
import '../screens/belt_tip_area_inspection_form_screen.dart';
import '../screens/conveyor_belt_inspection_form_screen.dart';
import '../screens/current_logbook_screen.dart';
import '../screens/early_shift_record_form_screen.dart';
import '../screens/emergency_drill_exercise_form_screen.dart';
import '../screens/emergency_drill_form_screen.dart';
import '../screens/explosive_control_record_form_screen.dart';
import '../screens/form_submission_history_screen.dart';
import '../screens/gassing_incident_form_screen.dart';
import '../screens/home_screen.dart';
import '../screens/inspection_control_sheet_form_screen.dart';
import '../screens/late_shift_record_form_screen.dart';
import '../screens/login_screen.dart';
import '../screens/lockout_lock_scissor_checklist_form_screen.dart';
import '../screens/machinery_operators_form_screen.dart';
import '../screens/miner_appointment_form_screen.dart';
import '../screens/monthly_fire_fighting_inspection_form_screen.dart';
import '../screens/my_profile_screen.dart';
import '../screens/notifications_screen.dart';
import '../screens/placeholder_screen.dart';
import '../screens/planned_task_observation_form_screen.dart';
import '../screens/profiles_screen.dart';
import '../screens/refuge_bay_inspection_form_screen.dart';
import '../screens/relieving_miner_form_screen.dart';
import '../screens/rock_breaker_inspection_form_screen.dart';
import '../screens/signature_requests_screen.dart';
import '../screens/safety_health_rep_form_screen.dart';
import '../screens/custom_forms_screen.dart';
import '../screens/form_builder_screen.dart';
import '../screens/templates/form_studio_screen.dart';
import '../screens/setup/locations_screen.dart';
import '../screens/setup/gangs_screen.dart';
import '../screens/setup/appointment_builder_screen.dart';
import '../screens/setup/appointments_admin_screen.dart';
import '../screens/my_appointments_screen.dart';
import '../screens/form_designer_screen.dart';
import '../screens/setup/audit_log_screen.dart';
import '../screens/setup/devices_admin_screen.dart';
import '../screens/setup/submission_review_screen.dart';
import '../screens/analytics_screen.dart';
import '../screens/reports_screen.dart';
import '../utils/report_data.dart' show ReportPeriod;
import '../screens/settings_screen.dart';
import '../screens/todos_screen.dart';
import '../screens/shift_boss_daily_report_form_screen.dart';
import '../screens/shift_boss_form_screen.dart';
import '../screens/special_brief_instruction_register_form_screen.dart';
import '../screens/special_instruction_form_screen.dart';
import '../screens/trackless_machinery_inspection_form_screen.dart';
import '../screens/waiting_place_inspection_form_screen.dart';
import '../screens/weekly_sherq_meeting_form_screen.dart';

class AppRouter {
  static GoRouter build(AuthProvider auth) {
    return GoRouter(
      refreshListenable: auth,
      initialLocation: '/',
      redirect: (context, state) {
        if (auth.loading) return null;
        final loggedIn = auth.user != null;
        final goingToLogin = state.matchedLocation == '/login';
        if (!loggedIn && !goingToLogin) return '/login';
        if (loggedIn && goingToLogin) return '/';
        return null;
      },
      routes: [
        GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
        GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
        // Three sample forms ported end-to-end
        GoRoute(
          path: '/shift-boss',
          builder: (_, __) => const ShiftBossFormScreen(),
        ),
        GoRoute(
          path: '/miner-appointment',
          builder: (_, __) => const MinerAppointmentFormScreen(),
        ),
        GoRoute(
          path: '/lockout-lock-scissor-checklist',
          builder: (_, __) => const LockoutLockScissorChecklistFormScreen(),
        ),
        GoRoute(
          path: '/relieving-miner',
          builder: (_, __) => const RelievingMinerFormScreen(),
        ),
        GoRoute(
          path: '/safety-health-rep',
          builder: (_, __) => const SafetyHealthRepFormScreen(),
        ),
        GoRoute(
          path: '/machinery-operators',
          builder: (_, __) => const MachineryOperatorsFormScreen(),
        ),
        GoRoute(
          path: '/gassing-incident',
          builder: (_, __) => const GassingIncidentFormScreen(),
        ),
        GoRoute(
          path: '/weekly-sherq-meeting',
          builder: (_, __) => const WeeklySherqMeetingFormScreen(),
        ),
        GoRoute(
          path: '/early-shift-record',
          builder: (_, __) => const EarlyShiftRecordFormScreen(),
        ),
        GoRoute(
          path: '/late-shift-record',
          builder: (_, __) => const LateShiftRecordFormScreen(),
        ),
        GoRoute(
          path: '/rock-breaker-inspection',
          builder: (_, __) => const RockBreakerInspectionFormScreen(),
        ),
        GoRoute(
          path: '/belt-tip-area-inspection',
          builder: (_, __) => const BeltTipAreaInspectionFormScreen(),
        ),
        GoRoute(
          path: '/conveyor-belt-inspection',
          builder: (_, __) => const ConveyorBeltInspectionFormScreen(),
        ),
        GoRoute(
          path: '/waiting-place-inspection',
          builder: (_, __) => const WaitingPlaceInspectionFormScreen(),
        ),
        GoRoute(
          path: '/explosive-control-record',
          builder: (_, __) => const ExplosiveControlRecordFormScreen(),
        ),
        GoRoute(
          path: '/action-log-underground-visits',
          builder: (_, __) => const ActionLogUndergroundVisitsFormScreen(),
        ),
        GoRoute(
          path: '/special-instruction',
          builder: (_, __) => const SpecialInstructionFormScreen(),
        ),
        GoRoute(
          path: '/special-brief-instruction-register',
          builder: (_, __) => const SpecialBriefInstructionRegisterFormScreen(),
        ),
        GoRoute(
          path: '/verbal-emergency-drills',
          builder: (_, __) => const EmergencyDrillFormScreen(
            title: 'Verbal Emergency Drills',
            formType: 'verbal_emergency_drills',
            pageNum: 'Page 80 of 84',
          ),
        ),
        GoRoute(
          path: '/physical-emergency-drills',
          builder: (_, __) => const EmergencyDrillFormScreen(
            title: 'Physical Emergency Drills',
            formType: 'physical_emergency_drills',
            pageNum: 'Page 81 of 84',
          ),
        ),
        GoRoute(
          path: '/emergency-drill-exercise',
          builder: (_, __) => const EmergencyDrillExerciseFormScreen(),
        ),
        GoRoute(
          path: '/monthly-fire-fighting-inspection',
          builder: (_, __) => const MonthlyFireFightingInspectionFormScreen(),
        ),
        GoRoute(
          path: '/refuge-bay-inspection',
          builder: (_, __) => const RefugeBayInspectionFormScreen(),
        ),
        GoRoute(
          path: '/inspection-control-sheet',
          builder: (_, __) => const InspectionControlSheetFormScreen(),
        ),
        GoRoute(
          path: '/planned-task-observation',
          builder: (_, __) => const PlannedTaskObservationFormScreen(),
        ),
        GoRoute(
          path: '/trackless-machinery-inspection',
          builder: (_, __) => const TracklessMachineryInspectionFormScreen(),
        ),
        GoRoute(
          path: '/notifications',
          builder: (_, __) => const NotificationsScreen(),
        ),
        GoRoute(
          path: '/signature-requests',
          builder: (_, state) => SignatureRequestsScreen(
            requestId: state.uri.queryParameters['request'],
          ),
        ),
        GoRoute(
          path: '/current-logbook',
          builder: (_, state) => CurrentLogbookScreen(
            justSubmittedId: state.uri.queryParameters['submitted'],
          ),
        ),
        GoRoute(
          path: '/my-profile',
          builder: (_, __) => const MyProfileScreen(),
        ),
        GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
        GoRoute(
          path: '/templates/studio',
          builder: (_, __) => const FormStudioScreen(),
        ),
        GoRoute(
          path: '/form-builder',
          builder: (_, __) => const FormBuilderScreen(),
        ),
        GoRoute(
          path: '/custom-forms',
          builder: (_, __) => const CustomFormsScreen(),
        ),
        GoRoute(
          path: '/setup/locations',
          builder: (_, __) => const LocationsScreen(),
        ),
        GoRoute(path: '/setup/gangs', builder: (_, __) => const GangsScreen()),
        GoRoute(path: '/todos', builder: (_, __) => const TodosScreen()),
        GoRoute(
          path: '/completed-logbook-history',
          builder: (_, __) => const FormSubmissionHistoryScreen(
            title: 'Completed Logbook History',
          ),
        ),
        GoRoute(
          path: '/individual-completed-logbook-history',
          builder: (_, __) => const FormSubmissionHistoryScreen(
            title: 'Individual Completed Logbook History',
          ),
        ),
        GoRoute(path: '/profiles', builder: (_, __) => const ProfilesScreen()),
        GoRoute(
          path: '/appointments',
          builder: (_, __) => const AppointmentsScreen(),
        ),
        GoRoute(path: '/admin', builder: (_, __) => const AdminScreen()),
        GoRoute(
          path: '/appointment-history-logs',
          builder: (_, __) => const AdminAppointmentsLogbookScreen(
            variant: AdminLogbookVariant.history,
          ),
        ),
        GoRoute(
          path: '/active-individual-current-logbook',
          builder: (_, __) => const AdminAppointmentsLogbookScreen(
            variant: AdminLogbookVariant.active,
          ),
        ),
        GoRoute(
          path: '/shift-boss-daily-report',
          builder: (_, __) => const ShiftBossDailyReportFormScreen(),
        ),
        GoRoute(
          path: '/appointment-builder',
          builder: (_, __) => const AppointmentBuilderScreen(),
        ),
        GoRoute(
          path: '/form-designer',
          builder: (_, __) => const FormDesignerScreen(),
        ),
        GoRoute(
          path: '/setup/devices',
          builder: (_, __) => const DevicesAdminScreen(),
        ),
        GoRoute(
          path: '/setup/audit-log',
          builder: (_, __) => const AuditLogScreen(),
        ),
        GoRoute(
          path: '/setup/submission-review',
          builder: (_, __) => const SubmissionReviewScreen(),
        ),
        GoRoute(
          path: '/analytics',
          builder: (_, __) => const AnalyticsScreen(),
        ),
        GoRoute(
          path: '/setup/appointments',
          builder: (_, __) => const AppointmentsAdminScreen(),
        ),
        GoRoute(
          path: '/my-appointments',
          builder: (_, __) => const MyAppointmentsScreen(),
        ),
        GoRoute(
          path: '/reports/daily',
          builder: (_, __) => const ReportScreen(period: ReportPeriod.daily),
        ),
        GoRoute(
          path: '/reports/weekly',
          builder: (_, __) => const ReportScreen(period: ReportPeriod.weekly),
        ),
        GoRoute(
          path: '/reports/monthly',
          builder: (_, __) => const ReportScreen(period: ReportPeriod.monthly),
        ),
        // All remaining routes from src/App.tsx as placeholders so URL surface
        // matches the web app. Port them one-by-one in follow-up sessions.
        ..._placeholders(),
      ],
    );
  }

  static Iterable<GoRoute> _placeholders() {
    // Web-parity stubs (the React app also placeholders these two).
    const webParityStubs = <String, (String, String)>{
      '/logbook-version-management': (
        'Logbook Version Management',
        'Review, edit, add, change, and update logbook versions, version history, and logbook sections.',
      ),
      '/send-notifications-reminders': (
        'Send Notifications and Reminders',
        'Send notification and reminder workflows will be connected here once the rules and recipients are defined.',
      ),
    };
    // Admin shell destinations queued as their own sub-projects.
    // (SP8 Reports now ships /reports/daily|weekly|monthly as real routes.)
    const adminStubs = <String, (String, String)>{};
    return [...webParityStubs.entries, ...adminStubs.entries].map(
      (e) => GoRoute(
        path: e.key,
        builder: (_, __) =>
            PlaceholderScreen(title: e.value.$1, description: e.value.$2),
      ),
    );
  }
}
