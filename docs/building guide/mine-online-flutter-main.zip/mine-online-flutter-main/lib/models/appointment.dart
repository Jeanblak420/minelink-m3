// SP4 Appointments lifecycle model. Pure data + transitions; no Flutter/Supabase
// deps so it is fully unit-testable. Round-trips through the `appointments` table.

enum AppointmentStatus {
  pendingAcceptance,
  pendingSignoff,
  active,
  declined,
  resigned,
}

extension AppointmentStatusX on AppointmentStatus {
  String get wire {
    switch (this) {
      case AppointmentStatus.pendingAcceptance:
        return 'pending_acceptance';
      case AppointmentStatus.pendingSignoff:
        return 'pending_signoff';
      case AppointmentStatus.active:
        return 'active';
      case AppointmentStatus.declined:
        return 'declined';
      case AppointmentStatus.resigned:
        return 'resigned';
    }
  }

  String get label {
    switch (this) {
      case AppointmentStatus.pendingAcceptance:
        return 'Pending acceptance';
      case AppointmentStatus.pendingSignoff:
        return 'Awaiting sign-off';
      case AppointmentStatus.active:
        return 'Active';
      case AppointmentStatus.declined:
        return 'Declined';
      case AppointmentStatus.resigned:
        return 'Resigned';
    }
  }

  static AppointmentStatus fromWire(String s) =>
      AppointmentStatus.values.firstWhere(
        (v) => v.wire == s,
        orElse: () => AppointmentStatus.pendingAcceptance,
      );
}

bool isLiveStatus(AppointmentStatus s) =>
    s == AppointmentStatus.pendingAcceptance ||
    s == AppointmentStatus.pendingSignoff ||
    s == AppointmentStatus.active;

/// Letter token values: standard profile tokens overlaid by template field values
/// (field keys win on collision).
Map<String, String> mergeLetterValues(
  Map<String, String> standard,
  Map<String, String> fieldValues,
) => {...standard, ...fieldValues};

class Appointment {
  const Appointment({
    required this.id,
    required this.templateId,
    required this.formType,
    required this.roleId,
    required this.roleCode,
    required this.appointeeId,
    required this.issuedBy,
    required this.shaftId,
    required this.section,
    required this.cycle,
    required this.effectiveDate,
    required this.status,
    required this.payload,
    required this.submissionId,
    required this.resignReason,
    required this.issuedAt,
    required this.acceptedAt,
    required this.activatedAt,
    required this.resignedAt,
  });

  final String id;
  final String? templateId;
  final String? formType;
  final String? roleId;
  final String roleCode;
  final String appointeeId;
  final String? issuedBy;
  final String? shaftId;
  final String? section;
  final String? cycle;
  final DateTime effectiveDate;
  final AppointmentStatus status;
  final Map<String, dynamic> payload;
  final String? submissionId;
  final String? resignReason;
  final DateTime issuedAt;
  final DateTime? acceptedAt;
  final DateTime? activatedAt;
  final DateTime? resignedAt;

  bool get canAccept => status == AppointmentStatus.pendingAcceptance;
  bool get canDecline => status == AppointmentStatus.pendingAcceptance;
  bool get canResign =>
      status == AppointmentStatus.pendingSignoff ||
      status == AppointmentStatus.active;

  static DateTime _d(dynamic v) => DateTime.parse(v as String);
  static DateTime? _dn(dynamic v) =>
      v == null ? null : DateTime.parse(v as String);

  factory Appointment.fromMap(Map<String, dynamic> m) => Appointment(
    id: (m['id'] ?? '') as String,
    templateId: m['template_id'] as String?,
    formType: m['form_type'] as String?,
    roleId: m['role_id'] as String?,
    roleCode: (m['role_code'] ?? '') as String,
    appointeeId: (m['appointee_id'] ?? '') as String,
    issuedBy: m['issued_by'] as String?,
    shaftId: m['shaft_id'] as String?,
    section: m['section'] as String?,
    cycle: m['cycle'] as String?,
    effectiveDate: _d(m['effective_date']),
    status: AppointmentStatusX.fromWire(
      (m['status'] ?? 'pending_acceptance') as String,
    ),
    payload:
        (m['payload'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{},
    submissionId: m['submission_id'] as String?,
    resignReason: m['resign_reason'] as String?,
    issuedAt: _d(m['issued_at']),
    acceptedAt: _dn(m['accepted_at']),
    activatedAt: _dn(m['activated_at']),
    resignedAt: _dn(m['resigned_at']),
  );

  Map<String, dynamic> toMap() => {
    'template_id': templateId,
    'form_type': formType,
    'role_id': roleId,
    'role_code': roleCode,
    'appointee_id': appointeeId,
    'issued_by': issuedBy,
    'shaft_id': shaftId,
    'section': section,
    'cycle': cycle,
    'effective_date': effectiveDate.toIso8601String().substring(0, 10),
    'status': status.wire,
    'payload': payload,
    'submission_id': submissionId,
    'resign_reason': resignReason,
  };
}
