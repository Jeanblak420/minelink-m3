// Form Builder SP2.1 model. Pure data + validation; no Flutter/Supabase deps so
// it is fully unit-testable. `fields`/`audience`/`requiredSigners` round-trip
// through the JSONB columns on custom_form_templates.

enum FormFieldType {
  text,
  multiline,
  number,
  date,
  dropdown,
  boolean,
  signature,
  section,
  table,
  dynamicDropdown,
}

FormFieldType _typeFromString(String? s) {
  return FormFieldType.values.firstWhere(
    (t) => t.name == s,
    orElse: () => FormFieldType.text,
  );
}

class FormFieldColumn {
  const FormFieldColumn({
    required this.key,
    required this.label,
    required this.type,
  });
  final String key;
  final String label;
  final String type; // 'text' | 'number'

  Map<String, dynamic> toMap() => {'key': key, 'label': label, 'type': type};

  factory FormFieldColumn.fromMap(Map<String, dynamic> m) => FormFieldColumn(
    key: (m['key'] ?? '') as String,
    label: (m['label'] ?? '') as String,
    type: (m['type'] ?? 'text') as String,
  );
}

class FormFieldDef {
  const FormFieldDef({
    required this.key,
    required this.type,
    required this.label,
    required this.required,
    this.help,
    this.options,
    this.columns,
    this.section,
    this.row,
    this.rowOrder,
    this.tabIndex,
    this.dropdownSource,
  });

  final String key;
  final FormFieldType type;
  final String label;
  final bool required;
  final String? help;
  final List<String>? options; // dropdown
  final List<FormFieldColumn>? columns; // table

  // SP4.6 legacy designer layout/config (all optional; absent → today's behavior).
  final String? section;
  final String? row;
  final int? rowOrder;
  final int? tabIndex;
  final String? dropdownSource; // dynamicDropdown source key

  Map<String, dynamic> toMap() => {
    'key': key,
    'type': type.name,
    'label': label,
    'required': required,
    if (help != null) 'help': help,
    if (options != null) 'options': options,
    if (columns != null) 'columns': columns!.map((c) => c.toMap()).toList(),
    if (section != null) 'section': section,
    if (row != null) 'row': row,
    if (rowOrder != null) 'rowOrder': rowOrder,
    if (tabIndex != null) 'tabIndex': tabIndex,
    if (dropdownSource != null) 'dropdownSource': dropdownSource,
  };

  factory FormFieldDef.fromMap(Map<String, dynamic> m) => FormFieldDef(
    key: (m['key'] ?? '') as String,
    type: _typeFromString(m['type'] as String?),
    label: (m['label'] ?? '') as String,
    required: (m['required'] ?? false) as bool,
    help: m['help'] as String?,
    options: (m['options'] as List?)?.map((e) => e as String).toList(),
    columns: (m['columns'] as List?)
        ?.map(
          (e) => FormFieldColumn.fromMap((e as Map).cast<String, dynamic>()),
        )
        .toList(),
    section: m['section'] as String?,
    row: m['row'] as String?,
    rowOrder: (m['rowOrder'] as num?)?.toInt(),
    tabIndex: (m['tabIndex'] as num?)?.toInt(),
    dropdownSource: m['dropdownSource'] as String?,
  );
}

/// Groups fields by section (first-seen order; no section → '' group, first),
/// each section's fields sorted by (row, rowOrder, tabIndex). Used by the legacy
/// designer's live preview and grouped fill rendering.
List<MapEntry<String, List<FormFieldDef>>> groupBySection(
  List<FormFieldDef> fields,
) {
  final order = <String>[];
  final map = <String, List<FormFieldDef>>{};
  for (final f in fields) {
    final s = f.section ?? '';
    if (!map.containsKey(s)) {
      order.add(s);
      map[s] = [];
    }
    map[s]!.add(f);
  }
  int cmp(FormFieldDef a, FormFieldDef b) {
    final r = (a.row ?? '').compareTo(b.row ?? '');
    if (r != 0) return r;
    final o = (a.rowOrder ?? 0).compareTo(b.rowOrder ?? 0);
    if (o != 0) return o;
    return (a.tabIndex ?? 0).compareTo(b.tabIndex ?? 0);
  }

  return [
    for (final s in order) MapEntry(s, [...map[s]!]..sort(cmp)),
  ];
}

class CustomFormTemplate {
  const CustomFormTemplate({
    required this.id,
    required this.code,
    required this.name,
    required this.description,
    required this.category,
    required this.fields,
    required this.audience,
    required this.requiredSigners,
    required this.version,
    required this.isActive,
    required this.createdBy,
  });

  final String id;
  final String code;
  final String name;
  final String? description;
  final String? category;
  final List<FormFieldDef> fields;
  final List<String> audience;
  final List<String> requiredSigners;
  final int version;
  final bool isActive;
  final String? createdBy;

  Map<String, dynamic> toMap() => {
    'code': code,
    'name': name,
    'description': description,
    'category': category,
    'fields': fields.map((f) => f.toMap()).toList(),
    'audience': audience,
    'required_signers': requiredSigners,
    'version': version,
    'is_active': isActive,
    if (createdBy != null) 'created_by': createdBy,
  };

  factory CustomFormTemplate.fromMap(Map<String, dynamic> m) =>
      CustomFormTemplate(
        id: (m['id'] ?? '') as String,
        code: (m['code'] ?? '') as String,
        name: (m['name'] ?? '') as String,
        description: m['description'] as String?,
        category: m['category'] as String?,
        fields: (m['fields'] as List? ?? const [])
            .map(
              (e) => FormFieldDef.fromMap((e as Map).cast<String, dynamic>()),
            )
            .toList(),
        audience: (m['audience'] as List? ?? const [])
            .map((e) => e as String)
            .toList(),
        requiredSigners: (m['required_signers'] as List? ?? const [])
            .map((e) => e as String)
            .toList(),
        version: (m['version'] ?? 1) as int,
        isActive: (m['is_active'] ?? true) as bool,
        createdBy: m['created_by'] as String?,
      );
}

/// Returns a list of human-readable problems; empty list means valid.
List<String> validateTemplate({
  required String name,
  required List<FormFieldDef> fields,
}) {
  final errors = <String>[];
  if (name.trim().isEmpty) errors.add('Form name is required.');
  final inputFields = fields
      .where((f) => f.type != FormFieldType.section)
      .toList();
  if (inputFields.isEmpty) errors.add('Add at least one field.');

  final seenKeys = <String>{};
  for (final f in fields) {
    if (f.label.trim().isEmpty) {
      errors.add('Every field needs a label.');
    }
    if (f.type == FormFieldType.section) continue;
    if (f.key.trim().isEmpty) {
      errors.add('Field "${f.label}" needs a key.');
    } else if (!seenKeys.add(f.key)) {
      errors.add('Duplicate field key: ${f.key}');
    }
    if (f.type == FormFieldType.dropdown &&
        (f.options == null || f.options!.isEmpty)) {
      errors.add('Dropdown "${f.label}" needs at least one option.');
    }
    if (f.type == FormFieldType.table &&
        (f.columns == null || f.columns!.isEmpty)) {
      errors.add('Table "${f.label}" needs at least one column.');
    }
  }
  return errors.toSet().toList(); // de-dupe identical messages
}

/// Empty audience means everyone. Otherwise the user's account type must be in
/// the list (a null account type is only allowed when audience is empty).
bool audienceAllows(List<String> audience, String? accountType) {
  if (audience.isEmpty) return true;
  if (accountType == null) return false;
  return audience.contains(accountType);
}
