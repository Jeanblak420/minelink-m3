// Mirrors `FormViewProps` from src/utils/formRegistry.ts (lines 11-17). Passed
// to every form screen when it's mounted from /signature-requests in view mode.

import 'package:flutter/foundation.dart';

import 'form_overlay.dart';

enum FormMode { edit, view }

class FormViewArgs {
  const FormViewArgs({
    this.mode = FormMode.edit,
    this.initialPayload,
    this.currentSignerRole,
    this.submissionId,
    this.requestId,
    this.onPendingSignatureChange,
    this.overlayOverride,
    this.embedded = false,
  });

  final FormMode mode;
  final Map<String, dynamic>? initialPayload;

  /// `'Mine Overseer'` or `'Mine Manager'` when this signer is the one
  /// expected to sign the submission. `null` for already-signed or finished
  /// submissions — in that case all signature pads are read-only.
  final String? currentSignerRole;

  final String? submissionId;

  /// The id of the pending signature_request the current signer should act
  /// on. Required for the inline Approve & forward / Send back actions
  /// rendered by [FormSignActions] inside view-mode forms.
  final String? requestId;

  /// Called when the current signer's pad emits a new PNG data URL.
  /// `/signature-requests` listens to this to enable the "Sign and Submit"
  /// button and to remember the pending signature.
  final ValueChanged<String>? onPendingSignatureChange;

  /// When set, the form renders this in-memory overlay instead of loading the
  /// saved one from Supabase. Used by the Form Builder live preview so unsaved
  /// edits show immediately. Null in every normal flow.
  final FormOverlay? overlayOverride;

  /// When true, the form omits its own Scaffold AppBar so it can be embedded in
  /// another screen (the Form Builder live-preview pane). False in every normal
  /// flow, so the standalone form is unchanged.
  final bool embedded;

  bool get isViewMode => mode == FormMode.view;

  /// True when this form should render the inline sign-mode action bar
  /// (Approve & forward / Send back). Requires both a signer role and a
  /// pending signature_request id.
  bool get canSign =>
      isViewMode &&
      (currentSignerRole?.isNotEmpty ?? false) &&
      (requestId?.isNotEmpty ?? false);
}
