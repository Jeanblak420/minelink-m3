// SP6 device registry model. Pure data; no Flutter/Supabase deps.

class Device {
  const Device({
    required this.id,
    required this.userId,
    required this.deviceName,
    required this.platform,
    required this.approved,
    required this.approvedAt,
    required this.lastSeenAt,
    required this.isActive,
    required this.createdAt,
  });

  final String id;
  final String userId;
  final String deviceName;
  final String platform;
  final bool approved;
  final bool isActive;
  final DateTime? approvedAt;
  final DateTime lastSeenAt;
  final DateTime createdAt;

  bool get isPending => isActive && !approved;
  String get statusLabel =>
      !isActive ? 'Revoked' : (approved ? 'Approved' : 'Pending');

  static DateTime _d(dynamic v) => DateTime.parse(v as String);
  static DateTime? _dn(dynamic v) =>
      v == null ? null : DateTime.parse(v as String);

  factory Device.fromMap(Map<String, dynamic> m) => Device(
    id: (m['id'] ?? '') as String,
    userId: (m['user_id'] ?? '') as String,
    deviceName: (m['device_name'] ?? '') as String,
    platform: (m['platform'] ?? 'other') as String,
    approved: (m['approved'] ?? false) as bool,
    approvedAt: _dn(m['approved_at']),
    lastSeenAt: _d(m['last_seen_at']),
    isActive: (m['is_active'] ?? true) as bool,
    createdAt: _d(m['created_at']),
  );
}
