// Org structure models: the Shaft → Section → Area hierarchy. Pure data; no
// Flutter/Supabase deps so the grouping helper is unit-testable.

/// Groups [items] by a parent-id key. Used to assemble the location tree
/// (sections by shaft_id, areas by section_id).
Map<String, List<T>> groupByParent<T>(
  List<T> items,
  String Function(T) parentId,
) {
  final out = <String, List<T>>{};
  for (final item in items) {
    out.putIfAbsent(parentId(item), () => <T>[]).add(item);
  }
  return out;
}

class Shaft {
  const Shaft({
    required this.id,
    required this.name,
    required this.description,
    required this.isActive,
  });

  final String id;
  final String name;
  final String? description;
  final bool isActive;

  // shafts uses `shaft_name` for the display name.
  factory Shaft.fromMap(Map<String, dynamic> m) => Shaft(
    id: (m['id'] ?? '') as String,
    name: (m['shaft_name'] ?? '') as String,
    description: m['description'] as String?,
    isActive: (m['is_active'] ?? true) as bool,
  );
}

class Section {
  const Section({
    required this.id,
    required this.shaftId,
    required this.name,
    required this.description,
    required this.isActive,
  });

  final String id;
  final String shaftId;
  final String name;
  final String? description;
  final bool isActive;

  factory Section.fromMap(Map<String, dynamic> m) => Section(
    id: (m['id'] ?? '') as String,
    shaftId: (m['shaft_id'] ?? '') as String,
    name: (m['name'] ?? '') as String,
    description: m['description'] as String?,
    isActive: (m['is_active'] ?? true) as bool,
  );
}

class Area {
  const Area({
    required this.id,
    required this.sectionId,
    required this.name,
    required this.description,
    required this.isActive,
  });

  final String id;
  final String sectionId;
  final String name;
  final String? description;
  final bool isActive;

  factory Area.fromMap(Map<String, dynamic> m) => Area(
    id: (m['id'] ?? '') as String,
    sectionId: (m['section_id'] ?? '') as String,
    name: (m['name'] ?? '') as String,
    description: m['description'] as String?,
    isActive: (m['is_active'] ?? true) as bool,
  );
}

class Shift {
  const Shift({
    required this.id,
    required this.name,
    required this.startTime,
    required this.endTime,
    required this.isActive,
  });

  final String id;
  final String name;
  final String? startTime;
  final String? endTime;
  final bool isActive;

  String get timeRange {
    if ((startTime ?? '').isEmpty && (endTime ?? '').isEmpty) return '';
    return '${startTime ?? '?'} - ${endTime ?? '?'}';
  }

  factory Shift.fromMap(Map<String, dynamic> m) => Shift(
    id: (m['id'] ?? '') as String,
    name: (m['name'] ?? '') as String,
    startTime: m['start_time'] as String?,
    endTime: m['end_time'] as String?,
    isActive: (m['is_active'] ?? true) as bool,
  );
}

class Gang {
  const Gang({
    required this.id,
    required this.name,
    required this.shaftId,
    required this.sectionId,
    required this.shiftId,
    required this.isActive,
  });

  final String id;
  final String name;
  final String? shaftId;
  final String? sectionId;
  final String? shiftId;
  final bool isActive;

  factory Gang.fromMap(Map<String, dynamic> m) => Gang(
    id: (m['id'] ?? '') as String,
    name: (m['name'] ?? '') as String,
    shaftId: m['shaft_id'] as String?,
    sectionId: m['section_id'] as String?,
    shiftId: m['shift_id'] as String?,
    isActive: (m['is_active'] ?? true) as bool,
  );
}

class GangMember {
  const GangMember({
    required this.id,
    required this.gangId,
    required this.userId,
  });

  final String id;
  final String gangId;
  final String userId;

  factory GangMember.fromMap(Map<String, dynamic> m) => GangMember(
    id: (m['id'] ?? '') as String,
    gangId: (m['gang_id'] ?? '') as String,
    userId: (m['user_id'] ?? '') as String,
  );
}

/// A pickable profile (gang member candidate / display).
class PickProfile {
  const PickProfile({required this.id, required this.name});
  final String id;
  final String name;

  factory PickProfile.fromMap(Map<String, dynamic> m) {
    final full = (m['full_name'] as String?)?.trim() ?? '';
    final email = (m['email'] as String?)?.trim() ?? '';
    return PickProfile(
      id: (m['id'] ?? '') as String,
      name: full.isNotEmpty ? full : (email.isNotEmpty ? email : 'Unknown'),
    );
  }
}
