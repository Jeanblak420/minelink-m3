// Inverse of `toMap()` for every class in `form_data.dart`. Used by
// /signature-requests to hydrate a form's typed state from the JSON payload
// stored in `form_submissions.payload`.
//
// All extensions are mechanical: `field = (m['field'] as T?) ?? field`. For
// child objects, delegate to the child's `applyMap`. For lists, replace the
// list contents using `_applyList`.

import 'form_data.dart';

String _s(Map<String, dynamic> m, String key) =>
    (m[key] as String?) ?? '';
bool _b(Map<String, dynamic> m, String key, [bool fallback = false]) =>
    (m[key] as bool?) ?? fallback;

void _applyList<T>(
  List<T> target,
  dynamic raw,
  T Function() create,
  void Function(T item, Map<String, dynamic> m) applyItem,
) {
  if (raw is! List) return;
  target.clear();
  for (final e in raw) {
    if (e is Map<String, dynamic>) {
      final item = create();
      applyItem(item, e);
      target.add(item);
    }
  }
}

void _applyChild<T>(T target, dynamic raw, void Function(T, Map<String, dynamic>) apply) {
  if (raw is Map<String, dynamic>) apply(target, raw);
}

extension WorkplaceSetApplyMap on WorkplaceSet {
  void applyMap(Map<String, dynamic> m) {
    stopes = _s(m, 'stopes');
    developmentEnds = _s(m, 'developmentEnds');
    declines = _s(m, 'declines');
    loadAndHaul = _s(m, 'loadAndHaul');
    travellingWay = _s(m, 'travellingWay');
    refugeBay = _s(m, 'refugeBay');
    store = _s(m, 'store');
    waitingPlace = _s(m, 'waitingPlace');
    conveyorBelts = _s(m, 'conveyorBelts');
    otherWorkplaces = _s(m, 'otherWorkplaces');
  }
}

extension ShiftBossSignaturesApplyMap on ShiftBossSignatures {
  void applyMap(Map<String, dynamic> m) {
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    mineOverseerDate = _s(m, 'mineOverseerDate');
    mineManagerSignature = _s(m, 'mineManagerSignature');
    mineManagerDate = _s(m, 'mineManagerDate');
  }
}

extension ShiftBossFormDataApplyMap on ShiftBossFormData {
  void applyMap(Map<String, dynamic> m) {
    title = _s(m, 'title');
    name = _s(m, 'name');
    identityNumber = _s(m, 'identityNumber');
    companyNumber = _s(m, 'companyNumber');
    shaft = _s(m, 'shaft');
    _applyChild(workplaces, m['workplaces'], (c, mm) => c.applyMap(mm));
    effectiveDate = _s(m, 'effectiveDate');
    nextRevisionDate = _s(m, 'nextRevisionDate');
    _applyChild(signatures, m['signatures'], (c, mm) => c.applyMap(mm));
  }
}

extension MinerAppointmentSignaturesApplyMap on MinerAppointmentSignatures {
  void applyMap(Map<String, dynamic> m) {
    minerSignature = _s(m, 'minerSignature');
    minerDate = _s(m, 'minerDate');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    mineOverseerDate = _s(m, 'mineOverseerDate');
    mineManagerSignature = _s(m, 'mineManagerSignature');
    mineManagerDate = _s(m, 'mineManagerDate');
  }
}

extension MinerAppointmentFormDataApplyMap on MinerAppointmentFormData {
  void applyMap(Map<String, dynamic> m) {
    title = _s(m, 'title');
    name = _s(m, 'name');
    identityNumber = _s(m, 'identityNumber');
    companyNumber = _s(m, 'companyNumber');
    sectionShaft = _s(m, 'sectionShaft');
    _applyChild(workplaces, m['workplaces'], (c, mm) => c.applyMap(mm));
    _applyChild(signatures, m['signatures'], (c, mm) => c.applyMap(mm));
  }
}

extension RelievingMinerSignaturesApplyMap on RelievingMinerSignatures {
  void applyMap(Map<String, dynamic> m) {
    relievingMinerSignature = _s(m, 'relievingMinerSignature');
    relievingMinerDate = _s(m, 'relievingMinerDate');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    mineOverseerDate = _s(m, 'mineOverseerDate');
    mineManagerSignature = _s(m, 'mineManagerSignature');
    mineManagerDate = _s(m, 'mineManagerDate');
  }
}

extension RelievingMinerFormDataApplyMap on RelievingMinerFormData {
  void applyMap(Map<String, dynamic> m) {
    title = _s(m, 'title');
    name = _s(m, 'name');
    identityNumber = _s(m, 'identityNumber');
    companyNumber = _s(m, 'companyNumber');
    sectionShaft = _s(m, 'sectionShaft');
    _applyChild(workplaces, m['workplaces'], (c, mm) => c.applyMap(mm));
    _applyChild(signatures, m['signatures'], (c, mm) => c.applyMap(mm));
  }
}

extension SafetyHealthRepSignaturesApplyMap on SafetyHealthRepSignatures {
  void applyMap(Map<String, dynamic> m) {
    managerSignature = _s(m, 'managerSignature');
    managerDate = _s(m, 'managerDate');
    managerWitness = _s(m, 'managerWitness');
    acceptedSignature = _s(m, 'acceptedSignature');
    acceptedDate = _s(m, 'acceptedDate');
    acceptedWitness = _s(m, 'acceptedWitness');
  }
}

extension SafetyHealthRepSectionApplyMap on SafetyHealthRepSection {
  void applyMap(Map<String, dynamic> m) {
    name = _s(m, 'name');
    companyNumber = _s(m, 'companyNumber');
    shaft = _s(m, 'shaft');
    section = _s(m, 'section');
    _applyChild(signatures, m['signatures'], (c, mm) => c.applyMap(mm));
  }
}

extension SafetyHealthRepFormDataApplyMap on SafetyHealthRepFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyChild(primary, m['primary'], (c, mm) => c.applyMap(mm));
    _applyChild(alternative, m['alternative'], (c, mm) => c.applyMap(mm));
  }
}

extension MachineryOperatorEntryApplyMap on MachineryOperatorEntry {
  void applyMap(Map<String, dynamic> m) {
    companyNumber = _s(m, 'companyNumber');
    location = _s(m, 'location');
    typeOfEquipment = _s(m, 'typeOfEquipment');
    licenceExpiryDate = _s(m, 'licenceExpiryDate');
    appointedForMonth = _s(m, 'appointedForMonth');
    signature = _s(m, 'signature');
  }
}

extension MachineryOperatorsFormDataApplyMap on MachineryOperatorsFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyList(operators, m['operators'], MachineryOperatorEntry.new,
        (item, mm) => item.applyMap(mm));
  }
}

extension GassingIncidentFormDataApplyMap on GassingIncidentFormData {
  void applyMap(Map<String, dynamic> m) {
    date = _s(m, 'date');
    coyNoOfInjured = _s(m, 'coyNoOfInjured');
    time = _s(m, 'time');
    workingPlace = _s(m, 'workingPlace');
    severity = _s(m, 'severity');
    description = _s(m, 'description');
    injuries = _s(m, 'injuries');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
  }
}

extension WeeklySherqTopicsApplyMap on WeeklySherqTopics {
  void applyMap(Map<String, dynamic> m) {
    standards = _b(m, 'standards');
    incident = _b(m, 'incident');
    emergencyPreparedness = _b(m, 'emergencyPreparedness');
    soReport = _b(m, 'soReport');
    instruction = _b(m, 'instruction');
    rockMechanicReport = _b(m, 'rockMechanicReport');
    ppe = _b(m, 'ppe');
    sheRepReport = _b(m, 'sheRepReport');
    procedures = _b(m, 'procedures');
    ventReport = _b(m, 'ventReport');
  }
}

extension AttendanceEntryApplyMap on AttendanceEntry {
  void applyMap(Map<String, dynamic> m) {
    coyNo = _s(m, 'coyNo');
    signature = _s(m, 'signature');
  }
}

extension WeeklySherqMeetingFormDataApplyMap on WeeklySherqMeetingFormData {
  void applyMap(Map<String, dynamic> m) {
    date = _s(m, 'date');
    time = _s(m, 'time');
    workplace = _s(m, 'workplace');
    duration = _s(m, 'duration');
    supervisorCoyNo = _s(m, 'supervisorCoyNo');
    sheRepCoyNo = _s(m, 'sheRepCoyNo');
    _applyChild(topics, m['topics'], (c, mm) => c.applyMap(mm));
    mattersDiscussed = _s(m, 'mattersDiscussed');
    feedbackFromCrew = _s(m, 'feedbackFromCrew');
    _applyList(attendance, m['attendance'], AttendanceEntry.new,
        (item, mm) => item.applyMap(mm));
    supervisorSignature = _s(m, 'supervisorSignature');
    sheRepSignature = _s(m, 'sheRepSignature');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
  }
}

extension EarlyShiftRecordFormDataApplyMap on EarlyShiftRecordFormData {
  void applyMap(Map<String, dynamic> m) {
    section = _s(m, 'section');
    strike = _s(m, 'strike');
    date = _s(m, 'date');
    wentUndergroundAt = _s(m, 'wentUndergroundAt');
    arrivedAtWaitingPlace = _s(m, 'arrivedAtWaitingPlace');
    minerArrivedAt = _s(m, 'minerArrivedAt');
    minerCoyNo = _s(m, 'minerCoyNo');
    waitingPlaceLocation = _s(m, 'waitingPlaceLocation');
    barricadeErected = _s(m, 'barricadeErected');
    barricadeDetails = _s(m, 'barricadeDetails');
    minerFollowedProcedure = _s(m, 'minerFollowedProcedure');
    minerFollowedDetails = _s(m, 'minerFollowedDetails');
    permissionToCompA = _s(m, 'permissionToCompA');
    minerPossessionGDI = _s(m, 'minerPossessionGDI');
    gdiNo = _s(m, 'gdiNo');
    blastingCableDisconnected = _s(m, 'blastingCableDisconnected');
    earlyEntryExamination = _s(m, 'earlyEntryExamination');
    earlyEntryDetails = _s(m, 'earlyEntryDetails');
    safeDeclarationBooklet = _s(m, 'safeDeclarationBooklet');
    safeDeclarationDetails = _s(m, 'safeDeclarationDetails');
    flammableGasesTest = _s(m, 'flammableGasesTest');
    flammableGasesDetails = _s(m, 'flammableGasesDetails');
    entryEquipmentAvailable = _s(m, 'entryEquipmentAvailable');
    entryEquipmentDetails = _s(m, 'entryEquipmentDetails');
    hygrometerAndAnemo = _s(m, 'hygrometerAndAnemo');
    hygrometerDetails = _s(m, 'hygrometerDetails');
    waterDownProperly = _s(m, 'waterDownProperly');
    drinkingWaterAvailable = _s(m, 'drinkingWaterAvailable');
    drinkingWaterDetails = _s(m, 'drinkingWaterDetails');
    specialInstruction = _s(m, 'specialInstruction');
    additionalRemarks = _s(m, 'additionalRemarks');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossSignatureDate = _s(m, 'shiftBossSignatureDate');
    minerOverseerSignature = _s(m, 'minerOverseerSignature');
    minerOverseerSignatureDate = _s(m, 'minerOverseerSignatureDate');
  }
}

extension LateShiftRecordFormDataApplyMap on LateShiftRecordFormData {
  void applyMap(Map<String, dynamic> m) {
    section = _s(m, 'section');
    strike = _s(m, 'strike');
    date = _s(m, 'date');
    minerInChargeCoyNo = _s(m, 'minerInChargeCoyNo');
    chargesCorrectlyPrepared = _s(m, 'chargesCorrectlyPrepared');
    chargesDetails = _s(m, 'chargesDetails');
    chargingUpDevEndNo = _s(m, 'chargingUpDevEndNo');
    ventHolingNo = _s(m, 'ventHolingNo');
    explosiveCorrectlyTransported = _s(m, 'explosiveCorrectlyTransported');
    testedForFlammableGas = _s(m, 'testedForFlammableGas');
    gdiNo = _s(m, 'gdiNo');
    chargingUnderDirectSupervision = _s(m, 'chargingUnderDirectSupervision');
    typeOfExplosivesUsed = _s(m, 'typeOfExplosivesUsed');
    typeOfFuseUsed = _s(m, 'typeOfFuseUsed');
    fuseLength = _s(m, 'fuseLength');
    amountOfFusesUsed = _s(m, 'amountOfFusesUsed');
    holesDislodgedCorrectly = _s(m, 'holesDislodgedCorrectly');
    holesDislodgedDetails = _s(m, 'holesDislodgedDetails');
    lengthOfDrillHoles = _s(m, 'lengthOfDrillHoles');
    lengthOfBlowPipe = _s(m, 'lengthOfBlowPipe');
    blastingCableToStandard = _s(m, 'blastingCableToStandard');
    blastingCableDetails = _s(m, 'blastingCableDetails');
    circuitTested = _s(m, 'circuitTested');
    blastingCableConnectedToTerminalBox =
        _s(m, 'blastingCableConnectedToTerminalBox');
    blastingCableTerminalDetails = _s(m, 'blastingCableTerminalDetails');
    distributionOfOldExplosivesObserved =
        _s(m, 'distributionOfOldExplosivesObserved');
    distributionOfOldExplosivesDiscussed =
        _s(m, 'distributionOfOldExplosivesDiscussed');
    workingPlaceBarricadeInPosition = _s(m, 'workingPlaceBarricadeInPosition');
    explosiveBoxesLocked = _s(m, 'explosiveBoxesLocked');
    barricadeExplosiveDetails = _s(m, 'barricadeExplosiveDetails');
    idCardsCorrectlyIssued = _s(m, 'idCardsCorrectlyIssued');
    airAndWaterHosesClosed = _s(m, 'airAndWaterHosesClosed');
    anyIncidentInjuriesReported = _s(m, 'anyIncidentInjuriesReported');
    arrivedOnSurfaceAt = _s(m, 'arrivedOnSurfaceAt');
    specialInstructionsGiven = _s(m, 'specialInstructionsGiven');
    additionalRemarks = _s(m, 'additionalRemarks');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossSignatureDate = _s(m, 'shiftBossSignatureDate');
    minerOverseerSignature = _s(m, 'minerOverseerSignature');
    minerOverseerSignatureDate = _s(m, 'minerOverseerSignatureDate');
  }
}

extension TracklessMachineryEntryApplyMap on TracklessMachineryEntry {
  // ignore: non_constant_identifier_names
  void applyMap(Map<String, dynamic> m) {
    dateOfInspection = _s(m, 'dateOfInspection');
    operatorCoyNumber = _s(m, 'operatorCoyNumber');
    machineNumber = _s(m, 'machineNumber');
    operatorTrained = _s(m, 'operatorTrained');
    operatorTrained_remedial = _s(m, 'operatorTrained_remedial');
    operatorLicence = _s(m, 'operatorLicence');
    operatorLicence_remedial = _s(m, 'operatorLicence_remedial');
    preUseChecklistAvailable = _s(m, 'preUseChecklistAvailable');
    preUseChecklistAvailable_remedial =
        _s(m, 'preUseChecklistAvailable_remedial');
    preUseChecklistCompleted = _s(m, 'preUseChecklistCompleted');
    preUseChecklistCompleted_remedial =
        _s(m, 'preUseChecklistCompleted_remedial');
    correctPPE = _s(m, 'correctPPE');
    correctPPE_remedial = _s(m, 'correctPPE_remedial');
    safetyBelt = _s(m, 'safetyBelt');
    safetyBelt_remedial = _s(m, 'safetyBelt_remedial');
  }
}

extension TracklessMachineryFormDataApplyMap on TracklessMachineryFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyList(inspections, m['inspections'], TracklessMachineryEntry.new,
        (item, mm) => item.applyMap(mm));
    shiftbossSignature = _s(m, 'shiftbossSignature');
    shiftbossSignatureDate = _s(m, 'shiftbossSignatureDate');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    mineOverseerSignatureDate = _s(m, 'mineOverseerSignatureDate');
  }
}

extension InspectionControlSheetRowApplyMap on InspectionControlSheetRow {
  void applyMap(Map<String, dynamic> m) {
    workplace = _s(m, 'workplace');
    final raw = m['days'];
    if (raw is List) {
      final next = raw.map((e) => (e as String?) ?? '').toList();
      for (var i = 0; i < days.length; i++) {
        days[i] = i < next.length ? next[i] : '';
      }
    }
  }
}

extension InspectionControlSheetFormDataApplyMap
    on InspectionControlSheetFormData {
  void applyMap(Map<String, dynamic> m) {
    monthFrom = _s(m, 'monthFrom');
    monthTo = _s(m, 'monthTo');
    _applyList(rows, m['rows'], InspectionControlSheetRow.new,
        (item, mm) => item.applyMap(mm));
  }
}

extension PlannedTaskObservationRowApplyMap on PlannedTaskObservationRow {
  void applyMap(Map<String, dynamic> m) {
    task = _s(m, 'task');
    annual = _s(m, 'annual');
    semester = _s(m, 'semester');
    quarterly = _s(m, 'quarterly');
    monthly = _s(m, 'monthly');
    biWeekly = _s(m, 'biWeekly');
    weekly = _s(m, 'weekly');
    daily = _s(m, 'daily');
  }
}

extension PlannedTaskObservationFormDataApplyMap
    on PlannedTaskObservationFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyList(rows, m['rows'], PlannedTaskObservationRow.new,
        (item, mm) => item.applyMap(mm));
  }
}

extension RefugeBayItemApplyMap on RefugeBayItem {
  void applyMap(Map<String, dynamic> m) {
    consequenceClassification = _s(m, 'consequenceClassification');
    yes = _b(m, 'yes');
    no = _b(m, 'no');
    remarks = _s(m, 'remarks');
    extraField = _s(m, 'extraField');
  }
}

extension RefugeBayInstructionApplyMap on RefugeBayInstruction {
  void applyMap(Map<String, dynamic> m) {
    instruction = _s(m, 'instruction');
    completionDate = _s(m, 'completionDate');
  }
}

extension RefugeBayInspectionFormDataApplyMap on RefugeBayInspectionFormData {
  void applyMap(Map<String, dynamic> m) {
    shaft = _s(m, 'shaft');
    date = _s(m, 'date');
    observer = _s(m, 'observer');
    refugeBayNo = _s(m, 'refugeBayNo');
    mineOverseer = _s(m, 'mineOverseer');
    section = _s(m, 'section');
    _applyList(items, m['items'], RefugeBayItem.new,
        (item, mm) => item.applyMap(mm));
    isLifeSustainable = _s(m, 'isLifeSustainable');
    _applyList(instructions, m['instructions'], RefugeBayInstruction.new,
        (item, mm) => item.applyMap(mm));
    observerDate = _s(m, 'observerDate');
    mineOverseerDate = _s(m, 'mineOverseerDate');
  }
}

extension FireFightingEquipmentEntryApplyMap on FireFightingEquipmentEntry {
  void applyMap(Map<String, dynamic> m) {
    workingPlace = _s(m, 'workingPlace');
    localityVehicleNo = _s(m, 'localityVehicleNo');
    inspectionDate = _s(m, 'inspectionDate');
    conditionOfSeal = _s(m, 'conditionOfSeal');
    pressureGauge = _s(m, 'pressureGauge');
    conditionOfHandleNozzle = _s(m, 'conditionOfHandleNozzle');
    conditionOfHose = _s(m, 'conditionOfHose');
    deficiency = _s(m, 'deficiency');
    dateOfLastAnnualService = _s(m, 'dateOfLastAnnualService');
  }
}

extension MonthlyFireFightingInspectionFormDataApplyMap
    on MonthlyFireFightingInspectionFormData {
  void applyMap(Map<String, dynamic> m) {
    department = _s(m, 'department');
    area = _s(m, 'area');
    name = _s(m, 'name');
    designation = _s(m, 'designation');
    _applyList(entries, m['entries'], FireFightingEquipmentEntry.new,
        (item, mm) => item.applyMap(mm));
    inspectorSignature = _s(m, 'inspectorSignature');
    inspectorName = _s(m, 'inspectorName');
    inspectorDate = _s(m, 'inspectorDate');
    sectionHeadSignature = _s(m, 'sectionHeadSignature');
    sectionHeadName = _s(m, 'sectionHeadName');
    sectionHeadDate = _s(m, 'sectionHeadDate');
  }
}

extension EmergencyDrillEmployeeApplyMap on EmergencyDrillEmployee {
  void applyMap(Map<String, dynamic> m) {
    col1 = _s(m, 'col1');
    col2 = _s(m, 'col2');
    col3 = _s(m, 'col3');
  }
}

extension EmergencyDrillFormDataApplyMap on EmergencyDrillFormData {
  void applyMap(Map<String, dynamic> m) {
    date = _s(m, 'date');
    refugeBayNo = _s(m, 'refugeBayNo');
    workingPlace = _s(m, 'workingPlace');
    emergencyDrillPerformed = _s(m, 'emergencyDrillPerformed');
    deficienciesObserved = _s(m, 'deficienciesObserved');
    recommendedImprovements = _s(m, 'recommendedImprovements');
    refugeBaySituatedAt = _s(m, 'refugeBaySituatedAt');
    _applyList(employees, m['employees'], EmergencyDrillEmployee.new,
        (item, mm) => item.applyMap(mm));
  }
}

extension EmergencyDrillExerciseFormDataApplyMap
    on EmergencyDrillExerciseFormData {
  void applyMap(Map<String, dynamic> m) {
    shiftBoss = _s(m, 'shiftBoss');
    workingPlace = _s(m, 'workingPlace');
    dateOfExercise = _s(m, 'dateOfExercise');
    typeOfEmergency = _s(m, 'typeOfEmergency');
    alarmMadeAt = _s(m, 'alarmMadeAt');
    allPersonsEvacuatedBy = _s(m, 'allPersonsEvacuatedBy');
    routesTaken = _s(m, 'routesTaken');
    procedureA = _s(m, 'procedureA');
    procedureB = _s(m, 'procedureB');
    procedureC = _s(m, 'procedureC');
    procedureD = _s(m, 'procedureD');
    procedureE = _s(m, 'procedureE');
    procedureF = _s(m, 'procedureF');
    rescuingInjuredWorkers = _s(m, 'rescuingInjuredWorkers');
    extinguishingFire = _s(m, 'extinguishingFire');
    majorFireOrExplosion = _s(m, 'majorFireOrExplosion');
    generalRemarks = _s(m, 'generalRemarks');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossSignatureDate = _s(m, 'shiftBossSignatureDate');
  }
}

extension SpecialBriefEntryApplyMap on SpecialBriefEntry {
  void applyMap(Map<String, dynamic> m) {
    title = _s(m, 'title');
    communicatedTo = _s(m, 'communicatedTo');
  }
}

extension SpecialBriefInstructionRegisterFormDataApplyMap
    on SpecialBriefInstructionRegisterFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyList(entries, m['entries'], SpecialBriefEntry.new,
        (item, mm) => item.applyMap(mm));
  }
}

extension SpecialInstructionSectionApplyMap on SpecialInstructionSection {
  void applyMap(Map<String, dynamic> m) {
    date = _s(m, 'date');
    time = _s(m, 'time');
    instructionTo = _s(m, 'instructionTo');
    detailOfInstruction = _s(m, 'detailOfInstruction');
    remedialAction = _s(m, 'remedialAction');
    issuerSignature = _s(m, 'issuerSignature');
    issuerSignatureDate = _s(m, 'issuerSignatureDate');
    receiverSignature = _s(m, 'receiverSignature');
    receiverSignatureDate = _s(m, 'receiverSignatureDate');
  }
}

extension SpecialInstructionFormDataApplyMap on SpecialInstructionFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyChild(section1, m['section1'], (c, mm) => c.applyMap(mm));
    _applyChild(section2, m['section2'], (c, mm) => c.applyMap(mm));
  }
}

extension ActionLogDeviationEntryApplyMap on ActionLogDeviationEntry {
  void applyMap(Map<String, dynamic> m) {
    deviationObserved = _s(m, 'deviationObserved');
    remedialAction = _s(m, 'remedialAction');
    estimatedCompletionDate = _s(m, 'estimatedCompletionDate');
    dateCompleted = _s(m, 'dateCompleted');
    signature = _s(m, 'signature');
  }
}

extension ActionLogUndergroundVisitsFormDataApplyMap
    on ActionLogUndergroundVisitsFormData {
  void applyMap(Map<String, dynamic> m) {
    date = _s(m, 'date');
    workingPlaceVisited = _s(m, 'workingPlaceVisited');
    nameOfSeniorOfficial = _s(m, 'nameOfSeniorOfficial');
    designation = _s(m, 'designation');
    _applyList(deviations, m['deviations'], ActionLogDeviationEntry.new,
        (item, mm) => item.applyMap(mm));
    shiftBossSignature = _s(m, 'shiftBossSignature');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    seniorOfficialSignature = _s(m, 'seniorOfficialSignature');
  }
}

extension ExplosiveControlEntryApplyMap on ExplosiveControlEntry {
  void applyMap(Map<String, dynamic> m) {
    description = _s(m, 'description');
    boxNo = _s(m, 'boxNo');
    amountInControlBook = _s(m, 'amountInControlBook');
    amountObserved = _s(m, 'amountObserved');
    amountDelivered = _s(m, 'amountDelivered');
  }
}

extension ExplosiveControlRecordFormDataApplyMap
    on ExplosiveControlRecordFormData {
  void applyMap(Map<String, dynamic> m) {
    section = _s(m, 'section');
    strike = _s(m, 'strike');
    date = _s(m, 'date');
    minerCoyNo = _s(m, 'minerCoyNo');
    _applyList(entries, m['entries'], ExplosiveControlEntry.new,
        (item, mm) => item.applyMap(mm));
    deviationsObserved = _s(m, 'deviationsObserved');
    deviationsDetails = _s(m, 'deviationsDetails');
    oldBoxesMarked = _s(m, 'oldBoxesMarked');
    oldBoxesMarkedDetails = _s(m, 'oldBoxesMarkedDetails');
    oldBoxesLocked = _s(m, 'oldBoxesLocked');
    oldBoxesLockedDetails = _s(m, 'oldBoxesLockedDetails');
    typeOfExplosiveInBox = _s(m, 'typeOfExplosiveInBox');
    totalInBox = _s(m, 'totalInBox');
    recordedCorrectly = _s(m, 'recordedCorrectly');
    recordedDetails = _s(m, 'recordedDetails');
    specialInstructions = _s(m, 'specialInstructions');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    mineOverseerDate = _s(m, 'mineOverseerDate');
  }
}

extension PlaceVisitedEntryApplyMap on PlaceVisitedEntry {
  void applyMap(Map<String, dynamic> m) {
    placeVisited = _s(m, 'placeVisited');
    miner = _s(m, 'miner');
  }
}

extension PlannedInspectionEntryApplyMap on PlannedInspectionEntry {
  void applyMap(Map<String, dynamic> m) {
    workingPlace = _s(m, 'workingPlace');
    unsafeConditions = _s(m, 'unsafeConditions');
    remedialAction = _s(m, 'remedialAction');
    responsiblePerson = _s(m, 'responsiblePerson');
    plannedDate = _s(m, 'plannedDate');
    completedDate = _s(m, 'completedDate');
    responsiblePersonSignature = _s(m, 'responsiblePersonSignature');
  }
}

extension DevEndEntryApplyMap on DevEndEntry {
  void applyMap(Map<String, dynamic> m) {
    devEndVentHoling = _s(m, 'devEndVentHoling');
    roofboltsFromFace = _s(m, 'roofboltsFromFace');
    roofboltsFromSidewall = _s(m, 'roofboltsFromSidewall');
    socketsInspected = _s(m, 'socketsInspected');
    averageLength = _s(m, 'averageLength');
    servicePipes = _s(m, 'servicePipes');
    ventPipes = _s(m, 'ventPipes');
  }
}

extension PillarDimensionEntryApplyMap on PillarDimensionEntry {
  void applyMap(Map<String, dynamic> m) {
    workplace = _s(m, 'workplace');
    vhNo = _s(m, 'vhNo');
    surveyNoteLeft = _s(m, 'surveyNoteLeft');
    surveyNoteRight = _s(m, 'surveyNoteRight');
    actualLeft = _s(m, 'actualLeft');
    actualRight = _s(m, 'actualRight');
    remedialAction = _s(m, 'remedialAction');
  }
}

extension InspectionCheckItemApplyMap on InspectionCheckItem {
  void applyMap(Map<String, dynamic> m) {
    item = _s(m, 'item');
    yes = _b(m, 'yes');
    no = _b(m, 'no');
    findings = _s(m, 'findings');
  }
}

extension ShiftBossDailyReportFormDataApplyMap
    on ShiftBossDailyReportFormData {
  void applyMap(Map<String, dynamic> m) {
    date = _s(m, 'date');
    dayShift = _b(m, 'dayShift');
    nightShift = _b(m, 'nightShift');
    cycleA = _b(m, 'cycleA');
    cycleB = _b(m, 'cycleB');
    cycleC = _b(m, 'cycleC');
    _applyList(placesVisited, m['placesVisited'], PlaceVisitedEntry.new,
        (item, mm) => item.applyMap(mm));
    _applyList(plannedInspections, m['plannedInspections'],
        PlannedInspectionEntry.new, (item, mm) => item.applyMap(mm));
    _applyList(devEnds, m['devEnds'], DevEndEntry.new,
        (item, mm) => item.applyMap(mm));
    _applyList(pillarDimensions, m['pillarDimensions'],
        PillarDimensionEntry.new, (item, mm) => item.applyMap(mm));
    _applyList(inspectionChecklist, m['inspectionChecklist'],
        InspectionCheckItem.new, (item, mm) => item.applyMap(mm));
    ventilationFlowReading = _s(m, 'ventilationFlowReading');
    temperatureWBReading = _s(m, 'temperatureWBReading');
    temperatureDBReading = _s(m, 'temperatureDBReading');
    general = _s(m, 'general');
    mineOverseerComments = _s(m, 'mineOverseerComments');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    managerMineOverseerSignature = _s(m, 'managerMineOverseerSignature');
    signatureDate = _s(m, 'signatureDate');
  }
}

extension WaitingPlaceCheckItemApplyMap on WaitingPlaceCheckItem {
  void applyMap(Map<String, dynamic> m) {
    yes = _b(m, 'yes');
    no = _b(m, 'no');
    remarks = _s(m, 'remarks');
  }
}

extension WaitingPlaceInspectionFormDataApplyMap
    on WaitingPlaceInspectionFormData {
  void applyMap(Map<String, dynamic> m) {
    section = _s(m, 'section');
    miner = _s(m, 'miner');
    date = _s(m, 'date');
    _applyList(items, m['items'], WaitingPlaceCheckItem.new,
        (item, mm) => item.applyMap(mm));
    specialInstructions = _s(m, 'specialInstructions');
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineOverseerSignature = _s(m, 'mineOverseerSignature');
    mineOverseerDate = _s(m, 'mineOverseerDate');
  }
}

extension InspectionItemApplyMap on InspectionItem {
  void applyMap(Map<String, dynamic> m) {
    yesNo = _s(m, 'yesNo');
    remedialAction = _s(m, 'remedialAction');
  }
}

extension RockBreakerInspectionFormDataApplyMap
    on RockBreakerInspectionFormData {
  void applyMap(Map<String, dynamic> m) {
    dateOfInspection = _s(m, 'dateOfInspection');
    positionOfRockBreaker = _s(m, 'positionOfRockBreaker');
    _applyList(items, m['items'], InspectionItem.new,
        (item, mm) => item.applyMap(mm));
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineManagerOverseerSignature = _s(m, 'mineManagerOverseerSignature');
    mineManagerOverseerDate = _s(m, 'mineManagerOverseerDate');
  }
}

extension BeltTipAreaInspectionFormDataApplyMap
    on BeltTipAreaInspectionFormData {
  void applyMap(Map<String, dynamic> m) {
    dateOfInspection = _s(m, 'dateOfInspection');
    positionOfTip = _s(m, 'positionOfTip');
    _applyList(items, m['items'], InspectionItem.new,
        (item, mm) => item.applyMap(mm));
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineManagerOverseerSignature = _s(m, 'mineManagerOverseerSignature');
    mineManagerOverseerDate = _s(m, 'mineManagerOverseerDate');
  }
}

extension ConveyorBeltInspectionFormDataApplyMap
    on ConveyorBeltInspectionFormData {
  void applyMap(Map<String, dynamic> m) {
    dateOfInspection = _s(m, 'dateOfInspection');
    positionOfBelt = _s(m, 'positionOfBelt');
    _applyList(walkwayItems, m['walkwayItems'], InspectionItem.new,
        (item, mm) => item.applyMap(mm));
    _applyList(beltConditionItems, m['beltConditionItems'], InspectionItem.new,
        (item, mm) => item.applyMap(mm));
    shiftBossSignature = _s(m, 'shiftBossSignature');
    shiftBossDate = _s(m, 'shiftBossDate');
    mineManagerOverseerSignature = _s(m, 'mineManagerOverseerSignature');
    mineManagerOverseerDate = _s(m, 'mineManagerOverseerDate');
  }
}

extension LockoutChecklistEntryApplyMap on LockoutChecklistEntry {
  void applyMap(Map<String, dynamic> m) {
    nameSurname = _s(m, 'nameSurname');
    operatorAssistant = _s(m, 'operatorAssistant');
    workplace = _s(m, 'workplace');
    trainedOnLockOut = _s(m, 'trainedOnLockOut');
    lockAvailable = _s(m, 'lockAvailable');
    scissorAvailable = _s(m, 'scissorAvailable');
    date = _s(m, 'date');
    signature = _s(m, 'signature');
  }
}

extension LockoutLockScissorChecklistFormDataApplyMap
    on LockoutLockScissorChecklistFormData {
  void applyMap(Map<String, dynamic> m) {
    _applyList(entries, m['entries'], LockoutChecklistEntry.new,
        (item, mm) => item.applyMap(mm));
    shiftBossSignature = _s(m, 'shiftBossSignature');
  }
}
