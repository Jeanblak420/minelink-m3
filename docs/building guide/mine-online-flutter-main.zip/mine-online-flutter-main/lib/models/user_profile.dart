class UserProfile {
  final String id;
  final String fullName;
  final String firstName;
  final String title;
  final String email;
  final String jobTitle;
  final String costCentre;
  final String? userAccountType;
  final String? themeMode;
  final String? customThemeColor;
  final bool isAdmin;
  final bool isSuperAdmin;
  final bool disabled;
  final String? companyNumber;
  final String? saIdNumber;
  final String? sectionShaft;
  final String? employeeNumber;
  final String? company;
  final String? location;
  final String? department;
  final String? occupation;
  final String? category;
  final String? shiftCycleId;
  final String? workArea;
  final String? deptCode;
  final String? payrollId;
  final String? phone;
  final String? signatureData;
  final String? createdAt;
  final String? updatedAt;

  const UserProfile({
    required this.id,
    required this.fullName,
    required this.firstName,
    required this.title,
    required this.email,
    required this.jobTitle,
    required this.costCentre,
    this.userAccountType,
    this.themeMode,
    this.customThemeColor,
    required this.isAdmin,
    required this.isSuperAdmin,
    this.disabled = false,
    this.companyNumber,
    this.saIdNumber,
    this.sectionShaft,
    this.employeeNumber,
    this.company,
    this.location,
    this.department,
    this.occupation,
    this.category,
    this.shiftCycleId,
    this.workArea,
    this.deptCode,
    this.payrollId,
    this.phone,
    this.signatureData,
    this.createdAt,
    this.updatedAt,
  });

  factory UserProfile.fromMap(Map<String, dynamic> map) => UserProfile(
    id: map['id'] as String,
    fullName: (map['full_name'] as String?) ?? '',
    firstName: (map['first_name'] as String?) ?? '',
    title: (map['title'] as String?) ?? '',
    email: (map['email'] as String?) ?? '',
    jobTitle: (map['job_title'] as String?) ?? '',
    costCentre: (map['cost_centre'] as String?) ?? '',
    userAccountType: map['user_account_type'] as String?,
    themeMode: map['theme_mode'] as String?,
    customThemeColor: map['custom_theme_color'] as String?,
    isAdmin: (map['is_admin'] as bool?) ?? false,
    isSuperAdmin: (map['is_super_admin'] as bool?) ?? false,
    disabled: (map['disabled'] as bool?) ?? false,
    companyNumber: map['company_number'] as String?,
    saIdNumber: map['sa_id_number'] as String?,
    sectionShaft: map['section_shaft'] as String?,
    employeeNumber: map['employee_number'] as String?,
    company: map['company'] as String?,
    location: map['location'] as String?,
    department: map['department'] as String?,
    occupation: map['occupation'] as String?,
    category: map['category'] as String?,
    shiftCycleId: map['shift_cycle_id'] as String?,
    workArea: map['work_area'] as String?,
    deptCode: map['dept_code'] as String?,
    payrollId: map['payroll_id'] as String?,
    phone: map['phone'] as String?,
    signatureData: map['signature_data'] as String?,
    createdAt: map['created_at'] as String?,
    updatedAt: map['updated_at'] as String?,
  );

  UserProfile copyWith(Map<String, dynamic> patch) {
    return UserProfile.fromMap({
      'id': id,
      'full_name': fullName,
      'first_name': firstName,
      'title': title,
      'email': email,
      'job_title': jobTitle,
      'cost_centre': costCentre,
      'user_account_type': userAccountType,
      'theme_mode': themeMode,
      'custom_theme_color': customThemeColor,
      'is_admin': isAdmin,
      'is_super_admin': isSuperAdmin,
      'disabled': disabled,
      'company_number': companyNumber,
      'sa_id_number': saIdNumber,
      'section_shaft': sectionShaft,
      'employee_number': employeeNumber,
      'company': company,
      'location': location,
      'department': department,
      'occupation': occupation,
      'category': category,
      'shift_cycle_id': shiftCycleId,
      'work_area': workArea,
      'dept_code': deptCode,
      'payroll_id': payrollId,
      'phone': phone,
      'signature_data': signatureData,
      'created_at': createdAt,
      'updated_at': updatedAt,
      ...patch,
    });
  }
}
