// Dart mirrors of src/types/FormData.ts. Field names match the TS interfaces
// exactly so the JSON payloads written to form_submissions.payload match.

class WorkplaceSet {
  String stopes;
  String developmentEnds;
  String declines;
  String loadAndHaul;
  String travellingWay;
  String refugeBay;
  String store;
  String waitingPlace;
  String conveyorBelts;
  String otherWorkplaces;

  WorkplaceSet({
    this.stopes = '',
    this.developmentEnds = '',
    this.declines = '',
    this.loadAndHaul = '',
    this.travellingWay = '',
    this.refugeBay = '',
    this.store = '',
    this.waitingPlace = '',
    this.conveyorBelts = '',
    this.otherWorkplaces = '',
  });

  Map<String, dynamic> toMap() => {
        'stopes': stopes,
        'developmentEnds': developmentEnds,
        'declines': declines,
        'loadAndHaul': loadAndHaul,
        'travellingWay': travellingWay,
        'refugeBay': refugeBay,
        'store': store,
        'waitingPlace': waitingPlace,
        'conveyorBelts': conveyorBelts,
        'otherWorkplaces': otherWorkplaces,
      };
}

class ShiftBossSignatures {
  String shiftBossSignature;
  String shiftBossDate;
  String mineOverseerSignature;
  String mineOverseerDate;
  String mineManagerSignature;
  String mineManagerDate;

  ShiftBossSignatures({
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineOverseerSignature = '',
    this.mineOverseerDate = '',
    this.mineManagerSignature = '',
    this.mineManagerDate = '',
  });

  Map<String, dynamic> toMap() => {
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineOverseerSignature': mineOverseerSignature,
        'mineOverseerDate': mineOverseerDate,
        'mineManagerSignature': mineManagerSignature,
        'mineManagerDate': mineManagerDate,
      };
}

class ShiftBossFormData {
  String title;
  String name;
  String identityNumber;
  String companyNumber;
  String shaft;
  WorkplaceSet workplaces;
  String effectiveDate;
  String nextRevisionDate;
  ShiftBossSignatures signatures;

  ShiftBossFormData({
    this.title = '',
    this.name = '',
    this.identityNumber = '',
    this.companyNumber = '',
    this.shaft = '',
    WorkplaceSet? workplaces,
    this.effectiveDate = '16/08/2023',
    this.nextRevisionDate = '16/08/2026',
    ShiftBossSignatures? signatures,
  })  : workplaces = workplaces ?? WorkplaceSet(),
        signatures = signatures ?? ShiftBossSignatures();

  Map<String, dynamic> toMap() => {
        'title': title,
        'name': name,
        'identityNumber': identityNumber,
        'companyNumber': companyNumber,
        'shaft': shaft,
        'workplaces': workplaces.toMap(),
        'effectiveDate': effectiveDate,
        'nextRevisionDate': nextRevisionDate,
        'signatures': signatures.toMap(),
      };
}

class MinerAppointmentSignatures {
  String minerSignature;
  String minerDate;
  String shiftBossSignature;
  String shiftBossDate;
  String mineOverseerSignature;
  String mineOverseerDate;
  String mineManagerSignature;
  String mineManagerDate;

  MinerAppointmentSignatures({
    this.minerSignature = '',
    this.minerDate = '',
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineOverseerSignature = '',
    this.mineOverseerDate = '',
    this.mineManagerSignature = '',
    this.mineManagerDate = '',
  });

  Map<String, dynamic> toMap() => {
        'minerSignature': minerSignature,
        'minerDate': minerDate,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineOverseerSignature': mineOverseerSignature,
        'mineOverseerDate': mineOverseerDate,
        'mineManagerSignature': mineManagerSignature,
        'mineManagerDate': mineManagerDate,
      };
}

class MinerAppointmentFormData {
  String title;
  String name;
  String identityNumber;
  String companyNumber;
  String sectionShaft;
  WorkplaceSet workplaces;
  MinerAppointmentSignatures signatures;

  MinerAppointmentFormData({
    this.title = '',
    this.name = '',
    this.identityNumber = '',
    this.companyNumber = '',
    this.sectionShaft = '',
    WorkplaceSet? workplaces,
    MinerAppointmentSignatures? signatures,
  })  : workplaces = workplaces ?? WorkplaceSet(),
        signatures = signatures ?? MinerAppointmentSignatures();

  Map<String, dynamic> toMap() => {
        'title': title,
        'name': name,
        'identityNumber': identityNumber,
        'companyNumber': companyNumber,
        'sectionShaft': sectionShaft,
        'workplaces': workplaces.toMap(),
        'signatures': signatures.toMap(),
      };
}

class RelievingMinerSignatures {
  String relievingMinerSignature;
  String relievingMinerDate;
  String shiftBossSignature;
  String shiftBossDate;
  String mineOverseerSignature;
  String mineOverseerDate;
  String mineManagerSignature;
  String mineManagerDate;

  RelievingMinerSignatures({
    this.relievingMinerSignature = '',
    this.relievingMinerDate = '',
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineOverseerSignature = '',
    this.mineOverseerDate = '',
    this.mineManagerSignature = '',
    this.mineManagerDate = '',
  });

  Map<String, dynamic> toMap() => {
        'relievingMinerSignature': relievingMinerSignature,
        'relievingMinerDate': relievingMinerDate,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineOverseerSignature': mineOverseerSignature,
        'mineOverseerDate': mineOverseerDate,
        'mineManagerSignature': mineManagerSignature,
        'mineManagerDate': mineManagerDate,
      };
}

class RelievingMinerFormData {
  String title;
  String name;
  String identityNumber;
  String companyNumber;
  String sectionShaft;
  WorkplaceSet workplaces;
  RelievingMinerSignatures signatures;

  RelievingMinerFormData({
    this.title = '',
    this.name = '',
    this.identityNumber = '',
    this.companyNumber = '',
    this.sectionShaft = '',
    WorkplaceSet? workplaces,
    RelievingMinerSignatures? signatures,
  })  : workplaces = workplaces ?? WorkplaceSet(),
        signatures = signatures ?? RelievingMinerSignatures();

  Map<String, dynamic> toMap() => {
        'title': title,
        'name': name,
        'identityNumber': identityNumber,
        'companyNumber': companyNumber,
        'sectionShaft': sectionShaft,
        'workplaces': workplaces.toMap(),
        'signatures': signatures.toMap(),
      };
}

class SafetyHealthRepSignatures {
  String managerSignature;
  String managerDate;
  String managerWitness;
  String acceptedSignature;
  String acceptedDate;
  String acceptedWitness;

  SafetyHealthRepSignatures({
    this.managerSignature = '',
    this.managerDate = '',
    this.managerWitness = '',
    this.acceptedSignature = '',
    this.acceptedDate = '',
    this.acceptedWitness = '',
  });

  Map<String, dynamic> toMap() => {
        'managerSignature': managerSignature,
        'managerDate': managerDate,
        'managerWitness': managerWitness,
        'acceptedSignature': acceptedSignature,
        'acceptedDate': acceptedDate,
        'acceptedWitness': acceptedWitness,
      };
}

class SafetyHealthRepSection {
  String name;
  String companyNumber;
  String shaft;
  String section;
  SafetyHealthRepSignatures signatures;

  SafetyHealthRepSection({
    this.name = '',
    this.companyNumber = '',
    this.shaft = '',
    this.section = '',
    SafetyHealthRepSignatures? signatures,
  }) : signatures = signatures ?? SafetyHealthRepSignatures();

  Map<String, dynamic> toMap() => {
        'name': name,
        'companyNumber': companyNumber,
        'shaft': shaft,
        'section': section,
        'signatures': signatures.toMap(),
      };
}

class SafetyHealthRepFormData {
  SafetyHealthRepSection primary;
  SafetyHealthRepSection alternative;

  SafetyHealthRepFormData({
    SafetyHealthRepSection? primary,
    SafetyHealthRepSection? alternative,
  })  : primary = primary ?? SafetyHealthRepSection(),
        alternative = alternative ?? SafetyHealthRepSection();

  Map<String, dynamic> toMap() => {
        'primary': primary.toMap(),
        'alternative': alternative.toMap(),
      };
}

class MachineryOperatorEntry {
  String companyNumber;
  String location;
  String typeOfEquipment;
  String licenceExpiryDate;
  String appointedForMonth;
  String signature;

  MachineryOperatorEntry({
    this.companyNumber = '',
    this.location = '',
    this.typeOfEquipment = '',
    this.licenceExpiryDate = '',
    this.appointedForMonth = '',
    this.signature = '',
  });

  Map<String, dynamic> toMap() => {
        'companyNumber': companyNumber,
        'location': location,
        'typeOfEquipment': typeOfEquipment,
        'licenceExpiryDate': licenceExpiryDate,
        'appointedForMonth': appointedForMonth,
        'signature': signature,
      };
}

class MachineryOperatorsFormData {
  List<MachineryOperatorEntry> operators;

  MachineryOperatorsFormData({List<MachineryOperatorEntry>? operators})
      : operators = operators ?? [MachineryOperatorEntry()];

  Map<String, dynamic> toMap() => {
        'operators': operators.map((o) => o.toMap()).toList(),
      };
}

class GassingIncidentFormData {
  String date;
  String coyNoOfInjured;
  String time;
  String workingPlace;
  String severity;
  String description;
  String injuries;
  String shiftBossSignature;
  String mineOverseerSignature;

  GassingIncidentFormData({
    this.date = '',
    this.coyNoOfInjured = '',
    this.time = '',
    this.workingPlace = '',
    this.severity = '',
    this.description = '',
    this.injuries = '',
    this.shiftBossSignature = '',
    this.mineOverseerSignature = '',
  });

  Map<String, dynamic> toMap() => {
        'date': date,
        'coyNoOfInjured': coyNoOfInjured,
        'time': time,
        'workingPlace': workingPlace,
        'severity': severity,
        'description': description,
        'injuries': injuries,
        'shiftBossSignature': shiftBossSignature,
        'mineOverseerSignature': mineOverseerSignature,
      };
}

class WeeklySherqTopics {
  bool standards;
  bool incident;
  bool emergencyPreparedness;
  bool soReport;
  bool instruction;
  bool rockMechanicReport;
  bool ppe;
  bool sheRepReport;
  bool procedures;
  bool ventReport;

  WeeklySherqTopics({
    this.standards = false,
    this.incident = false,
    this.emergencyPreparedness = false,
    this.soReport = false,
    this.instruction = false,
    this.rockMechanicReport = false,
    this.ppe = false,
    this.sheRepReport = false,
    this.procedures = false,
    this.ventReport = false,
  });

  Map<String, dynamic> toMap() => {
        'standards': standards,
        'incident': incident,
        'emergencyPreparedness': emergencyPreparedness,
        'soReport': soReport,
        'instruction': instruction,
        'rockMechanicReport': rockMechanicReport,
        'ppe': ppe,
        'sheRepReport': sheRepReport,
        'procedures': procedures,
        'ventReport': ventReport,
      };
}

class AttendanceEntry {
  String coyNo;
  String signature;

  AttendanceEntry({this.coyNo = '', this.signature = ''});

  Map<String, dynamic> toMap() => {
        'coyNo': coyNo,
        'signature': signature,
      };
}

class WeeklySherqMeetingFormData {
  String date;
  String time;
  String workplace;
  String duration;
  String supervisorCoyNo;
  String sheRepCoyNo;
  WeeklySherqTopics topics;
  String mattersDiscussed;
  String feedbackFromCrew;
  List<AttendanceEntry> attendance;
  String supervisorSignature;
  String sheRepSignature;
  String shiftBossSignature;
  String mineOverseerSignature;

  WeeklySherqMeetingFormData({
    this.date = '',
    this.time = '',
    this.workplace = '',
    this.duration = '',
    this.supervisorCoyNo = '',
    this.sheRepCoyNo = '',
    WeeklySherqTopics? topics,
    this.mattersDiscussed = '',
    this.feedbackFromCrew = '',
    List<AttendanceEntry>? attendance,
    this.supervisorSignature = '',
    this.sheRepSignature = '',
    this.shiftBossSignature = '',
    this.mineOverseerSignature = '',
  })  : topics = topics ?? WeeklySherqTopics(),
        attendance = attendance ?? <AttendanceEntry>[];

  Map<String, dynamic> toMap() => {
        'date': date,
        'time': time,
        'workplace': workplace,
        'duration': duration,
        'supervisorCoyNo': supervisorCoyNo,
        'sheRepCoyNo': sheRepCoyNo,
        'topics': topics.toMap(),
        'mattersDiscussed': mattersDiscussed,
        'feedbackFromCrew': feedbackFromCrew,
        'attendance': attendance.map((e) => e.toMap()).toList(),
        'supervisorSignature': supervisorSignature,
        'sheRepSignature': sheRepSignature,
        'shiftBossSignature': shiftBossSignature,
        'mineOverseerSignature': mineOverseerSignature,
      };
}

class EarlyShiftRecordFormData {
  String section;
  String strike;
  String date;
  String wentUndergroundAt;
  String arrivedAtWaitingPlace;
  String minerArrivedAt;
  String minerCoyNo;
  String waitingPlaceLocation;
  String barricadeErected;
  String barricadeDetails;
  String minerFollowedProcedure;
  String minerFollowedDetails;
  String permissionToCompA;
  String minerPossessionGDI;
  String gdiNo;
  String blastingCableDisconnected;
  String earlyEntryExamination;
  String earlyEntryDetails;
  String safeDeclarationBooklet;
  String safeDeclarationDetails;
  String flammableGasesTest;
  String flammableGasesDetails;
  String entryEquipmentAvailable;
  String entryEquipmentDetails;
  String hygrometerAndAnemo;
  String hygrometerDetails;
  String waterDownProperly;
  String drinkingWaterAvailable;
  String drinkingWaterDetails;
  String specialInstruction;
  String additionalRemarks;
  String shiftBossSignature;
  String shiftBossSignatureDate;
  String minerOverseerSignature;
  String minerOverseerSignatureDate;

  EarlyShiftRecordFormData({
    this.section = '',
    this.strike = '',
    this.date = '',
    this.wentUndergroundAt = '',
    this.arrivedAtWaitingPlace = '',
    this.minerArrivedAt = '',
    this.minerCoyNo = '',
    this.waitingPlaceLocation = '',
    this.barricadeErected = '',
    this.barricadeDetails = '',
    this.minerFollowedProcedure = '',
    this.minerFollowedDetails = '',
    this.permissionToCompA = '',
    this.minerPossessionGDI = '',
    this.gdiNo = '',
    this.blastingCableDisconnected = '',
    this.earlyEntryExamination = '',
    this.earlyEntryDetails = '',
    this.safeDeclarationBooklet = '',
    this.safeDeclarationDetails = '',
    this.flammableGasesTest = '',
    this.flammableGasesDetails = '',
    this.entryEquipmentAvailable = '',
    this.entryEquipmentDetails = '',
    this.hygrometerAndAnemo = '',
    this.hygrometerDetails = '',
    this.waterDownProperly = '',
    this.drinkingWaterAvailable = '',
    this.drinkingWaterDetails = '',
    this.specialInstruction = '',
    this.additionalRemarks = '',
    this.shiftBossSignature = '',
    this.shiftBossSignatureDate = '',
    this.minerOverseerSignature = '',
    this.minerOverseerSignatureDate = '',
  });

  Map<String, dynamic> toMap() => {
        'section': section,
        'strike': strike,
        'date': date,
        'wentUndergroundAt': wentUndergroundAt,
        'arrivedAtWaitingPlace': arrivedAtWaitingPlace,
        'minerArrivedAt': minerArrivedAt,
        'minerCoyNo': minerCoyNo,
        'waitingPlaceLocation': waitingPlaceLocation,
        'barricadeErected': barricadeErected,
        'barricadeDetails': barricadeDetails,
        'minerFollowedProcedure': minerFollowedProcedure,
        'minerFollowedDetails': minerFollowedDetails,
        'permissionToCompA': permissionToCompA,
        'minerPossessionGDI': minerPossessionGDI,
        'gdiNo': gdiNo,
        'blastingCableDisconnected': blastingCableDisconnected,
        'earlyEntryExamination': earlyEntryExamination,
        'earlyEntryDetails': earlyEntryDetails,
        'safeDeclarationBooklet': safeDeclarationBooklet,
        'safeDeclarationDetails': safeDeclarationDetails,
        'flammableGasesTest': flammableGasesTest,
        'flammableGasesDetails': flammableGasesDetails,
        'entryEquipmentAvailable': entryEquipmentAvailable,
        'entryEquipmentDetails': entryEquipmentDetails,
        'hygrometerAndAnemo': hygrometerAndAnemo,
        'hygrometerDetails': hygrometerDetails,
        'waterDownProperly': waterDownProperly,
        'drinkingWaterAvailable': drinkingWaterAvailable,
        'drinkingWaterDetails': drinkingWaterDetails,
        'specialInstruction': specialInstruction,
        'additionalRemarks': additionalRemarks,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossSignatureDate': shiftBossSignatureDate,
        'minerOverseerSignature': minerOverseerSignature,
        'minerOverseerSignatureDate': minerOverseerSignatureDate,
      };
}

class LateShiftRecordFormData {
  String section;
  String strike;
  String date;
  String minerInChargeCoyNo;
  String chargesCorrectlyPrepared;
  String chargesDetails;
  String chargingUpDevEndNo;
  String ventHolingNo;
  String explosiveCorrectlyTransported;
  String testedForFlammableGas;
  String gdiNo;
  String chargingUnderDirectSupervision;
  String typeOfExplosivesUsed;
  String typeOfFuseUsed;
  String fuseLength;
  String amountOfFusesUsed;
  String holesDislodgedCorrectly;
  String holesDislodgedDetails;
  String lengthOfDrillHoles;
  String lengthOfBlowPipe;
  String blastingCableToStandard;
  String blastingCableDetails;
  String circuitTested;
  String blastingCableConnectedToTerminalBox;
  String blastingCableTerminalDetails;
  String distributionOfOldExplosivesObserved;
  String distributionOfOldExplosivesDiscussed;
  String workingPlaceBarricadeInPosition;
  String explosiveBoxesLocked;
  String barricadeExplosiveDetails;
  String idCardsCorrectlyIssued;
  String airAndWaterHosesClosed;
  String anyIncidentInjuriesReported;
  String arrivedOnSurfaceAt;
  String specialInstructionsGiven;
  String additionalRemarks;
  String shiftBossSignature;
  String shiftBossSignatureDate;
  String minerOverseerSignature;
  String minerOverseerSignatureDate;

  LateShiftRecordFormData({
    this.section = '',
    this.strike = '',
    this.date = '',
    this.minerInChargeCoyNo = '',
    this.chargesCorrectlyPrepared = '',
    this.chargesDetails = '',
    this.chargingUpDevEndNo = '',
    this.ventHolingNo = '',
    this.explosiveCorrectlyTransported = '',
    this.testedForFlammableGas = '',
    this.gdiNo = '',
    this.chargingUnderDirectSupervision = '',
    this.typeOfExplosivesUsed = '',
    this.typeOfFuseUsed = '',
    this.fuseLength = '',
    this.amountOfFusesUsed = '',
    this.holesDislodgedCorrectly = '',
    this.holesDislodgedDetails = '',
    this.lengthOfDrillHoles = '',
    this.lengthOfBlowPipe = '',
    this.blastingCableToStandard = '',
    this.blastingCableDetails = '',
    this.circuitTested = '',
    this.blastingCableConnectedToTerminalBox = '',
    this.blastingCableTerminalDetails = '',
    this.distributionOfOldExplosivesObserved = '',
    this.distributionOfOldExplosivesDiscussed = '',
    this.workingPlaceBarricadeInPosition = '',
    this.explosiveBoxesLocked = '',
    this.barricadeExplosiveDetails = '',
    this.idCardsCorrectlyIssued = '',
    this.airAndWaterHosesClosed = '',
    this.anyIncidentInjuriesReported = '',
    this.arrivedOnSurfaceAt = '',
    this.specialInstructionsGiven = '',
    this.additionalRemarks = '',
    this.shiftBossSignature = '',
    this.shiftBossSignatureDate = '',
    this.minerOverseerSignature = '',
    this.minerOverseerSignatureDate = '',
  });

  Map<String, dynamic> toMap() => {
        'section': section,
        'strike': strike,
        'date': date,
        'minerInChargeCoyNo': minerInChargeCoyNo,
        'chargesCorrectlyPrepared': chargesCorrectlyPrepared,
        'chargesDetails': chargesDetails,
        'chargingUpDevEndNo': chargingUpDevEndNo,
        'ventHolingNo': ventHolingNo,
        'explosiveCorrectlyTransported': explosiveCorrectlyTransported,
        'testedForFlammableGas': testedForFlammableGas,
        'gdiNo': gdiNo,
        'chargingUnderDirectSupervision': chargingUnderDirectSupervision,
        'typeOfExplosivesUsed': typeOfExplosivesUsed,
        'typeOfFuseUsed': typeOfFuseUsed,
        'fuseLength': fuseLength,
        'amountOfFusesUsed': amountOfFusesUsed,
        'holesDislodgedCorrectly': holesDislodgedCorrectly,
        'holesDislodgedDetails': holesDislodgedDetails,
        'lengthOfDrillHoles': lengthOfDrillHoles,
        'lengthOfBlowPipe': lengthOfBlowPipe,
        'blastingCableToStandard': blastingCableToStandard,
        'blastingCableDetails': blastingCableDetails,
        'circuitTested': circuitTested,
        'blastingCableConnectedToTerminalBox':
            blastingCableConnectedToTerminalBox,
        'blastingCableTerminalDetails': blastingCableTerminalDetails,
        'distributionOfOldExplosivesObserved':
            distributionOfOldExplosivesObserved,
        'distributionOfOldExplosivesDiscussed':
            distributionOfOldExplosivesDiscussed,
        'workingPlaceBarricadeInPosition': workingPlaceBarricadeInPosition,
        'explosiveBoxesLocked': explosiveBoxesLocked,
        'barricadeExplosiveDetails': barricadeExplosiveDetails,
        'idCardsCorrectlyIssued': idCardsCorrectlyIssued,
        'airAndWaterHosesClosed': airAndWaterHosesClosed,
        'anyIncidentInjuriesReported': anyIncidentInjuriesReported,
        'arrivedOnSurfaceAt': arrivedOnSurfaceAt,
        'specialInstructionsGiven': specialInstructionsGiven,
        'additionalRemarks': additionalRemarks,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossSignatureDate': shiftBossSignatureDate,
        'minerOverseerSignature': minerOverseerSignature,
        'minerOverseerSignatureDate': minerOverseerSignatureDate,
      };
}

// Field names with `_remedial` suffix mirror the TS interface exactly so the
// JSON payload round-trips with the web app. Suppress the lowerCamelCase lint.
// ignore_for_file: non_constant_identifier_names
class TracklessMachineryEntry {
  String dateOfInspection;
  String operatorCoyNumber;
  String machineNumber;
  String operatorTrained;
  String operatorTrained_remedial;
  String operatorLicence;
  String operatorLicence_remedial;
  String preUseChecklistAvailable;
  String preUseChecklistAvailable_remedial;
  String preUseChecklistCompleted;
  String preUseChecklistCompleted_remedial;
  String correctPPE;
  String correctPPE_remedial;
  String safetyBelt;
  String safetyBelt_remedial;

  TracklessMachineryEntry({
    this.dateOfInspection = '',
    this.operatorCoyNumber = '',
    this.machineNumber = '',
    this.operatorTrained = '',
    this.operatorTrained_remedial = '',
    this.operatorLicence = '',
    this.operatorLicence_remedial = '',
    this.preUseChecklistAvailable = '',
    this.preUseChecklistAvailable_remedial = '',
    this.preUseChecklistCompleted = '',
    this.preUseChecklistCompleted_remedial = '',
    this.correctPPE = '',
    this.correctPPE_remedial = '',
    this.safetyBelt = '',
    this.safetyBelt_remedial = '',
  });

  Map<String, dynamic> toMap() => {
        'dateOfInspection': dateOfInspection,
        'operatorCoyNumber': operatorCoyNumber,
        'machineNumber': machineNumber,
        'operatorTrained': operatorTrained,
        'operatorTrained_remedial': operatorTrained_remedial,
        'operatorLicence': operatorLicence,
        'operatorLicence_remedial': operatorLicence_remedial,
        'preUseChecklistAvailable': preUseChecklistAvailable,
        'preUseChecklistAvailable_remedial': preUseChecklistAvailable_remedial,
        'preUseChecklistCompleted': preUseChecklistCompleted,
        'preUseChecklistCompleted_remedial': preUseChecklistCompleted_remedial,
        'correctPPE': correctPPE,
        'correctPPE_remedial': correctPPE_remedial,
        'safetyBelt': safetyBelt,
        'safetyBelt_remedial': safetyBelt_remedial,
      };
}

class TracklessMachineryFormData {
  List<TracklessMachineryEntry> inspections;
  String shiftbossSignature;
  String shiftbossSignatureDate;
  String mineOverseerSignature;
  String mineOverseerSignatureDate;

  TracklessMachineryFormData({
    List<TracklessMachineryEntry>? inspections,
    this.shiftbossSignature = '',
    this.shiftbossSignatureDate = '',
    this.mineOverseerSignature = '',
    this.mineOverseerSignatureDate = '',
  }) : inspections =
            inspections ?? List.generate(4, (_) => TracklessMachineryEntry());

  Map<String, dynamic> toMap() => {
        'inspections': inspections.map((i) => i.toMap()).toList(),
        'shiftbossSignature': shiftbossSignature,
        'shiftbossSignatureDate': shiftbossSignatureDate,
        'mineOverseerSignature': mineOverseerSignature,
        'mineOverseerSignatureDate': mineOverseerSignatureDate,
      };
}

class InspectionControlSheetRow {
  String workplace;
  List<String> days;

  InspectionControlSheetRow({this.workplace = '', List<String>? days})
      : days = days ?? List.filled(31, '');

  Map<String, dynamic> toMap() => {
        'workplace': workplace,
        'days': days,
      };
}

class InspectionControlSheetFormData {
  String monthFrom;
  String monthTo;
  List<InspectionControlSheetRow> rows;

  InspectionControlSheetFormData({
    this.monthFrom = '',
    this.monthTo = '',
    List<InspectionControlSheetRow>? rows,
  }) : rows = rows ?? List.generate(15, (_) => InspectionControlSheetRow());

  Map<String, dynamic> toMap() => {
        'monthFrom': monthFrom,
        'monthTo': monthTo,
        'rows': rows.map((r) => r.toMap()).toList(),
      };
}

class PlannedTaskObservationRow {
  String task;
  String annual;
  String semester;
  String quarterly;
  String monthly;
  String biWeekly;
  String weekly;
  String daily;

  PlannedTaskObservationRow({
    this.task = '',
    this.annual = '',
    this.semester = '',
    this.quarterly = '',
    this.monthly = '',
    this.biWeekly = '',
    this.weekly = '',
    this.daily = '',
  });

  Map<String, dynamic> toMap() => {
        'task': task,
        'annual': annual,
        'semester': semester,
        'quarterly': quarterly,
        'monthly': monthly,
        'biWeekly': biWeekly,
        'weekly': weekly,
        'daily': daily,
      };
}

/// Mirrors PREDEFINED_TASKS from src/components/PlannedTaskObservationForm.tsx
/// lines 8-21 — the 12 task labels the form pre-populates as the first 12 rows.
const List<String> _kPlannedTaskPredefinedTasks = [
  'Entry Examination and Making Safe',
  'Barring',
  'Support Marking',
  'Support Drilling and Installation',
  'Face preparation',
  'Face Drilling',
  'Explosives',
  'Loading and Hauling',
  'Road construction and maintenance',
  'Install and remove ventilation-columns service columns and accessories',
  'Priming and charging of face',
  'Charging with Emulsion',
];

class PlannedTaskObservationFormData {
  List<PlannedTaskObservationRow> rows;

  PlannedTaskObservationFormData({List<PlannedTaskObservationRow>? rows})
      : rows = rows ??
            [
              for (final t in _kPlannedTaskPredefinedTasks)
                PlannedTaskObservationRow(task: t),
              PlannedTaskObservationRow(),
              PlannedTaskObservationRow(),
              PlannedTaskObservationRow(),
            ];

  Map<String, dynamic> toMap() => {
        'rows': rows.map((r) => r.toMap()).toList(),
      };
}

class RefugeBayItem {
  String consequenceClassification;
  bool yes;
  bool no;
  String remarks;
  String extraField;

  RefugeBayItem({
    this.consequenceClassification = '',
    this.yes = false,
    this.no = false,
    this.remarks = '',
    this.extraField = '',
  });

  Map<String, dynamic> toMap() => {
        'consequenceClassification': consequenceClassification,
        'yes': yes,
        'no': no,
        'remarks': remarks,
        'extraField': extraField,
      };
}

class RefugeBayInstruction {
  String instruction;
  String completionDate;

  RefugeBayInstruction({this.instruction = '', this.completionDate = ''});

  Map<String, dynamic> toMap() => {
        'instruction': instruction,
        'completionDate': completionDate,
      };
}

class RefugeBayInspectionFormData {
  String shaft;
  String date;
  String observer;
  String refugeBayNo;
  String mineOverseer;
  String section;
  List<RefugeBayItem> items;
  String isLifeSustainable;
  List<RefugeBayInstruction> instructions;
  String observerDate;
  String mineOverseerDate;

  RefugeBayInspectionFormData({
    this.shaft = '',
    this.date = '',
    this.observer = '',
    this.refugeBayNo = '',
    this.mineOverseer = '',
    this.section = '',
    List<RefugeBayItem>? items,
    this.isLifeSustainable = '',
    List<RefugeBayInstruction>? instructions,
    this.observerDate = '',
    this.mineOverseerDate = '',
  })  : items = items ?? List.generate(28, (_) => RefugeBayItem()),
        instructions =
            instructions ?? List.generate(3, (_) => RefugeBayInstruction());

  Map<String, dynamic> toMap() => {
        'shaft': shaft,
        'date': date,
        'observer': observer,
        'refugeBayNo': refugeBayNo,
        'mineOverseer': mineOverseer,
        'section': section,
        'items': items.map((i) => i.toMap()).toList(),
        'isLifeSustainable': isLifeSustainable,
        'instructions': instructions.map((i) => i.toMap()).toList(),
        'observerDate': observerDate,
        'mineOverseerDate': mineOverseerDate,
      };
}

class FireFightingEquipmentEntry {
  String workingPlace;
  String localityVehicleNo;
  String inspectionDate;
  String conditionOfSeal;
  String pressureGauge;
  String conditionOfHandleNozzle;
  String conditionOfHose;
  String deficiency;
  String dateOfLastAnnualService;

  FireFightingEquipmentEntry({
    this.workingPlace = '',
    this.localityVehicleNo = '',
    this.inspectionDate = '',
    this.conditionOfSeal = '',
    this.pressureGauge = '',
    this.conditionOfHandleNozzle = '',
    this.conditionOfHose = '',
    this.deficiency = '',
    this.dateOfLastAnnualService = '',
  });

  Map<String, dynamic> toMap() => {
        'workingPlace': workingPlace,
        'localityVehicleNo': localityVehicleNo,
        'inspectionDate': inspectionDate,
        'conditionOfSeal': conditionOfSeal,
        'pressureGauge': pressureGauge,
        'conditionOfHandleNozzle': conditionOfHandleNozzle,
        'conditionOfHose': conditionOfHose,
        'deficiency': deficiency,
        'dateOfLastAnnualService': dateOfLastAnnualService,
      };
}

class MonthlyFireFightingInspectionFormData {
  String department;
  String area;
  String name;
  String designation;
  List<FireFightingEquipmentEntry> entries;
  String inspectorSignature;
  String inspectorName;
  String inspectorDate;
  String sectionHeadSignature;
  String sectionHeadName;
  String sectionHeadDate;

  MonthlyFireFightingInspectionFormData({
    this.department = '',
    this.area = '',
    this.name = '',
    this.designation = '',
    List<FireFightingEquipmentEntry>? entries,
    this.inspectorSignature = '',
    this.inspectorName = '',
    this.inspectorDate = '',
    this.sectionHeadSignature = '',
    this.sectionHeadName = '',
    this.sectionHeadDate = '',
  }) : entries =
            entries ?? List.generate(12, (_) => FireFightingEquipmentEntry());

  Map<String, dynamic> toMap() => {
        'department': department,
        'area': area,
        'name': name,
        'designation': designation,
        'entries': entries.map((e) => e.toMap()).toList(),
        'inspectorSignature': inspectorSignature,
        'inspectorName': inspectorName,
        'inspectorDate': inspectorDate,
        'sectionHeadSignature': sectionHeadSignature,
        'sectionHeadName': sectionHeadName,
        'sectionHeadDate': sectionHeadDate,
      };
}

class EmergencyDrillEmployee {
  String col1;
  String col2;
  String col3;

  EmergencyDrillEmployee({this.col1 = '', this.col2 = '', this.col3 = ''});

  Map<String, dynamic> toMap() => {
        'col1': col1,
        'col2': col2,
        'col3': col3,
      };
}

/// Used by both `verbal_emergency_drills` and `physical_emergency_drills` —
/// the web app keeps two interfaces with identical fields but a single shape.
class EmergencyDrillFormData {
  String date;
  String refugeBayNo;
  String workingPlace;
  String emergencyDrillPerformed;
  String deficienciesObserved;
  String recommendedImprovements;
  String refugeBaySituatedAt;
  List<EmergencyDrillEmployee> employees;

  EmergencyDrillFormData({
    this.date = '',
    this.refugeBayNo = '',
    this.workingPlace = '',
    this.emergencyDrillPerformed = '',
    this.deficienciesObserved = '',
    this.recommendedImprovements = '',
    this.refugeBaySituatedAt = '',
    List<EmergencyDrillEmployee>? employees,
  }) : employees =
            employees ?? List.generate(15, (_) => EmergencyDrillEmployee());

  Map<String, dynamic> toMap() => {
        'date': date,
        'refugeBayNo': refugeBayNo,
        'workingPlace': workingPlace,
        'emergencyDrillPerformed': emergencyDrillPerformed,
        'deficienciesObserved': deficienciesObserved,
        'recommendedImprovements': recommendedImprovements,
        'refugeBaySituatedAt': refugeBaySituatedAt,
        'employees': employees.map((e) => e.toMap()).toList(),
      };
}

class EmergencyDrillExerciseFormData {
  String shiftBoss;
  String workingPlace;
  String dateOfExercise;
  String typeOfEmergency;
  String alarmMadeAt;
  String allPersonsEvacuatedBy;
  String routesTaken;
  String procedureA;
  String procedureB;
  String procedureC;
  String procedureD;
  String procedureE;
  String procedureF;
  String rescuingInjuredWorkers;
  String extinguishingFire;
  String majorFireOrExplosion;
  String generalRemarks;
  String shiftBossSignature;
  String shiftBossSignatureDate;

  EmergencyDrillExerciseFormData({
    this.shiftBoss = '',
    this.workingPlace = '',
    this.dateOfExercise = '',
    this.typeOfEmergency = '',
    this.alarmMadeAt = '',
    this.allPersonsEvacuatedBy = '',
    this.routesTaken = '',
    this.procedureA = '',
    this.procedureB = '',
    this.procedureC = '',
    this.procedureD = '',
    this.procedureE = '',
    this.procedureF = '',
    this.rescuingInjuredWorkers = '',
    this.extinguishingFire = '',
    this.majorFireOrExplosion = '',
    this.generalRemarks = '',
    this.shiftBossSignature = '',
    this.shiftBossSignatureDate = '',
  });

  Map<String, dynamic> toMap() => {
        'shiftBoss': shiftBoss,
        'workingPlace': workingPlace,
        'dateOfExercise': dateOfExercise,
        'typeOfEmergency': typeOfEmergency,
        'alarmMadeAt': alarmMadeAt,
        'allPersonsEvacuatedBy': allPersonsEvacuatedBy,
        'routesTaken': routesTaken,
        'procedureA': procedureA,
        'procedureB': procedureB,
        'procedureC': procedureC,
        'procedureD': procedureD,
        'procedureE': procedureE,
        'procedureF': procedureF,
        'rescuingInjuredWorkers': rescuingInjuredWorkers,
        'extinguishingFire': extinguishingFire,
        'majorFireOrExplosion': majorFireOrExplosion,
        'generalRemarks': generalRemarks,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossSignatureDate': shiftBossSignatureDate,
      };
}

class SpecialBriefEntry {
  String title;
  String communicatedTo;

  SpecialBriefEntry({this.title = '', this.communicatedTo = ''});

  Map<String, dynamic> toMap() => {
        'title': title,
        'communicatedTo': communicatedTo,
      };
}

class SpecialBriefInstructionRegisterFormData {
  List<SpecialBriefEntry> entries;

  SpecialBriefInstructionRegisterFormData({List<SpecialBriefEntry>? entries})
      : entries = entries ?? <SpecialBriefEntry>[];

  Map<String, dynamic> toMap() => {
        'entries': entries.map((e) => e.toMap()).toList(),
      };
}

class SpecialInstructionSection {
  String date;
  String time;
  String instructionTo;
  String detailOfInstruction;
  String remedialAction;
  String issuerSignature;
  String issuerSignatureDate;
  String receiverSignature;
  String receiverSignatureDate;

  SpecialInstructionSection({
    this.date = '',
    this.time = '',
    this.instructionTo = '',
    this.detailOfInstruction = '',
    this.remedialAction = '',
    this.issuerSignature = '',
    this.issuerSignatureDate = '',
    this.receiverSignature = '',
    this.receiverSignatureDate = '',
  });

  Map<String, dynamic> toMap() => {
        'date': date,
        'time': time,
        'instructionTo': instructionTo,
        'detailOfInstruction': detailOfInstruction,
        'remedialAction': remedialAction,
        'issuerSignature': issuerSignature,
        'issuerSignatureDate': issuerSignatureDate,
        'receiverSignature': receiverSignature,
        'receiverSignatureDate': receiverSignatureDate,
      };
}

class SpecialInstructionFormData {
  SpecialInstructionSection section1;
  SpecialInstructionSection section2;

  SpecialInstructionFormData({
    SpecialInstructionSection? section1,
    SpecialInstructionSection? section2,
  })  : section1 = section1 ?? SpecialInstructionSection(),
        section2 = section2 ?? SpecialInstructionSection();

  Map<String, dynamic> toMap() => {
        'section1': section1.toMap(),
        'section2': section2.toMap(),
      };
}

class ActionLogDeviationEntry {
  String deviationObserved;
  String remedialAction;
  String estimatedCompletionDate;
  String dateCompleted;
  String signature;

  ActionLogDeviationEntry({
    this.deviationObserved = '',
    this.remedialAction = '',
    this.estimatedCompletionDate = '',
    this.dateCompleted = '',
    this.signature = '',
  });

  Map<String, dynamic> toMap() => {
        'deviationObserved': deviationObserved,
        'remedialAction': remedialAction,
        'estimatedCompletionDate': estimatedCompletionDate,
        'dateCompleted': dateCompleted,
        'signature': signature,
      };
}

class ActionLogUndergroundVisitsFormData {
  String date;
  String workingPlaceVisited;
  String nameOfSeniorOfficial;
  String designation;
  List<ActionLogDeviationEntry> deviations;
  String shiftBossSignature;
  String mineOverseerSignature;
  String seniorOfficialSignature;

  ActionLogUndergroundVisitsFormData({
    this.date = '',
    this.workingPlaceVisited = '',
    this.nameOfSeniorOfficial = '',
    this.designation = '',
    List<ActionLogDeviationEntry>? deviations,
    this.shiftBossSignature = '',
    this.mineOverseerSignature = '',
    this.seniorOfficialSignature = '',
  }) : deviations =
            deviations ?? List.generate(20, (_) => ActionLogDeviationEntry());

  Map<String, dynamic> toMap() => {
        'date': date,
        'workingPlaceVisited': workingPlaceVisited,
        'nameOfSeniorOfficial': nameOfSeniorOfficial,
        'designation': designation,
        'deviations': deviations.map((d) => d.toMap()).toList(),
        'shiftBossSignature': shiftBossSignature,
        'mineOverseerSignature': mineOverseerSignature,
        'seniorOfficialSignature': seniorOfficialSignature,
      };
}

class ExplosiveControlEntry {
  String description;
  String boxNo;
  String amountInControlBook;
  String amountObserved;
  String amountDelivered;

  ExplosiveControlEntry({
    this.description = '',
    this.boxNo = '',
    this.amountInControlBook = '',
    this.amountObserved = '',
    this.amountDelivered = '',
  });

  Map<String, dynamic> toMap() => {
        'description': description,
        'boxNo': boxNo,
        'amountInControlBook': amountInControlBook,
        'amountObserved': amountObserved,
        'amountDelivered': amountDelivered,
      };
}

class ExplosiveControlRecordFormData {
  String section;
  String strike;
  String date;
  String minerCoyNo;
  List<ExplosiveControlEntry> entries;
  String deviationsObserved;
  String deviationsDetails;
  String oldBoxesMarked;
  String oldBoxesMarkedDetails;
  String oldBoxesLocked;
  String oldBoxesLockedDetails;
  String typeOfExplosiveInBox;
  String totalInBox;
  String recordedCorrectly;
  String recordedDetails;
  String specialInstructions;
  String shiftBossSignature;
  String shiftBossDate;
  String mineOverseerSignature;
  String mineOverseerDate;

  ExplosiveControlRecordFormData({
    this.section = '',
    this.strike = '',
    this.date = '',
    this.minerCoyNo = '',
    List<ExplosiveControlEntry>? entries,
    this.deviationsObserved = '',
    this.deviationsDetails = '',
    this.oldBoxesMarked = '',
    this.oldBoxesMarkedDetails = '',
    this.oldBoxesLocked = '',
    this.oldBoxesLockedDetails = '',
    this.typeOfExplosiveInBox = '',
    this.totalInBox = '',
    this.recordedCorrectly = '',
    this.recordedDetails = '',
    this.specialInstructions = '',
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineOverseerSignature = '',
    this.mineOverseerDate = '',
  }) : entries = entries ?? List.generate(7, (_) => ExplosiveControlEntry());

  Map<String, dynamic> toMap() => {
        'section': section,
        'strike': strike,
        'date': date,
        'minerCoyNo': minerCoyNo,
        'entries': entries.map((e) => e.toMap()).toList(),
        'deviationsObserved': deviationsObserved,
        'deviationsDetails': deviationsDetails,
        'oldBoxesMarked': oldBoxesMarked,
        'oldBoxesMarkedDetails': oldBoxesMarkedDetails,
        'oldBoxesLocked': oldBoxesLocked,
        'oldBoxesLockedDetails': oldBoxesLockedDetails,
        'typeOfExplosiveInBox': typeOfExplosiveInBox,
        'totalInBox': totalInBox,
        'recordedCorrectly': recordedCorrectly,
        'recordedDetails': recordedDetails,
        'specialInstructions': specialInstructions,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineOverseerSignature': mineOverseerSignature,
        'mineOverseerDate': mineOverseerDate,
      };
}

/// Waiting-place inspection row: independent boolean yes/no + remarks.
class PlaceVisitedEntry {
  String placeVisited;
  String miner;

  PlaceVisitedEntry({this.placeVisited = '', this.miner = ''});

  Map<String, dynamic> toMap() => {
        'placeVisited': placeVisited,
        'miner': miner,
      };
}

class PlannedInspectionEntry {
  String workingPlace;
  String unsafeConditions;
  String remedialAction;
  String responsiblePerson;
  String plannedDate;
  String completedDate;
  String responsiblePersonSignature;

  PlannedInspectionEntry({
    this.workingPlace = '',
    this.unsafeConditions = '',
    this.remedialAction = '',
    this.responsiblePerson = '',
    this.plannedDate = '',
    this.completedDate = '',
    this.responsiblePersonSignature = '',
  });

  Map<String, dynamic> toMap() => {
        'workingPlace': workingPlace,
        'unsafeConditions': unsafeConditions,
        'remedialAction': remedialAction,
        'responsiblePerson': responsiblePerson,
        'plannedDate': plannedDate,
        'completedDate': completedDate,
        'responsiblePersonSignature': responsiblePersonSignature,
      };
}

class DevEndEntry {
  String devEndVentHoling;
  String roofboltsFromFace;
  String roofboltsFromSidewall;
  String socketsInspected;
  String averageLength;
  String servicePipes;
  String ventPipes;

  DevEndEntry({
    this.devEndVentHoling = '',
    this.roofboltsFromFace = '',
    this.roofboltsFromSidewall = '',
    this.socketsInspected = '',
    this.averageLength = '',
    this.servicePipes = '',
    this.ventPipes = '',
  });

  Map<String, dynamic> toMap() => {
        'devEndVentHoling': devEndVentHoling,
        'roofboltsFromFace': roofboltsFromFace,
        'roofboltsFromSidewall': roofboltsFromSidewall,
        'socketsInspected': socketsInspected,
        'averageLength': averageLength,
        'servicePipes': servicePipes,
        'ventPipes': ventPipes,
      };
}

class PillarDimensionEntry {
  String workplace;
  String vhNo;
  String surveyNoteLeft;
  String surveyNoteRight;
  String actualLeft;
  String actualRight;
  String remedialAction;

  PillarDimensionEntry({
    this.workplace = '',
    this.vhNo = '',
    this.surveyNoteLeft = '',
    this.surveyNoteRight = '',
    this.actualLeft = '',
    this.actualRight = '',
    this.remedialAction = '',
  });

  Map<String, dynamic> toMap() => {
        'workplace': workplace,
        'vhNo': vhNo,
        'surveyNoteLeft': surveyNoteLeft,
        'surveyNoteRight': surveyNoteRight,
        'actualLeft': actualLeft,
        'actualRight': actualRight,
        'remedialAction': remedialAction,
      };
}

class InspectionCheckItem {
  String item;
  bool yes;
  bool no;
  String findings;

  InspectionCheckItem({
    this.item = '',
    this.yes = false,
    this.no = false,
    this.findings = '',
  });

  Map<String, dynamic> toMap() => {
        'item': item,
        'yes': yes,
        'no': no,
        'findings': findings,
      };
}

class ShiftBossDailyReportFormData {
  String date;
  bool dayShift;
  bool nightShift;
  bool cycleA;
  bool cycleB;
  bool cycleC;
  List<PlaceVisitedEntry> placesVisited;
  List<PlannedInspectionEntry> plannedInspections;
  List<DevEndEntry> devEnds;
  List<PillarDimensionEntry> pillarDimensions;
  List<InspectionCheckItem> inspectionChecklist;
  String ventilationFlowReading;
  String temperatureWBReading;
  String temperatureDBReading;
  String general;
  String mineOverseerComments;
  String shiftBossSignature;
  String managerMineOverseerSignature;
  String signatureDate;

  ShiftBossDailyReportFormData({
    this.date = '',
    this.dayShift = false,
    this.nightShift = false,
    this.cycleA = false,
    this.cycleB = false,
    this.cycleC = false,
    List<PlaceVisitedEntry>? placesVisited,
    List<PlannedInspectionEntry>? plannedInspections,
    List<DevEndEntry>? devEnds,
    List<PillarDimensionEntry>? pillarDimensions,
    List<InspectionCheckItem>? inspectionChecklist,
    this.ventilationFlowReading = '',
    this.temperatureWBReading = '',
    this.temperatureDBReading = '',
    this.general = '',
    this.mineOverseerComments = '',
    this.shiftBossSignature = '',
    this.managerMineOverseerSignature = '',
    this.signatureDate = '',
  })  : placesVisited = placesVisited ?? [PlaceVisitedEntry()],
        plannedInspections = plannedInspections ?? [PlannedInspectionEntry()],
        devEnds = devEnds ?? [DevEndEntry()],
        pillarDimensions = pillarDimensions ?? [PillarDimensionEntry()],
        inspectionChecklist = inspectionChecklist ??
            _defaultChecklist();

  // Mirrors CHECKLIST_ITEMS in src/components/ShiftBossDailyReportForm.tsx
  // lines 46-60 — identical 14-row checklist, in the same order, so submissions
  // round-trip with the same `inspectionChecklist[i].item` strings on both apps.
  static List<InspectionCheckItem> _defaultChecklist() => const [
        'Auxiliary ventilation',
        'Blow pipes',
        'Exposure to dust and fumes',
        'Tipping points/Rock Breaker',
        'Gang register',
        'Cover holes',
        'Testing for gases',
        'Methanemometer no.',
        'Symbolic signs',
        'Safety devices/lock outs',
        'Conveyor belt',
        'First-aid equipment',
        'Over inspection of TMM pre-use checklists',
        'PPE',
      ]
          .map((label) => InspectionCheckItem(item: label))
          .toList();

  Map<String, dynamic> toMap() => {
        'date': date,
        'dayShift': dayShift,
        'nightShift': nightShift,
        'cycleA': cycleA,
        'cycleB': cycleB,
        'cycleC': cycleC,
        'placesVisited': placesVisited.map((e) => e.toMap()).toList(),
        'plannedInspections':
            plannedInspections.map((e) => e.toMap()).toList(),
        'devEnds': devEnds.map((e) => e.toMap()).toList(),
        'pillarDimensions': pillarDimensions.map((e) => e.toMap()).toList(),
        'inspectionChecklist':
            inspectionChecklist.map((e) => e.toMap()).toList(),
        'ventilationFlowReading': ventilationFlowReading,
        'temperatureWBReading': temperatureWBReading,
        'temperatureDBReading': temperatureDBReading,
        'general': general,
        'mineOverseerComments': mineOverseerComments,
        'shiftBossSignature': shiftBossSignature,
        'managerMineOverseerSignature': managerMineOverseerSignature,
        'signatureDate': signatureDate,
      };
}

class WaitingPlaceCheckItem {
  bool yes;
  bool no;
  String remarks;

  WaitingPlaceCheckItem({this.yes = false, this.no = false, this.remarks = ''});

  Map<String, dynamic> toMap() => {
        'yes': yes,
        'no': no,
        'remarks': remarks,
      };
}

class WaitingPlaceInspectionFormData {
  String section;
  String miner;
  String date;
  List<WaitingPlaceCheckItem> items;
  String specialInstructions;
  String shiftBossSignature;
  String shiftBossDate;
  String mineOverseerSignature;
  String mineOverseerDate;

  WaitingPlaceInspectionFormData({
    this.section = '',
    this.miner = '',
    this.date = '',
    List<WaitingPlaceCheckItem>? items,
    this.specialInstructions = '',
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineOverseerSignature = '',
    this.mineOverseerDate = '',
  }) : items = items ?? List.generate(29, (_) => WaitingPlaceCheckItem());

  Map<String, dynamic> toMap() => {
        'section': section,
        'miner': miner,
        'date': date,
        'items': items.map((e) => e.toMap()).toList(),
        'specialInstructions': specialInstructions,
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineOverseerSignature': mineOverseerSignature,
        'mineOverseerDate': mineOverseerDate,
      };
}

/// Inspection-checklist row used by rock-breaker, belt-tip-area, conveyor-belt
/// inspections (and any other form using a "yes/no + remedial" row shape).
class InspectionItem {
  String yesNo;
  String remedialAction;

  InspectionItem({this.yesNo = '', this.remedialAction = ''});

  Map<String, dynamic> toMap() => {
        'yesNo': yesNo,
        'remedialAction': remedialAction,
      };
}

class RockBreakerInspectionFormData {
  String dateOfInspection;
  String positionOfRockBreaker;
  List<InspectionItem> items;
  String shiftBossSignature;
  String shiftBossDate;
  String mineManagerOverseerSignature;
  String mineManagerOverseerDate;

  RockBreakerInspectionFormData({
    this.dateOfInspection = '',
    this.positionOfRockBreaker = '',
    List<InspectionItem>? items,
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineManagerOverseerSignature = '',
    this.mineManagerOverseerDate = '',
  }) : items = items ?? List.generate(10, (_) => InspectionItem());

  Map<String, dynamic> toMap() => {
        'dateOfInspection': dateOfInspection,
        'positionOfRockBreaker': positionOfRockBreaker,
        'items': items.map((e) => e.toMap()).toList(),
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineManagerOverseerSignature': mineManagerOverseerSignature,
        'mineManagerOverseerDate': mineManagerOverseerDate,
      };
}

class BeltTipAreaInspectionFormData {
  String dateOfInspection;
  String positionOfTip;
  List<InspectionItem> items;
  String shiftBossSignature;
  String shiftBossDate;
  String mineManagerOverseerSignature;
  String mineManagerOverseerDate;

  BeltTipAreaInspectionFormData({
    this.dateOfInspection = '',
    this.positionOfTip = '',
    List<InspectionItem>? items,
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineManagerOverseerSignature = '',
    this.mineManagerOverseerDate = '',
  }) : items = items ?? List.generate(8, (_) => InspectionItem());

  Map<String, dynamic> toMap() => {
        'dateOfInspection': dateOfInspection,
        'positionOfTip': positionOfTip,
        'items': items.map((e) => e.toMap()).toList(),
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineManagerOverseerSignature': mineManagerOverseerSignature,
        'mineManagerOverseerDate': mineManagerOverseerDate,
      };
}

class ConveyorBeltInspectionFormData {
  String dateOfInspection;
  String positionOfBelt;
  List<InspectionItem> walkwayItems;
  List<InspectionItem> beltConditionItems;
  String shiftBossSignature;
  String shiftBossDate;
  String mineManagerOverseerSignature;
  String mineManagerOverseerDate;

  ConveyorBeltInspectionFormData({
    this.dateOfInspection = '',
    this.positionOfBelt = '',
    List<InspectionItem>? walkwayItems,
    List<InspectionItem>? beltConditionItems,
    this.shiftBossSignature = '',
    this.shiftBossDate = '',
    this.mineManagerOverseerSignature = '',
    this.mineManagerOverseerDate = '',
  })  : walkwayItems = walkwayItems ?? List.generate(10, (_) => InspectionItem()),
        beltConditionItems =
            beltConditionItems ?? List.generate(17, (_) => InspectionItem());

  Map<String, dynamic> toMap() => {
        'dateOfInspection': dateOfInspection,
        'positionOfBelt': positionOfBelt,
        'walkwayItems': walkwayItems.map((e) => e.toMap()).toList(),
        'beltConditionItems':
            beltConditionItems.map((e) => e.toMap()).toList(),
        'shiftBossSignature': shiftBossSignature,
        'shiftBossDate': shiftBossDate,
        'mineManagerOverseerSignature': mineManagerOverseerSignature,
        'mineManagerOverseerDate': mineManagerOverseerDate,
      };
}

class LockoutChecklistEntry {
  String nameSurname;
  String operatorAssistant;
  String workplace;
  String trainedOnLockOut;
  String lockAvailable;
  String scissorAvailable;
  String date;
  String signature;

  LockoutChecklistEntry({
    this.nameSurname = '',
    this.operatorAssistant = '',
    this.workplace = '',
    this.trainedOnLockOut = '',
    this.lockAvailable = '',
    this.scissorAvailable = '',
    this.date = '',
    this.signature = '',
  });

  Map<String, dynamic> toMap() => {
        'nameSurname': nameSurname,
        'operatorAssistant': operatorAssistant,
        'workplace': workplace,
        'trainedOnLockOut': trainedOnLockOut,
        'lockAvailable': lockAvailable,
        'scissorAvailable': scissorAvailable,
        'date': date,
        'signature': signature,
      };
}

class LockoutLockScissorChecklistFormData {
  List<LockoutChecklistEntry> entries;
  String shiftBossSignature;

  LockoutLockScissorChecklistFormData({
    List<LockoutChecklistEntry>? entries,
    this.shiftBossSignature = '',
  }) : entries = entries ?? <LockoutChecklistEntry>[];

  Map<String, dynamic> toMap() => {
        'entries': entries.map((e) => e.toMap()).toList(),
        'shiftBossSignature': shiftBossSignature,
      };
}
