// Mirrors the `todos` row shape created in
// supabase/migrations/20260524185145_create_todos_table.sql.
// Two kinds: 'eng' (engineering, service_role-only inserts) and 'user'
// (user-requested change with screenshot/urgency/summary).

class Todo {
  Todo({
    required this.id,
    required this.kind,
    required this.title,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.description,
    this.summary,
    this.urgency,
    this.submitterName,
    this.submitterId,
    this.authorId,
    this.authorName,
    this.imageStoragePath,
    this.imageNotes,
    this.parentId,
  });

  final String id;
  final String kind; // 'eng' | 'user'
  final String title;
  final String? description;
  final String? summary;
  final String status; // 'planned' | 'doing' | 'done'
  final String? urgency; // 'asap' | 'whenever' | 'meeting'
  final String? submitterName;
  final String? submitterId;
  final String? authorId;
  final String? authorName;
  final String? imageStoragePath;
  final String? imageNotes;
  final String? parentId;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isUser => kind == 'user';
  bool get isEng => kind == 'eng';
  bool get isDone => status == 'done';

  factory Todo.fromRow(Map<String, dynamic> row) {
    return Todo(
      id: row['id'] as String,
      kind: row['kind'] as String,
      title: (row['title'] as String?) ?? '',
      description: row['description'] as String?,
      summary: row['summary'] as String?,
      status: (row['status'] as String?) ?? 'planned',
      urgency: row['urgency'] as String?,
      submitterName: row['submitter_name'] as String?,
      submitterId: row['submitter_id'] as String?,
      authorId: row['author_id'] as String?,
      authorName: row['author_name'] as String?,
      imageStoragePath: row['image_storage_path'] as String?,
      imageNotes: row['image_notes'] as String?,
      parentId: row['parent_id'] as String?,
      createdAt: DateTime.tryParse(row['created_at'] as String? ?? '') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(row['updated_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Todo copyWith({String? status}) => Todo(
        id: id,
        kind: kind,
        title: title,
        description: description,
        summary: summary,
        status: status ?? this.status,
        urgency: urgency,
        submitterName: submitterName,
        submitterId: submitterId,
        authorId: authorId,
        authorName: authorName,
        imageStoragePath: imageStoragePath,
        imageNotes: imageNotes,
        parentId: parentId,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );
}

class TodoUrgency {
  const TodoUrgency(this.id, this.short, this.label);
  final String id;
  final String short;
  final String label;
}

const todoUrgencies = <TodoUrgency>[
  TodoUrgency(
    'asap',
    'ASAP',
    'ASAP — change needs to be done as soon as possible',
  ),
  TodoUrgency(
    'whenever',
    'WHEN READY',
    "When ready — change can be done when you're done with what you need to do",
  ),
  TodoUrgency(
    'meeting',
    'NEXT MEETING',
    'Next meeting — change will be discussed and elaborated on at our next meeting',
  ),
];

TodoUrgency? todoUrgencyById(String? id) {
  if (id == null) return null;
  for (final u in todoUrgencies) {
    if (u.id == id) return u;
  }
  return null;
}

class TodoStatus {
  const TodoStatus(this.id, this.label, this.icon);
  final String id;
  final String label;
  final String icon; // material icon name (matches UI-kit)
}

const todoStatuses = <TodoStatus>[
  TodoStatus('planned', 'Planned', 'pending'),
  TodoStatus('doing', 'In Progress', 'play_circle'),
  TodoStatus('done', 'Completed', 'check_circle'),
];
