// SP4.5 Full-edit form builder — the per-form edit overlay. Pure data; no
// Flutter/Supabase deps so it is unit-testable. Reuses the SP2 FormFieldDef.
// Stored on custom_form_templates.overlay (jsonb), keyed by code = form_type.
//
// An overlay never rewrites a form's typed payload; added/page field VALUES live
// under payload['overlay'] (see overlayValuesFromPayload). With an empty overlay
// the form renders byte-identically to the bespoke baseline.

import 'custom_form_template.dart';

/// A per-field override applied to an EXISTING bespoke field (Phase B). All
/// members optional; a null member means "no change".
class FieldOverride {
  const FieldOverride({
    this.hidden = false,
    this.label,
    this.type,
    this.required,
  });

  final bool hidden;
  final String? label;
  final String? type;
  final bool? required;

  Map<String, dynamic> toMap() => {
    'hidden': hidden,
    if (label != null) 'label': label,
    if (type != null) 'type': type,
    if (required != null) 'required': required,
  };

  factory FieldOverride.fromMap(Map<String, dynamic> m) => FieldOverride(
    hidden: (m['hidden'] ?? false) as bool,
    label: m['label'] as String?,
    type: m['type'] as String?,
    required: m['required'] as bool?,
  );
}

/// An admin-added page/section of extra fields, appended to the form.
class OverlayPage {
  const OverlayPage({
    required this.id,
    required this.title,
    required this.fields,
  });

  final String id;
  final String title;
  final List<FormFieldDef> fields;

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'fields': fields.map((f) => f.toMap()).toList(),
  };

  factory OverlayPage.fromMap(Map<String, dynamic> m) => OverlayPage(
    id: (m['id'] ?? '') as String,
    title: (m['title'] ?? '') as String,
    fields: (m['fields'] as List? ?? const [])
        .map((e) => FormFieldDef.fromMap((e as Map).cast<String, dynamic>()))
        .toList(),
  );
}

class FormOverlay {
  const FormOverlay({
    required this.addedFields,
    required this.addedPages,
    required this.fieldOverrides,
    this.order = const [],
  });

  /// Extra fields appended to the end of the form body.
  final List<FormFieldDef> addedFields;

  /// Extra pages/sections, each with its own fields.
  final List<OverlayPage> addedPages;

  /// Per-field overrides for existing bespoke fields, keyed by stable field id.
  final Map<String, FieldOverride> fieldOverrides;

  /// Optional reordering of an editable region, by field id.
  final List<String> order;

  bool get hasContent =>
      addedFields.isNotEmpty ||
      addedPages.isNotEmpty ||
      fieldOverrides.isNotEmpty ||
      order.isNotEmpty;

  Map<String, dynamic> toMap() => {
    'version': 1,
    'addedFields': addedFields.map((f) => f.toMap()).toList(),
    'addedPages': addedPages.map((p) => p.toMap()).toList(),
    'fieldOverrides': {
      for (final e in fieldOverrides.entries) e.key: e.value.toMap(),
    },
    'order': order,
  };

  factory FormOverlay.fromMap(Map<String, dynamic> m) => FormOverlay(
    addedFields: (m['addedFields'] as List? ?? const [])
        .map((e) => FormFieldDef.fromMap((e as Map).cast<String, dynamic>()))
        .toList(),
    addedPages: (m['addedPages'] as List? ?? const [])
        .map((e) => OverlayPage.fromMap((e as Map).cast<String, dynamic>()))
        .toList(),
    fieldOverrides: {
      for (final e in (m['fieldOverrides'] as Map? ?? const {}).entries)
        e.key as String: FieldOverride.fromMap(
          (e.value as Map).cast<String, dynamic>(),
        ),
    },
    order: (m['order'] as List? ?? const []).map((e) => e as String).toList(),
  );
}

/// The effective field order: ids named in [order] first (in that order,
/// ignoring any not in [natural]), then any [natural] ids not named in [order],
/// in natural order. Empty [order] → [natural] unchanged.
List<String> applyFieldOrder(List<String> natural, List<String> order) {
  final naturalSet = natural.toSet();
  final used = <String>{};
  final out = <String>[];
  for (final id in order) {
    if (naturalSet.contains(id) && used.add(id)) out.add(id);
  }
  for (final id in natural) {
    if (used.add(id)) out.add(id);
  }
  return out;
}

/// Every overlay-added field (top-level added fields + each page's fields), used
/// to build the submission payload and the PDF appendix.
List<FormFieldDef> allOverlayFields(FormOverlay o) => [
  ...o.addedFields,
  for (final p in o.addedPages) ...p.fields,
];

/// The overlay value map stored under payload['overlay'] (or empty).
Map<String, dynamic> overlayValuesFromPayload(Map<String, dynamic> payload) {
  final v = payload['overlay'];
  return v is Map ? v.cast<String, dynamic>() : <String, dynamic>{};
}
