// SP3 Appointment Builder + Letter Builder model. Pure data + validation; no
// Flutter/Supabase deps so it is fully unit-testable. `fields` reuses the SP2
// FormFieldDef shape and round-trips through appointment_templates.fields jsonb.

import 'custom_form_template.dart';

class AppointmentRole {
  const AppointmentRole({
    required this.id,
    required this.label,
    required this.code,
    required this.description,
    required this.isMandatory,
    required this.isActive,
    required this.sortOrder,
  });

  final String id;
  final String label;
  final String? code;
  final String? description;
  final bool isMandatory;
  final bool isActive;
  final int sortOrder;

  /// "2.6.1 — Mine Manager" when a code exists, else just the label.
  String get displayLabel =>
      code == null || code!.isEmpty ? label : '$code — $label';

  Map<String, dynamic> toMap() => {
    'code': code,
    'label': label,
    'description': description,
    'is_mandatory': isMandatory,
    'is_active': isActive,
    'sort_order': sortOrder,
  };

  factory AppointmentRole.fromMap(Map<String, dynamic> m) => AppointmentRole(
    id: (m['id'] ?? '') as String,
    label: (m['label'] ?? '') as String,
    code: m['code'] as String?,
    description: m['description'] as String?,
    isMandatory: (m['is_mandatory'] ?? false) as bool,
    isActive: (m['is_active'] ?? true) as bool,
    sortOrder: (m['sort_order'] ?? 0) as int,
  );
}

class AppointmentTemplate {
  const AppointmentTemplate({
    required this.id,
    required this.code,
    required this.name,
    required this.description,
    required this.roleId,
    required this.language,
    required this.fields,
    required this.letterBody,
    required this.requiredSigners,
    required this.version,
    required this.isActive,
    required this.createdBy,
  });

  final String id;
  final String code;
  final String name;
  final String? description;
  final String? roleId;
  final String language;
  final List<FormFieldDef> fields;
  final String letterBody;
  final List<String> requiredSigners;
  final int version;
  final bool isActive;
  final String? createdBy;

  Map<String, dynamic> toMap() => {
    'code': code,
    'name': name,
    'description': description,
    'role_id': roleId,
    'language': language,
    'fields': fields.map((f) => f.toMap()).toList(),
    'letter_body': letterBody,
    'required_signers': requiredSigners,
    'version': version,
    'is_active': isActive,
    if (createdBy != null) 'created_by': createdBy,
  };

  factory AppointmentTemplate.fromMap(Map<String, dynamic> m) =>
      AppointmentTemplate(
        id: (m['id'] ?? '') as String,
        code: (m['code'] ?? '') as String,
        name: (m['name'] ?? '') as String,
        description: m['description'] as String?,
        roleId: m['role_id'] as String?,
        language: (m['language'] ?? 'en') as String,
        fields: (m['fields'] as List? ?? const [])
            .map(
              (e) => FormFieldDef.fromMap((e as Map).cast<String, dynamic>()),
            )
            .toList(),
        letterBody: (m['letter_body'] ?? '') as String,
        requiredSigners: (m['required_signers'] as List? ?? const [])
            .map((e) => e as String)
            .toList(),
        version: (m['version'] ?? 1) as int,
        isActive: (m['is_active'] ?? true) as bool,
        createdBy: m['created_by'] as String?,
      );
}

/// Standard profile-derived tokens available to every letter (resolved from the
/// appointee's profile at issue time; sample data in SP3 preview).
const List<String> kStandardLetterTokens = [
  'full_name',
  'first_name',
  'last_name',
  'employee_number',
  'id_number',
  'occupation',
  'section',
  'company',
  'date',
];

final RegExp _tokenRe = RegExp(r'\{\{\s*([a-zA-Z0-9_]+)\s*\}\}');

/// Distinct `{{token}}` names in first-seen order.
List<String> extractPlaceholders(String body) {
  final seen = <String>[];
  for (final m in _tokenRe.allMatches(body)) {
    final name = m.group(1)!;
    if (!seen.contains(name)) seen.add(name);
  }
  return seen;
}

/// Replace `{{token}}` with values[token]; unknown tokens are left verbatim so
/// authors can see their mistakes rather than silent blanks.
String renderLetterBody(String body, Map<String, String> values) {
  return body.replaceAllMapped(_tokenRe, (m) {
    final name = m.group(1)!;
    return values.containsKey(name) ? values[name]! : m.group(0)!;
  });
}

/// Human-readable problems with a draft template; empty means valid. Reuses the
/// SP2 field validator (`validateTemplate`) for field-level rules.
List<String> validateAppointmentTemplate({
  required String name,
  required String? roleId,
  required List<FormFieldDef> fields,
}) {
  final errors = <String>[];
  if (name.trim().isEmpty) errors.add('Template name is required.');
  if (roleId == null || roleId.isEmpty) {
    errors.add('Select an appointment role.');
  }
  // Field-level rules (keys, dropdown options, table columns, "at least one
  // field"). Drop the form-builder's own name message — this model has its own.
  errors.addAll(
    validateTemplate(
      name: name.trim().isEmpty ? 'placeholder' : name,
      fields: fields,
    ).where((e) => e != 'Form name is required.'),
  );
  return errors.toSet().toList();
}
