// Mirrors src/utils/signatureWorkflow.ts → SignatureRequest / ProfileSnapshot.

class ProfileSnapshot {
  final String id;
  final String fullName;
  final String firstName;
  final String email;
  final String title;
  final String jobTitle;
  final String companyNumber;
  final String company;
  final String department;
  final String costCentre;
  final String location;
  final String phone;
  final String occupation;
  final String userAccountType;

  const ProfileSnapshot({
    required this.id,
    required this.fullName,
    required this.firstName,
    required this.email,
    required this.title,
    required this.jobTitle,
    required this.companyNumber,
    required this.company,
    required this.department,
    required this.costCentre,
    required this.location,
    required this.phone,
    required this.occupation,
    required this.userAccountType,
  });

  static String _s(Map<String, dynamic>? m, String k) =>
      (m?[k] as String?) ?? '';

  factory ProfileSnapshot.fromMap(Map<String, dynamic> m) => ProfileSnapshot(
        id: _s(m, 'id'),
        fullName: _s(m, 'full_name'),
        firstName: _s(m, 'first_name'),
        email: _s(m, 'email'),
        title: _s(m, 'title'),
        jobTitle: _s(m, 'job_title'),
        companyNumber: _s(m, 'company_number'),
        company: _s(m, 'company'),
        department: _s(m, 'department'),
        costCentre: _s(m, 'cost_centre'),
        location: _s(m, 'location'),
        phone: _s(m, 'phone'),
        occupation: _s(m, 'occupation'),
        userAccountType: _s(m, 'user_account_type'),
      );

  String get displayName {
    final parts = [title, fullName.isNotEmpty ? fullName : firstName]
        .where((s) => s.isNotEmpty)
        .toList();
    return parts.join(' ');
  }
}

class SignatureSubmission {
  final String id;
  final String userId;
  final String formType;
  final String title;
  final Map<String, dynamic> payload;
  final DateTime? createdAt;

  const SignatureSubmission({
    required this.id,
    required this.userId,
    required this.formType,
    required this.title,
    required this.payload,
    required this.createdAt,
  });

  factory SignatureSubmission.fromMap(Map<String, dynamic> m) =>
      SignatureSubmission(
        id: (m['id'] as String?) ?? '',
        userId: (m['user_id'] as String?) ?? '',
        formType: (m['form_type'] as String?) ?? '',
        title: (m['title'] as String?) ?? '',
        payload: (m['payload'] as Map<String, dynamic>?) ?? const {},
        createdAt: DateTime.tryParse(m['created_at'] as String? ?? ''),
      );
}

class SignatureRequest {
  final String id;
  final String submissionId;
  final String requestedBy;
  final String requestedRole;
  final String signatureField;
  final String? dateField;
  final int stepOrder;
  final String status;
  final String? signedBy;
  final DateTime? signedAt;
  final Map<String, dynamic> requestMetadata;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final SignatureSubmission? submission;
  final ProfileSnapshot? submitterProfile;
  final ProfileSnapshot? signedByProfile;

  const SignatureRequest({
    required this.id,
    required this.submissionId,
    required this.requestedBy,
    required this.requestedRole,
    required this.signatureField,
    required this.dateField,
    required this.stepOrder,
    required this.status,
    required this.signedBy,
    required this.signedAt,
    required this.requestMetadata,
    required this.createdAt,
    required this.updatedAt,
    required this.submission,
    required this.submitterProfile,
    required this.signedByProfile,
  });

  factory SignatureRequest.fromMap(Map<String, dynamic> m) => SignatureRequest(
        id: (m['id'] as String?) ?? '',
        submissionId: (m['submission_id'] as String?) ?? '',
        requestedBy: (m['requested_by'] as String?) ?? '',
        requestedRole: (m['requested_role'] as String?) ?? '',
        signatureField: (m['signature_field'] as String?) ?? '',
        dateField: m['date_field'] as String?,
        stepOrder: (m['step_order'] as int?) ?? 0,
        status: (m['status'] as String?) ?? 'pending',
        signedBy: m['signed_by'] as String?,
        signedAt: DateTime.tryParse(m['signed_at'] as String? ?? ''),
        requestMetadata:
            (m['request_metadata'] as Map<String, dynamic>?) ?? const {},
        createdAt: DateTime.tryParse(m['created_at'] as String? ?? ''),
        updatedAt: DateTime.tryParse(m['updated_at'] as String? ?? ''),
        submission: m['submission'] is Map<String, dynamic>
            ? SignatureSubmission.fromMap(
                m['submission'] as Map<String, dynamic>)
            : null,
        submitterProfile: m['submitterProfile'] is Map<String, dynamic>
            ? ProfileSnapshot.fromMap(
                m['submitterProfile'] as Map<String, dynamic>)
            : null,
        signedByProfile: m['signedByProfile'] is Map<String, dynamic>
            ? ProfileSnapshot.fromMap(
                m['signedByProfile'] as Map<String, dynamic>)
            : null,
      );
}
