// Mirrors src/hooks/useNotifications.ts → Notification + NotificationMetadata.

class AppNotification {
  final String id;
  final String type; // 'message' | 'system' | 'warning' | 'success'
  final String title;
  final String body;
  final bool read;
  final DateTime createdAt;
  final String? actionUrl;
  final String? category;
  final Map<String, dynamic>? metadata;

  AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.read,
    required this.createdAt,
    this.actionUrl,
    this.category,
    this.metadata,
  });

  factory AppNotification.fromRow(Map<String, dynamic> row) {
    final metadata = row['metadata'] as Map<String, dynamic>?;
    return AppNotification(
      id: row['id'] as String,
      type: (row['type'] as String?) ?? 'system',
      title: (row['title'] as String?) ?? '',
      body: (row['body'] as String?) ?? '',
      read: row['read_at'] != null,
      createdAt: DateTime.tryParse(row['created_at'] as String? ?? '') ??
          DateTime.now(),
      actionUrl: row['action_url'] as String?,
      category: metadata == null ? null : metadata['category'] as String?,
      metadata: metadata,
    );
  }

  AppNotification copyWith({bool? read}) => AppNotification(
        id: id,
        type: type,
        title: title,
        body: body,
        read: read ?? this.read,
        createdAt: createdAt,
        actionUrl: actionUrl,
        category: category,
        metadata: metadata,
      );
}
