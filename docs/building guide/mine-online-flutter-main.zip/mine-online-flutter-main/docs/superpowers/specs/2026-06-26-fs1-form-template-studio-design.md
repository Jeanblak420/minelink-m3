# Form Template Studio — FS1 (lifecycle foundation)

**Date:** 2026-06-26
**Status:** Approved (design — user delegated the approach)

## The program (context)

Let admins customize the **look, wording, and tables** of the 27 statutory forms,
**without ever touching the originals**, and manage edited versions through a
draft → test → active lifecycle. Built as a small program; this spec is **FS1**.

- **FS1 (this spec)** — the **Studio + lifecycle**: an Originals tab (read-only,
  clone-to-edit, never delete) and an Edited tab (drafts: edit / test / set
  active / delete). Editing reuses the existing overlay editor + the SP11 live
  preview. "Test" opens the form fully fillable + signable in a sandbox that
  never writes real data. "Set active" makes the app use that edited version
  everywhere; the original is the permanent fallback (deactivate to revert).
- **FS2 (later)** — click-on-the-rendered-page WYSIWYG editing.
- **FS3 (later)** — reflect edits into the printed **PDF** (per-form).

FS1 delivers the user's entire workflow end-to-end using today's editing
capabilities (add fields/tables, hide/relabel, reorder, live preview, signature
chain). FS2/FS3 progressively deepen the editing surface.

## Discoveries (verified)

- `custom_form_templates` is **empty** (clean slate) and already has `overlay`
  (jsonb), `base_form_type` (text), `is_active` (bool, default true), `name`,
  `id`. An **overlay draft** = a row with `base_form_type` set + its own `overlay`
  + `name`. We reuse `is_active` as the active/inactive flag for drafts (a row
  with `base_form_type` null is a standalone SP2 custom form, unaffected).
- `loadFormOverlay(formType)` today loads the single overlay row by
  `code = formType`. Every form path (26 screens' `FormOverlayHost` +
  `_loadOverrides`, the PDF appendix) funnels through it — so changing it to
  return the **active draft** automatically makes all forms + PDFs use the active
  edited version, with the original as fallback when none is active.
- Persistence funnels through two shared helpers in
  `lib/utils/signature_workflow.dart`: `persistFormSubmission(...)` and
  `saveFormSubmissionAndStartWorkflow(...)`. Gating these two is the whole
  test-sandbox — no per-form changes.

## Data model — migration `supabase/migrations/<ts>_fs1_template_lifecycle.sql`

Reuse the existing columns; add one guard:

```sql
-- At most one ACTIVE overlay draft per base form (originals = no active draft).
create unique index if not exists custom_form_templates_one_active_overlay
  on public.custom_form_templates (base_form_type)
  where base_form_type is not null and is_active = true;
```

Drafts are created **inactive** (`is_active = false`); "Set active" flips exactly
one to true (deactivating its siblings first). Applied via Management API.

## Data layer — `lib/utils/form_overlay_data.dart`

- **Change** `loadFormOverlay(formType)` to load the **active draft**:
  `select overlay from custom_form_templates where base_form_type = formType
   and is_active = true limit 1` → `FormOverlay.fromMap(overlay)` or null.
  (All existing callers keep working; they now get the active edited version, or
  null = original.)
- Add an `OverlayDraft` model (`id, baseFormType, name, isActive, overlay`) +:
  - `Future<List<OverlayDraft>> listOverlayDrafts()` — all rows with
    `base_form_type` not null, ordered by base then name.
  - `Future<String> createOverlayDraft(String baseFormType, String name)` —
    insert (`base_form_type`, `name`, `overlay = {}`, `is_active = false`,
    `created_by`); returns the new id. Empty overlay ⇒ the draft renders
    identically to the original (the "exact copy" starting point).
  - `Future<void> saveOverlayDraft(String id, {required String name, required FormOverlay overlay})`.
  - `Future<void> deleteOverlayDraft(String id)`.
  - `Future<void> setOverlayDraftActive(String id, String baseFormType)` —
    `update ... set is_active=false where base_form_type=$baseFormType`; then
    `update ... set is_active=true where id=$id`.
  - `Future<void> deactivateOverlayForForm(String baseFormType)` — set all
    `is_active=false` for that base (revert to original).
- Keep `loadFieldOverrides` / `loadEditedFormTypes` working (they call
  `loadFormOverlay`, so they now reflect the active draft).
- **Remove** the old single-overlay `saveFormOverlay(formType, title, overlay)`
  upsert path (superseded by `saveOverlayDraft(id, ...)`); update its callers
  (the overlay editor — see below).

## Test sandbox — `lib/utils/signature_workflow.dart`

Add a process-global flag + gate the two persistence helpers:
```dart
/// When true (a Studio "Test" form is open), submissions are NOT written —
/// the helpers return a fake id so the form's fill+sign flow completes for
/// testing without touching real data.
bool formTestMode = false;
```
At the top of both `persistFormSubmission` and
`saveFormSubmissionAndStartWorkflow`:
```dart
if (formTestMode) return 'test-${DateTime.now().microsecondsSinceEpoch}';
```
(Signing pads still work locally; nothing persists.) The Studio sets
`formTestMode = true` before pushing a Test form and `false` in a `whenComplete`.

## Editor — `lib/screens/form_builder/` (overlay editor)

The overlay editor (currently `_OverlayEditorScreen` inside
`form_builder_screen.dart`) is reworked to operate on an **OverlayDraft** (id +
baseFormType + name) instead of a `FormMetadata` form-type only:
- Loads/saves by **draft id** (`saveOverlayDraft(id, name: …, overlay: …)`).
- An editable **name** field (the draft's title).
- Live preview (SP11) unchanged — it already renders the form with the
  in-progress overlay (`overlayOverride: _build()`).
Extract `_OverlayEditorScreen` into its own file
`lib/screens/form_builder/overlay_editor_screen.dart` (it has grown large and is
now shared by the Studio).

## Studio screen — `lib/screens/templates/form_studio_screen.dart` (new)

Admin-gated. A `TabBar` with two tabs:

- **Originals** — `kFormMetadataRegistry` grouped by category. Each row: form
  title; a single **Edit** action → `createOverlayDraft(formType, 'Copy of
  <title>')` then open the overlay editor on the new draft. **No delete.** (An
  "Active: <draft name>" chip shows when that form currently has an active draft.)
- **Edited** — `listOverlayDrafts()` grouped by base form. Each row: draft name +
  base-form title + an **Active**/**Inactive** chip; actions:
  - **Edit** → overlay editor on the draft id.
  - **Test** → set `formTestMode=true`, push `buildFormView(baseFormType,
    FormViewArgs(mode: edit, overlayOverride: draft.overlay))` (fully fillable +
    signable); reset the flag on pop. A top banner notes "Test mode — nothing is
    saved."
  - **Set active** / **Deactivate** → `setOverlayDraftActive` /
    `deactivateOverlayForForm`.
  - **Delete** (with confirm) → `deleteOverlayDraft`.

Route `/templates/studio` + a **Form Studio** leaf in the Templates sidebar
section. The SP10a "Current forms" list inside Form Builder is **removed** (the
Studio's Originals tab replaces it); Form Builder keeps its custom-form (SP2)
authoring. The ✎ "Edit a current form" app-bar action is removed too.

## Testing — `test/overlay_draft_test.dart`

Pure logic is thin (mostly IO + UI), so cover what's pure:
- A small pure helper `activeDraftName(List<OverlayDraft>, baseFormType)` →
  the active draft's name or null (used for the Originals "Active:" chip) — unit
  test it (empty, no-active, one-active).
- The lifecycle data functions are IO; verify via analyze + build + the
  Management-API smoke (create draft → set active → `loadFormOverlay` returns it
  → deactivate → returns null) + the user's in-app pass.

## Files

New:
- `supabase/migrations/<ts>_fs1_template_lifecycle.sql`
- `lib/screens/templates/form_studio_screen.dart`
- `lib/screens/form_builder/overlay_editor_screen.dart` (extracted)
- `test/overlay_draft_test.dart`

Edited:
- `lib/utils/form_overlay_data.dart` (active-draft load + lifecycle CRUD + model)
- `lib/utils/signature_workflow.dart` (`formTestMode` + gates)
- `lib/screens/form_builder_screen.dart` (remove the "Current forms" list + ✎
  action; move the overlay editor out)
- `lib/routing/router.dart` (+ `/templates/studio`)
- `lib/widgets/admin/admin_sidebar.dart` (+ Form Studio leaf)

No new dependency.

## Verification

`flutter analyze` clean · `flutter test` green (existing + the pure helper) ·
`flutter build windows --release`. Management-API smoke of the lifecycle. The
user's in-app pass: Originals → Edit (creates a copy) → add a field/table + see
it in the live preview → Save → it appears in Edited (inactive) → Test (fill +
sign, nothing saved) → Set active → the real form now shows the edits → Deactivate
→ back to the original.

## Non-goals (FS1)

- No click-on-the-page editing (FS2) and no editing of the existing baked-in
  wording/tables beyond today's hide/relabel/add (FS2/FS3).
- No PDF reflection of edits (FS3) — the printed PDF still uses the bespoke
  generator; added fields already appear via the existing PDF appendix.
- Originals are never mutated or deleted; "Edit" always clones.
