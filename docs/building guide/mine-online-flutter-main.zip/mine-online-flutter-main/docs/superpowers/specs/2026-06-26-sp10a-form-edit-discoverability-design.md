# SP10a — "Current forms" editable list (form-edit discoverability)

**Date:** 2026-06-26
**Status:** Approved (design)
**Scope:** Ship 1 of the form-edit UX work. Ship 2 (reorder pilot + editable-field
catalog completion) is a separate later spec.

## Problem

Admins can't find how to edit the 27 built-in forms. The **Form Builder**
(`/form-builder`) body only lists **custom** forms (built from scratch) — empty
for a fresh project, so it reads as "nothing to edit." Editing a current form is
hidden behind a single app-bar ✎ icon (`_pickCurrentForm` → a `SimpleDialog`
list → `_OverlayEditorScreen`). The user reported all three Templates screens
look like they have nothing editable inside.

## Goal

Surface the 27 built-in forms as a visible, tappable list in the Form Builder
body, each opening the existing overlay editor, with a marker showing which
forms have already been edited. Purely a discoverability change — the forms and
the editor itself are unchanged.

## Discoveries (verified in code)

- `form_builder_screen.dart`: `_pickCurrentForm()` already opens
  `_OverlayEditorScreen(meta: FormMetadata)` for a chosen built-in form. The
  body currently renders only the `custom_form_templates` list + a "New form" FAB.
- `kFormMetadataRegistry` (`lib/utils/form_metadata.dart`) lists every built-in
  form with `formType`, `title`, `category`.
- `form_overlay_data.dart` has `loadFormOverlay(formType)` (single) and
  `saveFormOverlay(...)`. Overlay rows are `custom_form_templates` rows with
  `base_form_type` not null. `FormOverlay.hasContent` tells whether an overlay
  actually customizes anything.

## Design

### Data layer — `lib/utils/form_overlay_data.dart`
Add a bulk loader:

```dart
/// form_types whose saved overlay actually customizes the form (non-empty).
Future<Set<String>> loadEditedFormTypes() async { ... }
```
- One query: `select code, overlay from custom_form_templates where base_form_type is not null`.
- Return the set of `code`s whose `FormOverlay.fromMap(overlay).hasContent` is true.

### Pure helper — `lib/utils/form_metadata.dart` (or a small new util)
Add a pure, unit-tested grouping:

```dart
/// Ordered category -> forms, preserving first-seen category order and the
/// registry's within-category order.
Map<String, List<FormMetadata>> groupFormsByCategory(List<FormMetadata> forms);
```

### Screen — `lib/screens/form_builder_screen.dart`
- In `initState`/`_load`, also fetch `loadEditedFormTypes()` into state
  (`Set<String> _edited`), best-effort (failure → empty set, never blocks the
  custom-forms list).
- Render the body as two labelled sections inside the existing `PageBody.list`:
  1. **"Current forms"** (heading + helper text "Tap a form to add fields, or
     hide / relabel its existing ones."): for each category from
     `groupFormsByCategory(kFormMetadataRegistry)`, a small category subheading
     then a tile per form — `ListTile(title: form.title, subtitle: category,
     trailing: "Edited" chip when `_edited.contains(form.formType)`, onTap: →
     `_OverlayEditorScreen(meta: form)`). Reuse the existing push used by
     `_pickCurrentForm` (extract a `_openOverlayEditor(FormMetadata)` helper so
     both the ✎ icon and the list call it).
  2. **"Custom forms"** (existing list of `custom_form_templates` the admin
     built from scratch), with the current empty-state text.
- The ✎ "Edit a current form" app-bar icon stays (now redundant but harmless);
  it calls the same `_openOverlayEditor` via the picker.
- After returning from the editor (`saved == true` or always), reload so the
  "Edited" chips refresh.

## Testing — `test/form_metadata_test.dart` (or extend an existing test file)
`groupFormsByCategory`:
- Groups by category; preserves category first-seen order and within-category
  order.
- A single-category input yields one group with all forms.
- Empty input yields an empty map.

## Files

New:
- `test/form_metadata_test.dart` (if none exists for this).

Edited:
- `lib/utils/form_overlay_data.dart` (`loadEditedFormTypes`)
- `lib/utils/form_metadata.dart` (`groupFormsByCategory`)
- `lib/screens/form_builder_screen.dart` (visible current-forms list)

No migration. No new dependency.

## Verification

`flutter analyze` clean · `flutter test` green (existing + grouping tests) ·
`flutter build windows --release`. Visual pass (the user): Form Builder now shows
every built-in form grouped by category; tapping one opens the editor; edited
forms show the chip.

## Non-goals

- No change to the forms themselves, the overlay editor, or the PDF.
- No reorder/retype (Ship 2).
- No change to Appointment Builder / Form Designer (they author custom +
  appointment templates; out of scope here).
