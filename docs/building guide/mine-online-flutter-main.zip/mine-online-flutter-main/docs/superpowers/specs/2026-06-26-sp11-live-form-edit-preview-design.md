# SP11 — Live form-edit preview

**Date:** 2026-06-26
**Status:** Approved (design)

## Goal

When an admin edits a current form in the overlay editor, show the **whole form
rendered live**, reflecting every unsaved edit as it's made: added
fields/pages/**tables**, hide/relabel of existing fields, and field reorder. So
"see the edit visually and add a table and more" works in real time, not only
after Save.

## Problem (verified in code)

Every overlay-aware path loads the overlay from the DB by `form_type`:
- bespoke screens: `_loadOverrides()` → `loadFieldOverrides(formType)` (and
  `loadFormOverlay` for `early_shift_record`'s `order`);
- `FormOverlayHost(formType, …)` → `loadFormOverlay(formType)` for added
  fields/pages.

So the editor's existing "Preview" shows the **saved** overlay, never the
in-editor unsaved edits. Adding a table already works (the "Added fields" editor
has a Table button + column editor), but you can't *see* it until you Save.

## Architecture — injected overlay override

Add an optional in-memory `FormOverlay` that, when present, is used **instead of**
the DB load. The editor's live preview passes the current `_build()` overlay; in
every normal flow the override is `null`, so the 27 forms load from the DB and
render **byte-identically to today**. The change is inert outside the preview.

### 1. `lib/models/form_view_args.dart`
Add `final FormOverlay? overlayOverride;` (import `form_overlay.dart`), wired
through the const constructor (default `null`). Document: "When set, the form
renders this in-memory overlay instead of loading the saved one — used by the
Form Builder live preview."

### 2. `lib/widgets/form_builder/form_overlay_host.dart`
Add `final FormOverlay? overlayOverride;`. In `_load`, when
`widget.overlayOverride != null`, use it directly and skip the Supabase read:
```dart
Future<void> _load() async {
  if (widget.overlayOverride != null) {
    setState(() { _overlay = widget.overlayOverride; _loaded = true; });
    return;
  }
  // ... existing DB load unchanged ...
}
```
Also rebuild when the override changes (`didUpdateWidget` → if
`overlayOverride` differs, re-run `_load`) so the live preview updates.

### 3. Screen sweep — the 26 bespoke form screens
Each screen that has a `FormOverlayHost(` + a `_loadOverrides()` gets two inert
edits. The list (from grep): early_shift_record, weekly_sherq_meeting,
trackless_machinery_inspection, waiting_place_inspection, special_instruction,
shift_boss, special_brief_instruction_register, shift_boss_daily_report,
safety_health_rep, rock_breaker_inspection, refuge_bay_inspection,
relieving_miner, planned_task_observation, miner_appointment,
monthly_fire_fighting_inspection, machinery_operators,
lockout_lock_scissor_checklist, inspection_control_sheet, late_shift_record,
gassing_incident, explosive_control_record, emergency_drill,
emergency_drill_exercise, conveyor_belt_inspection, belt_tip_area_inspection,
action_log_underground_visits.

**Recipe (uniform):**

(a) In `_loadOverrides()`, prefer the override before the DB load:
```dart
Future<void> _loadOverrides() async {
  final override = widget.viewArgs?.overlayOverride;
  if (override != null) {
    setState(() => _overrides = override.fieldOverrides);
    return;
  }
  final o = await loadFieldOverrides('<formType>');
  if (!mounted || o.isEmpty) return;
  setState(() => _overrides = o);
}
```
For `early_shift_record` (which also tracks `_order`), the override branch sets
`_order = override.order` too, and the DB branch keeps using `loadFormOverlay`.

(b) In the `FormOverlayHost(...)` call, add:
```dart
overlayOverride: widget.viewArgs?.overlayOverride,
```

Both edits are **no-ops when the override is null** (the DB path runs exactly as
before), so a normally-opened form is unchanged. Screens whose state field for
overrides is named differently, or that load in `didChangeDependencies` instead
of `initState`, keep their structure — only the override-preference branch + the
host param are added.

> If a screen has no `_loadOverrides()` (not override-instrumented) it still gets
> the `FormOverlayHost` `overlayOverride:` param so added fields preview live.

### 4. Editor live preview — `lib/screens/form_builder_screen.dart`
In `_OverlayEditorScreen`:
- Keep `_build()` (the in-progress overlay) as the preview source.
- Add a debounced preview rebuilder: a `Timer? _previewDebounce` and an
  `int _previewRev` bumped ~350 ms after the last edit (call a `_schedulePreview()`
  from every mutator/`setState` path, or wrap `setState`). The preview widget is
  keyed by `_previewRev` so it rebuilds only when editing settles (keeps typing
  smooth and avoids rebuilding signature pads on every keystroke).
- Layout: on wide width (`LayoutBuilder`, ≥ ~900 px) show **editor | live
  preview** side by side (each in its own scroll view, ~50/50 or 5/4). On narrow,
  a SegmentedButton/tab toggles **Edit / Preview**.
- The preview renders:
  ```dart
  KeyedSubtree(
    key: ValueKey('preview_$_previewRev'),
    child: buildFormView(
      widget.meta.formType,
      FormViewArgs(mode: FormMode.view, overlayOverride: _build()),
    ) ?? const Text('No preview for this form.'),
  )
  ```
  `mode: view` makes it read-only (forms already disable inputs in view mode via
  `AbsorbPointer`). The existing app-bar "Preview" button can stay (full-screen
  preview) or be removed in favour of the inline pane — keep it for narrow-screen
  fallback.

## Testing

This is UI/integration; pure-logic surface is thin. Add a focused widget/logic
test only where cheap:
- `FormOverlayHost` with `overlayOverride` set renders the override's added
  fields without any Supabase call (pump it with a non-empty override and assert
  the added field's label appears; assert an empty/absent override renders
  `SizedBox.shrink`). If Supabase-client construction in a widget test is
  awkward, cover the override-selection logic by asserting
  `FormViewArgs(overlayOverride: o).overlayOverride == o` and rely on
  analyze/build + the manual pass for the rest.

Otherwise verification is `flutter analyze` + `flutter test` (existing suite must
stay green — the sweep must not change byte output when override is null) +
`flutter build windows --release`, plus the user's manual pass.

## Files

Edited:
- `lib/models/form_view_args.dart` (overlayOverride)
- `lib/widgets/form_builder/form_overlay_host.dart` (overlayOverride + didUpdateWidget)
- `lib/screens/form_builder_screen.dart` (live preview pane + debounce)
- 26 bespoke form screens (inert override-preference + host param)

No migration, no new dependency, no PDF change.

## Non-goals / safety

- The override is `null` in every non-preview flow → the 27 forms are unchanged
  (the primary safety property; the existing test suite guards it).
- The preview is read-only (`mode: view`); it never submits or writes.
- No change to submission payloads, the signature chain, or PDFs.
- Reorder only visibly reflects on forms that are reorder-instrumented
  (currently `early_shift_record`); hide/relabel reflects on catalogued forms;
  added fields/pages/tables reflect on all — matching today's capabilities, now
  shown live.
