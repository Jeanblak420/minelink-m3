# SP8 — Reports (Daily / Weekly / Monthly + PDF export)

**Date:** 2026-06-25
**Status:** Approved (design)
**Fills:** sidebar placeholders `/reports/daily`, `/reports/weekly`, `/reports/monthly`

## Goal

Give Admin / Super Admin a period compliance report over real app data. The
three sidebar leaves (Daily / Weekly / Monthly) are the **same report** over a
different date window. Each report has two parts:

1. **Compliance summary** — KPIs + breakdowns for the period.
2. **Submission register** — a line-item table of every form submitted in the
   window.

Reports are **on-demand only** (no persisted/scheduled reports, no new tables —
that can be a later SP). Export is **PDF** via the existing `pdf`/`printing`
stack. No new dependencies.

This reuses the SP7 analytics idioms (client-side aggregation, `sortedDesc`,
the `_bump` counting pattern) and the SP2 custom-form PDF approach
(`pw.MultiPage` auto-pagination).

## Non-goals

- No CSV export (PDF only — decided).
- No persisted/saved reports, no scheduling, no new DB table or RPC.
- No "system performance" metrics (same call as SP7 — meaningless here).
- Existing forms/PDFs untouched — this is purely additive.

## Period semantics

A pure helper computes the window from a period + anchor date:

```
ReportWindow reportWindow(ReportPeriod period, DateTime anchor)
  // returns { start (inclusive), end (exclusive), label }
```

- **daily** — the single calendar day of `anchor`. `start` = anchor at 00:00,
  `end` = next day 00:00. Label e.g. `Tuesday, 24 June 2026`.
- **weekly** — the Mon–Sun week containing `anchor`. `start` = Monday 00:00,
  `end` = following Monday 00:00. Label e.g. `Week of 22–28 June 2026`.
- **monthly** — the calendar month of `anchor`. `start` = 1st 00:00, `end` =
  1st of next month 00:00. Label e.g. `June 2026`.

Windows are computed in **local time** (the user reasons about "today" locally),
then converted to UTC ISO for the Supabase range queries. Defaults: today / this
week / this month. The screen offers a date picker to move the anchor.

Boundary correctness (inclusive start, exclusive end; month/year rollover; week
starting Monday) is the primary unit-test target.

## Data layer — `lib/utils/report_data.dart`

Mirrors `analytics_data.dart`: a pure `computeReport(...)` (unit-tested) plus a
thin `loadReport(...)` that fetches windowed rows and delegates.

```dart
enum ReportPeriod { daily, weekly, monthly }

class ReportWindow {
  final DateTime start;   // inclusive, local
  final DateTime end;     // exclusive, local
  final String label;     // human period label
}

class ReportRow {
  final DateTime? date;       // created_at
  final String formType;      // raw form_type
  final String formLabel;     // human label via form_metadata, fallback to type
  final String submitter;     // resolved name, fallback email / "Unknown user"
  final String status;        // workflow_status, fallback "—"
  final Map<String, dynamic> raw; // the submission row (future: tap-to-open)
}

class ReportSummary {
  final ReportPeriod period;
  final ReportWindow window;
  // KPIs
  final int submissions;
  final int fullySigned;
  final int pendingInChain;
  final int incidents;
  final int appointmentsIssued;
  final int appointmentsAccepted;
  final double signatureCompletionRate;
  // Breakdowns (sorted desc at render time)
  final Map<String, int> byFormType;   // keyed by human label
  final Map<String, int> byStatus;
  // Register
  final List<ReportRow> register;      // newest-first
}
```

`computeReport` signature (all rows pre-fetched, pure):

```dart
ReportSummary computeReport({
  required ReportPeriod period,
  required ReportWindow window,
  required List<Map<String, dynamic>> submissions,      // in-window
  required List<Map<String, dynamic>> appointments,     // in-window (issued_at)
  required List<Map<String, dynamic>> signatureRequests,// in-window
  required Map<String, Map<String, dynamic>> profiles,  // id -> profile row
});
```

Reused constants/helpers (no duplication):
- `kAppointmentFormTypes`, `kIncidentFormTypes`, `kPendingWorkflowStatuses` from
  `admin_dashboard_data.dart`.
- `sortedDesc(...)` from `analytics_data.dart`.
- Human form labels from `lib/utils/form_metadata.dart` (fallback to raw type).
- Submitter name resolution mirrors `admin_dashboard_data.dart` (`full_name` →
  `email` → "Unknown user").

KPI derivation:
- `submissions` = count of in-window submissions.
- `fullySigned` = `workflow_status == 'fully_signed'`.
- `pendingInChain` = `workflow_status in kPendingWorkflowStatuses`.
- `incidents` = `form_type in kIncidentFormTypes`.
- `appointmentsIssued` = appointments rows in window; `appointmentsAccepted` =
  those with non-null `accepted_at`.
- `signatureCompletionRate` = signed / total signature_requests in window
  (0.0 when none).

`loadReport(ReportPeriod period, DateTime anchor)`:
- compute `window` via `reportWindow`.
- fetch `form_submissions` (`id,user_id,form_type,title,workflow_status,
  current_signature_role,created_at`) where `created_at >= start && < end`,
  `.limit(5000)`, order created_at desc.
- fetch `appointments` (`status, accepted_at, issued_at`) in window by
  `issued_at`.
- fetch `signature_requests` (`status, created_at`) in window.
- fetch `profiles` for the distinct submitter `user_id`s (inFilter), like the
  dashboard loader.
- delegate to `computeReport`.

## PDF — `lib/pdf/generate_report_pdf.dart`

`Future<pw.Document> generateReportPdf(ReportSummary s, {DateTime? generatedAt})`
using `pw.MultiPage` (auto-pagination — same approach as
`generate_custom_form_pdf.dart`), Roboto bundled for Unicode, letter format.

Layout:
- **Header** (page 1): "Mine Online" eyebrow, report title
  (`Daily/Weekly/Monthly Report`), period label, "Generated: <date>".
- **Summary** section: a compact KPI table (label → value) for the seven KPIs.
- **Breakdowns**: "By form" and "By workflow status" two-column count tables
  (sorted desc).
- **Register**: a `Date | Form | Submitter | Status` table that flows across
  pages. Empty-state row when no submissions.
- **Footer**: page numbers (`Page x of y`).

A pure `reportPdfValueString(...)`-style helper (if any non-trivial formatting)
is unit-test-exposed; otherwise formatting stays inline.

## Screen — `lib/screens/reports_screen.dart`

One `ReportScreen(period: ReportPeriod)` backs all three routes (variant pattern
like `FormSubmissionHistoryScreen` / `AdminAppointmentsLogbookScreen`).

- Admin gate via `isAdminProfile(profile)` — same guard + "available to Admin
  and Super Admin" fallback body as `analytics_screen.dart`.
- AppBar: title (`Daily/Weekly/Monthly Reports`), back button, **Export PDF**
  action (`Printing.layoutPdf(onLayout: ... generateReportPdf(...).save())`),
  Refresh, then `commonAppBarActions()`.
- Body: an anchor picker (a date picker; the chosen date is interpreted per the
  period), the period label, KPI cards (reuse `KpiStatCard` + the `_statTile`
  idiom), the two breakdown `MiniBarChart`s, and the register as a simple
  `DataTable`/list. Loading + error states like the analytics screen.
- Uses `PageBody.list` for layout parity.

## Routing — `lib/routing/router.dart`

- Remove the three `'/reports/*'` entries from the `adminStubs` map in
  `_placeholders()` (leave the two web-parity stubs).
- Add three real `GoRoute`s near the other admin routes:
  `/reports/daily` → `ReportScreen(period: ReportPeriod.daily)`, etc.

## Testing — `test/report_test.dart` (TDD, pure logic only)

- `reportWindow` boundaries: daily start/end; weekly starts Monday & spans 7
  days; monthly start = 1st, end = next month 1st; month/year rollover (Dec →
  Jan); end is exclusive.
- `computeReport`: KPI counts (fully-signed, pending, incidents, appointments
  issued/accepted, signature completion), breakdown maps keyed by human label,
  register newest-first ordering, submitter name resolution + fallbacks, empty
  input → zeros / empty register / 0.0 rate.

## Files touched

New:
- `lib/utils/report_data.dart`
- `lib/pdf/generate_report_pdf.dart`
- `lib/screens/reports_screen.dart`
- `test/report_test.dart`

Edited:
- `lib/routing/router.dart` (3 stubs → 3 real routes)

No migration. No new dependency.

## Verification

`flutter analyze` (clean) · `flutter test` (existing 44 + new report tests
pass) · `flutter build windows --release`. Visual `flutter run -d windows` pass
is the user's.
