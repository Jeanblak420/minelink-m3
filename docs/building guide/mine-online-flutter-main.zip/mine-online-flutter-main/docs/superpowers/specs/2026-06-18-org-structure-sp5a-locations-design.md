# Org Structure SP5a — Locations (Shafts → Sections → Areas) — Design

**Date:** 2026-06-18
**Status:** Approved (standing approval) for build
**Parent:** SP5 Org structure — first slice (unblocks SP3 Appointment Builder /
SP4 Appointments lifecycle, which need shaft/section/area pickers).

## Goal

Give Admin/Super Admin a Locations admin screen to manage the
**Shaft → Section → Area** hierarchy with real CRUD (create / edit / archive /
restore), backed by Supabase. Other features (appointments, gangs) will read
this hierarchy.

## Data model

- **Reuse the existing `public.shafts`** table (8 live rows): `id` uuid,
  `shaft_name` text, `description` text, `is_active` bool, timestamps. The Dart
  `Shaft` model maps `shaft_name` → `name`.
- **New `public.sections`**: `id` uuid pk, `shaft_id` uuid FK→shafts (cascade),
  `name` text, `description` text, `is_active` bool default true, timestamps.
- **New `public.areas`**: `id` uuid pk, `section_id` uuid FK→sections (cascade),
  `name` text, `description` text, `is_active` bool default true, timestamps.
- RLS on all three (drop+recreate for shafts since it pre-exists): authenticated
  read active rows (admins read all); admins insert/update via
  `public.is_admin(auth.uid())`. Archive = `is_active=false` (no row deletes).
- Migration authored + applied by us via the Management API.

## Components

- `lib/models/org_location.dart` — `Shaft`, `Section`, `Area` (+ `fromMap`/`toMap`),
  all with `id/name/description/isActive` and the parent id where relevant.
- `lib/utils/org_data.dart` — `loadShafts/loadSections/loadAreas({includeArchived})`,
  `saveShaft/saveSection/saveArea` (insert or update), `setShaftActive/…`. Mirrors
  the `custom_form_data.dart` query pattern.
- `lib/screens/setup/locations_screen.dart` — admin-gated (`isAdminProfile`); a
  three-level expandable hierarchy: shafts (ExpansionTile) → sections → areas,
  each with add / edit / archive-restore. A shared name+description editor dialog.
- `lib/routing/router.dart` — replace the `/setup/locations` placeholder with the
  real screen.

## Testing

- Unit-test a pure `groupByParent` helper used to build the hierarchy (sections
  grouped by `shaft_id`, areas by `section_id`).
- `flutter analyze` clean, `flutter test` green, `flutter build windows --release` OK.
- Manual: open `/setup/locations` from the sidebar (Setup → Locations) as admin;
  the 8 existing shafts list; add a section under one and an area under that;
  edit + archive + restore work; a non-admin sees the access-required message.

## Constraints

- No new dependencies. No "Claude"/AI naming. RLS gated by `public.is_admin`.
