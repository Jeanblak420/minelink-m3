# Form Builder SP2.3 — Signature chain for built forms — Design

**Date:** 2026-06-17
**Status:** Approved for planning
**Parent:** SP2 Form Builder (final phase — completes full parity).

## Goal

Let an admin mark a custom form as requiring sign-off, and have built-form
submissions flow through the **existing** signature workflow (request → sign →
complete) with the signatures shown in the PDF — **without any edge-function
changes**.

## Key finding (why this is small)

The `signature-workflow` edge function does not read `required_signers` from any
table. It has a hard-coded `signatureRules` list keyed on **payload signature
field paths** — notably `signatures.mineOverseerSignature` (order 10) and
`signatures.mineManagerSignature` (order 20) — and drives the chain by finding
the next *blank* recognized field. Signing uses the signer's saved profile
signature (`signSignatureRequest`), and document review uses the SP2.2 PDF — so
**no custom view-mode is required**.

Therefore a custom form joins the chain simply by carrying those recognized
blank signature fields in its payload at submit time.

## Changes

- **`lib/utils/dynamic_form_payload.dart`** — add pure
  `applyCustomChainSignatureFields(List<String> requiredSigners, Map payload)`:
  for each supported signer (`mine_overseer`, `mine_manager`) put a blank
  `signatures.<role>Signature` + date field into the payload (under a
  `signatures` map); returns true if any were added (→ this is a chain
  submission). Supported-signer map is the single source of truth.
- **Builder editor (`form_builder_screen.dart`)** — add a "Signature workflow"
  section: FilterChips for **Mine Overseer** and **Mine Manager** (values
  `mine_overseer`, `mine_manager`); Shift Boss is the submitter. Persist via the
  existing `required_signers` column (already on the table + in `saveTemplate`).
  Initialise from the existing template when editing.
- **Fill submit (`custom_forms_screen.dart`)** — after building the payload,
  call `applyCustomChainSignatureFields`. If it returns true, submit with
  `saveFormSubmissionAndStartWorkflow(code, name, payload, profile: currentProfile)`;
  otherwise keep `persistFormSubmission`. Surface workflow errors via SnackBar.
- **PDF (`generate_custom_form_pdf.dart`)** — after the field blocks, if the
  payload has any recognized chain signature fields, render an **"Approvals"**
  section: one row per signer (Mine Overseer / Mine Manager) showing the
  embedded signature image, or "Pending" when blank.

## Non-goals

- No edge-function changes; no new signature-request screens (the existing
  `/signature-requests` handles sign / send-back / complete generically).
- No custom form view-mode in `buildFormView` (signers review via the PDF). A
  future nicety, not needed here.
- Shift Boss is not a chain step (it is the submitter); no shift-boss
  auto-stamp is wired for custom forms (`kShiftBossSignaturePathByFormType` has
  no custom entry, so `applyShiftBossAutoStamp` is a safe no-op for them).

## Testing

- Unit-test `applyCustomChainSignatureFields`: empty/unknown signers → false, no
  mutation; `mine_overseer` → adds blank `signatures.mineOverseerSignature` +
  date and returns true; existing non-empty signature values are preserved
  (`putIfAbsent`); both signers add both field sets.
- `flutter analyze` clean, `flutter test` green, `flutter build windows --release` OK.
- Manual: build a form with Mine Overseer + Mine Manager required; submit as a
  Shift Boss; confirm it appears in `/signature-requests` for the Mine Overseer,
  signs through to Mine Manager, completes; the PDF shows the Approvals section
  with the captured signatures.

## Constraints

- No new dependencies. No "Claude"/AI naming. Reuses existing workflow + PDF.
