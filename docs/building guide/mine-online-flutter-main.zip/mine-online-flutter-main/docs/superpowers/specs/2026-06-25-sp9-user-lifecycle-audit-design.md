# SP9a — User Lifecycle + Audit Trail

**Date:** 2026-06-25
**Status:** Approved (design)
**Scope:** First slice of SP9 (user lifecycle + audit logs). The
submission-review queue is a separate later slice and is NOT in this spec.

## Goal

Give Super Admins the ability to **disable / re-enable** user accounts (a real
suspend, not just cosmetic) and **change roles with an audit trail**, and give
Admins a **read-only Audit Log** screen. Build on the existing, already-populated
`public.audit_log` table rather than inventing a new one.

## Discoveries that shape this (verified against the live DB)

- `public.audit_log` **already exists and is live** — 360 rows, written by the
  `admin-create-user` edge function on `user.create` / `user.delete` /
  `user.update_password`. The HANDOFF's "vestigial audit_log" note is **stale**;
  this is the real table. Columns: `id uuid`, `user_id uuid` (the actor),
  `action varchar`, `entity_type varchar`, `entity_id uuid`, `old_values jsonb`,
  `new_values jsonb`, `ip_address`, `user_agent`, `created_at timestamptz`.
- Its only RLS policy is `"Allow public read audit_log"` with `USING (true)` —
  i.e. the audit log is **world-readable**. This spec tightens it.
- `public.profiles` has **no** disable/active/status column. It has `email`,
  `full_name`, `is_super_admin bool`, `user_account_type text`.
- `profiles` UPDATE is **Super-Admin-only** for other users (policy "Users and
  super admins can update profiles"). The edge function is also super-admin
  gated. So lifecycle writes are Super Admin; audit *viewing* will be Admin.
- `public.is_admin(uid uuid)` exists (used for the new read policy).
- `AuthProvider` already `_fetchProfile`s and subscribes to `profile:$id`
  realtime updates — the natural hook for immediate disable-lockout.

## Non-goals

- No submission-review queue (separate SP9 slice).
- No new audit table (reuse `audit_log`).
- No bulk user import, no password-policy changes, no email/invite flow changes.
- Existing forms / PDFs untouched.

## Data model changes — migration `supabase/migrations/<ts>_sp9_user_lifecycle_audit.sql`

1. **profiles disable columns**
   ```sql
   alter table public.profiles
     add column if not exists disabled boolean not null default false,
     add column if not exists disabled_at timestamptz;
   ```

2. **Tighten audit_log read to admins** (security fix)
   ```sql
   drop policy if exists "Allow public read audit_log" on public.audit_log;
   create policy "Admins read audit_log" on public.audit_log
     for select to authenticated
     using (public.is_admin(auth.uid()));
   ```
   No INSERT/UPDATE/DELETE policy is added — only the service role (edge
   function) and the SECURITY DEFINER trigger write, both of which bypass RLS.

3. **Role-change audit trigger** (audits the existing client-side profile edit
   path, actor = the admin doing it)
   ```sql
   create or replace function public.fn_audit_profile_role_change()
   returns trigger
   language plpgsql
   security definer
   set search_path = public
   as $$
   begin
     if new.user_account_type is distinct from old.user_account_type then
       insert into public.audit_log
         (user_id, action, entity_type, entity_id, old_values, new_values)
       values
         (auth.uid(), 'user.role_change', 'user', new.id,
          jsonb_build_object('user_account_type', old.user_account_type),
          jsonb_build_object('user_account_type', new.user_account_type));
     end if;
     return new;
   end;
   $$;

   drop trigger if exists trg_profiles_audit_role on public.profiles;
   create trigger trg_profiles_audit_role
     after update on public.profiles
     for each row execute function public.fn_audit_profile_role_change();
   ```
   The trigger watches **only** `user_account_type` — `disabled` changes are
   audited by the edge function (where `auth.uid()` is the service role and would
   be a useless actor), so the trigger must not double-log them.

All three applied via the Management API (PAT in Credential Manager) AND written
to the migrations folder.

## Edge function — `supabase/functions/admin-create-user/index.ts`

Add one **additive, backward-compatible** action (the web app only sends
create/delete/update_password, so it is unaffected):

```ts
if (action === "set_disabled") {
  if (!userId || typeof body.disabled !== "boolean") { /* 400 */ }
  const disabled = body.disabled as boolean;
  // 1) real enforcement: ban / unban the auth user
  const { error: banErr } = await supabaseAdmin.auth.admin.updateUserById(
    userId,
    { ban_duration: disabled ? "876000h" : "none" }, // ~100y ban, or lift
  );
  if (banErr) { /* 400 with banErr.message */ }
  // 2) reflect on the profile (for UI + AuthProvider lockout)
  await supabaseAdmin.from("profiles").update({
    disabled,
    disabled_at: disabled ? new Date().toISOString() : null,
  }).eq("id", userId);
  // 3) audit
  await writeAuditLog(supabaseAdmin, callerUser.id, {
    action: disabled ? "user.disable" : "user.enable",
    entity_id: userId,
  });
  return /* 200 { success: true } */;
}
```

Redeploy via the Management API (`POST /v1/projects/<ref>/functions` deploy, or
the deploy MCP tool if available) after editing the file.

## Flutter changes

### Models / providers
- `lib/models/user_profile.dart`: add `final bool disabled;` parsed from
  `map['disabled'] == true` in `fromMap` (default false).
- `lib/providers/auth_provider.dart`: after `_fetchProfile` and inside the
  realtime update callback, if the resulting profile is non-null and
  `disabled == true`, call `signOut()` and set a public
  `String? lockoutMessage` ("Your account has been disabled. Contact an
  administrator.") so the login screen can show it. Guard against loops (only
  sign out when currently signed in).

### Utilities
- `lib/utils/role_access.dart`: add
  ```dart
  bool isSuperAdminProfile(UserProfile? profile) {
    if (profile == null) return false;
    return profile.isSuperAdmin || profile.userAccountType == 'Super Admin';
  }
  ```
- `lib/utils/admin_user.dart`: add
  ```dart
  Future<AdminUserResult> adminSetUserDisabled({
    required String userId,
    required bool disabled,
  }) => _invoke({'action': 'set_disabled', 'userId': userId, 'disabled': disabled});
  ```
- `lib/utils/audit_data.dart` (new):
  - `class AuditEntry` — `id, actorId, action, entityType, entityId, oldValues,
    newValues, createdAt` (parsed from a row).
  - Pure **`String describeAuditEntry(AuditEntry e, {String? actorName, String? targetName})`** — maps action → sentence:
    - `user.create` → "{actor} created an account for {target}"
    - `user.delete` → "{actor} deleted {target}'s account"
    - `user.update_password` → "{actor} reset {target}'s password"
    - `user.disable` → "{actor} disabled {target}'s account"
    - `user.enable` → "{actor} re-enabled {target}'s account"
    - `user.role_change` → "{actor} changed {target}'s role from {old} to {new}"
      (reads `old_values`/`new_values` `user_account_type`)
    - fallback → "{actor} performed {action} on {entityType} {target}"
    - Missing actor/target names degrade to "An administrator" / "a user".
  - `Future<List<AuditEntry>> loadAuditLog({int limit = 200, String? action})`
    — selects from `audit_log` ordered `created_at desc`, optional `.eq('action')`.
  - `Future<Map<String,String>> loadActorTargetNames(List<AuditEntry>)` — one
    `profiles` `inFilter` over the union of actor + entity ids → id→display name.

### Screens
- `lib/screens/profiles_screen.dart`: for **super admins**, add a Disable /
  Enable affordance per user row (confirm dialog → `adminSetUserDisabled` →
  refresh), and a "Disabled" badge on rows where `disabled == true`. Admins who
  aren't super-admin don't see the control (parity with the DB gate).
- `lib/screens/setup/audit_log_screen.dart` (new): admin-gated (`isAdminProfile`).
  Loads `loadAuditLog()` + names, renders a list of `describeAuditEntry` lines
  with relative/absolute time and the raw action chip; a filter row of action
  chips (All / Role changes / Disable-enable / Account create-delete /
  Passwords). Loading + error states mirror `analytics_screen.dart`.

### Routing / nav
- `lib/routing/router.dart`: add `GoRoute('/setup/audit-log')` → `AuditLogScreen`.
- `lib/widgets/admin/admin_sidebar.dart`: add a Setup leaf
  `SidebarLeaf('Audit Log', Icons.fact_check_outlined, '/setup/audit-log', accent: …)`.

## Testing — `test/audit_test.dart` (TDD, pure logic)

`describeAuditEntry` for: create, delete, update_password, disable, enable,
role_change (with old→new), unknown-action fallback, and missing-name
degradation. No DB/IO in tests.

## Files

New:
- `lib/utils/audit_data.dart`
- `lib/screens/setup/audit_log_screen.dart`
- `test/audit_test.dart`
- `supabase/migrations/<ts>_sp9_user_lifecycle_audit.sql`

Edited:
- `supabase/functions/admin-create-user/index.ts` (+ redeploy)
- `lib/models/user_profile.dart`
- `lib/providers/auth_provider.dart`
- `lib/utils/role_access.dart`
- `lib/utils/admin_user.dart`
- `lib/screens/profiles_screen.dart`
- `lib/routing/router.dart`
- `lib/widgets/admin/admin_sidebar.dart`

## Verification

`flutter analyze` clean · `flutter test` green (existing + new audit tests) ·
`flutter build windows --release`. Migration applied + edge function deployed via
Management API and smoke-checked (a disable/enable round-trip writes two audit
rows and flips `profiles.disabled`). Visual `flutter run -d windows` is the
user's pass.

## Risks / parity notes

- The shared edge function change is purely additive — the web app's existing
  three actions are untouched.
- Tightening `audit_log` SELECT to admins is a deliberate security fix. If the
  web app currently reads `audit_log` as a non-admin it would lose that read;
  that would have been an unintended exposure. Acceptable and correct.
- The `ban_duration` approach blocks re-login/refresh; existing access tokens
  stay valid until expiry (~1h), so the AuthProvider profile-realtime lockout is
  the immediate-effect complement.
