# SP4 — Appointments Lifecycle — Design

**Date:** 2026-06-21
**Status:** Approved (standing autonomy grant)
**Sub-project:** SP4 of the "absorb legacy Mine-On-Line admin feature set" program.
**Predecessor:** SP3 (Appointment Builder + Letter Builder — roles + templates catalog).
**Successors:** SP6 Devices, SP7 Analytics, SP8 Reports, SP9 user-lifecycle / audit.

---

## 1. Goal

Turn SP3's appointment **templates** into live, issued, signed **appointments**.
An admin issues an appointment to a named person against a role + template; the
appointee accepts and signs it; where the template requires it, Mine Overseer /
Mine Manager co-sign via the existing signature chain; the appointment becomes
active; the appointee or an admin can later resign it. One live appointment per
person/role/shaft/month is enforced.

## 2. Key architectural decision — reuse the signature chain

The app already has a robust co-sign mechanism: the `signature-workflow` edge
function drives a Mine Overseer (order 10) → Mine Manager (order 20) chain off
recognized payload signature paths (`signatures.mineOverseerSignature`,
`signatures.mineManagerSignature`), creating `signature_requests` rows, advancing
the chain, and creating server-side `notifications` (in-app + email). SP3
templates already carry `required_signers` drawn from exactly those two roles
(`kChainSignerLabels`).

So SP4 does **not** reinvent co-signing. The appointee's *acceptance* is the
analog of the web form's "shift boss submits + auto-stamps" moment; the template's
`required_signers` are the analog of the overseer/manager chain. On acceptance of
a template that needs co-signers, we create a `form_submissions` row and call
`start_workflow` — the existing chain + the existing `/signature-requests` screen
handle the rest. **The edge function is not modified.**

A dedicated `appointments` table sits on top as the legal lifecycle record and
links to the co-sign `form_submissions` row via `submission_id`.

## 2a. Addendum (user direction, 2026-06-21) — built-in appointment forms

The lifecycle must also drive the **3 existing hardcoded appointment forms**
(`shift_boss_appointment`, `miner_appointment`, `relieving_miner_appointment`),
not only SP3 dynamic templates. They run the same **issue → appointee accepts &
signs → co-sign → resign** flow, reusing their existing form screens + PDFs.

- An appointment references **either** an SP3 dynamic template (`template_id`, a
  `appt_…` form_type) **or** a built-in form (`form_type` ∈ the 3 above,
  `template_id` null). A new nullable `appointments.form_type` column holds the
  submission/render form_type for both kinds (for dynamic it equals the template
  `code`).
- **Issue** of a built-in creates only the lifecycle shell (appointee + shaft +
  cycle + effective date); there are no admin-filled fields — the appointee fills
  the real form at acceptance.
- **Accept** branches by kind: dynamic → the signature-pad accept already
  specified (§6); built-in → open the existing form screen (fill mode), which
  submits + auto-stamps the appointee's signature + starts the chain exactly as
  today; a new optional `onSubmitted(submissionId)` callback on those 3 screens
  lets the inbox link the submission to the appointment and move it to
  `pending_signoff`. The `activate_on_signoff` trigger then activates it on chain
  completion — unchanged.
- A small const catalog `lib/utils/appointable_forms.dart` lists the built-in
  appointable forms (code, label, screen-open builder, hasChain).

**Deferred to a NEW sub-project SP4.5** (own spec): unifying *all 27* current
forms with the custom form builder into one catalog (the user's broader
"integrate with all our current forms" ask). SP4 covers appointment forms only.

## 3. Scope

### In scope
1. `appointments` table + RLS + uniqueness + a generated `period_month` column.
2. DB triggers: (a) lifecycle notifications (issue / accept / decline / resign);
   (b) flip appointment → `active` when its linked submission becomes
   `fully_signed`.
3. Admin issue flow + monitor screen at `/setup/appointments`.
4. Appointee inbox at `/my-appointments` (accept-and-sign / decline / resign /
   view letter).
5. Co-sign reconciliation: at acceptance, stamp appointee signature + inject blank
   chain slots, insert `form_submissions`, `start_workflow`.
6. Small integration so co-signers can read the letter:
   `generatePdfForFormType` gains an `appt_` branch; the signature-requests screen
   shows "View letter PDF" for `appt_` requests.
7. Sidebar entries for the two new routes; unit tests for pure lifecycle logic.

### Out of scope (deferred)
- Full `appointment_audit_logs` table (field-level change history with reasons) →
  **SP9**. SP4 captures lifecycle via per-row timestamps + `resign_reason`.
- Gang role-capacity enforcement (`required_count` per gang role) → later.
- Multi-client / multi-shaft per appointment; `clients` table → out.
- Re-appointment automation / expiry sweeps → out (a resigned/declined row simply
  frees the uniqueness slot so a new one can be issued).
- Editing an issued appointment's fields after issue → out (resign + re-issue).

## 4. Data model

### 4.1 `appointments`
| Column | Type | Notes |
|---|---|---|
| `id` | uuid pk default `gen_random_uuid()` | |
| `template_id` | uuid null → `appointment_templates(id)` on delete set null | template used |
| `role_id` | uuid null → `appointment_roles(id)` on delete set null | |
| `role_code` | text not null | snapshot of role code/label key for uniqueness + history stability |
| `appointee_id` | uuid not null → `profiles(id)` on delete cascade | the appointed person |
| `issued_by` | uuid null → `profiles(id)` on delete set null | admin who issued |
| `shaft_id` | uuid null → `shafts(id)` on delete set null | uniqueness scope |
| `section` | text null | snapshot |
| `cycle` | text null | snapshot |
| `effective_date` | date not null | the appointment/shift date |
| `period_month` | date generated always as `(date_trunc('month', effective_date)::date)` stored | uniqueness key |
| `status` | text not null default `'pending_acceptance'` | see state machine; CHECK constraint |
| `payload` | jsonb not null default `'{}'` | field values + `letterValues` map + appointee signature |
| `submission_id` | uuid null → `form_submissions(id)` on delete set null | the co-sign document, when required |
| `resign_reason` | text null | |
| `issued_at` | timestamptz not null default now() | |
| `accepted_at` | timestamptz null | |
| `declined_at` | timestamptz null | |
| `activated_at` | timestamptz null | |
| `resigned_at` | timestamptz null | |
| `updated_at` | timestamptz not null default now() | |

`status` CHECK ∈ {`pending_acceptance`, `pending_signoff`, `active`, `declined`,
`resigned`}.

### 4.2 Uniqueness
Partial unique index:
```sql
create unique index appointments_one_live_per_slot
  on public.appointments (appointee_id, role_code, shaft_id, period_month)
  where status in ('pending_acceptance', 'pending_signoff', 'active');
```
Plus an app-level pre-check before issue for a friendly "already has a live X
appointment this month" message. Resigned/declined rows are excluded, so the slot
frees up.

### 4.3 RLS
- Enable RLS.
- **SELECT**: `appointee_id = auth.uid()` OR `public.is_admin(auth.uid())`.
- **INSERT**: admins only (`public.is_admin`). (Issuing is an admin action.)
- **UPDATE**: admins (any row) OR the appointee on their own row. Column-level
  intent (appointee may only move their own row through accept/decline/resign) is
  enforced in the data layer + the lifecycle helper, not via per-column policies
  (Postgres RLS can't do per-column easily); the trigger-set fields are server
  side. This matches how the app gates elsewhere.
- No DELETE policy (soft lifecycle only).

### 4.4 Triggers (SECURITY DEFINER, owner = postgres)
1. `appointments_notify()` — `AFTER INSERT OR UPDATE OF status` on
   `appointments`:
   - INSERT (status `pending_acceptance`): notify `appointee_id` — type
     `message`, title "New appointment", body "<Role> appointment pending your
     acceptance", `action_url` `/my-appointments`, metadata
     `{appointmentId, roleCode, status:'pending_acceptance'}`.
   - status → `pending_signoff` or `active` (i.e. the appointee accepted): notify
     `issued_by` (skip if null) — "Appointment accepted".
   - status → `declined`: notify `issued_by` — type `warning`, "Appointment
     declined".
   - status → `resigned`: notify `issued_by` — type `warning`, "Appointment
     resigned" (+ reason in metadata).
   Notifications are inserted with the trigger's definer rights, so cross-user
   inserts are allowed (Flutter cannot do this under RLS).
2. `appointments_activate_on_signoff()` — `AFTER UPDATE OF workflow_status` on
   `form_submissions`: when `NEW.workflow_status = 'fully_signed'` and an
   `appointments` row has `submission_id = NEW.id` and status `pending_signoff`,
   set that row `status='active', activated_at=now(), updated_at=now()`.

Migration file: `supabase/migrations/<ts>_sp4_appointments.sql`, written to the
repo and applied via the Management API (PAT in Windows Credential Manager
`claude-supabase-pat-hhrnkzznpadrmyverhyb`; project ref `hhrnkzznpadrmyverhyb`).

## 5. State machine

```
                 issue (admin)
                      │
                      ▼
            ┌───────────────────┐   decline (appointee)   ┌──────────┐
            │ pending_acceptance │ ───────────────────────▶│ declined │ (terminal)
            └───────────────────┘                          └──────────┘
                      │ accept (+sign)
        ┌─────────────┴──────────────┐
   no required_signers          has required_signers
        │                             │ create form_submissions + start_workflow
        ▼                             ▼
   ┌────────┐                 ┌───────────────┐  chain fully_signed   ┌────────┐
   │ active │◀────────────────│ pending_signoff│ ────────(trigger)───▶│ active │
   └────────┘                 └───────────────┘                       └────────┘
        │  resign (appointee/admin)        │ resign                        │ resign
        └───────────────┬──────────────────┴───────────────────────────────┘
                        ▼
                  ┌──────────┐
                  │ resigned │ (terminal)
                  └──────────┘
```

## 6. Components / files

**Model** — `lib/models/appointment.dart` (pure Dart; no Flutter/Supabase):
- `enum AppointmentStatus { pendingAcceptance, pendingSignoff, active, declined, resigned }`
  with `wire`/`fromWire` string mapping + a `label` for display.
- `class Appointment` (+ `fromMap`/`toMap`), getters `isLive`, `canAccept`,
  `canResign`.
- Pure helpers (unit-tested):
  - `Map<String,String> buildLetterValues(profile fields…, fieldValues)` — actually
    placed in the data/util layer since it needs profile; the pure part is
    `mergeLetterValues(Map standardTokens, Map fieldValues)` with field-key
    precedence.
  - `String? appointmentUniquenessError(...)` is data-layer (needs DB); the pure
    check `isLiveStatus(AppointmentStatus)` lives here.

**Data layer** — `lib/utils/appointment_data.dart`:
- `loadAppointments({String? appointeeId, bool adminAll})` (admin: all; appointee:
  own).
- `loadMyAppointments()` — current user's, ordered by status priority then date.
- `Future<void> issueAppointment({template, role, appointeeProfile, shaftId,
  section, cycle, effectiveDate, fieldValues})` — runs the uniqueness pre-check,
  builds `payload` (fieldValues + resolved `letterValues`), inserts row.
- `Future<void> acceptAppointment(Appointment a, AppointmentTemplate t, UserProfile
  me)` — stamps appointee signature into `payload.signatures.appointeeSignature`
  (+ date); if `t.requiredSigners` empty → update status `active`, `accepted_at`,
  `activated_at`; else inject blank chain slots
  (`injectChainSignatureFields`), `persistFormSubmission`-style insert into
  `form_submissions` (form_type = `t.code`, title), `invoke start_workflow`, set
  `submission_id` + status `pending_signoff` + `accepted_at`.
- `Future<void> declineAppointment(Appointment a)` — status `declined`,
  `declined_at`.
- `Future<void> resignAppointment(Appointment a, String reason)` — status
  `resigned`, `resigned_at`, `resign_reason`. (If `submission_id` set, leave the
  document as-is; resignation supersedes.)
- Reuses `supabase` client; mirrors `org_data.dart` shape.

**Integration** — `lib/utils/form_registry.dart`:
- `generatePdfForFormType`: add `if (formType.startsWith('appt_'))` → load the
  appointment template by code, render via SP3's `generateAppointmentLetterPdf`
  using `payload['letterValues']` (fall back to extracting from payload).

**Screens**:
- `lib/screens/setup/appointments_admin_screen.dart` — `AppointmentsAdminScreen`
  (admin-gated). Monitor list (status filter chips) + FAB "Issue appointment" →
  `_IssueAppointmentFlow` (template picker from active templates → appointee picker
  from profiles → shaft/section/cycle + effective date → dynamic field inputs from
  `template.fields` → uniqueness check → issue). Row actions: view letter PDF,
  resign-on-behalf (reason dialog).
- `lib/screens/my_appointments_screen.dart` — `MyAppointmentsScreen` (any signed-in
  user). Cards for each appointment with status badge; pending_acceptance → "Accept
  & sign" (signature via `profiles.signature_data` or a drawn `SignatureCanvasField`)
  + "Decline"; active/pending_signoff → "View letter" + "Resign". Co-sign progress
  for `pending_signoff` links to `/signature-requests`.

**Signature screen** — `lib/screens/signature_requests_screen.dart`: for requests
whose submission `form_type` starts with `appt_`, show "View letter PDF" (via
`generatePdfForFormType`) and hide the "Open form (view mode)" button (no form
view widget for appointments).

**Routing + sidebar** — `lib/routing/router.dart` adds `/setup/appointments` +
`/my-appointments`; `lib/widgets/admin/admin_sidebar.dart` (or the nav source)
gains an "Appointments" entry (admin) and "My Appointments" (all users).

**Tests** — `test/appointment_lifecycle_test.dart`: status wire mapping,
`isLiveStatus`, `mergeLetterValues` precedence, `canAccept`/`canResign`
transitions.

## 7. Data flow (happy path, co-sign template)

1. Admin opens `/setup/appointments` → Issue → picks "Shift Supervisor" template,
   appointee Jane, Shaft 1, cycle, date → fills fields → issue. Row inserted
   `pending_acceptance`; trigger notifies Jane.
2. Jane opens `/my-appointments`, taps "Accept & sign", signs. Data layer stamps
   her signature, injects blank overseer/manager slots, inserts `form_submissions`
   (`appt_…`), calls `start_workflow`; row → `pending_signoff`; trigger notifies
   the issuer. Edge function notifies the Mine Overseer.
3. Mine Overseer signs in `/signature-requests`; chain advances to Mine Manager;
   Manager signs; submission → `fully_signed`. The `activate_on_signoff` trigger
   flips Jane's appointment → `active`.
4. Later Jane (or an admin) resigns with a reason → `resigned`; trigger notifies
   the issuer; the uniqueness slot frees.

For a no-cosign template, step 2 sets `active` directly and steps 3 is skipped.

## 8. Error handling

- Admin gate on `/setup/appointments`; `/my-appointments` is available to all
  signed-in users (it only ever shows their own rows via RLS).
- Uniqueness: pre-check returns a friendly dialog ("Jane already has a live Shift
  Supervisor appointment for Shaft 1 this month"); the DB partial unique index is
  the backstop (a 23505 is caught and surfaced).
- Accept requires a signature: if `profiles.signature_data` is empty and the user
  draws nothing, block with the same message pattern as the form flow
  (`MissingProfileSignatureException` analog).
- Network/DB failures surface via screen `_error` + SnackBar with Refresh.

## 9. Testing / verification

- `flutter analyze` clean; `flutter test` green (existing 56 + new lifecycle
  tests); `flutter build windows --release` succeeds.
- Migration applied + verified via Management API (table, index, triggers exist;
  a manual insert→update smoke check of the activate trigger on a scratch row,
  rolled back).
- User runs the visual `flutter run -d windows` pass (issue → accept → co-sign →
  resign).

## 10. Risks / open questions

- **Trigger-driven activation coupling.** The `activate_on_signoff` trigger keys
  on `submission_id`. Low risk; the link is set at acceptance and never reused.
- **Appointee UPDATE policy breadth.** RLS lets an appointee update their own row;
  the data layer restricts them to status transitions (accept/decline/resign).
  Acceptable for SP4 — a malicious client could set arbitrary status on their own
  row, but cannot affect others' rows or admin-only data. SP9 audit will harden.
- **`appt_` letter rendering needs `letterValues` in payload.** Captured at issue
  time; if a template's fields change afterwards the stored values still render
  (snapshot semantics — desirable for legal letters).
- **Two appointment surfaces** (`/appointments` forms-hub vs `/setup/appointments`
  lifecycle). Named distinctly; the hub is the legacy fixed forms, the new screen
  is template-driven lifecycle. Reconciling them is out of scope.
