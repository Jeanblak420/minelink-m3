# Admin Shell + Dashboard — Design (Sub-project 1)

**Date:** 2026-06-16
**Status:** Approved for planning
**App:** Mine Online (Flutter — Windows + Android), Supabase project `hhrnkzznpadrmyverhyb`

## Goal

Give Admin and Super Admin users the sidebar-driven dashboard shown in the
reference screenshot: a persistent left sidebar, four KPI stat cards, a Quick
Actions grid, a dismissible demo-tip banner, and an Appointment Activity feed.
**All numbers and lists are real data fetched from Supabase** — the screenshot's
figures (156 / 23 / 7 / 2, "John Smith"…) are mock; in the app they are live.

This is the first sub-project of a larger program that absorbs the original
"Mine-On-Line" admin feature set into our Flutter app. The remaining features
are catalogued in the Roadmap appendix and ship as their own specs. In this
sub-project they exist only as labeled **"Coming soon"** placeholder routes so
the full navigation and flow from the screenshot is present end-to-end.

## Non-goals (this sub-project)

- No new Supabase tables. KPIs/feed read only existing tables
  (`profiles`, `form_submissions`).
- No Form Builder, Appointment Builder, Letter Builder, appointments
  lifecycle, org structure (shafts/gangs), device management, analytics,
  reports, or audit logging implementation — those are placeholders here and
  full sub-projects later (see Roadmap).
- No global router refactor. The shell is a reusable layout widget, not a
  `ShellRoute`/`StatefulShellRoute`.

## Who sees it

Admin **and** Super Admin (`isAdminProfile(profile) == true`, which already
covers `isAdmin`, `isSuperAdmin`, and the `Admin` / `Super Admin`
`userAccountType` values). `home_screen.dart` routes both tiers to the new
shell. All other roles keep their existing dashboards untouched.

## Architecture

### Shell attachment — `AdminShell` layout widget (chosen approach)

The app today gives every route its own `Scaffold` (AppBar +
`commonAppBarActions` + `MobileBottomNav`). Rather than refactor the router,
`AdminShell` is a reusable widget that renders the sidebar + content region.
The Admin dashboard screen — and every future admin-native screen (Form
Builder, etc.) — wraps itself in `AdminShell`, so the sidebar persists across
admin-native surfaces. Sidebar links that target **existing** legacy screens
(`/appointments`, `/profiles`, logbook/history routes) navigate to those
screens as they are today (they keep their own chrome).

Rationale: zero risk to the 40+ existing routes, no nested-Scaffold/duplicate
AppBar problems, and the big builders slot in cleanly later as AdminShell
screens. Trade-off accepted: clicking a sidebar item that points to a legacy
screen leaves the shell on that screen; this is acceptable for SP1 and will
shrink over time as legacy targets are themselves migrated to AdminShell.

### Responsiveness

- **Wide (≥1000 px, Windows):** permanent ~260 px sidebar on the left +
  scrollable content area.
- **Narrow (<1000 px, Android):** sidebar collapses to a hamburger `Drawer`
  opened from an AppBar; the existing `MobileBottomNav` stays for app-wide
  consistency. KPI cards flow 4 → 2 → 1 columns; Quick Actions wrap.
- Breakpoint constant lives on `AdminShell` (1000.0). Note: this differs from
  `MobileBottomNav`'s 720.0 breakpoint — between 720–1000 px the bottom nav is
  hidden but the sidebar is still a drawer; that is intentional and fine.

### Theming

Uses existing tokens only: `Theme.of(context).colorScheme` + `MolTones.of(context)`.
The four KPI accents map to `MolTones`: Employees → `info`/`navy`,
Active Appointments → `success`, Pending Forms → `warning`, Safety Incidents →
`danger`. Works in light, dark, and custom-seed themes — not hard-coded to the
screenshot's light palette.

## Data — all real, computed on load + realtime refresh

A single helper module `lib/utils/admin_dashboard_data.dart` exposes:

```
class AdminDashboardData {
  final int totalEmployees;
  final int activeAppointments;
  final int pendingForms;
  final int safetyIncidents;
  final List<AppointmentActivityItem> recentActivity;
}

class AppointmentActivityItem {
  final String submissionId;
  final String name;          // profile full_name | email | 'Unknown user'
  final String subtitle;      // occupation • location  (either may be empty)
  final DateTime? date;       // created_at
  final String? workflowStatus;
  final String? currentSignatureRole;
}
```

### KPI definitions (mirror legacy semantics, mapped to our schema)

Appointment form types: `{'shift_boss_appointment', 'miner_appointment',
'relieving_miner'}` — defined as a single `kAppointmentFormTypes` constant so
later sub-projects extend one list. Incident form types: `{'gassing_incident'}`
as `kIncidentFormTypes`.

| Card | Query | Legacy analogue |
|---|---|---|
| Total Employees | `select count() from profiles` | total users |
| Active Appointments | `count from form_submissions where form_type in kAppointmentFormTypes and workflow_status='fully_signed'` | appointments `status='accepted'` |
| Pending Forms | `count from form_submissions where workflow_status in ('submitted','pending_signature')` | submissions awaiting review |
| Safety Incidents | `count from form_submissions where form_type in kIncidentFormTypes` | incident count |

Counts use Supabase head/count requests (`.count(CountOption.exact)`), not full
row fetches, so the cards stay cheap.

### Activity feed query

`form_submissions` where `form_type in kAppointmentFormTypes`, ordered by
`created_at desc`, `limit 6`; then one batched `profiles` fetch
(`inFilter('id', userIds)`) for the submitter names/occupation/location —
mirroring the existing pattern in
`admin_appointments_logbook_screen.dart`. "View All →" navigates to
`/appointment-history-logs`.

### Loading / error / empty states

- KPI cards show a small shimmer/`CircularProgressIndicator` placeholder while
  loading; on error show `—` and a retry affordance in the shell.
- Activity feed: spinner while loading; `EmptyState` (existing widget) when
  there are no appointment submissions; inline error text on failure.

### Realtime

One channel `admin-dashboard` subscribing to `form_submissions` (all events)
and `profiles` (all events); on any change, re-run the data load (debounced /
guarded by `mounted`). Mirrors the resubscribe pattern already used in
`admin_appointments_logbook_screen.dart`. Channel is unsubscribed in
`dispose()`.

## Sidebar structure

Role-gated to Admin/Super Admin. Items map to existing routes where possible;
otherwise to a placeholder route. Sections are collapsible; the active item is
highlighted by matching the current location.

- **Dashboard** → `/`
- **Shiftboss Logbook** (expandable)
  - Combined View → `/current-logbook`
  - Appointments → `/appointments`
  - Daily Reports → `/reports/daily` *(placeholder — SP8)*
  - Weekly Reports → `/reports/weekly` *(placeholder — SP8)*
  - Monthly Reports → `/reports/monthly` *(placeholder — SP8)*
- **Templates** (expandable)
  - Form Builder → `/form-builder` *(placeholder — SP2)*
  - Appointment Builder → `/appointment-builder` *(placeholder — SP3)*
- **Report History** → `/completed-logbook-history`
- **Setup** (expandable)
  - User Management → `/profiles`
  - Locations (Shafts/Sections/Areas) → `/setup/locations` *(placeholder — SP5)*
  - Gangs → `/setup/gangs` *(placeholder — SP5)*
  - Devices → `/setup/devices` *(placeholder — SP6)*
  - Analytics → `/analytics` *(placeholder — SP7)*
  - Notifications → `/notifications`
  - Settings → `/settings`
  - Admin Workspace → `/admin`
- **Download Mobile App** → info dialog (this *is* the app; explains the
  Android build / where to get the APK). No new route.
- **Logout** → `context.read<AuthProvider>().signOut()`

Top of the content region keeps the existing trailing actions
(`TodosChecklistButton`, `NotificationBell`, `AccountBadge`) so notification and
account access are unchanged.

## Quick Actions grid

Cards (icon + label), wired to the same routes the screenshot implies:

- New Appointment → `/appointments`
- Incomplete → `/active-individual-current-logbook`
- Design Form → `/form-builder` *(placeholder — SP2)*
- Manage Workforce → `/profiles`
- Forms Management → `/appointments`
- View Reports → `/completed-logbook-history`
- Mobile App → same info dialog as the sidebar item

A dismissible demo-tip info banner sits above the grid (matches the screenshot;
dismiss state held in screen `State`, not persisted in SP1).

## Files

New:
- `lib/widgets/admin/admin_shell.dart` — responsive Scaffold (sidebar | drawer) + content slot
- `lib/widgets/admin/admin_sidebar.dart` — sidebar item model + collapsible sections + active-route highlight
- `lib/widgets/admin/kpi_stat_card.dart` — single stat card (title, value, icon, MolTone accent, loading state)
- `lib/widgets/admin/quick_actions_grid.dart` — quick-action tiles
- `lib/widgets/admin/appointment_activity_feed.dart` — recent-activity list + "View All"
- `lib/widgets/admin/mobile_app_info_dialog.dart` — the "Download Mobile App" dialog
- `lib/screens/admin_dashboard_screen.dart` — composes the above inside `AdminShell`
- `lib/utils/admin_dashboard_data.dart` — KPI + activity queries, `kAppointmentFormTypes`, `kIncidentFormTypes`

Changed:
- `lib/screens/home_screen.dart` — route Admin **and** Super Admin to
  `AdminDashboardScreen`. (The existing `AdminDashboard` / `SuperAdminDashboard`
  card-grid widgets remain in the tree for non-admin fallbacks and history but
  are no longer reached by admin/super-admin users.)
- `lib/routing/router.dart` — add placeholder `GoRoute`s for the net-new
  destinations: `/form-builder`, `/appointment-builder`, `/reports/daily`,
  `/reports/weekly`, `/reports/monthly`, `/setup/locations`, `/setup/gangs`,
  `/setup/devices`, `/analytics`. Each uses the existing `PlaceholderScreen`
  with a title + "Coming soon" description naming its sub-project.

## Testing / verification

- `flutter analyze` clean.
- `flutter run -d windows`: sidebar permanent; KPI cards show real counts
  (currently 9 / 3 / 8 / 1 against live data); activity feed lists recent
  appointment submissions with real submitter names; placeholders open and read
  "Coming soon"; Logout works; theme toggle (light/dark) keeps it legible.
- Resize below 1000 px: sidebar becomes a hamburger drawer; cards reflow; bottom
  nav appears below 720 px.
- Submit/sign an appointment elsewhere → dashboard KPIs/feed update via realtime.

## Constraints honored

- No "Claude"/AI naming anywhere in code, UI strings, or data.
- No new dependencies; Material 3 + `Icons.*` only.
- Field/`form_type` names unchanged; reads existing payload shape.
- No auto-inserts into `public.todos` / `SEED_ENG` unless explicitly instructed.

---

## Appendix — Program Roadmap (follow-on sub-projects)

Derived from the original Mine-On-Line app
(`…\Original-Mine-Online-app\mine-on-line-backend`). Each is its own
spec → plan → implementation cycle, reworked natively for Flutter + Supabase
(not a literal port of the Node/React/old-Flutter code).

| SP | Feature | Legacy source | Notes for Flutter+Supabase |
|---|---|---|---|
| SP2 | **Form Builder** | `form_templates` (JSONB `fields`/`schema`), `/web/forms/templates*`, field-type library, archive/restore, versioning | New `form_templates` table; visual field editor; dynamic renderer that can feed our existing submission pipeline |
| SP3 | **Appointment Builder + Letter Builder** | `appointment_templates`, `/web/appointments/forms/templates*`, `{{placeholder}}` letters | Role-based templates; markdown letter editor with profile placeholder substitution |
| SP4 | **Appointments lifecycle** | `appointments` (request→accept→resign), uniqueness per role/shaft/cycle/month, `appointment_roles` | Reconcile with our existing signature-chain workflow; roles catalog; uniqueness guard |
| SP5 | **Org structure** | shafts/sections/areas, gangs + memberships + role requirements, shifts | New tables + CRUD admin screens; feeds appointment/gang selectors |
| SP6 | **Device management** | `devices` register + admin approve, `X-Device-ID` | Optional for Supabase model; register + approve UI + gating if adopted |
| SP7 | **Analytics** | `/web/analytics/{forms,appointments,users,system}` | Aggregate queries → charts; the dashboard KPIs are the seed of this |
| SP8 | **Reports** | Daily/Weekly/Monthly compliance + PDF/Excel export | Report screens behind the sidebar's Reports items; reuse PDF runtime |
| SP9 | **User lifecycle, audit logs, submission review** | `user_*_logs`, review_status approve/reject, audit trails | Audit tables; review/approve UI over `form_submissions` |
