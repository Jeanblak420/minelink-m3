# Form Builder SP2.2 — Generic PDF for built forms — Design

**Date:** 2026-06-17
**Status:** Approved for planning
**Parent:** SP2 Form Builder (after SP2.1 authoring + fill).

## Goal

Render any custom-form submission to a clean, paginated PDF, and surface it
through the existing PDF entry points so built forms behave like the hard-coded
forms for download/print.

## Approach

Because this PDF is net-new (not mirroring a jsPDF web layout), use the
**high-level `pw.MultiPage` API** (auto-pagination) rather than the
absolute-mm `PageCtx` runtime used by the 27 ported forms. Roboto is bundled
(`assets/fonts/Roboto-*.ttf`) and used via `pw.ThemeData.withFont` for Unicode.

## Components

- `lib/pdf/generate_custom_form_pdf.dart` — `Future<pw.Document> generateCustomFormPdf(CustomFormTemplate template, Map<String,dynamic> payload)`:
  - Header (page 1): company line "Mine Online", the form name, and the
    submission/print date.
  - One block per field, in template order:
    - `section` → bold heading.
    - `text` / `multiline` / `number` / `date` / `dropdown` → label + value row
      (value `—` when blank).
    - `boolean` → label + "Yes"/"No".
    - `signature` → label + embedded PNG (via `decodeSignatureBytes`, aspect kept).
    - `table` → a `pw.Table` with the column labels as the header row and the
      payload's list-of-maps as data rows.
- `lib/utils/custom_form_data.dart` — add `Future<CustomFormTemplate?> loadTemplateByCode(String code)`.
- `lib/utils/form_registry.dart` — in `generatePdfForFormType`, when `formType`
  starts with `custom_`, fetch the template by code and return
  `generateCustomFormPdf(template, payload)` (or null if not found). This
  automatically enables the submission viewer's "Download PDF" for custom forms
  (it already calls `generatePdfForFormType`).
- `lib/screens/custom_forms_screen.dart` — add a "Generate PDF" action on the
  fill screen (preview/print the just-entered values via `Printing.layoutPdf`),
  mirroring the existing form screens' pattern.

## Non-goals

- No signature-chain integration (SP2.3).
- Not pixel-matching any web layout (these forms have no web equivalent).

## Testing

- Unit test the pure value helper (`customPdfValueString`) for null/num/bool/
  string/date.
- `flutter analyze` clean, `flutter test` green, `flutter build windows --release` OK.
- Manual: build a custom form with every field type, submit it, open it from the
  current logbook / history → "Download PDF" produces a readable PDF with the
  section headings, values, signature image, and table; "Generate PDF" on the
  fill screen previews before submit.

## Constraints

- No new dependencies (`pdf` + `printing` already used). No "Claude"/AI naming.
