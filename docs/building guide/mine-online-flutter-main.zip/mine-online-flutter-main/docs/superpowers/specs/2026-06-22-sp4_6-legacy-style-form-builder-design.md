# SP4.6 — Builder 1: legacy-style form designer — Design

**Date:** 2026-06-22
**Status:** Draft for user review (standing autonomy grant)
**Sub-project:** SP4.6 — the second builder of the user's two-builder vision.
**Predecessors:** SP2 (Form Builder — custom forms), SP3 (Appointment Builder),
SP4 (Appointments lifecycle), SP4.5 (full-edit overlay over current forms).

---

## 1. Goal

Re-implement the **original Mine-On-Line app's form builder UX**, faithfully —
"exactly as the old app" — as a second, distinct builder ("Builder 1"). It
authors into the **existing** template tables (no duplicate storage) while
reproducing the legacy designer's three-column layout, field types, field
configuration, data-linked dropdowns, live preview, and version/archive
lifecycle.

This is the counterpart to **Builder 2** (SP4.5, the full-edit overlay builder
over the 27 current forms). Both coexist — the user explicitly wants two builders.

## 2. What the old app's builder is (faithful reference)

From the legacy React app (`FormBuilder.jsx` / `AppointmentFormDesigner.jsx` +
`FormTemplateManager` / `AppointmentFormTemplateManager`):

- **Manager (list) screen:** title + "Create New Form"; search; a
  category/role filter; **Active Templates** and **Archived Templates** sections;
  per-row Edit / Archive / Restore.
- **Designer screen — three columns:**
  - **Left (16rem):** "Form Fields" — a clickable list of the form's fields +
    a "+ Add Field" button. Selected field highlighted.
  - **Center:** "Live Preview" — renders the form grouped by **section →
    row → row_order**, each field shown with its preview input.
  - **Right (floating panel):** "Edit Field" — the selected field's config.
  - **Top:** metadata header (Form Name, Version, Language, + Role for
    appointment forms / Category + Description for general forms).
  - **Bottom:** Cancel / Save.
- **Field types:** `text`, `textarea`, `date`, `number`, `checkbox`,
  `static_dropdown`, `dynamic_dropdown`.
- **Field config:** Label, Name (snake_case id), Section, Row, Row Order, Tab
  Index, Required, lines (textarea), Static Options (comma-separated), Dynamic
  Source.
- **Dynamic dropdowns:** bound to a mine table via `appointment_dropdown_sources`
  (`table_name`, `value_column`, `label_column`, `display_name`); at fill time the
  options come from that table.
- **Versioning:** free-form `version` string; soft-delete via `archived`;
  Active/Archived split + Restore.

## 3. Approach — reuse storage, reproduce UX

Builder 1 is an **alternate authoring UX** over the SAME templates SP2/SP3 already
store. It does **not** introduce the legacy's parallel tables
(`form_templates`, `appointment_field_types`). Rationale: the field-type list is a
constant in Flutter (no table needed), and SP2's `custom_form_templates` +
SP3's `appointment_templates` already hold `fields` (a `FormFieldDef[]` JSON) +
version + active flag. So:

- **General forms** → authored into `custom_form_templates` (SP2 storage).
- **Appointment forms** → authored into `appointment_templates` (SP3 storage).
- The designer simply provides the legacy three-column UX over these.

The one capability the existing storage lacks — **data-linked dropdowns** — gets a
small new catalog table + model/renderer support (see §5).

## 4. Scope

### In scope
1. Extend `FormFieldDef` (SP2 model) with optional legacy layout/config:
   `section`, `row`, `rowOrder`, `tabIndex`, and a new field type
   `dynamicDropdown` carrying a `dropdownSource` (the source key).
2. New `form_dropdown_sources` catalog table + data layer + admin seed.
3. **Legacy designer screen** (`/form-designer`): three-column manager + designer
   reproducing the legacy look/flow, authoring into `custom_form_templates`
   (general) and `appointment_templates` (appointment).
4. **Live preview** grouped by section → row → row_order.
5. **Fill-time + PDF support** for dynamic dropdowns + section/row grouping (extend
   `DynamicFormRenderer` and the custom-form PDF to honor the new props). Existing
   forms with no section/row metadata render exactly as today.
6. Version string display + archive/restore (reuse SP2 `is_active`/`version`).
7. Sidebar entry "Form Designer".

### Out of scope
- Re-creating the legacy's `form_templates` / `appointment_field_types` /
  raw-SQL dropdown endpoint (replaced by a const field-type list + an allowlisted
  `form_dropdown_sources` read).
- Touching the 27 bespoke forms or Builder 2 (SP4.5) — unchanged.
- Migrating existing SP2 custom forms' layout (they have no section/row; they keep
  rendering linearly).

## 5. Data model

### 5.1 `FormFieldDef` extension (SP2 model, additive)
Add optional fields (all default null/absent → existing templates unaffected):
`section` (String?), `row` (String?), `rowOrder` (int?), `tabIndex` (int?),
`dropdownSource` (String?, for the new type). Add `FormFieldType.dynamicDropdown`.
`toMap`/`fromMap` round-trip them; absent keys = legacy-free field (today's
behavior).

### 5.2 `form_dropdown_sources` (new)
Migration `20260622xxxxxx_form_dropdown_sources.sql`:
| Column | Type | Notes |
|---|---|---|
| `id` | uuid pk | |
| `key` | text unique not null | stable source key stored on the field (`dropdownSource`) |
| `table_name` | text not null | the source table |
| `value_column` | text not null | |
| `label_column` | text not null | |
| `display_name` | text not null | shown in the builder picker |
| `is_active` | boolean default true | |
| timestamps | | |

RLS: authenticated read active; admin write. **Seed** (admin-readable mine
tables): `shafts`, `sections`, `areas`, `gangs`, `shifts`, `appointment_roles`,
`profiles` (value=id, label=name/full_name).

**Safety:** the data layer reads dynamic options via `supabase.from(table_name)
.select('value_column,label_column')` restricted to the seeded allowlist — never
arbitrary SQL. Each source's table already has RLS; only allowlisted, admin-safe
tables are seeded.

## 6. Components / files

**Model** — extend `lib/models/custom_form_template.dart` (`FormFieldDef` +
`FormFieldType.dynamicDropdown`) + tests.

**Data** — `lib/utils/form_dropdown_data.dart`: `loadDropdownSources()`,
`saveDropdownSource(...)`, `loadDropdownOptions(sourceKey)` (→ `[{value,label}]`
via the allowlisted source). Reuse `custom_form_data.dart` /
`appointment_template_data.dart` for template save/load.

**Designer screen** — `lib/screens/form_designer_screen.dart`:
- `FormDesignerManagerScreen` — Active/Archived list + Create New Form +
  search/filter; a toggle for General vs Appointment forms (authors into the
  matching table).
- `_DesignerScreen` — the three-column layout: `_FieldListPanel`,
  `_LivePreviewPanel` (groups by section→row→rowOrder, renders via
  `DynamicFormRenderer`), `_FieldEditorPanel` (Label/Name/Section/Row/Row
  Order/Tab Index/Required/type-specific options incl. Dynamic Source picker).
  Metadata header + Cancel/Save. On narrow screens the three columns stack
  (tabs), keeping Flutter-appropriate responsiveness.

**Renderer** — extend `lib/widgets/form_builder/dynamic_form_renderer.dart`:
add a `dynamicDropdown` case (loads options from the source) and an optional
section/row grouping mode (used by the live preview + fill screen). Linear
rendering stays the default when no section/row metadata is present.

**PDF** — extend `generate_custom_form_pdf.dart` to print `dynamicDropdown`
values + (optionally) section/row grouping. Resolved option labels are stored in
the payload so the PDF needs no DB lookup.

**Routing + sidebar** — add `/form-designer` (admin) + a "Form Designer" sidebar
leaf under Templates.

**Tests** — `test/form_designer_test.dart`: `FormFieldDef` round-trip with the new
props; section/row grouping sort logic (section→row→rowOrder); dropdown-source
key resolution.

## 7. Data flow

Admin opens `/form-designer` → picks General or Appointment → Create New Form →
sets metadata → adds fields (left), configures each (right), sees the grouped
Live Preview (center) → Save into `custom_form_templates` /
`appointment_templates`. A `dynamicDropdown` field stores its `dropdownSource`
key; at fill time the renderer loads `[{value,label}]` from the allowlisted
source and the selected value (+ resolved label) goes into the payload, so the
PDF renders without a DB lookup.

## 8. Error handling

- Admin-gated designer (`isAdminProfile`). Non-admins unaffected.
- Dynamic-dropdown load failure → the field renders as an empty/disabled dropdown
  with a retry, never crashes the form.
- Save validation reuses `validateTemplate` (+ a check that every
  `dynamicDropdown` has a source).
- Unknown/disabled source key → renders no options (safe).

## 9. Testing / verification

- `flutter analyze` clean; `flutter test` green (existing + new designer tests);
  `flutter build windows --release`.
- Migration applied + verified via Management API.
- User runs the visual `flutter run -d windows` pass; cross-checks the designer
  look against the legacy app.

## 10. Risks / open questions

- **"Exactly as the old app" fidelity vs. Flutter idiom.** The three-column
  desktop designer maps well to Windows; on Android/narrow widths the columns
  stack (tabs). This is a faithful adaptation, not a pixel clone of the web CSS.
- **Two builders over appointment templates.** SP3's Appointment Builder and this
  legacy designer both author `appointment_templates`. They coexist (same
  storage); the designer is just the legacy-style UX. No conflict.
- **Dynamic-dropdown RLS.** Only allowlisted, admin-safe tables are seeded; reads
  honor each table's existing RLS. `profiles` as a source returns id/full_name
  (already readable by the app).
- **Section/row on existing SP2 forms.** They have none → render linearly exactly
  as today (additive, no migration).
