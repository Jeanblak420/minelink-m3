# SP3 — Appointment Builder + Letter Builder — Design

**Date:** 2026-06-21
**Status:** Approved (standing autonomy grant)
**Sub-project:** SP3 of the "absorb legacy Mine-On-Line admin feature set" program.
**Predecessors:** SP1 (Admin Shell), SP2 (Form Builder — full parity), SP5 (Org structure).
**Successor:** SP4 (Appointments lifecycle — request → accept/sign → resign).

---

## 1. Goal

Give admins a native authoring surface for **legal appointment templates** and their
**appointment letters**, mirroring the legacy app's "Appointment Form Designer" +
"Letter Builder" pair, re-implemented natively against this Flutter + Supabase app.

SP3 is **authoring only**. It produces reusable templates and previewable letter PDFs.
It does **not** issue appointments to real people, drive the accept/sign/resign
lifecycle, or enforce one-per-role uniqueness — all of that is SP4. The schema is
built forward-compatible so SP4 attaches cleanly.

## 2. Background / what exists today

- **Three hardcoded appointment forms** already ship (`shift_boss_appointment`,
  `miner_appointment`, `relieving_miner_appointment`) as bespoke Dart screens with
  signature chains. SP3 does **not** replace or migrate these — it adds a
  builder-driven path alongside them. (Reconciling the two is a later concern; the
  hardcoded forms keep working untouched.)
- **No appointment-roles catalog exists.** Roles are implicit today
  (occupation-substring checks in `lib/utils/role_access.dart`). SP3 introduces a
  minimal explicit catalog, which SP4 also needs.
- **SP2 Form Builder** is the closest analog: `custom_form_templates` table,
  `FormFieldDef` field model (`lib/models/custom_form_template.dart`), the field
  editor in `form_builder_screen.dart`, schema-driven PDF in
  `generate_custom_form_pdf.dart`. SP3 reuses `FormFieldDef` and the field-editor
  pattern.
- **Admin CRUD pattern** to copy: `lib/screens/setup/locations_screen.dart` +
  `lib/utils/org_data.dart` (admin gate via `isAdminProfile(profile)`,
  read-active/admin-write RLS, load/save/setActive data functions).
- **Legacy reference:** `documents/legal_appointments.md` (roles → templates →
  user_appointments → signatures → audit) and the React `LetterBuilder.jsx` /
  `AppointmentFormDesigner.jsx` components. Legacy letter placeholders use
  `{{field_name}}` syntax with a field-insertion sidebar and sample-data preview.

## 3. Scope

### In scope (SP3)
1. **Appointment roles catalog** — new `appointment_roles` table, seeded with the
   roles the app uses today plus core MHSA statutory roles. Lightweight admin
   management (add / edit / archive) via a dialog inside the builder.
2. **Appointment Builder** — admin authors `appointment_templates`: role, name,
   description, language, form fields (reusing `FormFieldDef`), and required signers
   (reusing the existing chain-signer keys).
3. **Letter Builder** — per template, a letter-body editor with a placeholder
   palette, live preview against sample data, and a PDF letter generator. Supports a
   minimal markdown subset (`# heading`, `**bold**`) — no new dependencies.
4. **Route** `/appointment-builder` activated (placeholder removed).
5. **Unit tests** for placeholder extraction/substitution + template validation.

### Out of scope (deferred to SP4 / later)
- Issuing an appointment to a real person; `user_appointments` rows.
- Accept / sign / resign lifecycle and any edge-function / signature-chain wiring.
- One-per-role/shaft/cycle/month uniqueness enforcement.
- Migrating the three hardcoded appointment forms onto the builder.
- A dedicated `/setup/appointment-roles` route (roles managed inline for now).
- Multi-language letter rendering beyond storing a `language` tag (single language
  per template; no translation tooling).
- `integrity_hash` / audit-log columns (SP4/SP9 concern).

## 4. Data model

Two new tables. Naming and RLS follow the SP5 migrations. UUID PKs (consistent with
`custom_form_templates`, not the legacy SERIAL).

### 4.1 `appointment_roles`
| Column | Type | Notes |
|---|---|---|
| `id` | uuid pk default `gen_random_uuid()` | |
| `code` | text null | legal reg code e.g. `2.13.1` (nullable — not all roles have one) |
| `label` | text not null | human title e.g. "Shift Supervisor (Shift Boss)" |
| `description` | text null | regulatory responsibility overview |
| `is_mandatory` | boolean not null default false | required per law |
| `is_active` | boolean not null default true | soft-delete / archive |
| `sort_order` | int not null default 0 | display ordering |
| `created_at` | timestamptz not null default now() | |
| `updated_at` | timestamptz not null default now() | |

**Seed** (is_active=true): Mine Manager (`2.6.1`, mandatory), Mine Overseer (`2.9.2`,
mandatory), Shift Supervisor / Shift Boss (`2.13.1`, mandatory), Miner (Competent A),
Relieving Miner, Engineer (`2.13.2`). `sort_order` ascending in that order.

### 4.2 `appointment_templates`
| Column | Type | Notes |
|---|---|---|
| `id` | uuid pk default `gen_random_uuid()` | |
| `code` | text not null unique | stable ref e.g. `appt_shift_boss_ab12`; forward-compat as a `form_type` in SP4 |
| `name` | text not null | template name |
| `description` | text null | |
| `role_id` | uuid null references `appointment_roles(id)` on delete set null | |
| `language` | text not null default `'en'` | tag only in SP3 |
| `fields` | jsonb not null default `'[]'` | `FormFieldDef[]` (same shape as custom_form_templates) |
| `letter_body` | text not null default `''` | letter template with `{{placeholder}}` tokens |
| `required_signers` | jsonb not null default `'[]'` | chain-signer keys (reuse `kChainSignerLabels`) |
| `version` | int not null default 1 | bumped on each save |
| `is_active` | boolean not null default true | archive |
| `created_by` | uuid null | author (auth.uid()) |
| `created_at` | timestamptz not null default now() | |
| `updated_at` | timestamptz not null default now() | |

### 4.3 RLS (both tables)
- Enable RLS.
- **SELECT**: authenticated users may read `is_active = true` rows. Admins
  (`public.is_admin(auth.uid())`) may read all (incl. archived) — matches SP5/SP2.
- **INSERT / UPDATE / DELETE**: admins only (`public.is_admin(auth.uid())`).
  We use soft-delete (`is_active=false`) over hard DELETE, as elsewhere.

Migration file: `supabase/migrations/<ts>_sp3_appointment_templates.sql`. Written to
the repo **and** applied via the Management API (PAT in Windows Credential Manager
`claude-supabase-pat-hhrnkzznpadrmyverhyb`; project ref `hhrnkzznpadrmyverhyb`).

## 5. Letter placeholders

Letter body is plain text with `{{token}}` placeholders. Two token namespaces:

- **Template field tokens** — any field key defined on the template: `{{<key>}}`.
- **Standard profile tokens** — a fixed set resolved from the appointee's profile at
  issue time (SP4); in SP3 preview they resolve from sample data:
  `{{full_name}}`, `{{first_name}}`, `{{last_name}}`, `{{employee_number}}`,
  `{{id_number}}`, `{{occupation}}`, `{{section}}`, `{{company}}`, `{{date}}`.

**Resolution order:** template field tokens take precedence over profile tokens on a
key collision (documented; the palette labels both groups so authors can avoid
clashes). An unresolved token renders verbatim (`{{foo}}`) so authors see mistakes.

**Markdown subset** (rendered by the PDF generator + preview only): a line starting
with `# ` is a centered bold heading; `**bold**` inline spans render bold. Everything
else is plain paragraphs, blank line = paragraph break. No external markdown
dependency — parsed in-house.

Pure, unit-tested helpers live in the model:
- `List<String> extractPlaceholders(String body)` — distinct `{{token}}` names.
- `String renderLetterBody(String body, Map<String,String> values)` — substitute;
  leave unknown tokens verbatim.

## 6. Components / files

**Models** — `lib/models/appointment_template.dart` (pure Dart, no Flutter/Supabase
imports; reuses `FormFieldDef` from `custom_form_template.dart`):
- `AppointmentRole` (+ `toMap`/`fromMap`)
- `AppointmentTemplate` (+ `toMap`/`fromMap`)
- `extractPlaceholders`, `renderLetterBody`, `kStandardLetterTokens`
- `validateAppointmentTemplate({name, roleId, fields})` → `List<String>` errors

**Data layer** — `lib/utils/appointment_template_data.dart` (mirrors `org_data.dart`
/ `custom_form_data.dart`):
- `loadAppointmentRoles({includeArchived})`, `saveAppointmentRole({...})`,
  `setAppointmentRoleActive(id, active)`
- `loadAppointmentTemplates({includeArchived})`,
  `loadAppointmentTemplateById(id)`,
  `saveAppointmentTemplate({...})` (insert/update, bump version on update),
  `setAppointmentTemplateActive(id, active)`
- `generateTemplateCode(name)` helper for the stable `code`.

**PDF** — `lib/pdf/generate_appointment_letter_pdf.dart`:
- `Future<pw.Document> generateAppointmentLetterPdf(AppointmentTemplate t, Map<String,String> values, {AppointmentRole? role})`
- Formal letter layout: header (role label as title), substituted+markdown-rendered
  body paragraphs, signature blocks for each required signer + the appointee. Reuses
  bundled Roboto fonts and `PdfPageFormat.letter`. Used by the preview button now;
  reused at issue time in SP4.

**Screens** — `lib/screens/setup/appointment_builder_screen.dart`:
- `AppointmentBuilderScreen` — admin-gated (`isAdminProfile`) list of templates
  (active + archived toggle), create/edit/archive, "Manage roles" action.
- `_TemplateEditorScreen` — two sections/tabs:
  - **Details & fields**: role picker (from catalog), name/description/language,
    required-signers chips, field editor (reuse SP2's field-editor list/pattern).
  - **Letter**: multiline letter-body editor, placeholder palette (insert at
    cursor), live preview pane (sample-data substitution), "Preview PDF" button
    (`Printing.layoutPdf`).
- `_RolesManagerDialog` — list roles, add/edit (code, label, description, mandatory),
  archive/restore.

**Routing** — `lib/routing/router.dart`: remove `/appointment-builder` from
`_placeholders()`; add a real `GoRoute` rendering `AppointmentBuilderScreen`.

**Tests** — `test/appointment_template_test.dart`: `extractPlaceholders`,
`renderLetterBody` (substitution, unknown-token passthrough, collision precedence),
`validateAppointmentTemplate`.

## 7. Data flow

Author flow: admin opens `/appointment-builder` → creates a template (role + fields)
→ switches to Letter tab → writes letter body inserting `{{tokens}}` from the palette
→ live preview substitutes sample data → "Preview PDF" renders the letter →
Save persists to `appointment_templates`. Roles come from `appointment_roles` (seeded;
editable via the dialog).

SP4 will read these templates to issue `user_appointments`, resolve real profile
values into the letter, run the signature chain, and render the final signed PDF.

## 8. Error handling

- Admin gate: non-admins see the standard read-only "admins only" message
  (same as `locations_screen.dart`).
- Save validation: `validateAppointmentTemplate` errors shown in a dialog before
  any DB write (mirrors `form_builder_screen.dart`).
- DB/network failures surface via the screen's `_error` state + a SnackBar, with a
  Refresh affordance (matches existing setup screens).
- Unresolved placeholders render verbatim rather than throwing.

## 9. Testing / verification

- `flutter analyze` clean.
- `flutter test` green (existing 44 + new appointment-template tests).
- `flutter build windows --release` succeeds.
- Migration applied and verified via Management API (`list_tables` / select).
- User runs the visual `flutter run -d windows` pass.

## 10. Risks / open questions

- **Hardcoded vs builder appointment forms coexist.** Accepted for SP3; reconciliation
  (whether the three bespoke forms migrate onto the builder) is deferred. No conflict
  because they use different storage and routes.
- **Token collision** between a field key and a profile token — resolved by documented
  precedence (field wins) + palette labelling. Low risk.
- **Letter formatting fidelity.** The markdown subset is intentionally minimal; if
  richer letters are needed later, revisit (would likely need a dependency — ask
  first).
