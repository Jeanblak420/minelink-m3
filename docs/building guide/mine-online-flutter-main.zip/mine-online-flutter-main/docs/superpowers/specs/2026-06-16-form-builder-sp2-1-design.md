# Form Builder — Phase SP2.1: Builder + Renderer + Capture — Design

**Date:** 2026-06-16
**Status:** Approved for planning
**App:** Mine Online (Flutter — Windows + Android), Supabase project `hhrnkzznpadrmyverhyb`
**Parent:** SP2 (Form Builder) of the admin program — see
`docs/superpowers/specs/2026-06-16-admin-shell-dashboard-design.md` roadmap.

## Goal

Let Admin/Super Admin users **build custom forms without code**, and let the
targeted audience **fill and submit** them. Built forms capture into the
existing `form_submissions` table so they immediately appear in the logbooks,
history, and submission viewer. This is the first of three SP2 phases; full
parity (PDF + signature chain) is the SP2 goal, delivered across the phases.

## Phase map (SP2 = full parity, sequenced)

- **SP2.1 (this spec)** — template storage, visual builder (all field types),
  per-form audience targeting, dynamic renderer, fill→submit as **non-chain**
  forms.
- **SP2.2** — generic schema-driven **PDF** for built forms; wired into the
  submission viewer, history "View PDF", and a "Generate PDF" button.
- **SP2.3** — **signature-chain parity**: `required_signers` enforcement,
  integration with the existing signature workflow (edge function +
  `signature_requests`), submitter auto-stamp, and chain view-mode rendering;
  reconciles custom templates with the server-side `form_templates` registry.

## Non-goals (SP2.1)

- No PDF generation for built forms (SP2.2).
- No signature chain / `signature_requests` for built forms — they submit as
  non-chain (the `required_signers` array is **authored and stored** now but
  **not enforced** until SP2.3).
- No conditional/branching logic, no formulas, no file/photo upload fields, no
  template version history (a single `version` int is stored and bumped on
  save; old versions are not retained).
- Does not touch the 27 hard-coded forms, the vestigial
  `form_fields`/`form_instances`/`form_signatures` tables, or the existing
  42-row `form_templates` registry.

## Why a new table (not extending `form_templates`)

The existing `form_templates` registry (42 rows) is keyed by `form_type`, holds
`required_signers`, and is read **server-side by the signature workflow**.
Extending it now would couple SP2.1 to a possibly load-bearing server table
before we have inspected the edge function. SP2.1 instead uses a **self-contained
new table** (`custom_form_templates`) with zero risk to existing behavior.
SP2.3 — when we integrate the chain and have inspected the edge function — will
decide how custom templates reconcile with the registry (e.g. mirror a row, or
teach the edge function to read the new table).

## Data model

### New table: `custom_form_templates`

| Column | Type | Notes |
|---|---|---|
| `id` | uuid pk default gen_random_uuid() | |
| `code` | text unique not null | the `form_submissions.form_type` value; generated `custom_<slug>_<short>` |
| `name` | text not null | form title |
| `description` | text | optional |
| `category` | text | optional grouping label |
| `fields` | jsonb not null default '[]' | ordered array of field defs (below) |
| `audience` | jsonb not null default '[]' | array of allowed `user_account_type` strings; `[]` = everyone |
| `required_signers` | jsonb not null default '[]' | authored for SP2.3; not enforced in SP2.1 |
| `version` | int not null default 1 | bumped on each save |
| `is_active` | boolean not null default true | archive = false |
| `created_by` | uuid | auth user id |
| `created_at` / `updated_at` | timestamptz default now() | |

RLS policies:
- SELECT: any authenticated user may read rows where `is_active = true`
  (audience filtering is applied client-side in SP2.1 for simplicity; a stricter
  server policy can follow). Admins may read all (incl. archived).
- INSERT / UPDATE: only admin/super-admin (mirror the `todos` eng-lock pattern —
  gate via a policy keyed on the caller's profile account type, matching how
  `20260525150000_lock_eng_todos_to_service_role.sql` restricts writes).
- No DELETE in SP2.1 (archive via `is_active=false`).

Created via a Supabase migration in `supabase/migrations/` (timestamped), applied
by us (not the user), per the repo's Supabase operating rule.

### Field definition (one element of `fields`)

```jsonc
{
  "key": "string",        // unique within the form; the payload key
  "type": "text" | "multiline" | "number" | "date" | "dropdown"
        | "boolean" | "signature" | "section" | "table",
  "label": "string",
  "required": true,        // ignored for "section"
  "help": "string?",       // optional helper text
  "options": ["..."],      // dropdown only
  "columns": [             // table only
    { "key": "string", "label": "string", "type": "text" | "number" }
  ]
}
```

### Payload shape written to `form_submissions.payload`

A flat JSON object keyed by each field's `key`:
- text/multiline/dropdown → String
- number → num
- date → ISO-8601 String
- boolean → bool
- signature → base64 PNG String (same as existing `SignatureCanvasField`)
- table → `List<Map<String,dynamic>>` (one map per row, keyed by column `key`)
- section → not written (layout only)

## Components & files

New library code:
- `lib/models/custom_form_template.dart` — `CustomFormTemplate` + `FormFieldDef`
  + `FormFieldType` enum; `fromMap`/`toMap`; pure helpers
  `validateTemplate(...)` (unique keys, dropdown has options, table has columns)
  and `audienceAllows(template, accountType)`.
- `lib/utils/custom_form_data.dart` — Supabase reads/writes: `loadTemplates({bool includeArchived})`, `loadFillableTemplates(accountType)`, `saveTemplate(...)`, `setTemplateActive(id, active)`; `slugifyCode(name)`.
- `lib/widgets/form_builder/field_editor.dart` — per-field editor row (type
  picker + label + key + required + type-specific config: options list, table
  columns); reorderable.
- `lib/widgets/form_builder/dynamic_form_renderer.dart` — given a
  `CustomFormTemplate`, builds the fillable form for all field types, tracks
  values, enforces `required`, returns the assembled payload. Reuses
  `SignatureCanvasField`, `DatePickerField`, and the inspection-items table
  widget pattern.
- `lib/screens/form_builder_screen.dart` — `/form-builder` (admin/super-admin):
  template list (active + archived tabs), create/edit (name, description,
  category, audience multi-select, field editor list with add/reorder/remove),
  save, archive/restore.
- `lib/screens/custom_forms_screen.dart` — `/custom-forms`: lists active
  templates the current account type may fill; tapping opens the renderer in a
  fill screen; submit calls `persistFormSubmission(code, name, payload)` then
  shows confirmation.

Changed:
- `lib/routing/router.dart` — replace the `/form-builder` placeholder with the
  real `FormBuilderScreen`; add `/custom-forms` → `CustomFormsScreen`.
- `lib/widgets/admin/admin_sidebar.dart` — `/form-builder` leaf already exists
  (now resolves to the real screen); add a "Custom Forms" leaf (→ `/custom-forms`)
  under "Shiftboss Logbook" (visible to all, audience-filtered in the screen).
- (No change needed to the "Design Form" quick action — already → `/form-builder`.)

## Access control

- Building (list/create/edit/archive) is admin/super-admin only — enforced both
  by RLS (writes) and UI (`isAdminProfile(profile)` gate on `FormBuilderScreen`,
  mirroring `admin_appointments_logbook_screen.dart`'s access guard).
- Filling: any signed-in user whose `userAccountType` is in the template's
  `audience` (or whose audience is empty = everyone). `CustomFormsScreen` and the
  renderer apply `audienceAllows(...)`.

## Data flow

1. Admin opens `/form-builder` → `loadTemplates(includeArchived: true)`.
2. Create/edit → assemble `CustomFormTemplate` → `validateTemplate` →
   `saveTemplate` (insert with generated `code`, or update + bump `version`).
3. Audience user opens `/custom-forms` → `loadFillableTemplates(accountType)`
   (active + audience match).
4. Fill via `DynamicFormRenderer` → required validation → payload assembled →
   `persistFormSubmission(code, name, payload)` → row in `form_submissions`
   (non-chain; default `workflow_status`). Appears in current logbook / history.

## Error handling

- Builder save: surface Supabase errors inline (SnackBar + keep form open);
  block save when `validateTemplate` fails, listing the specific problems
  (duplicate keys, dropdown without options, table without columns, empty name).
- Renderer submit: block on missing required fields with field-level messages;
  surface insert errors via SnackBar; on success navigate back with a confirmation.
- List load failures: inline error + Retry, matching the dashboard pattern.

## Testing

Unit tests (pure logic, no Supabase):
- `test/custom_form_template_test.dart` — `fromMap`/`toMap` round-trip;
  `validateTemplate` catches duplicate keys, dropdown-without-options,
  table-without-columns, empty label/name; `audienceAllows` (empty audience =
  everyone; match; non-match); `slugifyCode` shape.
- `test/dynamic_form_payload_test.dart` — a pure `buildPayload(fields, values)`
  helper produces correctly typed values per field type and omits `section`.

Verification: `flutter analyze` clean; `flutter test` green; `flutter run -d windows`:
- As admin: build a form using every field type, set an audience, save; it
  appears in the list; archive/restore works.
- As a targeted user: the form appears in `/custom-forms`, fills, submits, and
  shows up in the current logbook / completed history; a non-targeted account
  does not see it.
- `flutter build windows --release` succeeds.

## Constraints honored

- No "Claude"/AI naming in code, UI, or data.
- No new dependencies (Material 3 + existing widgets).
- Field/`form_type`/payload conventions consistent with existing forms so built
  submissions round-trip through the existing logbook/history/viewer.
- Supabase migration + RLS authored and applied by us, not the user.
- No auto-inserts into `public.todos` / SEED_ENG unless explicitly instructed.

## Open items deferred to later SP2 phases (recorded, not built here)

- Generic PDF rendering of built forms (SP2.2).
- Signature-chain enforcement, `signature_requests` integration, submitter
  auto-stamp, registry reconciliation, chain view-mode (SP2.3).
- Server-side audience enforcement (currently client-side), template version
  history, conditional logic, file/photo fields.
