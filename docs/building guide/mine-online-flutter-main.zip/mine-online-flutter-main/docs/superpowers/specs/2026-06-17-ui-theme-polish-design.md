# UI & Theme Polish — Design

**Date:** 2026-06-17
**Status:** Approved for planning
**App:** Mine Online (Flutter — Windows + Android)

## Goal

Polish the admin shell + dashboard and the theming experience: fix layout
robustness, make the dashboard fully interactive, give the sidebar a distinct
look with a collapsible rail and colorful icons, and make per-user theme
customization richer and clearer (with a live preview). Profile-based theme
persistence + cross-device sync **already exists** (`ThemeProvider` commits
`theme_mode`/`custom_theme_color` to `profiles`; realtime syncs) — this work
improves the UX around it, not the persistence itself.

## Already done (pre-req, committed)

- KPI card overflow fixed: card content is shrink-safe (label ellipsis, value in
  `FittedBox`), and the KPI grid uses a fixed cell height (`mainAxisExtent`)
  instead of a width-dependent aspect ratio so cells are never too short.

## Phase 1 — Sidebar + Dashboard interactivity

### Sidebar (`admin_shell.dart`, `admin_sidebar.dart`)
- **Distinct background:** the sidebar panel uses a primary-tinted surface
  `Color.alphaBlend(scheme.primary.withValues(alpha: 0.07), scheme.surface)`
  with a right hairline border (`tones.line`). Adapts to every theme (the tint
  follows the active primary), and clearly separates nav from content.
- **Collapsible rail:** a session-scoped `ValueNotifier<bool> sidebarCollapsed`
  (new `lib/widgets/admin/sidebar_state.dart`) survives navigation between
  admin-native screens. A toggle button (chevron) at the top of the sidebar
  flips it. Expanded width 260; **collapsed width 72 with icons still visible**
  (labels hidden, each item shows a tooltip; sections collapse to their icon).
  Never fully hidden.
- **Colorful icons:** `SidebarLeaf` gains an accent `color`. Inactive items
  render their icon in that accent; the active item keeps the
  `primaryContainer` highlight. Section headers get an accent too. Colors come
  from a small, fixed palette so each item is visually distinct and premium.

### Dashboard (`kpi_stat_card.dart`, `appointment_activity_feed.dart`, `admin_dashboard_data.dart`, `admin_dashboard_screen.dart`)
- **Clickable KPI cards:** `KpiStatCard` gains an optional `onTap`. Wiring:
  Total Employees → `/profiles`; Active Appointments → `/appointment-history-logs`;
  Pending Forms → `/active-individual-current-logbook`; Safety Incidents →
  `/completed-logbook-history`.
- **Clickable activity rows:** `AppointmentActivityItem` gains the raw
  `row` map (added in `computeAdminDashboard`/`loadAdminDashboard`). The feed
  exposes `onOpen(AppointmentActivityItem)`; tapping a row opens the existing
  `SubmissionViewerDialog(row: item.row)` so it shows the real submission.
- **Cards distinguishable on all themes:** add a hairline outline to the global
  `cardTheme` (`RoundedRectangleBorder` with `side: BorderSide(color: outlineVariant)`)
  in `theme_provider.dart` so every Card reads clearly on any surface/seed color.

## Phase 2 — Theme customization polish

(`settings_screen.dart`, `theme_provider.dart`)

- **Clearer "Appearance" section:** labeled groups — "Theme mode" (Light / Dark /
  Custom) and, for custom, "Accent colour" with helper text. Copy explains the
  setting is saved to the user's profile and follows them across devices.
- **Live mini-preview panel:** a labeled preview Card that renders sample UI in
  the *previewed* scheme — a sample card, a FilledButton, a couple of chips, a
  KPI swatch, and a small sidebar strip — so the user sees "how it will look"
  before saving. (The whole app already previews live; this gives a focused,
  always-visible sample.)
- **Dependency-free colour picker:** keep the preset swatches + hex field, and
  add three R/G/B sliders that stay in sync with the hex value. No new package.
- **Custom in light or dark:** add a base-brightness toggle for custom mode so a
  custom accent works on a light *or* dark base. `theme_provider` gets
  `_customScheme(hex, brightness)`; the stored value distinguishes them (e.g.
  `theme_mode = 'custom'` + a `custom_theme_dark` flag, OR encode as
  `'custom'`/`'custom_dark'`). Chosen encoding: store mode `'custom'` and a
  boolean in the existing columns by reusing `theme_mode` values `'custom'`
  (light) and `'custom_dark'` (dark) — no new DB column needed.

## Phase 3 — App-wide colorful icons

- A shared helper `lib/theme/icon_accents.dart` exposing a tasteful, theme-aware
  accent for a given semantic category, plus a reusable approach for tinting
  leading/trailing icons.
- Apply across the primary surfaces: home dashboard cards (`DashboardCard`),
  the role dashboards, the Quick Actions grid, the sidebar (Phase 1), and the
  common app-bar action icons — so icons read as premium and colorful without a
  new dependency. Monochrome-but-accent-tinted (single-color Material glyphs in
  distinct colors), per the chosen approach.

## Cross-cutting constraints

- No new dependencies (Material 3 + `Icons.*` only).
- No "Claude"/AI naming anywhere.
- Theme persistence/sync untouched (already works); only the UI around it grows.
- Accessibility: accent icon colors must keep adequate contrast on their
  surface in light, dark, and custom themes (use accents derived from
  `MolTones`/scheme, not arbitrary low-contrast hues).
- Keep each widget file focused; the sidebar rail logic stays in the sidebar
  widgets.

## Testing

- Pure logic unit-tested where present (e.g. an `accentForIndex`/palette helper,
  the custom-mode brightness parsing in `ThemeProvider`).
- `flutter analyze` clean, `flutter test` green, `flutter build windows --release`
  succeeds after each phase.
- Manual (GUI) per phase: sidebar collapses to a rail with icons visible and a
  distinct background; KPI cards and activity rows navigate/open the viewer;
  cards are clearly outlined in light/dark/custom; the theme preview panel
  reflects changes and saving persists (reload → still applied); colorful icons
  render with good contrast in all themes.

## Build order

Phase 1 → Phase 2 → Phase 3, each its own plan + subagent-driven build with
review, then resume SP2.2 (PDF for built forms).
