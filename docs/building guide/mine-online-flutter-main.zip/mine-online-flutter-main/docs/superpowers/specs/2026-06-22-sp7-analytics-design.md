# SP7 — Analytics — Design

**Date:** 2026-06-22
**Status:** Approved (standing autonomy grant)
**Sub-project:** SP7 of the "absorb legacy Mine-On-Line admin feature set" program.
**Predecessors:** SP1 Admin shell + dashboard … SP6 Devices.

---

## 1. Goal

An admin **Analytics** dashboard at `/analytics` (replacing the placeholder):
headline KPIs + breakdown charts + a submissions trend over forms, appointments,
users/devices, and the signature workflow — over a selectable date range.

## 2. Approach + key decisions

- **No new dependencies.** The app has a proven KPI pattern (`KpiStatCard` +
  pure compute function in `admin_dashboard_data.dart`) but no chart library. The
  legacy analytics screen itself only had KPI cards + lists with *placeholder*
  chart boxes. So SP7 **hand-rolls lightweight charts with `CustomPaint`**
  (horizontal bar breakdowns + a trend sparkline) — zero deps, and more than the
  legacy shipped. (If richer interactive charts are wanted later, `fl_chart` is a
  small additive change.)
- **Client-side aggregation**, mirroring `admin_dashboard_data.dart`: fetch rows
  (date-filtered) then aggregate in a **pure, unit-tested `computeAnalytics(...)`**.
  Data volumes are small (a young app); no SQL views/RPCs or migration needed.
  (If volumes grow, swap the loader for `supabase.rpc()` aggregates later — the
  pure compute boundary makes that easy.)

## 3. Scope

### In scope
1. `lib/utils/analytics_data.dart` — `AnalyticsSummary` model + pure
   `computeAnalytics(...)` + async `loadAnalytics({int days})`.
2. Chart widgets `lib/widgets/analytics/mini_bar_chart.dart` +
   `trend_sparkline.dart` (CustomPaint).
3. `lib/screens/analytics_screen.dart` — admin-gated; range chips (7/30/90/365);
   four sections (Forms, Appointments, Users & Devices, Signatures) each with
   reused `KpiStatCard`s + a breakdown bar chart + a top-N list; Forms also gets a
   30-day trend sparkline.
4. Real route `/analytics` (remove placeholder); sidebar leaf already exists.
5. Unit tests for `computeAnalytics`.

### Out of scope
- "System performance" metrics (uptime/response time) — the legacy mocked these;
  not meaningful for a Supabase-direct app. Skipped (YAGNI).
- Export of analytics (that's SP8 Reports territory).
- New deps / DB migrations / RPC aggregates (client-side is sufficient now).

## 4. Data + metrics

All from existing tables (read-only). Date filter applies to each table's natural
timestamp.

- **Forms** (`form_submissions`, filter `created_at`): total + % change vs prior
  equal-length period; counts by `form_type` (top N); counts by `workflow_status`
  (`submitted`/`pending_signature`/`fully_signed`); **per-day counts** (trend).
- **Appointments** (`appointments`, filter `issued_at`): total; by `status`
  (pending_acceptance/pending_signoff/active/declined/resigned); by `role_code`
  (top N); acceptance rate = `accepted_at not null / total`.
- **Users & Devices** (`profiles`, `devices`): active profiles count + breakdown
  by `user_account_type`; devices total + by `platform`; device pending count
  (`approved=false and is_active`).
- **Signatures** (`signature_requests`, filter `created_at`): pending count by
  `requested_role`; completion rate = `status='signed' / total`.

## 5. Components / files

**Data layer** — `lib/utils/analytics_data.dart`:
- `class Breakdown` = `List<MapEntry<String,int>>` helper (sorted desc) — or just
  return `Map<String,int>` and sort in the widget. Use a small
  `sortedDesc(Map<String,int>)` util.
- `class AnalyticsSummary` (immutable): `formsTotal`, `formsChangePct` (num?),
  `formsByType` (Map), `formsByStatus` (Map), `formsPerDay` (List<int>),
  `apptTotal`, `apptByStatus` (Map), `apptByRole` (Map), `apptAcceptanceRate`
  (double), `profilesByAccountType` (Map), `devicesTotal`, `devicesByPlatform`
  (Map), `devicesPending`, `sigPendingByRole` (Map), `sigCompletionRate` (double).
- `AnalyticsSummary computeAnalytics({required DateTime now, required int days,
  required List<Map> submissions, prior submissions, appointments, profiles,
  devices, signatureRequests})` — pure; buckets `formsPerDay` over the last
  [days]; % change uses a pre-fetched prior-period submission count.
- `Future<AnalyticsSummary> loadAnalytics({int days = 30})` — fetches the windows
  (current + prior for forms) with `.gte/.lt('created_at', …)`, caps `.limit(5000)`,
  calls `computeAnalytics`.

**Widgets** — `lib/widgets/analytics/`:
- `MiniBarChart({Map<String,int> data, Color color, int maxBars = 6})` — labeled
  horizontal bars (CustomPaint or `LayoutBuilder` + `FractionallySizedBox`; use
  simple `Row`+`Container` bars for crispness, no CustomPaint needed for bars).
- `TrendSparkline({List<int> values, Color color})` — a CustomPaint line/area for
  the per-day trend.

**Screen** — `lib/screens/analytics_screen.dart`: `initState` → `loadAnalytics`;
range chips re-load; four `Card` sections; reuse `KpiStatCard`
(`lib/widgets/admin/kpi_stat_card.dart`) for headline numbers; `PageBody.list`;
`commonAppBarActions`; admin gate via `isAdminProfile`.

**Routing** — `lib/routing/router.dart`: remove `/analytics` from `_placeholders()`;
add a real `GoRoute` → `AnalyticsScreen`.

**Tests** — `test/analytics_test.dart`: `computeAnalytics` over sample rows
(by-type/status counts; per-day bucketing with a fixed `now`; acceptance +
completion rates; % change).

## 6. Data flow

Admin opens `/analytics` → `loadAnalytics(days: 30)` fetches the date-windowed rows
→ `computeAnalytics` aggregates → sections render KPI cards + bar charts + trend +
top-N lists. Changing the range chip re-loads. (Optional realtime refresh on
`form_submissions` is a nice-to-have; a manual Refresh action is included.)

## 7. Error handling

- Admin-gated (`isAdminProfile`); non-admins see the standard message.
- Load failure → `_error` + SnackBar + Refresh (existing pattern).
- Empty data → charts render an "No data for this range" state; rates default to 0.

## 8. Testing / verification

- `flutter analyze` clean; `flutter test` green (existing 74 + analytics tests);
  `flutter build windows --release`.
- No migration. User runs the visual `flutter run -d windows` pass.

## 9. Risks / open questions

- **Client-side aggregation cap.** `.limit(5000)` per window; fine for a young app.
  If volumes exceed that, move aggregation to `supabase.rpc()` (the pure compute
  boundary isolates the change). Documented, not built now.
- **Hand-rolled charts** are intentionally simple (bars + sparkline). Faithful to
  the legacy (which had less) and dependency-free; richer charts are a later
  optional `fl_chart` add.
- **RLS on aggregated tables.** Admins can read all rows (existing policies allow
  admin reads on form_submissions/appointments/devices/signature_requests), so the
  aggregates are complete for admins.
