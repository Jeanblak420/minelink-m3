# SP9c — Broader Audit Feed

**Date:** 2026-06-25
**Status:** Approved (design)
**Scope:** Third/final slice of SP9. Builds on SP9a (`audit_log`,
`describeAuditEntry`, the `/setup/audit-log` screen) and is independent of SP9b.

## Goal

Capture **appointment** and **device** lifecycle actions in the existing
`public.audit_log` and surface them in the same Audit Log screen, so the log is a
single feed of meaningful admin/user actions — not just user-account changes.

Mostly DB triggers + describer cases. No new screen, no new Flutter dependency.

## Discoveries (verified against the live DB)

- `public.appointments` columns include: `id, role_code, appointee_id,
  issued_by, status, issued_at, accepted_at, declined_at, activated_at,
  resigned_at`. Statuses: `pending_acceptance / pending_signoff / active /
  declined / resigned`. Existing trigger: `trg_appointments_notify`.
- `public.devices` columns include: `id, user_id, device_name, platform,
  approved, approved_by, is_active`. Existing triggers: `trg_devices_guard`,
  `trg_devices_notify`.
- `audit_log` (live, SP9a) + the pure `describeAuditEntry` already render entries;
  the describer has a generic fallback so unknown actions don't break.

## Data model — migration `supabase/migrations/<ts>_sp9c_broader_audit.sql`

Two `SECURITY DEFINER` trigger functions writing `audit_log`. They are additive —
the existing notify/guard triggers are untouched.

### Appointments

```sql
create or replace function public.fn_audit_appointment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
  v_appointee text;
begin
  if tg_op = 'INSERT' then
    v_action := 'appointment.issued';
  elsif new.status is distinct from old.status then
    v_action := case new.status
      when 'pending_signoff' then 'appointment.accepted'
      when 'active'          then 'appointment.activated'
      when 'declined'        then 'appointment.declined'
      when 'resigned'        then 'appointment.resigned'
      else null
    end;
  else
    v_action := null;
  end if;

  if v_action is null then
    return new;
  end if;

  select full_name into v_appointee
    from public.profiles where id = new.appointee_id;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, new_values)
  values (
    coalesce(auth.uid(),
             case when tg_op = 'INSERT' then new.issued_by else null end),
    v_action, 'appointment', new.id,
    jsonb_build_object('role_code', new.role_code,
                       'appointee_name', v_appointee,
                       'status', new.status)
  );
  return new;
end;
$$;

drop trigger if exists trg_appointments_audit on public.appointments;
create trigger trg_appointments_audit
  after insert or update on public.appointments
  for each row execute function public.fn_audit_appointment();
```

> Note: `pending_signoff` is the status an appointment reaches once the appointee
> accepts (mirrors the SP4 lifecycle), so it maps to `appointment.accepted`.

### Devices

```sql
create or replace function public.fn_audit_device()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
begin
  if new.approved = true and coalesce(old.approved, false) = false then
    v_action := 'device.approved';
  elsif new.is_active = false and coalesce(old.is_active, true) = true then
    v_action := 'device.revoked';
  elsif new.is_active = true and coalesce(old.is_active, true) = false then
    v_action := 'device.restored';
  else
    v_action := null;
  end if;

  if v_action is null then
    return new;
  end if;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, new_values)
  values (
    auth.uid(), v_action, 'device', new.id,
    jsonb_build_object('platform', new.platform,
                       'device_name', new.device_name)
  );
  return new;
end;
$$;

drop trigger if exists trg_devices_audit on public.devices;
create trigger trg_devices_audit
  after update on public.devices
  for each row execute function public.fn_audit_device();
```

Device-registration inserts are intentionally NOT logged (every app launch
upserts a device row — too noisy for an audit feed).

Applied via the Management API AND written to `supabase/migrations/`.

## Flutter changes

### `lib/utils/audit_data.dart`
Add cases to `describeAuditEntry` (read from `newValues`):
- `appointment.issued` → "{actor} issued a {role_code} appointment to {appointee_name}"
  (fallbacks: "An administrator" actor; "an appointee" when name missing;
  "an appointment" when role_code missing).
- `appointment.accepted` → "{actor} accepted a {role_code} appointment".
- `appointment.declined` → "{actor} declined a {role_code} appointment".
- `appointment.activated` → "A {role_code} appointment became active".
- `appointment.resigned` → "{actor} resigned from a {role_code} appointment".
- `device.approved` → "{actor} approved a device ({platform})".
- `device.revoked` → "{actor} revoked a device ({platform})".
- `device.restored` → "{actor} restored a device ({platform})".
A shared private helper formats the "{role_code} appointment" / "({platform})"
fragments so the cases stay short.

Refactor `loadAuditLog` to filter by a **list** of actions:
`Future<List<AuditEntry>> loadAuditLog({int limit = 200, List<String>? actions})`
— uses `.inFilter('action', actions)` when the list is non-empty, else no filter.
(The only caller is the Audit Log screen.)

### `lib/screens/setup/audit_log_screen.dart`
Change the `_Filter` model to hold `List<String>? actions` (null = all). Existing
single-action chips become one-element lists. Add two **group** chips:
- "Appointments" → all five `appointment.*` actions.
- "Devices" → the three `device.*` actions.
Selection compares by identity of the chosen filter (track the selected `_Filter`
index or label rather than a single action string).

## Testing — additions to `test/audit_test.dart`
Pure `describeAuditEntry`:
- `appointment.issued` with role_code + appointee_name →
  "Jean Burger issued a Shift Boss appointment to Bob Miner".
- `appointment.activated` (no actor) → "A Shift Boss appointment became active".
- `device.approved` with platform → "Jean Burger approved a device (windows)".
- `device.revoked` → "Jean Burger revoked a device (android)".
- A missing-field fallback (e.g. `appointment.issued` with no appointee_name →
  "… to an appointee").

## Files

New:
- `supabase/migrations/<ts>_sp9c_broader_audit.sql`

Edited:
- `lib/utils/audit_data.dart` (describer cases + `loadAuditLog` actions param)
- `lib/screens/setup/audit_log_screen.dart` (group filter chips)
- `test/audit_test.dart`

## Verification

`flutter analyze` clean · `flutter test` green · `flutter build windows
--release`. Migration applied + the two trigger functions/triggers verified to
exist via the Management API. The live trigger writes are exercised by the user's
in-app pass (issue/accept an appointment, approve/revoke a device → entries
appear in the Audit Log under the Appointments / Devices filters).

## Non-goals / parity notes

- No device-registration logging (noisy). No new screen or table.
- Existing user/submission audit entries and the notify/guard triggers are
  untouched. Triggers are additive and `SECURITY DEFINER` (consistent with SP9a).
- `auth.uid()` may be null for an activation driven by the signature-chain
  completion path; the describer degrades the actor gracefully.
