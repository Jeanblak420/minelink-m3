# SP4.5 — Full-edit Form Builder (pixel-identical overlay) — Design

**Date:** 2026-06-21
**Status:** Draft for user review (standing autonomy grant)
**Sub-project:** SP4.5 of the "absorb legacy Mine-On-Line admin feature set" program.
**Predecessors:** SP2 (Form Builder — custom forms), SP3 (Appointment Builder),
SP4 (Appointments lifecycle).
**Successor:** SP4.6 — "legacy-style" builder (a faithful clone of the original
Mine-On-Line app's builder). Deferred; its own spec.

---

## 1. Goal

Make every **current** form in the app editable through a builder — the 27
built-in bespoke forms **and** the appointment forms — supporting full editing:
add fields, **add pages**, remove/hide fields, relabel, re-type, reorder.

**Hard constraint (non-negotiable):** the forms must look **pixel-identical to
today** — on screen and in PDF — for everything the admin has not deliberately
changed. A form nobody edits is byte-identical to the current build. Nothing
delivered in SP1–SP4 changes or breaks.

This is **Builder 2** of a two-builder vision. **Builder 1** (a faithful
re-implementation of the *old* Mine-On-Line app's builder, "exactly as the old
app") is a separate later sub-project (**SP4.6**) and is out of scope here.

## 2. Why an overlay, not a schema rebuild

"Fully editable" and "pixel-identical even when edited" can only both hold if the
untouched parts of a form keep rendering through their existing bespoke widgets.
So we do **not** convert forms into a generic schema rendered by a generic
engine (that would shift spacing/layout). Instead:

- The **bespoke screen + bespoke PDF remain the baseline renderer.** Untouched →
  identical, by construction.
- Each form carries an **edit overlay** (a list of operations) describing only
  what the admin changed. The bespoke screen + PDF apply the overlay.
- The builder's dynamic field primitives are the **same helper widgets** the
  bespoke forms already use (`_tf`-style `TextFormField`, yes/no dropdown,
  `DatePickerField`, `SignatureCanvasField`, the inspection-table widget), so an
  added/edited field is visually indistinguishable from a native one. A shared
  `dynamic_form_primitives.dart` holds these so screen + PDF + builder agree.

## 3. Scope

### In scope (SP4.5)
1. **Overlay model + storage** — per-form overlay of edit operations.
2. **Form registry** — metadata for all current forms (built-ins + appointment
   forms) so the builder can list them.
3. **Full-edit builder UI** — pick a current form → edit it: add fields, add
   pages/sections, hide/remove, relabel, re-type, reorder, mark required.
4. **Overlay application** in the bespoke form screens (shared mechanism) +
   bespoke PDFs (shared mechanism), preserving pixel-identity for untouched
   content and matching styles for edited/added content.
5. **Payload namespacing** so overlay-added values never collide with the typed
   payload; round-trips through view-mode + logbook + signature chain unchanged.
6. **Phased rollout across all 27 built-ins + appointment forms.**

### Phasing (all within SP4.5; reported at each milestone)
- **Phase A — Foundation + universal additions/pages.** Overlay model, storage,
  registry, builder UI, shared primitives, and the shared "added fields / added
  pages" applicator wired into every current form screen + PDF. Delivers
  add-fields and add-pages on **every** form, fully pixel-identical (appended /
  new-page content only; nothing existing moves). This is the bulk of "additions
  and new pages with whatever the user pleases."
- **Phase B — Per-field structural overrides.** Hide/remove, relabel, re-type,
  reorder of **existing** fields. Requires per-form anchor instrumentation
  (giving existing fields stable ids the overlay can target). Rolled out form by
  form; each instrumented form keeps pixel-identity (only the explicitly
  overridden field changes).

### Out of scope
- **Builder 1** (legacy-app clone) → SP4.6.
- Changing a form's **submission semantics or signature chain** (form_type,
  chain signers, the edge function) — overlays add/skin fields; they do not
  rewire the workflow.
- Re-rendering untouched forms through a generic engine (explicitly rejected).

## 4. Data model

Reuse `custom_form_templates` (SP2) as the per-form overlay store, keyed by the
form's `code` = its `form_type`. One row per edited current form.

Migration `20260622xxxxxx_form_overlays.sql`:
- `alter table public.custom_form_templates add column if not exists overlay jsonb not null default '{}'::jsonb;`
- `alter table public.custom_form_templates add column if not exists base_form_type text;`
  (`base_form_type` is set for overlay rows; null for standalone SP2 custom
  forms. A standalone custom form is unchanged.)

`overlay` JSON shape (versioned):
```json
{
  "version": 1,
  "addedPages": [ { "id": "p1", "title": "Extra checks", "fields": [ FormFieldDef, ... ] } ],
  "addedFields": [ { "anchor": "append", "field": FormFieldDef } ],
  "fieldOverrides": {            // Phase B; keyed by stable field id
    "shiftBossName": { "hidden": false, "label": "Supervisor name", "type": "text", "required": true }
  },
  "order": [ "fieldId", "..." ]  // Phase B; optional reordering within a region
}
```
`FormFieldDef` is the SP2 model (reused as-is). RLS already on
`custom_form_templates` (read-active/admin-write) covers overlays.

## 5. Components / files

**Shared primitives** — `lib/widgets/form_builder/dynamic_form_primitives.dart`:
the exact field widgets the bespoke forms use, exposed for the dynamic renderer +
builder preview so added/edited fields match native styling. (Refactor the
bespoke `_tf`/`_yn` helpers' styling into shared builders; bespoke screens may
adopt them with zero visual change.)

**Overlay model** — `lib/models/form_overlay.dart` (pure): `FormOverlay`
(`addedPages`, `addedFields`, `fieldOverrides`, `order`) + `fromMap`/`toMap` +
helpers (`hasContent`, `effectiveAddedFields`). Reuses `FormFieldDef`.

**Registry** — `lib/utils/form_metadata.dart`: `FormMetadata` (formType, title,
route, category, isAppointmentForm, chainSigners) + `kFormMetadataRegistry` for
all current forms. Drives the builder's "pick a form" list.

**Data layer** — extend `lib/utils/custom_form_data.dart` (or new
`form_overlay_data.dart`): `loadOverlay(formType)`, `saveOverlay(formType,
overlay)`, used by builder + screens + PDF.

**Builder UI** — extend `lib/screens/form_builder_screen.dart` with a "Edit a
current form" entry → form picker (from registry) → `_OverlayEditorScreen`:
shows the form's structure (Phase B: existing fields as targetable rows; Phase A:
just the added-fields/pages editor using `FieldEditorList`) + a live preview that
renders the actual bespoke screen with the overlay applied.

**Overlay application (screens)** — `lib/widgets/form_builder/form_overlay_host.dart`:
a shared widget appended into each bespoke screen's body that renders
`addedFields` + `addedPages` via the shared primitives (Phase A). Phase B adds an
override-lookup the bespoke fields consult by stable id. One small insert per
screen; renders nothing when the overlay is empty (→ pixel-identical).

**Overlay application (PDF)** — `lib/pdf/pdf_overlay_appendix.dart`: appends
added fields/pages to a bespoke `pw.Document` in matching style; called at the
end of each bespoke generator. No-op when empty.

**Payload** — overlay values live under `payload['overlay']` (added fields/pages)
and never touch typed keys. View-mode hydrate + logbook + chain ignore it; PDF +
viewer render it.

## 6. Pixel-identity guarantee + verification

- **By construction:** untouched content renders through the unchanged bespoke
  widgets/PDF; the overlay host/appendix render nothing when empty.
- **Verification per form:** a golden check — with an empty overlay, the screen
  widget tree and the generated PDF bytes equal the pre-SP4.5 output. Phase A
  ships a test asserting empty-overlay PDFs are unchanged for a sample of forms;
  manual visual diff for the rest during the user's run pass.
- Added/edited fields use shared primitives matched to bespoke styling, so they
  sit seamlessly with native fields.

## 7. Error handling

- Admin-gated builder (`isAdminProfile`). Non-admin fill/screens unaffected.
- Overlay load failure → render the form with no overlay (safe degradation:
  identical to today).
- Validation reuses `validateTemplate` for added fields; overrides validated for
  type compatibility before save.

## 8. Testing / verification

- `flutter analyze` clean; `flutter test` green (existing 64 + overlay model
  tests + empty-overlay-PDF golden); `flutter build windows --release`.
- Overlay migration applied + verified via Management API.
- User runs the visual `flutter run -d windows` pass.

## 9. Risks / open questions

- **Scale.** All 27 + appointment forms is the largest sub-project yet. Phase A
  is universal and mechanical (shared host/appendix); Phase B is per-form and
  rolls out progressively. Milestones reported as forms land.
- **Phase B pixel-identity when *re-typing/relabeling* an existing field.** The
  field re-renders via the matched primitive; near-identical but the one changed
  field is, by definition, changed. Untouched fields never move.
- **"Add a page" in absolute-coordinate PDFs.** New pages are appended as clean
  builder-style pages (consistent, not mimicking a specific legacy page) — the
  existing pages are untouched.
- **Builder 1 (legacy clone)** intentionally deferred to SP4.6 to keep this
  tractable; the registry + primitives built here are reused there.
