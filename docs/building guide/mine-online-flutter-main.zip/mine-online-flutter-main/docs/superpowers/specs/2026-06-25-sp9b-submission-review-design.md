# SP9b — Submission Review Queue

**Date:** 2026-06-25
**Status:** Approved (design)
**Scope:** Second slice of SP9. Independent of SP9a (user lifecycle) and SP9c
(broader audit feed), though it reuses SP9a's `audit_log` + `describeAuditEntry`.

## Goal

Give Admins a queue to review submitted forms and **approve / reject / flag**
them **outside the signature chain**, with a reviewer note. Each review is
audited and notifies the submitter.

## Discoveries (verified against the live DB)

- `public.form_submissions` columns: `id, user_id, form_type, title, payload,
  created_at, workflow_status, current_signature_role, completed_at, updated_at,
  device_id`. **No review columns yet.**
- `form_submissions` has **SELECT + INSERT policies only — NO UPDATE policy.**
  The signature chain mutates rows via the service-role `signature-workflow`
  edge function. Admins already SELECT every submission (policy "Users and admins
  can view form submissions").
- RLS UPDATE policies are row-level, not column-level — a broad admin UPDATE
  policy would let admins overwrite `payload`/`workflow_status`. So review writes
  go through a `SECURITY DEFINER` RPC instead (column-scoped, admin-gated).
- `notifications` columns include `user_id, type, title, message, body,
  action_url, metadata, is_read, created_at` (same shape the edge function uses).
- `audit_log` (live, SP9a) + the pure `describeAuditEntry` are ready to record
  review events.

## Data model — migration `supabase/migrations/<ts>_sp9b_submission_review.sql`

```sql
alter table public.form_submissions
  add column if not exists review_status text not null default 'pending',
  add column if not exists review_note text,
  add column if not exists reviewed_by uuid references public.profiles(id),
  add column if not exists reviewed_at timestamptz;

-- Optional sanity constraint on allowed values.
alter table public.form_submissions
  drop constraint if exists form_submissions_review_status_chk;
alter table public.form_submissions
  add constraint form_submissions_review_status_chk
  check (review_status in ('pending','approved','rejected','flagged'));

create or replace function public.set_submission_review(
  p_submission_id uuid,
  p_status text,
  p_note text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_actor uuid := auth.uid();
  v_old text;
  v_user uuid;
  v_title text;
begin
  if not public.is_admin(v_actor) then
    raise exception 'Forbidden: admin only';
  end if;
  if p_status not in ('pending','approved','rejected','flagged') then
    raise exception 'Invalid review status: %', p_status;
  end if;

  select review_status, user_id, title
    into v_old, v_user, v_title
    from public.form_submissions
   where id = p_submission_id;
  if not found then
    raise exception 'Submission not found';
  end if;

  update public.form_submissions
     set review_status = p_status,
         review_note = p_note,
         reviewed_by = v_actor,
         reviewed_at = now()
   where id = p_submission_id;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, old_values, new_values)
  values
    (v_actor, 'submission.review', 'form_submission', p_submission_id,
     jsonb_build_object('review_status', v_old),
     jsonb_build_object('review_status', p_status, 'note', p_note,
                        'title', v_title));

  -- Notify the submitter (skip when reverting to pending or self-review).
  if p_status <> 'pending' and v_user is not null and v_user <> v_actor then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    values (
      v_user, 'system',
      'Submission ' || p_status,
      'Your "' || coalesce(v_title, 'submission') || '" was ' || p_status ||
        case when p_note is not null and length(trim(p_note)) > 0
             then '. Note: ' || p_note else '' end,
      '/current-logbook',
      jsonb_build_object('category', 'review', 'submission_id', p_submission_id)
    );
  end if;
end;
$$;

grant execute on function
  public.set_submission_review(uuid, text, text) to authenticated;
```

Applied via the Management API AND written to `supabase/migrations/`.

## Flutter changes

### Data layer — `lib/utils/review_data.dart` (new)
- `class ReviewSubmission` — `id, formType, formLabel, title, submitter,
  createdAt, workflowStatus, reviewStatus, reviewNote, raw` (raw row passed to
  the viewer dialog). `formLabel` via `formLabelFor` (reuse `report_data.dart`'s
  helper? It's in `report_data.dart`; to avoid a cross-import, use
  `form_metadata.dart`'s registry directly here, same one-liner).
- Pure **`String reviewStatusLabel(String? status)`** → `Pending` / `Approved` /
  `Rejected` / `Flagged` (null/empty → `Pending`, unknown → the raw value).
- `Future<List<ReviewSubmission>> loadReviewQueue({String? status})` — selects
  `form_submissions` (id, user_id, form_type, title, workflow_status,
  review_status, review_note, payload, created_at) filtered by `review_status`
  when `status != null`, ordered `created_at desc`, limit 1000; resolves submitter
  names via one `profiles` `inFilter`.
- `Future<void> setSubmissionReview({required String id, required String status,
  String? note})` → `supabase.rpc('set_submission_review', params: {...})`.

### Audit describer — `lib/utils/audit_data.dart`
Add a `case 'submission.review'` to `describeAuditEntry`:
> "{actor} {status} the submission \"{title}\"" — status/title read from
> `newValues` (`review_status`, `title`); falls back to a generic phrasing if
> absent. (No target-name dependency, since `entity_id` is a submission, not a
> profile.)

Also add a "Submission reviews" filter (`submission.review`) to the Audit Log
screen's chip list.

### Screen — `lib/screens/setup/submission_review_screen.dart` (new)
- Admin-gated (`isAdminProfile`), loading/error states like `audit_log_screen.dart`.
- Filter chips: All / Pending / Approved / Rejected / Flagged (drive `loadReviewQueue`).
- Rows: title, `form · submitter · date`, a review-status badge (color from a
  small tone map), a **View** icon (opens `SubmissionViewerDialog(row: ...)`) and
  a **Review** icon → a dialog with three choices (Approve/Reject/Flag) + a note
  `TextField` → `setSubmissionReview` → reload + snackbar.

### Routing / nav
- `lib/routing/router.dart`: `GoRoute('/setup/submission-review')` →
  `SubmissionReviewScreen`.
- `lib/widgets/admin/admin_sidebar.dart`: a Setup leaf
  `SidebarLeaf('Submission Review', Icons.rate_review_outlined, '/setup/submission-review', accent: …)`.

## Testing — `test/review_test.dart` + additions to `test/audit_test.dart`
- `reviewStatusLabel`: pending (incl. null/empty), approved, rejected, flagged,
  unknown passthrough.
- `describeAuditEntry` `submission.review`: with title+status in `new_values`
  ("… approved the submission \"Weekly SHERQ Meeting\""), and the missing-data
  fallback.

## Files

New:
- `lib/utils/review_data.dart`
- `lib/screens/setup/submission_review_screen.dart`
- `test/review_test.dart`
- `supabase/migrations/<ts>_sp9b_submission_review.sql`

Edited:
- `lib/utils/audit_data.dart` (submission.review describer case)
- `lib/screens/setup/audit_log_screen.dart` (filter chip)
- `lib/routing/router.dart`
- `lib/widgets/admin/admin_sidebar.dart`
- `test/audit_test.dart`

## Verification

`flutter analyze` clean · `flutter test` green · `flutter build windows
--release`. Migration applied + RPC smoke-checked (a review round-trip flips
`review_status`, writes one `audit_log` row + one notification). Visual run is
the user's.

## Non-goals / parity notes

- The signature chain is untouched: `review_status` is orthogonal to
  `workflow_status`. A form can be fully signed and still flagged, or pending
  signature and approved.
- No bulk review actions, no review SLA/assignment.
- Writes go only through the admin-gated RPC — no client UPDATE on
  `form_submissions`, so the (intentional) absence of an UPDATE policy stays.
