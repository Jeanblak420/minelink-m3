# SP10b — Field reorder pilot (Early Shift Record)

**Date:** 2026-06-26
**Status:** Approved (design)
**Scope:** Ship 2 of the form-edit UX work — a bounded pilot proving the
field-reorder mechanism on ONE form. Rolling reorder out to other forms, retype,
PDF reflection, and editable-field-catalog completion are explicitly out of scope
(separate follow-ups).

## Goal

Let an admin drag-reorder a **contiguous block of fields** on a built-in form and
have the **on-screen fill form** honor that order — proving the end-to-end
mechanism (overlay `order` → screen render → editor drag UI) on a single pilot
form before any broad rollout.

## Hard safety boundaries (non-negotiable)

1. **PDF is untouched.** Reorder affects only the on-screen fill form. Every
   bespoke PDF generator keeps its exact statutory coordinate layout. The legal
   document never changes from a reorder.
2. **Empty overlay → byte-identical.** With no saved `order`, the form renders in
   its natural order exactly as today. The refactor must preserve the current
   sequence when no override is present (this is the primary test).
3. **Bounded region.** Only a clean, contiguous block of simple single-widget
   fields is reorderable. Conditional fields, dividers, the yes/no safety checks,
   signatures, and the overlay host are NOT in the reorderable region.

## Pilot form + region

`early_shift_record`. The reorderable region is the top identity/timing block
(screen lines ~234–286, before the `Divider()`): eight fields, each a single
widget in a flat sequence, no conditionals:

| id | label |
|----|-------|
| `section` | Section |
| `strike` | Strike |
| `date` | Date |
| `wentUndergroundAt` | Went underground at (am/pm) |
| `arrivedAtWaitingPlace` | Arrived at waiting place at (am/pm) |
| `minerArrivedAt` | Miner arrived at (am/pm) |
| `minerCoyNo` | Miner Coy No. |
| `waitingPlaceLocation` | Waiting place location |

Everything below the divider (the yes/no checks, conditionals, special
instruction, additional remarks, signatures, overlay host) stays exactly where it
is. (`date` is the `DatePickerField` at line 248; it gets a stable id for
ordering but stays a date picker — no override-awareness needed for reorder.)

## Mechanism

### Pure logic — `lib/models/form_overlay.dart`
Reuse the existing `FormOverlay.order` (`List<String>`). Add a pure, tested
helper:

```dart
/// The effective field order: ids named in [order] first (in that order,
/// ignoring any not in [natural]), then any [natural] ids not named in [order],
/// in natural order. Empty [order] → [natural] unchanged.
List<String> applyFieldOrder(List<String> natural, List<String> order) { ... }
```

### Reorderable-block catalog — `lib/utils/form_field_catalog.dart`
Add a per-form ordered block list (reuses `FormFieldRef`):

```dart
const Map<String, List<FormFieldRef>> kReorderableBlocks = {
  'early_shift_record': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('strike', 'Strike'),
    FormFieldRef('date', 'Date'),
    FormFieldRef('wentUndergroundAt', 'Went underground at (am/pm)'),
    FormFieldRef('arrivedAtWaitingPlace', 'Arrived at waiting place at (am/pm)'),
    FormFieldRef('minerArrivedAt', 'Miner arrived at (am/pm)'),
    FormFieldRef('minerCoyNo', 'Miner Coy No.'),
    FormFieldRef('waitingPlaceLocation', 'Waiting place location'),
  ],
};
```
This is the single source of truth for both the screen (natural id order) and the
editor (drag list labels).

### Pilot screen — `lib/screens/early_shift_record_form_screen.dart`
- Load the full overlay, not just overrides: replace
  `loadFieldOverrides('early_shift_record')` with `loadFormOverlay(...)`,
  storing `_overrides = overlay?.fieldOverrides ?? {}` and
  `_order = overlay?.order ?? const []`.
- Refactor the top block (lines ~234–286) into an id-keyed builder map built
  inline in `build`:
  ```dart
  final blockBuilders = <String, Widget>{
    'section': _tf('Section', _data.section, (v) => _data.section = v, id: 'section'),
    'strike': _tf('Strike', _data.strike, (v) => _data.strike = v, id: 'strike'),
    'date': DatePickerField(value: _data.date, onChanged: (v) => setState(() => _data.date = v)),
    'wentUndergroundAt': _tf(...),
    // ... all eight, identical widgets to today
  };
  final blockIds = kReorderableBlocks['early_shift_record']!.map((r) => r.id).toList();
  ```
  Then render the block with **12px BETWEEN fields only** (no trailing spacer),
  followed by the existing 16px gap + `Divider()` exactly as today:
  ```dart
  final orderedIds = applyFieldOrder(blockIds, _order);
  for (var i = 0; i < orderedIds.length; i++) ...[
    blockBuilders[orderedIds[i]]!,
    if (i < orderedIds.length - 1) const SizedBox(height: 12),
  ],
  const SizedBox(height: 16),
  const Divider(),
  const SizedBox(height: 8),
  // ... unchanged: the yes/no checks begin here
  ```
  The widgets are exactly the ones in place today and the inter-field 12px +
  trailing 16px/`Divider()`/8px spacing is preserved, so an empty `_order`
  yields a byte-identical layout. (Current spacing to preserve: each top field is
  followed by `SizedBox(height: 12)`; after `waitingPlaceLocation` it is
  `SizedBox(height: 16)` then `Divider()` then `SizedBox(height: 8)`.)
- Nothing below the divider changes.

### Editor — `lib/screens/form_builder_screen.dart` (`_OverlayEditorScreen`)
- Add a **"Reorder fields"** section, shown only when
  `kReorderableBlocks[meta.formType]` exists. It renders a `ReorderableListView`
  of those fields in the current effective order
  (`applyFieldOrder(blockIds, _overlay.order)`), each row a drag handle + label.
- On reorder, update local state holding the new id list; `_build()` includes it
  as `order:` in the saved `FormOverlay`. A "Reset order" affordance clears it
  back to `[]` (natural order).
- The existing add-fields / add-pages / existing-field hide-relabel sections are
  unchanged.

## Testing — `test/form_overlay_test.dart` (extend if it exists, else create)
Pure `applyFieldOrder`:
- empty order → natural unchanged;
- full permutation → that permutation;
- partial order (subset) → named ids first, remaining natural ids appended in
  natural order;
- unknown ids in order are ignored;
- idempotence: `applyFieldOrder(natural, applyFieldOrder(natural, order))` is
  stable.

## Files

New:
- `test/form_overlay_test.dart` (if absent).

Edited:
- `lib/models/form_overlay.dart` (`applyFieldOrder`)
- `lib/utils/form_field_catalog.dart` (`kReorderableBlocks`)
- `lib/screens/early_shift_record_form_screen.dart` (ordered top block)
- `lib/screens/form_builder_screen.dart` (reorder UI in `_OverlayEditorScreen`)

No migration (the overlay column + `order` field already exist). No new dependency
(`ReorderableListView` is core Flutter).

## Verification

`flutter analyze` clean · `flutter test` green (existing + `applyFieldOrder`) ·
`flutter build windows --release`. Manual (user): with no overlay, Early Shift
Record looks identical; reorder the top block in the editor → Save → the fill
form shows the new order; the generated PDF is unchanged.

## Non-goals (explicit)

- No reorder of the yes/no safety checks, conditionals, signatures, or fields
  below the divider.
- No reorder on the other 26 forms (each needs its own bounded-region refactor —
  follow-up if the pilot proves valuable).
- No **retype** (the `FieldOverride.type` field stays unused; changing a
  statutory field's input type is dubious and low-value).
- No PDF reflection of reorder/hide/relabel.
- No editable-field-catalog completion (separate mechanical sweep).
