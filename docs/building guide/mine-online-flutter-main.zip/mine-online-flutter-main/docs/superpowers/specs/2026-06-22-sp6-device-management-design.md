# SP6 — Device Management — Design

**Date:** 2026-06-22
**Status:** Approved (standing autonomy grant; two key decisions confirmed by user)
**Sub-project:** SP6 of the "absorb legacy Mine-On-Line admin feature set" program.
**Predecessors:** SP1 Admin shell … SP4.6 Builder 1.

---

## 1. Goal

Bring the legacy app's **device management** into the Flutter app: each install
registers as a device, admins approve / revoke devices, and every form/appointment
submission records the device that made it (audit trail).

## 2. Two decisions (confirmed)

- **Enforcement = informational + audit, NOT a hard gate.** The legacy hard-blocked
  unapproved devices via a Node middleware (`X-Device-ID` header). This app talks to
  Supabase **directly** (no middleware); a hard block would mean gating every table's
  RLS on an approved-device check — invasive and lockout-prone. So SP6 is a
  governance + audit feature: unapproved devices still function, but admins see/manage
  them and submissions are device-stamped.
- **Add deps for stable per-install identity (user-approved).** `uuid` (generate the
  device id) + `shared_preferences` (persist it locally so the same install is
  recognized across launches). Without local persistence there is no stable device
  identity; with it, audit binding is real.

## 3. Scope

### In scope
1. New deps `uuid`, `shared_preferences`.
2. `devices` table + RLS + an approval-guard trigger + a notifications trigger.
3. Local device identity (get-or-create uuid; platform via `dart:io`).
4. **Auto-registration** on authenticated launch (upsert the device row; refresh
   last_seen).
5. Admin screen `/setup/devices` (list / approve / revoke / restore) — replaces the
   placeholder; sidebar leaf already exists.
6. **Audit binding:** nullable `device_id` on `form_submissions`, stamped centrally by
   the two persist functions.
7. Notifications: admins on new registration; user on approval.

### Out of scope
- Hard login/RLS enforcement (explicitly rejected — informational only).
- Per-table device gating; appointment_signatures device columns (no such table here).
- A rich per-user "my devices" management UI (the user is notified on approval; the
  admin screen is the management surface). A read-only "this device" status is a
  nice-to-have, deferred.

## 4. Data model

### 4.1 `devices`
| Column | Type | Notes |
|---|---|---|
| `id` | uuid pk | the **client-generated** device id (stable per install) |
| `user_id` | uuid not null → `profiles(id)` on delete cascade | registering user |
| `device_name` | text not null | e.g. "Windows 11 (DESKTOP-AB12)" or a user name |
| `platform` | text not null check in ('windows','android','other') | from `dart:io` |
| `approved` | boolean not null default false | admin-controlled |
| `approved_at` | timestamptz null | |
| `approved_by` | uuid null → `profiles(id)` on delete set null | |
| `last_seen_at` | timestamptz not null default now() | refreshed each launch |
| `is_active` | boolean not null default true | revoke = false |
| `created_at` / `updated_at` | timestamptz not null default now() | |

### 4.2 RLS
- **SELECT**: `user_id = auth.uid()` OR `public.is_admin(auth.uid())`.
- **INSERT**: `with check (user_id = auth.uid())`.
- **UPDATE**: `using/with check (user_id = auth.uid() or public.is_admin(auth.uid()))`.

### 4.3 Guard trigger (BEFORE UPDATE)
`devices_guard_approval`: when the caller is **not** an admin, force the
approval/active columns to their OLD values — so a user's launch upsert may refresh
`last_seen_at`/`device_name` but can never self-approve or self-revoke. Admins may
change them.

### 4.4 Notifications trigger (AFTER INSERT OR UPDATE OF approved), SECURITY DEFINER
- INSERT → notify every admin: "New device registered" (`action_url`
  `/setup/devices`).
- `approved` false→true → notify `user_id`: "Device approved".
(Same pattern as the SP4 appointment triggers; revoked from public/authenticated.)

### 4.5 `form_submissions.device_id` (audit)
`alter table public.form_submissions add column if not exists device_id uuid;`
Nullable, no FK (avoids cascade coupling). Stamped at insert time by the two persist
functions; existing rows stay null; nothing else reads it except future audit views.

Migration file `supabase/migrations/<ts>_devices.sql`, written to the repo **and**
applied via the Management API (PAT `claude-supabase-pat-hhrnkzznpadrmyverhyb`, ref
`hhrnkzznpadrmyverhyb`).

## 5. Components / files

**Local identity** — `lib/utils/device_identity.dart`:
- `Future<String> currentDeviceId()` — read `device_id` from `shared_preferences`;
  if absent, generate `const Uuid().v4()`, persist, return it. Cache in memory.
- `String? cachedDeviceId` — the in-memory value (null until first `currentDeviceId`);
  read synchronously by the persist functions for audit stamping.
- `String currentPlatform()` — `'windows' | 'android' | 'other'` via `dart:io`.
- `String defaultDeviceName()` — e.g. `Platform.operatingSystemVersion` trimmed +
  platform.

**Model** — `lib/models/device.dart` (pure): `Device` (+ `fromMap`), getters
`isPending`/`statusLabel`. Optional unit test for status logic.

**Data layer** — `lib/utils/device_data.dart`:
- `Future<void> registerCurrentDevice(UserProfile me)` — upsert
  `{id: deviceId, user_id, device_name, platform, last_seen_at}` (onConflict id).
- `Future<List<Device>> loadDevices({bool includeRevoked = true})` (admin: all).
- `Future<void> setDeviceApproved(String id, bool approved)` — set
  `approved`, `approved_at`, `approved_by`.
- `Future<void> setDeviceActive(String id, bool active)` — revoke/restore.

**Auto-register hook** — `lib/providers/auth_provider.dart`: after the profile loads
on sign-in, call `registerCurrentDevice(profile)` (fire-and-forget; failures
swallowed/logged — never block sign-in).

**Audit stamping** — `lib/utils/signature_workflow.dart`: `persistFormSubmission`
and `saveFormSubmissionAndStartWorkflow` add `'device_id': cachedDeviceId` to the
insert when non-null.

**Admin screen** — `lib/screens/setup/devices_admin_screen.dart` (admin-gated;
mirrors `appointments_admin_screen.dart`): status filter chips (All / Pending /
Approved / Revoked); a Card per device (device_name, platform icon, user name,
status badge, last-seen); row menu **Approve / Revoke / Restore**. Loads a
`profiles` id→name map for display.

**Routing** — `lib/routing/router.dart`: remove `/setup/devices` from `_placeholders()`;
add a real `GoRoute` → `DevicesAdminScreen`.

**pubspec** — add `uuid` + `shared_preferences`; `flutter pub get`.

## 6. Data flow

Sign-in → profile loads → `registerCurrentDevice(me)` upserts this install's device
(pending) → the INSERT trigger notifies admins. Admin opens `/setup/devices`,
**Approves** → the UPDATE trigger notifies the user. Thereafter every form/appointment
submission carries `device_id` (audit). Revoke flips `is_active=false`
(informational; submissions keep working).

## 7. Error handling

- Device registration is best-effort: any failure is logged and never blocks sign-in
  or the app.
- Admin screen: `_error` + SnackBar + Refresh (existing pattern).
- Guard trigger prevents privilege escalation on the approval columns regardless of
  client behaviour.
- `cachedDeviceId` null (e.g. registration not yet run) → submissions simply omit
  `device_id`.

## 8. Testing / verification

- `flutter analyze` clean; `flutter test` green (existing 72 + device status test);
  `flutter build windows --release`.
- Migration applied + verified (table, triggers, guard) via Management API; a
  non-admin self-approval attempt is rejected by the guard (smoke-tested in a
  rolled-back DO block).
- User runs the visual `flutter run -d windows` pass.

## 9. Risks / open questions

- **Shared device id across users on one install.** The device row is keyed by the
  install's uuid; if a second user signs in on the same install, the upsert reassigns
  `user_id` (current user) and keeps the approval state. Acceptable for a
  governance/audit feature (one install ≈ one operator).
- **No hard enforcement** — by design (informational). If hard gating is ever wanted,
  it's a separate, carefully-rolled-out RLS change.
- **`shared_preferences` on Windows + Android** — both supported by the plugin; no
  platform-specific code needed.
