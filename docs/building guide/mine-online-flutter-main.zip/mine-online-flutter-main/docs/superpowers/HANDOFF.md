# Mine Online — Program Handoff / Continuation Guide

**Last updated:** 2026-06-25
**Purpose:** Let a fresh chat continue the "absorb the legacy admin feature set
into the Flutter app" program without re-deriving context.

---

## What this program is

Bring the original **Mine-On-Line** app's admin / super-admin capabilities into
the current **Flutter + Supabase** app (`Mine Online`), re-implemented natively
(NOT a literal port). Legacy reference folder:
`C:\Users\Somebody Someone\Desktop\Blak_AI-Agent_Model\Mine Online\Original-Mine-Online-app\mine-on-line-backend`
(multi-language: Node backend, React frontend, old Flutter, `documents/`).

Specs + plans for every sub-project live in `docs/superpowers/specs/` and
`docs/superpowers/plans/`.

## Status — DONE and merged to `main`

- **SP1 — Admin Shell + Dashboard**: responsive sidebar shell (permanent ≥1000px,
  hamburger drawer below) for Admin + Super Admin; 4 real-data KPI cards;
  Quick Actions; dismissible tip; Appointment Activity feed. Files under
  `lib/widgets/admin/` + `lib/screens/admin_dashboard_screen.dart` +
  `lib/utils/admin_dashboard_data.dart`.
- **SP2 — Form Builder (full parity)**:
  - SP2.1 authoring + fill (`custom_form_templates` table; `/form-builder`
    admin, `/custom-forms` audience). All field types incl. signature, section,
    repeating table; per-form audience targeting.
  - SP2.2 generic schema-driven PDF (`lib/pdf/generate_custom_form_pdf.dart`);
    wired into the submission viewer's Download PDF + a fill-screen "Generate PDF".
  - SP2.3 signature chain for custom forms (no edge-function change — inject the
    recognized blank signature fields `signatures.mineOverseerSignature` /
    `signatures.mineManagerSignature` so the existing `signature-workflow`
    function drives the chain; PDF "Approvals" section).
- **UI & Theme Polish**: sidebar distinct bg + collapse-to-rail (icons stay,
  `sidebar_state.dart` ValueNotifier) + icons in **theme primary** (matches the
  screenshot; NOT a rainbow); KPI overflow fixed (FittedBox + fixed grid cell
  height); clickable KPI cards + activity rows (open submission viewer); global
  card hairline outline; Settings "Appearance" with live preview panel, RGB
  sliders, presets, hex, custom Light/Dark base (`theme_mode` values:
  `light`/`dark`/`custom`/`custom_dark`). NOTE: theme persistence to
  `profiles.theme_mode`/`custom_theme_color` + cross-device sync ALREADY existed
  in `ThemeProvider`.
- **SP5 — Org structure**:
  - SP5a Locations (`/setup/locations`): Shaft → Section → Area CRUD. Reused
    existing `shafts` (8 rows); added `sections`, `areas`.
  - SP5b Gangs + Shifts (`/setup/gangs`): gang CRUD (shaft→section + shift
    pickers), per-gang members (from `profiles`), Shifts manager. Added
    `shifts`, `gangs`, `gang_memberships`.
  - Models `lib/models/org_location.dart`; data `lib/utils/org_data.dart`;
    screens `lib/screens/setup/`.
- **SP3 — Appointment Builder + Letter Builder** (authoring only):
  - New tables `appointment_roles` (seeded: Mine Manager 2.6.1, Mine Overseer
    2.9.2, Shift Supervisor/Shift Boss 2.13.1, Engineer 2.13.2, Miner, Relieving
    Miner) + `appointment_templates` (role + `FormFieldDef` fields + `letter_body`,
    required_signers, version). Read-active/admin-write RLS via
    `public.is_admin`. Migration `20260621120000_create_appointment_templates.sql`.
  - `/appointment-builder` is now LIVE (admin-gated): list + editor with
    **Details & fields** tab (role picker, name/desc/language, signer chips,
    reused SP2 `FieldEditorList`) and **Letter** tab (token palette for field keys
    and standard profile tokens, live preview, Preview PDF). "Manage roles" dialog
    does role CRUD. Letter tokens `{{key}}`/`{{full_name}}` etc.; minimal markdown
    (`# heading`, `**bold**`).
  - Files: model `lib/models/appointment_template.dart` (pure: `extractPlaceholders`,
    `renderLetterBody`, `validateAppointmentTemplate`, reuses `FormFieldDef`);
    data `lib/utils/appointment_template_data.dart`; PDF
    `lib/pdf/generate_appointment_letter_pdf.dart`; screen
    `lib/screens/setup/appointment_builder_screen.dart`. Tests
    `test/appointment_template_test.dart` (12). Spec + plan under
    `docs/superpowers/specs|plans/2026-06-21-sp3-*`.
  - NOTE: SP3 is authoring only — issuance/lifecycle lives in SP4 (now done).
- **SP4 — Appointments lifecycle** (DONE): issue → appointee accepts & signs →
  Mine Overseer/Manager co-sign (reuses the existing `signature-workflow` edge
  function, unchanged) → active → resign. One-live-per appointee/role/shaft/month
  enforced.
  - New table `appointments` (migration `20260621140000` + `20260621150000` adds
    `form_type`): lifecycle record with `status` ∈ pending_acceptance /
    pending_signoff / active / declined / resigned, generated `period_month`,
    partial unique index `appointments_one_live_per_slot`, RLS (appointee reads
    own, admin all; admin insert; appointee-or-admin update). Two SECURITY DEFINER
    triggers: `trg_appointments_notify` (issue/accept/decline/resign → notifications)
    and `trg_appointments_activate` (flips to active when the linked
    `form_submissions` row hits `fully_signed`). Both smoke-tested.
  - **Works with BOTH** SP3 dynamic templates (`appt_…`) **and the 3 built-in
    appointment forms** (shift_boss/miner/relieving_miner). Built-ins run the same
    lifecycle: issue creates a shell; the appointee opens the existing form screen
    (new optional `onSubmitted` ctor param) to fill+sign, which links the
    submission and starts the chain. Catalog: `lib/utils/appointable_forms.dart`.
  - Files: model `lib/models/appointment.dart`; data `lib/utils/appointment_data.dart`
    (issue/accept/decline/resign + uniqueness + `linkAppointmentSubmission`);
    screens `lib/screens/setup/appointments_admin_screen.dart` (issue+monitor) +
    `lib/screens/my_appointments_screen.dart` (appointee inbox). `form_registry`
    renders `appt_` letters. Routes `/setup/appointments` (admin sidebar) +
    `/my-appointments` (sidebar + appointments hub card). Tests
    `test/appointment_lifecycle_test.dart` (8). Spec/plan
    `docs/superpowers/specs|plans/2026-06-21-sp4-*`.

- **SP4.5 — Full-edit form builder (overlay), Phase A DONE** (2026-06-21): the
  builder can now EDIT every current form via a per-form **overlay** stored on
  `custom_form_templates` (`overlay` jsonb + `base_form_type`, migration
  `20260622120000`). Architecture is an **overlay** (NOT a schema rebuild): the
  bespoke screen/PDF stay the baseline → un-edited forms are pixel-identical; the
  overlay layers on added fields/pages. Phase A delivers **add-fields + add-pages
  across all 27 forms** (+ appointment forms).
  - Foundation: `lib/models/form_overlay.dart` (+ tests), `lib/utils/form_overlay_data.dart`,
    `lib/utils/form_metadata.dart` (registry of all 27 forms),
    `lib/widgets/form_builder/form_overlay_host.dart` (screen applicator — renders
    nothing when empty), `lib/pdf/pdf_overlay_appendix.dart` (PDF appendix, no-op
    when empty, applied in `generatePdfForFormType`). Builder UI: "Edit a current
    form" in `form_builder_screen.dart` (pick a form → add fields/pages → Save/Preview).
  - Every form screen got a `FormOverlayHost` insert + `payload['overlay']` merge.
    Lockout checklist is PDF-only (no persist) so its added-field VALUES aren't
    saved — minor known gap.
  - This is **Builder 2** of the user's two-builder vision. **Builder 1** (faithful
    clone of the OLD Mine-On-Line app's builder) is **SP4.6**, still to spec.
  - Spec/plan `docs/superpowers/specs|plans/2026-06-21-sp4_5-*`.

- **SP4.6 — Builder 1 (legacy-style form designer) DONE** (2026-06-22): a
  faithful re-implementation of the OLD Mine-On-Line app's form builder UX — a
  manager (Active/Archived + Create New Form) + a **3-column designer** (Form
  Fields list | Live Preview grouped by section→row→rowOrder | Edit Field panel)
  at `/form-designer` (admin; Templates sidebar). Authors into the EXISTING
  `custom_form_templates` (general) + `appointment_templates` (appointment) — no
  duplicate storage. Adds the legacy **data-linked "dynamic dropdown"**: new
  `form_dropdown_sources` allowlist table (seeded shafts/sections/areas/gangs/
  shifts/appointment_roles/profiles; migration `20260622160000`); options read
  via `supabase.from(allowlisted_table)` (never raw SQL). `FormFieldDef` extended
  with optional `section/row/rowOrder/tabIndex/dropdownSource` +
  `FormFieldType.dynamicDropdown` (+ `groupBySection`); `DynamicFormRenderer` gains
  a `grouped` mode + dynamic-dropdown rendering; custom-form PDF prints the
  resolved option label (`<key>__label`). Files: `lib/screens/form_designer_screen.dart`,
  `lib/utils/form_dropdown_data.dart`. Tests `test/form_designer_test.dart` (3).
  Both builders now exist (Builder 2 = SP4.5 overlay; Builder 1 = this).
- **SP6 — Device Management DONE** (2026-06-22): per-install device registry,
  informational + audit (NOT a hard gate — Supabase-direct, no middleware). On
  authenticated launch the app auto-upserts a `devices` row keyed by a locally
  persisted uuid (`lib/utils/device_identity.dart`; new deps `uuid` +
  `shared_preferences`), platform via `dart:io`. Admin screen `/setup/devices`
  (replaces placeholder; sidebar leaf existed) lists devices with Approve / Revoke
  / Restore. `devices` table (migration `20260622180000`) + RLS + a guard trigger
  (non-admins can't self-approve) + a SECURITY DEFINER notify trigger (admins on
  registration, user on approval). Submissions are device-stamped via a nullable
  `form_submissions.device_id` set centrally in the two persist functions. Files:
  `lib/models/device.dart`, `lib/utils/device_data.dart`,
  `lib/screens/setup/devices_admin_screen.dart`. Tests `test/device_test.dart` (2).
- **SP7 — Analytics DONE** (2026-06-22): admin dashboard at `/analytics` (replaces
  placeholder; sidebar leaf existed). KPIs + **hand-rolled charts (NO new deps)** —
  `MiniBarChart` + `TrendSparkline` (CustomPaint) under `lib/widgets/analytics/`.
  Four sections (Forms / Appointments / Users & Devices / Signatures) with reused
  `KpiStatCard` + breakdown bars + a 30-day submissions trend, over 7/30/90/365-day
  range chips. Client-side aggregation via a pure `computeAnalytics(...)` in
  `lib/utils/analytics_data.dart` (mirrors `admin_dashboard_data.dart`; NO
  migration/RPC — swap the loader for `supabase.rpc()` later if volumes grow).
  Tests `test/analytics_test.dart` (4). "System performance" metrics intentionally
  skipped (the legacy mocked them; meaningless for Supabase-direct).
- **SP8 — Reports DONE** (2026-06-25): admin Daily/Weekly/Monthly **period
  compliance reports** at `/reports/daily|weekly|monthly` (replaces the 3
  placeholders; sidebar leaves existed). Each report = a **compliance summary**
  (KPIs: submissions, fully-signed, pending-in-chain, safety incidents,
  appointments issued/accepted, signature-completion %) + breakdowns (by form,
  by status) + a **submission register** line-item table. The three differ only
  by date window. **PDF export** via `Printing.layoutPdf` over a `pw.MultiPage`
  generator (`lib/pdf/generate_report_pdf.dart`, modeled on the custom-form PDF).
  **On-demand only — NO migration, NO new deps.** Client-side aggregation: pure
  `reportWindow(period, anchor)` (local-time windows, Mon-start weeks, exclusive
  end) + `computeReport(...)` in `lib/utils/report_data.dart`, both unit-tested
  (`test/report_test.dart`, 6); thin `loadReport(period, anchor)` fetches windowed
  rows. Reuses `kIncidentFormTypes`/`kPendingWorkflowStatuses` (dashboard),
  `sortedDesc` (analytics), form labels (`form_metadata.dart`). One
  `ReportScreen(period: ReportPeriod)` backs all three routes (variant pattern).
  Spec/plan `docs/superpowers/specs|plans/2026-06-25-sp8-*`.
- **SP9a — User Lifecycle + Audit Trail DONE** (2026-06-25): first slice of SP9
  (the user picked it over audit-only / submission-review). Super Admins can
  **disable / re-enable** accounts and **role changes are audited**; Admins get a
  read-only **Audit Log** screen at `/setup/audit-log` (sidebar leaf added).
  - **Built on the EXISTING live `public.audit_log`** (360 rows, already written
    by the `admin-create-user` edge function on create/delete/password). The
    earlier "vestigial audit_log" note was WRONG — corrected in the DB map below.
  - Migration `20260625120000_sp9_user_lifecycle_audit.sql` (applied via Mgmt
    API): adds `profiles.disabled`+`disabled_at`; **security fix** — replaced the
    world-readable `"Allow public read audit_log"` policy with admin-only
    `"Admins read audit_log"` (`is_admin(auth.uid())`); SECURITY DEFINER trigger
    `trg_profiles_audit_role` audits `user_account_type` changes (`user.role_change`).
  - Edge function gained an **additive** `set_disabled` action (bans/unbans the
    auth user via `ban_duration`, flips `profiles.disabled`, writes
    `user.disable`/`user.enable`); deployed via `npx supabase functions deploy`
    (Docker-less, `SUPABASE_ACCESS_TOKEN`=PAT). Backward-compatible with the web
    app's create/delete/update_password.
  - Flutter: `UserProfile.disabled`; `AuthProvider` force-signs-out a disabled
    profile (immediate lockout on top of the ban) + exposes `lockoutMessage`;
    `isSuperAdminProfile`; `adminSetUserDisabled`; pure tested
    `describeAuditEntry` + loaders in `lib/utils/audit_data.dart`
    (`test/audit_test.dart`, 8); `AuditLogScreen`; User Management gains a
    super-admin Disable/Enable action + "Disabled" badge. **Gating split**:
    lifecycle WRITES = Super Admin; audit VIEW = Admin.
  - Spec/plan `docs/superpowers/specs|plans/2026-06-25-sp9-*`.
- **SP9b — Submission Review Queue DONE** (2026-06-25): admin queue to
  **approve / reject / flag** submitted forms **outside the signature chain** with
  a reviewer note, at `/setup/submission-review` (sidebar leaf). Writes go through
  an admin-gated **`SECURITY DEFINER` RPC `set_submission_review(p_submission_id,
  p_status, p_note)`** (migration `20260625130000`) — because `form_submissions`
  has NO client UPDATE policy (chain writes are service-role); the RPC updates only
  the review columns, writes a `submission.review` audit row, and notifies the
  submitter. New cols `form_submissions.review_status` (default `pending`, check
  pending/approved/rejected/flagged) + `review_note`/`reviewed_by`/`reviewed_at`.
  Flutter: `lib/utils/review_data.dart` (pure tested `reviewStatusLabel` +
  `loadReviewQueue` + `setSubmissionReview` rpc), `SubmissionReviewScreen` (reuses
  `SubmissionViewerDialog`), `describeAuditEntry` submission.review case + an Audit
  Log filter chip. Tests `test/review_test.dart` (3) + audit additions. Gating:
  Admin. NOTE: the RPC can't be smoke-tested via the Mgmt API (`auth.uid()` null →
  admin check raises) — live round-trip is the in-app pass.
- **SP9c — Broader Audit Feed DONE** (2026-06-25): audits **appointment** + **device**
  lifecycle into the same `audit_log`. Migration `20260625140000` adds two additive
  `SECURITY DEFINER` triggers: `trg_appointments_audit`
  (issued/accepted/activated/declined/resigned; `new_values` carries role_code +
  appointee_name snapshot) and `trg_devices_audit` (approved/revoked/restored;
  device-registration inserts NOT logged — too noisy). `describeAuditEntry` renders
  all eight new actions; the Audit Log screen's `loadAuditLog` now takes an action
  **list** (`.inFilter`) with **Appointments** + **Devices** group filter chips.
  Tests in `test/audit_test.dart` (now 16). **SP9 is now fully done** (a/b/c).
  103 tests pass overall.
- **SP10a — Form-edit discoverability DONE** (2026-06-26): the user couldn't find
  how to edit the built-in forms (Form Builder body only listed *custom* forms;
  editing a current form was hidden behind the ✎ app-bar icon). Form Builder now
  shows a **"Current forms"** section — all built-ins from `kFormMetadataRegistry`
  grouped by category, each tappable → the existing overlay editor (shared
  `_openOverlayEditor` helper), with an **"Edited"** chip on forms that have a
  non-empty overlay. Pure tested `groupFormsByCategory` (`test/form_metadata_test.dart`)
  plus a bulk `loadEditedFormTypes()` (one query). Discoverability only — no form/PDF/
  editor change. Spec/plan `docs/superpowers/specs|plans/2026-06-26-sp10a-*`.
- **SP10b — Field reorder pilot DONE** (2026-06-26): admins can drag-reorder the
  top identity/timing block (8 fields) of **Early Shift Record** in the overlay
  editor; the on-screen fill form honors the saved order. **Hard boundaries kept:
  PDF generators UNTOUCHED (reorder is on-screen only), empty overlay =
  byte-identical, only a bounded contiguous no-conditional block** (everything
  below the divider — yes/no checks, conditionals, signatures, overlay host —
  unchanged). Mechanism: pure tested `applyFieldOrder(natural, order)` in
  `form_overlay.dart`; `kReorderableBlocks` catalog (`form_field_catalog.dart`)
  is the single source of truth for the screen's id order + the editor list; the
  pilot screen renders the block from an id-keyed builder map; the overlay editor
  has a `ReorderableListView` + "Reset order" writing `overlay.order`. Tests in
  `test/form_overlay_test.dart`. **NOTE:** `kFormFieldCatalog` already covers many
  forms (hide/relabel works on them), not just the pilot.
  **REMAINING (not built):** reorder for the other forms (each needs its own
  bounded-region refactor — repeat the SP10b pattern per form); **retype**
  (`FieldOverride.type` still unused — dubious for statutory fields); PDF
  reflection of reorder/hide/relabel (risky for coordinate PDFs). Do per-form,
  only if asked.
- **SP11 — Live form-edit preview DONE** (2026-06-26): the overlay editor renders
  the **whole form live** as you edit — added fields/**tables**, hide/relabel, and
  reorder reflect immediately (side-by-side on wide windows via `LayoutBuilder
  ≥900px`, Edit/Preview tabs on narrow). Mechanism: new **`FormViewArgs.overlayOverride`**
  (`FormOverlay?`); `FormOverlayHost` uses it instead of `loadFormOverlay` when set
  (+ `didUpdateWidget` re-load); the **26 bespoke form screens** prefer
  `widget.viewArgs?.overlayOverride` in `_loadOverrides()` before the DB load + pass
  it to their `FormOverlayHost`. **Override is null in every normal flow → the 27
  forms stay byte-identical** (payload-parity suite unchanged, 111 tests — the
  safety guarantee). Preview pane = `buildFormView(formType, FormViewArgs(mode:
  view, overlayOverride: _build()))` keyed by overlay hash. (Adding a table already
  worked via the "Added fields" Table button + column editor; SP11 makes it
  visible.) Spec/plan `docs/superpowers/specs|plans/2026-06-26-sp11-*`. The 26-screen
  sweep used parallel subagents (recipe in the plan) — repeat it for any new form
  screen.
- **SP11b — preview polish DONE** (2026-06-26): (1) the live preview is now
  **debounced** (~350 ms after the last edit) so typing a relabel doesn't rebuild
  the heavy form each keystroke — `_OverlayEditorScreen` caches `_previewOverlay`
  and only refreshes the preview key on settle; (2) new **`FormViewArgs.embedded`**
  (default false) — the 26 form screens render `appBar: embedded ? null :
  AppBar(...)`, and the preview passes `embedded: true` + wraps the pane in
  `AbsorbPointer`, so the nested app bar and accidental-navigation footgun are gone.
  Inert when false → standalone forms byte-identical (111 tests). The `embedded`
  app-bar edit was a scripted sed sweep over the 26 `*_form_screen.dart`.
- **FS1 — Form Template Studio (lifecycle foundation) DONE** (2026-06-26): first
  of a **Form Template Studio program (FS1→FS2→FS3)** the user wants: edit the 27
  forms' look/wording/tables, originals never touched, draft→test→active lifecycle.
  **FS1** ships the Studio at `/templates/studio` (sidebar **Form Studio**, admin):
  an **Originals** tab (`kFormMetadataRegistry`, read-only, **Edit = clone to a
  draft**, never delete) and an **Edited** tab (drafts: Edit / **Test** / **Set
  active**/Deactivate / Delete). An **overlay draft** = a `custom_form_templates`
  row with `base_form_type` + own `overlay` + `is_active`; one active per form
  (migration `20260626120000` partial unique index, smoke-verified). Data layer
  reworked (`form_overlay_data.dart`): `loadFormOverlay(formType)` now returns the
  **active** draft (so all 26 forms + the PDF appendix use it; none active =
  original fallback) + `OverlayDraft`/`listOverlayDrafts`/`createOverlayDraft`/
  `saveOverlayDraft`/`deleteOverlayDraft`/`setOverlayDraftActive`/
  `deactivateOverlayForForm`/`loadOverlayDraft` + pure tested `activeDraftName`
  (`test/overlay_draft_test.dart`). The overlay editor is now **public
  `OverlayEditorScreen({draftId, baseFormType})`** (in `form_builder_screen.dart`),
  loads/saves by draft id with a name field; reuses the SP11 live preview. **Test**
  opens the form fully fillable+signable with the draft injected via
  `overlayOverride`, in a sandbox: global **`formTestMode`** (signature_workflow.dart)
  short-circuits `persistFormSubmission`/`saveFormSubmissionAndStartWorkflow` so
  nothing writes. **SP10a's "Current forms" list + the ✎ picker were removed** from
  Form Builder (Studio Originals replaces them); Form Builder is back to custom-form
  authoring. 113 tests pass. Spec/plan `docs/superpowers/specs|plans/2026-06-26-fs1-*`.
  **NEXT — FS2:** click-on-the-rendered-page WYSIWYG (make the live preview
  interactive: click an element to edit, click space to add, drag to place).
  **THEN FS3:** reflect edits into the printed PDF (the bespoke coordinate
  generators — the hard part). The draft `overlay` + active-draft resolution are
  the shared substrate both build on.

## Status — REMAINING roadmap (build next, in this order)

1. **SP4.5 Phase B — hide + relabel DONE across all 27 forms** (2026-06-22):
   each screen loads `loadFieldOverrides(formType)` into `_overrides`; its
   `_tf`/`_yn`-style helpers take an optional `id` and consult it (hide →
   `SizedBox.shrink()`, relabel → `override.label ?? label`). Per-form
   `lib/utils/form_field_catalog.dart` drives the builder's "Existing fields"
   editor. Purely additive (byte-identical with no override). Repeating
   tables/inspection-item widgets/signatures/date-pickers were NOT instrumented.
   **REMAINING in Phase B:** (a) reflect hide/relabel in the **PDF** (27 bespoke
   coordinate generators hardcode labels/positions — risky, per-form, no reflow);
   (b) **retype** + **reorder** of existing fields (heavier; reorder fights fixed
   layouts); (c) repeating-table field editing (needs a table-aware overlay).
   These threaten the pixel guarantee — do per-form with care, not a blind sweep.
   **Then SP4.6 — Builder 1** (legacy-app clone). Also pending: **gang
   role-requirements** (deferred from SP5b; unblocked by the SP3 roles catalog).
2. **SP9 User lifecycle / audit logs / submission review** (SP6 added
   `form_submissions.device_id` + the `devices` registry — useful audit inputs).
   (SP8 Reports is DONE — see above.)
3. **Optional polish:** extend the accent-icon treatment to remaining app-bar /
   per-screen icons (currently primary-coloured on sidebar, dashboard cards,
   quick actions only).

Placeholder routes still live (sidebar "Coming soon"):
`/logbook-version-management`, `/send-notifications-reminders`.
(`/appointment-builder`, `/setup/appointments`, `/my-appointments`,
`/form-designer`, `/setup/devices`, `/analytics`,
`/reports/daily|weekly|monthly` are now real routes — no longer placeholders.)

## How to work here (conventions + hard rules)

- **Git — NEVER `git add -A` / `git add .` / `git reset --hard` / `git clean`.**
  The working tree permanently carries the user's uncommitted WIP and a 46MB
  gitignored `release/`. Stage explicit paths only. To sync branches, `git stash -u`
  first. (See memory `feedback-never-git-add-all`.) Lost WIP is recoverable from
  dangling commits via `git reflog` + `git restore --source=<sha> -- <files>`.
- **Branch/merge:** `main` is the single base now. Per feature: branch off `main`,
  build, verify, then merge to `main` (PR via `gh`, or merge locally + push if
  `gh` flakes — it has). Delete the merged branch. Don't build a deep stack.
- **Supabase is yours.** Apply migrations + schema/RLS yourself. The claude.ai
  MCP gateway returns -32600 here, so use the **Management API** with the PAT in
  Windows Credential Manager target `claude-supabase-pat-hhrnkzznpadrmyverhyb`
  (UTF-16 decoded). Project ref `hhrnkzznpadrmyverhyb` (derive from local `.env`).
  Write the migration file in `supabase/migrations/` AND apply it. RLS gate:
  `public.is_admin(auth.uid())` (exists). Read-active + admin-write pattern as in
  the SP5 migrations.
- **⚠️ GRANT to `authenticated` on every NEW table.** Tables created via raw SQL
  (Management API / CLI migrations) do NOT get the `authenticated`/`anon`
  table-level grants the Supabase *dashboard* auto-applies. Postgres checks table
  privilege BEFORE RLS, so the client fails with `permission denied for table`
  (SQLSTATE `42501`) even with correct RLS policies — RLS is never reached. Every
  migration that `create table`s MUST also
  `grant select, insert, update, delete on <table> to authenticated;` (RLS still
  gates rows — grant broad, restrict via RLS, the Supabase model). This was a
  latent bug across ALL SP-created tables (appointments, devices, audit_log,
  custom_form_templates, sections, …); fixed wholesale in migration
  `20260625160000_grant_authenticated_on_app_tables.sql`. Legacy/vestigial tables
  intentionally stay ungranted. Verify a new table with
  `select has_table_privilege('authenticated','public.<t>','SELECT')` or a
  `set local role authenticated; select count(*) from <t>` smoke (0 rows, NOT
  42501).
- **Verify every change:** `flutter analyze` (clean) + `flutter test` (currently
  44 pass) + `flutter build windows --release`. The user runs the visual
  `flutter run -d windows` pass themselves (no GUI here).
- **No "Claude"/AI naming** in code, UI strings, or `public.todos`/SEED_ENG.
  No new dependencies without asking (Material 3 + `Icons.*`, `pdf`, `printing`,
  `go_router`, `provider`, `supabase_flutter`, `signature`, `dynamic_color`).
- **Patterns to copy:** data layer like `lib/utils/custom_form_data.dart` /
  `org_data.dart`; admin-gated screen like `form_builder_screen.dart` /
  `locations_screen.dart` (`isAdminProfile(profile)` gate); unit-test pure logic
  only; `dart format` touched files before committing.
- **⚠️ `PageBody` does NOT scroll** — it only constrains width + centres. A tall
  child (a `Column` of intrinsic-height content, or a `ListView(shrinkWrap: true,
  physics: NeverScrollable)`) put directly in `PageBody` overflows vertically.
  For such screens pass **`PageBody.list(scrollable: true, ...)`** (added 2026-06-26;
  wraps the child in a `SingleChildScrollView`), OR make the child a real scroller
  (a plain `ListView`, or wrap in `SingleChildScrollView`). Screens whose body is a
  `Column` ending in an `Expanded(...)` fill the height and are fine. This bit
  Analytics/Reports/Devices/Setup-Appointments/Form-Builder; all fixed.
- **Process:** brainstorm → spec (`docs/superpowers/specs/`) → plan → build.
  The user has given STANDING APPROVAL to proceed autonomously without per-step
  gates ("no need to approve, I trust you") — keep that unless they say otherwise.

## DB tables — quick map

- **Real / used:** `profiles`, `form_submissions`, `signature_requests`,
  `notifications`, `todos` (+ `parent_id`), `user_presence`, and SP-created:
  `custom_form_templates`, `sections`, `areas`, `shifts`, `gangs`,
  `gang_memberships`, `appointment_roles` (6 seeded), `appointment_templates`,
  `appointments` (SP4 lifecycle), `form_dropdown_sources` (SP4.6 data-linked
  dropdown allowlist, 7 seeded), `devices` (SP6 registry; `form_submissions` got a
  `device_id` audit column). `custom_form_templates` also now carries
  `overlay`+`base_form_type` (SP4.5 per-form edit overlays). `shafts` (8 rows) reused.
- **Real / used (SP9):** `audit_log` is **LIVE, not vestigial** (was
  mis-labelled before) — written by the `admin-create-user` edge function and the
  `trg_profiles_audit_role` trigger; read by `/setup/audit-log`. Cols: `user_id`
  (actor), `action`, `entity_type`, `entity_id`, `old_values`/`new_values` jsonb,
  `created_at`. RLS: admin-only SELECT; writes are service-role / SECURITY
  DEFINER only. `profiles` gained `disabled`/`disabled_at` (SP9a). `audit_log`
  also captures `submission.review` (SP9b) and `appointment.*`/`device.*` (SP9c)
  via SECURITY DEFINER triggers + the `set_submission_review` RPC. `form_submissions`
  gained `review_status`/`review_note`/`reviewed_by`/`reviewed_at` (SP9b).
- **Vestigial — IGNORE (not used by the Flutter app):** `form_templates`
  (42-row registry), `form_fields`, `form_instances`, `form_signatures`,
  `workplaces`, legacy `users`/`roles`/`user_roles`/`sessions`,
  per-form `*_records` tables.
- **Signature chain:** the `signature-workflow` edge function
  (`supabase/functions/signature-workflow/index.ts`) drives the chain off
  recognized payload signature-field paths (hard-coded `signatureRules`:
  `signatures.mineOverseerSignature` order 10, `signatures.mineManagerSignature`
  order 20), NOT a table. Signing uses the signer's `profiles.signature_data`.

## Immediate next action

**SP9 is fully DONE** (a: user lifecycle + audit trail; b: submission review queue;
c: broader audit feed) — see entries above. SP1–SP9 are all merged.

Open roadmap items, if the user wants them (none are started):

- **Gang role-requirements** — deferred from SP5b, unblocked by the SP3 roles
  catalog (`appointment_roles`). Per-gang required appointment roles + a
  compliance view (who's missing a required appointment).
- **SP4.5 Phase B remainder** — PDF hide/relabel reflection, field retype,
  reorder, repeating-table editing. Risky for the pixel-perfect coordinate PDFs;
  do per-form with care only if asked.
- **Optional polish** — extend the accent-icon treatment to remaining app-bar /
  per-screen icons.

No clear "next" is mandated — ask the user which direction. Same cadence:
brainstorm → spec → plan → build → verify → merge.
