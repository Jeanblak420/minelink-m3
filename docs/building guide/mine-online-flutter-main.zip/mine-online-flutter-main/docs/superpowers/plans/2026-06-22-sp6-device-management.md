# SP6 — Device Management Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:subagent-driven-development or superpowers:executing-plans. Steps use checkbox (`- [ ]`).

**Goal:** Per-install device auto-registration + admin approve/revoke + device-stamped submissions (informational/audit, no hard gate).

**Architecture:** A `devices` table keyed by a locally-persisted client uuid; auto-upserted on sign-in; a guard trigger keeps approval admin-only; a SECURITY DEFINER trigger notifies admins (registration) + the user (approval). A nullable `form_submissions.device_id` is stamped centrally by the two persist functions. Admin screen at `/setup/devices`.

**Tech Stack:** Flutter, `supabase_flutter`, `provider`, `go_router`, + new `uuid`, `shared_preferences`. `dart:io` for platform.

## Global Constraints

- New deps allowed here (user-approved): `uuid`, `shared_preferences`. No others.
- Informational only — never block sign-in/app on device state.
- No "Claude"/AI naming. `dart format` touched files. Verify: analyze + test + build windows.
- Supabase: migration in `supabase/migrations/` AND applied via Management API (PAT `claude-supabase-pat-hhrnkzznpadrmyverhyb`, ref `hhrnkzznpadrmyverhyb`). RLS via `public.is_admin(auth.uid())`.

## File Structure

- `pubspec.yaml` — add `uuid`, `shared_preferences`.
- Create `supabase/migrations/20260622180000_devices.sql`.
- Create `lib/utils/device_identity.dart`, `lib/models/device.dart`, `lib/utils/device_data.dart`.
- Modify `lib/providers/auth_provider.dart` (register on sign-in), `lib/utils/signature_workflow.dart` (stamp device_id).
- Create `lib/screens/setup/devices_admin_screen.dart`.
- Modify `lib/routing/router.dart` (real route).
- Create `test/device_test.dart`.

---

### Task 1: Deps

- [ ] Add to `pubspec.yaml` deps: `uuid: ^4.5.1` and `shared_preferences: ^2.3.5`. Run `flutter pub get`. Expected: resolves OK.
- [ ] Commit `SP6: add uuid + shared_preferences deps`.

### Task 2: Migration (table + RLS + guard + notify trigger + form_submissions.device_id)

- [ ] **Write** `supabase/migrations/20260622180000_devices.sql`:

```sql
create table if not exists public.devices (
  id            uuid primary key,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  device_name   text not null,
  platform      text not null check (platform in ('windows','android','other')),
  approved      boolean not null default false,
  approved_at   timestamptz,
  approved_by   uuid references public.profiles(id) on delete set null,
  last_seen_at  timestamptz not null default now(),
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists devices_user_idx on public.devices (user_id);
alter table public.devices enable row level security;

create policy "Read own or admin devices" on public.devices for select to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid()));
create policy "Insert own devices" on public.devices for insert to authenticated
  with check (user_id = auth.uid());
create policy "Update own or admin devices" on public.devices for update to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid()))
  with check (user_id = auth.uid() or public.is_admin(auth.uid()));

-- Non-admins may refresh last_seen/name but never the approval/active columns.
create or replace function public.devices_guard_approval()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin(auth.uid()) then
    new.approved := old.approved;
    new.approved_at := old.approved_at;
    new.approved_by := old.approved_by;
    new.is_active := old.is_active;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_devices_guard on public.devices;
create trigger trg_devices_guard before update on public.devices
  for each row execute function public.devices_guard_approval();

-- Notify admins on registration; notify the user on approval.
create or replace function public.devices_notify()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT') then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    select p.id, 'message', 'New device registered',
           coalesce((select full_name from public.profiles where id = new.user_id), 'A user')
             || ' registered a ' || new.platform || ' device',
           '/setup/devices',
           jsonb_build_object('deviceId', new.id::text, 'platform', new.platform)
    from public.profiles p
    where p.is_admin or p.is_super_admin or p.user_account_type in ('Admin','Super Admin');
    return new;
  elsif (tg_op = 'UPDATE' and new.approved is distinct from old.approved and new.approved) then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    values (new.user_id, 'success', 'Device approved',
            'Your device "' || new.device_name || '" has been approved.',
            '/setup/devices',
            jsonb_build_object('deviceId', new.id::text, 'approved', true));
    return new;
  end if;
  return new;
end $$;
revoke all on function public.devices_notify() from public;
revoke all on function public.devices_notify() from authenticated;
drop trigger if exists trg_devices_notify on public.devices;
create trigger trg_devices_notify after insert or update of approved on public.devices
  for each row execute function public.devices_notify();

alter table public.form_submissions add column if not exists device_id uuid;
```

- [ ] **Apply** via Management API. **Verify**: table + 2 triggers + `form_submissions.device_id` exist. **Smoke** (DO block, rolled back): a non-admin update can't flip `approved` (guard).
- [ ] **Commit** `SP6: devices table + RLS + guard/notify triggers + form_submissions.device_id`.

### Task 3: Local device identity

- [ ] **Create** `lib/utils/device_identity.dart`:

```dart
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

const _kDeviceIdKey = 'device_id';
String? _cached;

/// In-memory device id (null until [currentDeviceId] has run once). Read
/// synchronously by the submission persist path for audit stamping.
String? get cachedDeviceId => _cached;

/// Get-or-create the stable per-install device id.
Future<String> currentDeviceId() async {
  if (_cached != null) return _cached!;
  final prefs = await SharedPreferences.getInstance();
  var id = prefs.getString(_kDeviceIdKey);
  if (id == null || id.isEmpty) {
    id = const Uuid().v4();
    await prefs.setString(_kDeviceIdKey, id);
  }
  _cached = id;
  return id;
}

String currentPlatform() {
  if (Platform.isWindows) return 'windows';
  if (Platform.isAndroid) return 'android';
  return 'other';
}

String defaultDeviceName() {
  final p = currentPlatform();
  final v = Platform.operatingSystemVersion;
  final label = p == 'windows' ? 'Windows' : (p == 'android' ? 'Android' : 'Device');
  return v.trim().isEmpty ? label : '$label (${v.trim()})';
}
```

- [ ] **Analyze** → clean. **Commit** `SP6: local device identity (uuid + shared_preferences + platform)`.

### Task 4: Model + test (TDD)

- [ ] **Create** `test/device_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/device.dart';

void main() {
  Device d({bool approved = false, bool active = true}) => Device.fromMap({
    'id': 'x', 'user_id': 'u', 'device_name': 'PC', 'platform': 'windows',
    'approved': approved, 'is_active': active,
    'last_seen_at': '2026-06-22T00:00:00Z', 'created_at': '2026-06-22T00:00:00Z',
  });
  test('status: pending / approved / revoked', () {
    expect(d().statusLabel, 'Pending');
    expect(d(approved: true).statusLabel, 'Approved');
    expect(d(approved: true, active: false).statusLabel, 'Revoked');
    expect(d(active: false).statusLabel, 'Revoked');
  });
  test('isPending only when active and not approved', () {
    expect(d().isPending, true);
    expect(d(approved: true).isPending, false);
    expect(d(active: false).isPending, false);
  });
}
```

- [ ] **Run → fail.** **Create** `lib/models/device.dart`:

```dart
class Device {
  const Device({
    required this.id, required this.userId, required this.deviceName,
    required this.platform, required this.approved, required this.approvedAt,
    required this.lastSeenAt, required this.isActive, required this.createdAt,
  });
  final String id, userId, deviceName, platform;
  final bool approved, isActive;
  final DateTime? approvedAt;
  final DateTime lastSeenAt, createdAt;

  bool get isPending => isActive && !approved;
  String get statusLabel => !isActive ? 'Revoked' : (approved ? 'Approved' : 'Pending');

  static DateTime _d(dynamic v) => DateTime.parse(v as String);
  static DateTime? _dn(dynamic v) => v == null ? null : DateTime.parse(v as String);

  factory Device.fromMap(Map<String, dynamic> m) => Device(
    id: (m['id'] ?? '') as String,
    userId: (m['user_id'] ?? '') as String,
    deviceName: (m['device_name'] ?? '') as String,
    platform: (m['platform'] ?? 'other') as String,
    approved: (m['approved'] ?? false) as bool,
    approvedAt: _dn(m['approved_at']),
    lastSeenAt: _d(m['last_seen_at']),
    isActive: (m['is_active'] ?? true) as bool,
    createdAt: _d(m['created_at']),
  );
}
```

- [ ] **Run → pass.** **Commit** `SP6: device model + status tests (TDD)`.

### Task 5: Data layer

- [ ] **Create** `lib/utils/device_data.dart`:

```dart
import '../config/supabase_client.dart';
import '../models/device.dart';
import '../models/user_profile.dart';
import 'device_identity.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();

Future<void> registerCurrentDevice(UserProfile me) async {
  final id = await currentDeviceId();
  await supabase.from('devices').upsert({
    'id': id,
    'user_id': me.id,
    'device_name': defaultDeviceName(),
    'platform': currentPlatform(),
    'last_seen_at': _nowUtc(),
  }, onConflict: 'id');
}

Future<List<Device>> loadDevices() async {
  final rows = await supabase.from('devices').select().order('created_at', ascending: false);
  return (rows as List).cast<Map<String, dynamic>>().map(Device.fromMap).toList();
}

Future<void> setDeviceApproved(String id, bool approved) async {
  await supabase.from('devices').update({
    'approved': approved,
    'approved_at': approved ? _nowUtc() : null,
    'approved_by': approved ? supabase.auth.currentUser?.id : null,
    'updated_at': _nowUtc(),
  }).eq('id', id);
}

Future<void> setDeviceActive(String id, bool active) async {
  await supabase.from('devices').update({'is_active': active, 'updated_at': _nowUtc()}).eq('id', id);
}
```

- [ ] **Analyze** → clean. **Commit** `SP6: device data layer (register/load/approve/revoke)`.

### Task 6: Auto-register on sign-in + audit stamping

- [ ] **Modify** `lib/providers/auth_provider.dart`: import `device_data.dart`; after each `await _fetchProfile(...)` where the profile is set on sign-in (the two sites that also call `_presence.start(...)`), add a fire-and-forget guarded call: `if (_profile != null) { registerCurrentDevice(_profile!).catchError((_) {}); }`.
- [ ] **Modify** `lib/utils/signature_workflow.dart`: import `device_identity.dart`; in both `persistFormSubmission` and `saveFormSubmissionAndStartWorkflow`, when building the insert map add `if (cachedDeviceId != null) 'device_id': cachedDeviceId,`.
- [ ] **Analyze** → clean. **Commit** `SP6: auto-register device on sign-in + stamp device_id on submissions`.

### Task 7: Admin screen + route

- [ ] **Create** `lib/screens/setup/devices_admin_screen.dart` (admin-gated; mirror `appointments_admin_screen.dart`): load `loadDevices()` + a `profiles` id→full_name map; status filter chips (All/Pending/Approved/Revoked); Card per device (device_name, platform, user name, status badge, last-seen `dd MMM yyyy`); PopupMenu **Approve** (if pending), **Revoke** (if active), **Restore** (if revoked) → `setDeviceApproved`/`setDeviceActive` then reload.
- [ ] **Modify** `lib/routing/router.dart`: import the screen; add `GoRoute(path: '/setup/devices', builder: (_, __) => const DevicesAdminScreen())`; remove `/setup/devices` from `_placeholders()`.
- [ ] **Analyze** → clean. **Commit** `SP6: devices admin screen + live route`.

### Task 8: Verify + merge

- [ ] `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- [ ] Migration verified via Management API.
- [ ] Update `HANDOFF.md` + memory (SP6 done; next SP7). Merge `sp6-device-management` → main; push; delete branch.

## Self-Review

**Spec coverage:** deps (T1) ✓; table+RLS+guard+notify+device_id col (T2) ✓; local identity (T3) ✓; model (T4) ✓; data layer register/load/approve/revoke (T5) ✓; auto-register + audit stamp (T6) ✓; admin screen + route (T7) ✓; informational-only / never-block (T6 guarded call) ✓; notifications (T2 trigger) ✓.

**Placeholder scan:** migration timestamp is the real filename; all code shown.

**Type consistency:** `currentDeviceId`/`cachedDeviceId`/`currentPlatform`/`defaultDeviceName` (T3) used in T5/T6. `Device.fromMap`/`statusLabel`/`isPending` (T4) used in T5/T7. `registerCurrentDevice(UserProfile)`/`loadDevices`/`setDeviceApproved(id,bool)`/`setDeviceActive(id,bool)` (T5) used in T6/T7. `form_submissions.device_id` (T2) written in T6.
