# Admin Shell + Dashboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give Admin and Super Admin users a sidebar-driven dashboard (KPI cards, Quick Actions, demo-tip banner, Appointment Activity feed) with all figures fetched live from Supabase, plus labeled "Coming soon" placeholders for the rest of the legacy admin feature set.

**Architecture:** A reusable `AdminShell` layout widget renders a permanent sidebar on wide screens (≥1000 px) and a hamburger `Drawer` on narrow screens. `AdminDashboardScreen` composes the dashboard inside it. A pure `computeAdminDashboard()` function derives KPIs/activity from already-fetched rows (unit-tested); an async `loadAdminDashboard()` does the Supabase I/O. `home_screen.dart` routes admin/super-admin to the new screen; new placeholder routes cover unbuilt destinations. No router refactor.

**Tech Stack:** Flutter (Material 3), `supabase_flutter ^2.8.0`, `go_router ^17.2.3`, `provider ^6.1.2`, `intl ^0.20.1`. Existing helpers: `MolTones`, `PageBody`, `EmptyState`, `StatusChip`, `commonAppBarActions`/`homeHeaderActions`, `MobileBottomNav`.

**Spec:** `docs/superpowers/specs/2026-06-16-admin-shell-dashboard-design.md`

---

## File Structure

New files:
- `lib/utils/admin_dashboard_data.dart` — form-type constants, `AdminDashboardData` + `AppointmentActivityItem` models, pure `computeAdminDashboard()`, async `loadAdminDashboard()`.
- `lib/widgets/admin/admin_sidebar.dart` — `isSidebarRouteActive()` (pure), `AdminSidebar` widget (collapsible sections, active highlight, Download-app action, Logout).
- `lib/widgets/admin/admin_shell.dart` — `AdminShell` responsive scaffold (sidebar | drawer + top actions).
- `lib/widgets/admin/kpi_stat_card.dart` — `KpiStatCard` single stat tile.
- `lib/widgets/admin/quick_actions_grid.dart` — `QuickActionsGrid` + `QuickAction`.
- `lib/widgets/admin/appointment_activity_feed.dart` — `AppointmentActivityFeed` list.
- `lib/widgets/admin/mobile_app_info_dialog.dart` — `showMobileAppInfo()`.
- `lib/screens/admin_dashboard_screen.dart` — `AdminDashboardScreen` (loads data, realtime, composes the above in `AdminShell`).
- `test/admin_dashboard_data_test.dart` — unit tests for `computeAdminDashboard()`.
- `test/admin_sidebar_test.dart` — unit tests for `isSidebarRouteActive()`.

Modified files:
- `lib/screens/home_screen.dart` — route Admin & Super Admin to `AdminDashboardScreen`.
- `lib/routing/router.dart` — add 9 placeholder routes.

---

## Task 1: Dashboard data layer (constants, models, pure compute)

**Files:**
- Create: `lib/utils/admin_dashboard_data.dart`
- Test: `test/admin_dashboard_data_test.dart`

- [ ] **Step 1: Write the failing test**

Create `test/admin_dashboard_data_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/admin_dashboard_data.dart';

void main() {
  final submissions = <Map<String, dynamic>>[
    {'id': 's1', 'user_id': 'u1', 'form_type': 'shift_boss_appointment', 'workflow_status': 'fully_signed', 'current_signature_role': null, 'created_at': '2026-06-10T08:00:00Z'},
    {'id': 's2', 'user_id': 'u2', 'form_type': 'miner_appointment', 'workflow_status': 'pending_signature', 'current_signature_role': 'Mine Overseer', 'created_at': '2026-06-12T08:00:00Z'},
    {'id': 's3', 'user_id': 'u1', 'form_type': 'gassing_incident', 'workflow_status': 'submitted', 'current_signature_role': null, 'created_at': '2026-06-11T08:00:00Z'},
    {'id': 's4', 'user_id': 'u3', 'form_type': 'shift_boss_daily_report', 'workflow_status': 'submitted', 'current_signature_role': null, 'created_at': '2026-06-09T08:00:00Z'},
  ];
  final profiles = <String, Map<String, dynamic>>{
    'u1': {'id': 'u1', 'full_name': 'Alice Stone', 'email': 'alice@x.co', 'occupation': 'Shift Boss', 'location': 'Shaft 1'},
    'u2': {'id': 'u2', 'full_name': '', 'email': 'bob@x.co', 'job_title': 'Miner', 'location': ''},
  };

  test('counts KPIs from submissions', () {
    final d = computeAdminDashboard(profileCount: 9, submissions: submissions, profiles: profiles);
    expect(d.totalEmployees, 9);
    expect(d.activeAppointments, 1); // s1 only (appt + fully_signed)
    expect(d.pendingForms, 3); // s2, s3, s4 (submitted/pending_signature)
    expect(d.safetyIncidents, 1); // s3
  });

  test('activity feed includes only appointment rows, newest-first order preserved', () {
    final d = computeAdminDashboard(profileCount: 9, submissions: submissions, profiles: profiles);
    expect(d.recentActivity.map((a) => a.submissionId), ['s1', 's2']);
  });

  test('activity item name/subtitle resolve from profile with fallbacks', () {
    final d = computeAdminDashboard(profileCount: 9, submissions: submissions, profiles: profiles);
    final a = d.recentActivity[0];
    expect(a.name, 'Alice Stone');
    expect(a.subtitle, 'Shift Boss • Shaft 1');
    final b = d.recentActivity[1];
    expect(b.name, 'bob@x.co'); // empty full_name -> email
    expect(b.subtitle, 'Miner'); // job_title used, empty location dropped
    expect(b.workflowStatus, 'pending_signature');
  });

  test('activityLimit caps the feed', () {
    final many = List.generate(10, (i) => {
      'id': 'a$i', 'user_id': 'u1', 'form_type': 'miner_appointment',
      'workflow_status': 'submitted', 'created_at': '2026-06-0${i}T08:00:00Z',
    });
    final d = computeAdminDashboard(profileCount: 0, submissions: many, profiles: const {}, activityLimit: 6);
    expect(d.recentActivity.length, 6);
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/admin_dashboard_data_test.dart`
Expected: FAIL — `Target of URI doesn't exist: 'package:mine_online/utils/admin_dashboard_data.dart'`.

- [ ] **Step 3: Write the implementation**

Create `lib/utils/admin_dashboard_data.dart`:

```dart
// Data layer for the admin dashboard. Pure `computeAdminDashboard` derives the
// KPI counts + activity feed from already-fetched rows (unit tested);
// `loadAdminDashboard` performs the Supabase reads. Mirrors the query pattern
// in admin_appointments_logbook_screen.dart.

import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';

/// Form types treated as appointments (legacy "appointments" table).
const Set<String> kAppointmentFormTypes = {
  'shift_boss_appointment',
  'miner_appointment',
  'relieving_miner',
};

/// Form types treated as safety incidents.
const Set<String> kIncidentFormTypes = {
  'gassing_incident',
};

/// Workflow statuses that count as a form still pending in the chain.
const Set<String> kPendingWorkflowStatuses = {
  'submitted',
  'pending_signature',
};

class AppointmentActivityItem {
  const AppointmentActivityItem({
    required this.submissionId,
    required this.name,
    required this.subtitle,
    required this.date,
    required this.workflowStatus,
    required this.currentSignatureRole,
  });

  final String submissionId;
  final String name;
  final String subtitle;
  final DateTime? date;
  final String? workflowStatus;
  final String? currentSignatureRole;
}

class AdminDashboardData {
  const AdminDashboardData({
    required this.totalEmployees,
    required this.activeAppointments,
    required this.pendingForms,
    required this.safetyIncidents,
    required this.recentActivity,
  });

  final int totalEmployees;
  final int activeAppointments;
  final int pendingForms;
  final int safetyIncidents;
  final List<AppointmentActivityItem> recentActivity;

  static const empty = AdminDashboardData(
    totalEmployees: 0,
    activeAppointments: 0,
    pendingForms: 0,
    safetyIncidents: 0,
    recentActivity: [],
  );
}

String _displayName(Map<String, dynamic>? p) {
  final full = (p?['full_name'] as String?)?.trim() ?? '';
  if (full.isNotEmpty) return full;
  final email = (p?['email'] as String?)?.trim() ?? '';
  if (email.isNotEmpty) return email;
  return 'Unknown user';
}

String _subtitle(Map<String, dynamic>? p) {
  final occ = ((p?['occupation'] as String?)?.trim().isNotEmpty == true)
      ? (p!['occupation'] as String).trim()
      : ((p?['job_title'] as String?)?.trim() ?? '');
  final loc = (p?['location'] as String?)?.trim() ?? '';
  return [occ, loc].where((s) => s.isNotEmpty).join(' • ');
}

/// Pure: derive the dashboard from already-fetched rows. `submissions` is
/// assumed to be ordered newest-first (the feed preserves that order).
AdminDashboardData computeAdminDashboard({
  required int profileCount,
  required List<Map<String, dynamic>> submissions,
  required Map<String, Map<String, dynamic>> profiles,
  int activityLimit = 6,
}) {
  var active = 0;
  var pending = 0;
  var incidents = 0;
  final apptRows = <Map<String, dynamic>>[];

  for (final r in submissions) {
    final type = r['form_type'] as String?;
    final status = r['workflow_status'] as String?;
    final isAppt = type != null && kAppointmentFormTypes.contains(type);
    if (isAppt && status == 'fully_signed') active++;
    if (status != null && kPendingWorkflowStatuses.contains(status)) pending++;
    if (type != null && kIncidentFormTypes.contains(type)) incidents++;
    if (isAppt) apptRows.add(r);
  }

  final recent = apptRows.take(activityLimit).map((r) {
    final uid = r['user_id'] as String?;
    final p = uid == null ? null : profiles[uid];
    final dateStr = r['created_at'] as String?;
    return AppointmentActivityItem(
      submissionId: r['id'] as String? ?? '',
      name: _displayName(p),
      subtitle: _subtitle(p),
      date: dateStr == null ? null : DateTime.tryParse(dateStr),
      workflowStatus: r['workflow_status'] as String?,
      currentSignatureRole: r['current_signature_role'] as String?,
    );
  }).toList();

  return AdminDashboardData(
    totalEmployees: profileCount,
    activeAppointments: active,
    pendingForms: pending,
    safetyIncidents: incidents,
    recentActivity: recent,
  );
}

/// Loads the dashboard data from Supabase.
Future<AdminDashboardData> loadAdminDashboard() async {
  final profileRows = await supabase.from('profiles').select('id');
  final profileCount = (profileRows as List).length;

  final subRows = await supabase
      .from('form_submissions')
      .select(
          'id,user_id,form_type,title,workflow_status,current_signature_role,created_at')
      .order('created_at', ascending: false, nullsFirst: false)
      .limit(500);
  final submissions = (subRows as List).cast<Map<String, dynamic>>();

  final apptUserIds = submissions
      .where((r) => kAppointmentFormTypes.contains(r['form_type']))
      .map((r) => r['user_id'] as String?)
      .whereType<String>()
      .toSet()
      .toList();

  final profiles = <String, Map<String, dynamic>>{};
  if (apptUserIds.isNotEmpty) {
    final pr = await supabase
        .from('profiles')
        .select('id,full_name,email,occupation,job_title,location')
        .inFilter('id', apptUserIds);
    for (final row in (pr as List).cast<Map<String, dynamic>>()) {
      profiles[row['id'] as String] = row;
    }
  }

  return computeAdminDashboard(
    profileCount: profileCount,
    submissions: submissions,
    profiles: profiles,
  );
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/admin_dashboard_data_test.dart`
Expected: PASS (4 tests).

- [ ] **Step 5: Commit**

```bash
git add lib/utils/admin_dashboard_data.dart test/admin_dashboard_data_test.dart
git commit -m "Add admin dashboard data layer (KPIs + activity feed)"
```

---

## Task 2: Admin sidebar (route matcher + widget)

**Files:**
- Create: `lib/widgets/admin/admin_sidebar.dart`
- Test: `test/admin_sidebar_test.dart`

- [ ] **Step 1: Write the failing test**

Create `test/admin_sidebar_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/widgets/admin/admin_sidebar.dart';

void main() {
  test('root only active on exact /', () {
    expect(isSidebarRouteActive('/', '/'), isTrue);
    expect(isSidebarRouteActive('/', '/profiles'), isFalse);
  });

  test('non-root active on exact match or sub-path', () {
    expect(isSidebarRouteActive('/profiles', '/profiles'), isTrue);
    expect(isSidebarRouteActive('/reports', '/reports/daily'), isTrue);
    expect(isSidebarRouteActive('/reports', '/reportsX'), isFalse);
    expect(isSidebarRouteActive('/appointments', '/'), isFalse);
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/admin_sidebar_test.dart`
Expected: FAIL — URI for `admin_sidebar.dart` doesn't exist.

- [ ] **Step 3: Write the implementation**

Create `lib/widgets/admin/admin_sidebar.dart`:

```dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../theme/mol_tones.dart';
import 'mobile_app_info_dialog.dart';

/// True when [currentLocation] should highlight the item for [itemRoute].
bool isSidebarRouteActive(String itemRoute, String currentLocation) {
  if (itemRoute == '/') return currentLocation == '/';
  return currentLocation == itemRoute ||
      currentLocation.startsWith('$itemRoute/');
}

class SidebarLeaf {
  const SidebarLeaf(this.label, this.icon, this.route);
  final String label;
  final IconData icon;
  final String route;
}

class SidebarSection {
  const SidebarSection(this.label, this.icon, this.children);
  final String label;
  final IconData icon;
  final List<SidebarLeaf> children;
}

const _navItems = <Object>[
  SidebarLeaf('Dashboard', Icons.dashboard_outlined, '/'),
  SidebarSection('Shiftboss Logbook', Icons.menu_book_outlined, [
    SidebarLeaf('Combined View', Icons.dashboard_customize_outlined, '/current-logbook'),
    SidebarLeaf('Appointments', Icons.assignment_outlined, '/appointments'),
    SidebarLeaf('Daily Reports', Icons.today_outlined, '/reports/daily'),
    SidebarLeaf('Weekly Reports', Icons.date_range_outlined, '/reports/weekly'),
    SidebarLeaf('Monthly Reports', Icons.calendar_month_outlined, '/reports/monthly'),
  ]),
  SidebarSection('Templates', Icons.build_outlined, [
    SidebarLeaf('Form Builder', Icons.dynamic_form_outlined, '/form-builder'),
    SidebarLeaf('Appointment Builder', Icons.settings_suggest_outlined, '/appointment-builder'),
  ]),
  SidebarLeaf('Report History', Icons.history_outlined, '/completed-logbook-history'),
  SidebarSection('Setup', Icons.tune_outlined, [
    SidebarLeaf('User Management', Icons.group_outlined, '/profiles'),
    SidebarLeaf('Locations', Icons.place_outlined, '/setup/locations'),
    SidebarLeaf('Gangs', Icons.groups_2_outlined, '/setup/gangs'),
    SidebarLeaf('Devices', Icons.devices_outlined, '/setup/devices'),
    SidebarLeaf('Analytics', Icons.insights_outlined, '/analytics'),
    SidebarLeaf('Notifications', Icons.notifications_outlined, '/notifications'),
    SidebarLeaf('Settings', Icons.settings_outlined, '/settings'),
    SidebarLeaf('Admin Workspace', Icons.shield_outlined, '/admin'),
  ]),
];

class AdminSidebar extends StatelessWidget {
  const AdminSidebar({super.key, required this.location});

  final String location;

  void _go(BuildContext context, String route) {
    // Close the drawer first if we're inside one.
    final nav = Navigator.of(context);
    if (nav.canPop()) nav.pop();
    if (route != location) context.go(route);
  }

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    final scheme = Theme.of(context).colorScheme;

    return Container(
      color: tones.bgMuted,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            child: Text(
              'Admin',
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              children: [
                for (final item in _navItems)
                  if (item is SidebarLeaf)
                    _LeafTile(
                      leaf: item,
                      active: isSidebarRouteActive(item.route, location),
                      onTap: () => _go(context, item.route),
                    )
                  else if (item is SidebarSection)
                    _SectionTile(
                      section: item,
                      location: location,
                      onTapLeaf: (r) => _go(context, r),
                    ),
                const SizedBox(height: 8),
                Divider(color: tones.lineFaint, height: 1),
                _LeafActionTile(
                  icon: Icons.download_outlined,
                  label: 'Download Mobile App',
                  onTap: () {
                    final nav = Navigator.of(context);
                    if (nav.canPop()) nav.pop();
                    showMobileAppInfo(context);
                  },
                ),
                _LeafActionTile(
                  icon: Icons.logout,
                  label: 'Logout',
                  color: scheme.error,
                  onTap: () => context.read<AuthProvider>().signOut(),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LeafTile extends StatelessWidget {
  const _LeafTile({required this.leaf, required this.active, required this.onTap});
  final SidebarLeaf leaf;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: active ? scheme.primaryContainer : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                Icon(leaf.icon,
                    size: 20,
                    color: active ? scheme.onPrimaryContainer : scheme.onSurfaceVariant),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    leaf.label,
                    style: TextStyle(
                      fontWeight: active ? FontWeight.w600 : FontWeight.w500,
                      color: active ? scheme.onPrimaryContainer : scheme.onSurface,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LeafActionTile extends StatelessWidget {
  const _LeafActionTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final c = color ?? scheme.onSurface;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                Icon(icon, size: 20, color: c),
                const SizedBox(width: 12),
                Text(label, style: TextStyle(fontWeight: FontWeight.w500, color: c)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionTile extends StatefulWidget {
  const _SectionTile({
    required this.section,
    required this.location,
    required this.onTapLeaf,
  });
  final SidebarSection section;
  final String location;
  final void Function(String route) onTapLeaf;

  @override
  State<_SectionTile> createState() => _SectionTileState();
}

class _SectionTileState extends State<_SectionTile> {
  late bool _open = widget.section.children
      .any((l) => isSidebarRouteActive(l.route, widget.location));

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => setState(() => _open = !_open),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                child: Row(
                  children: [
                    Icon(widget.section.icon, size: 20, color: scheme.onSurfaceVariant),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(widget.section.label,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                    ),
                    Icon(_open ? Icons.expand_less : Icons.expand_more,
                        size: 20, color: scheme.onSurfaceVariant),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (_open)
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Column(
              children: [
                for (final leaf in widget.section.children)
                  _LeafTile(
                    leaf: leaf,
                    active: isSidebarRouteActive(leaf.route, widget.location),
                    onTap: () => widget.onTapLeaf(leaf.route),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/admin_sidebar_test.dart`
Expected: PASS (2 tests). (`mobile_app_info_dialog.dart` is created in Task 3; until then analyze/compile of the full app will report a missing import — the unit test still passes because the test only imports `isSidebarRouteActive`. Run Task 3 next before `flutter analyze`.)

- [ ] **Step 5: Commit**

```bash
git add lib/widgets/admin/admin_sidebar.dart test/admin_sidebar_test.dart
git commit -m "Add admin sidebar (nav structure + active-route matcher)"
```

---

## Task 3: Mobile-app info dialog

**Files:**
- Create: `lib/widgets/admin/mobile_app_info_dialog.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/admin/mobile_app_info_dialog.dart`:

```dart
import 'package:flutter/material.dart';

/// Explains that this IS the Mine Online app and where to get the Android build.
/// (The "Download Mobile App" sidebar item / Quick Action open this.)
Future<void> showMobileAppInfo(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: const Icon(Icons.smartphone_outlined),
      title: const Text('Mine Online Mobile'),
      content: const Text(
        "You're already using the Mine Online app. The Android build (APK) is "
        'distributed to field tablets through your administrator. Ask your '
        'administrator for the latest release if you need to install it on '
        'another device.',
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: const Text('Got it'),
        ),
      ],
    ),
  );
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/widgets/admin/`
Expected: No issues in `mobile_app_info_dialog.dart` and `admin_sidebar.dart` (the sidebar's import now resolves).

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/admin/mobile_app_info_dialog.dart
git commit -m "Add mobile-app info dialog for admin shell"
```

---

## Task 4: KPI stat card

**Files:**
- Create: `lib/widgets/admin/kpi_stat_card.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/admin/kpi_stat_card.dart`:

```dart
import 'package:flutter/material.dart';

import '../../theme/mol_tones.dart';

/// A single KPI tile: tinted icon chip + label + big value (or a loading
/// placeholder). `tone` comes from MolTones (info/success/warning/danger).
class KpiStatCard extends StatelessWidget {
  const KpiStatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.tone,
    required this.loading,
  });

  final String label;
  final int value;
  final IconData icon;
  final MolTone tone;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: tone.tint,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 24, color: tone.accent),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12,
                      color: scheme.onSurfaceVariant,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  if (loading)
                    const SizedBox(
                      height: 24,
                      width: 24,
                      child: Padding(
                        padding: EdgeInsets.all(3),
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  else
                    Text(
                      '$value',
                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/widgets/admin/kpi_stat_card.dart`
Expected: No issues found.

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/admin/kpi_stat_card.dart
git commit -m "Add KPI stat card widget"
```

---

## Task 5: Quick Actions grid

**Files:**
- Create: `lib/widgets/admin/quick_actions_grid.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/admin/quick_actions_grid.dart`:

```dart
import 'package:flutter/material.dart';

class QuickAction {
  const QuickAction({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
}

/// Responsive grid of quick-action tiles (4 / 3 / 2 columns by width).
class QuickActionsGrid extends StatelessWidget {
  const QuickActionsGrid({super.key, required this.actions});
  final List<QuickAction> actions;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final cols = c.maxWidth >= 720
            ? 4
            : c.maxWidth >= 480
                ? 3
                : 2;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: actions.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: cols,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.3,
          ),
          itemBuilder: (_, i) => _QuickActionTile(action: actions[i]),
        );
      },
    );
  }
}

class _QuickActionTile extends StatelessWidget {
  const _QuickActionTile({required this.action});
  final QuickAction action;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: action.onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(action.icon, size: 28, color: scheme.primary),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                action.label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/widgets/admin/quick_actions_grid.dart`
Expected: No issues found.

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/admin/quick_actions_grid.dart
git commit -m "Add quick actions grid widget"
```

---

## Task 6: Appointment Activity feed

**Files:**
- Create: `lib/widgets/admin/appointment_activity_feed.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/admin/appointment_activity_feed.dart`:

```dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../theme/mol_tones.dart';
import '../../utils/admin_dashboard_data.dart';
import '../empty_state.dart';
import '../mol_chips.dart';

/// "Appointment Activity" card: header + "View All", then recent appointment
/// rows (name, subtitle, status pill, date) or an empty state.
class AppointmentActivityFeed extends StatelessWidget {
  const AppointmentActivityFeed({
    super.key,
    required this.items,
    required this.loading,
    required this.onViewAll,
  });

  final List<AppointmentActivityItem> items;
  final bool loading;
  final VoidCallback onViewAll;

  static final _fmt = DateFormat('d MMM yyyy');

  @override
  Widget build(BuildContext context) {
    final tones = MolTones.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('Appointment Activity',
                      style: Theme.of(context).textTheme.titleMedium),
                ),
                TextButton(onPressed: onViewAll, child: const Text('View All →')),
              ],
            ),
            const SizedBox(height: 4),
            if (loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (items.isEmpty)
              const EmptyState(
                icon: Icons.assignment_outlined,
                title: 'No appointment activity yet',
                body: 'Submitted appointment forms will appear here.',
              )
            else
              for (var i = 0; i < items.length; i++) ...[
                if (i > 0) Divider(color: tones.lineFaint, height: 1),
                _ActivityRow(item: items[i], dateLabel: _label(items[i].date)),
              ],
          ],
        ),
      ),
    );
  }

  String _label(DateTime? d) => d == null ? '—' : _fmt.format(d.toLocal());
}

class _ActivityRow extends StatelessWidget {
  const _ActivityRow({required this.item, required this.dateLabel});
  final AppointmentActivityItem item;
  final String dateLabel;

  StatusChip _statusChip() {
    switch (item.workflowStatus) {
      case 'fully_signed':
        return const StatusChip(kind: StatusChipKind.complete, dense: true);
      case 'pending_signature':
        return StatusChip(
          kind: StatusChipKind.pending,
          label: item.currentSignatureRole != null
              ? 'Pending • ${item.currentSignatureRole}'
              : 'Pending',
          dense: true,
        );
      default:
        return const StatusChip(
            kind: StatusChipKind.doing, label: 'Submitted', dense: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.name,
                    style: Theme.of(context).textTheme.titleSmall),
                if (item.subtitle.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(item.subtitle,
                        style: TextStyle(
                            fontSize: 12, color: scheme.onSurfaceVariant)),
                  ),
                const SizedBox(height: 6),
                _statusChip(),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(dateLabel,
              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
        ],
      ),
    );
  }
}
```

- [ ] **Step 2: Verify the StatusChip API matches**

Run: `flutter analyze lib/widgets/admin/appointment_activity_feed.dart`
Expected: No issues found. (`StatusChip` / `StatusChipKind` are used the same way as in `admin_appointments_logbook_screen.dart`: `StatusChip(kind: StatusChipKind.complete, dense: true)` and the `label:` variant. If analyze reports a mismatch, open `lib/widgets/mol_chips.dart` and adjust the constructor call to match the real signature.)

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/admin/appointment_activity_feed.dart
git commit -m "Add appointment activity feed widget"
```

---

## Task 7: AdminShell responsive scaffold

**Files:**
- Create: `lib/widgets/admin/admin_shell.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/admin/admin_shell.dart`:

```dart
import 'package:flutter/material.dart';

import '../../theme/mol_tones.dart';
import '../app_bar_actions.dart';
import '../mobile_bottom_nav.dart';
import 'admin_sidebar.dart';

/// Responsive admin layout: a permanent sidebar on wide screens (≥1000 px),
/// a hamburger Drawer on narrow screens (keeping the app-wide bottom nav).
/// `child` is the page content; it manages its own scrolling.
class AdminShell extends StatelessWidget {
  const AdminShell({
    super.key,
    required this.location,
    required this.child,
    this.title = 'Mine Online',
  });

  final String location;
  final Widget child;
  final String title;

  static const sidebarBreakpoint = 1000.0;
  static const sidebarWidth = 260.0;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);
    final wide = MediaQuery.of(context).size.width >= sidebarBreakpoint;

    if (wide) {
      return Scaffold(
        backgroundColor: scheme.surface,
        body: SafeArea(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: sidebarWidth,
                child: AdminSidebar(location: location),
              ),
              VerticalDivider(width: 1, color: tones.line),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: homeHeaderActions(),
                      ),
                    ),
                    Expanded(child: child),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: scheme.surface,
      appBar: AppBar(
        title: Text(title),
        actions: commonAppBarActions(),
      ),
      drawer: Drawer(child: SafeArea(child: AdminSidebar(location: location))),
      bottomNavigationBar: MobileBottomNav(location: location),
      body: SafeArea(child: child),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/widgets/admin/admin_shell.dart`
Expected: No issues found.

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/admin/admin_shell.dart
git commit -m "Add responsive AdminShell scaffold"
```

---

## Task 8: AdminDashboardScreen (compose + load + realtime)

**Files:**
- Create: `lib/screens/admin_dashboard_screen.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/screens/admin_dashboard_screen.dart`:

```dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_client.dart';
import '../theme/mol_tones.dart';
import '../utils/admin_dashboard_data.dart';
import '../widgets/admin/admin_shell.dart';
import '../widgets/admin/appointment_activity_feed.dart';
import '../widgets/admin/kpi_stat_card.dart';
import '../widgets/admin/mobile_app_info_dialog.dart';
import '../widgets/admin/quick_actions_grid.dart';
import '../widgets/page_body.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool _loading = true;
  String? _error;
  bool _tipDismissed = false;
  AdminDashboardData _data = AdminDashboardData.empty;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await loadAdminDashboard();
      if (!mounted) return;
      setState(() {
        _data = data;
        _loading = false;
      });
      _resubscribe();
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  void _resubscribe() {
    if (_channel != null) return;
    _channel = supabase
        .channel('admin-dashboard')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'form_submissions',
          callback: (_) => _load(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'profiles',
          callback: (_) => _load(),
        )
        .subscribe();
  }

  List<QuickAction> _quickActions() => [
        QuickAction(icon: Icons.add_circle_outline, label: 'New Appointment', onTap: () => context.go('/appointments')),
        QuickAction(icon: Icons.hourglass_empty, label: 'Incomplete', onTap: () => context.go('/active-individual-current-logbook')),
        QuickAction(icon: Icons.design_services_outlined, label: 'Design Form', onTap: () => context.go('/form-builder')),
        QuickAction(icon: Icons.groups_outlined, label: 'Manage Workforce', onTap: () => context.go('/profiles')),
        QuickAction(icon: Icons.folder_open_outlined, label: 'Forms Management', onTap: () => context.go('/appointments')),
        QuickAction(icon: Icons.bar_chart_outlined, label: 'View Reports', onTap: () => context.go('/completed-logbook-history')),
        QuickAction(icon: Icons.smartphone_outlined, label: 'Mobile App', onTap: () => showMobileAppInfo(context)),
      ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tones = MolTones.of(context);

    return AdminShell(
      location: '/',
      title: 'Admin Dashboard',
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            PageBody.list(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Mine Online',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700)),
                  Text('Admin Dashboard',
                      style: TextStyle(color: scheme.onSurfaceVariant)),
                  const SizedBox(height: 20),

                  if (_error != null)
                    Card(
                      color: tones.danger.tint,
                      child: ListTile(
                        leading: Icon(Icons.error_outline, color: tones.danger.accent),
                        title: Text('Could not load dashboard data', style: TextStyle(color: tones.danger.fg)),
                        subtitle: Text(_error!, style: TextStyle(color: tones.danger.fg)),
                        trailing: TextButton(onPressed: _load, child: const Text('Retry')),
                      ),
                    ),

                  // KPI cards
                  LayoutBuilder(builder: (context, c) {
                    final cols = c.maxWidth >= 900 ? 4 : c.maxWidth >= 560 ? 2 : 1;
                    final cards = [
                      KpiStatCard(label: 'Total Employees', value: _data.totalEmployees, icon: Icons.people_outline, tone: tones.info, loading: _loading),
                      KpiStatCard(label: 'Active Appointments', value: _data.activeAppointments, icon: Icons.assignment_turned_in_outlined, tone: tones.success, loading: _loading),
                      KpiStatCard(label: 'Pending Forms', value: _data.pendingForms, icon: Icons.pending_actions_outlined, tone: tones.warning, loading: _loading),
                      KpiStatCard(label: 'Safety Incidents', value: _data.safetyIncidents, icon: Icons.warning_amber_outlined, tone: tones.danger, loading: _loading),
                    ];
                    return GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: cols,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 2.6,
                      children: cards,
                    );
                  }),
                  const SizedBox(height: 24),

                  // Quick Actions
                  Row(children: [
                    Icon(Icons.bolt_outlined, size: 20, color: scheme.primary),
                    const SizedBox(width: 6),
                    Text('Quick Actions', style: Theme.of(context).textTheme.titleMedium),
                  ]),
                  const SizedBox(height: 12),
                  QuickActionsGrid(actions: _quickActions()),
                  const SizedBox(height: 12),

                  // Demo tip banner (dismissible)
                  if (!_tipDismissed)
                    Card(
                      color: tones.success.tint,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
                        child: Row(
                          children: [
                            Icon(Icons.lightbulb_outline, color: tones.success.accent),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Tip: Quick Actions give fast access to common tasks — create appointments, manage your workforce, and review reports.',
                                style: TextStyle(color: tones.success.fg, fontSize: 13),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, size: 18),
                              tooltip: 'Dismiss',
                              onPressed: () => setState(() => _tipDismissed = true),
                            ),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),

                  // Appointment activity
                  AppointmentActivityFeed(
                    items: _data.recentActivity,
                    loading: _loading,
                    onViewAll: () => context.go('/appointment-history-logs'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/screens/admin_dashboard_screen.dart`
Expected: No issues found.

- [ ] **Step 3: Commit**

```bash
git add lib/screens/admin_dashboard_screen.dart
git commit -m "Add AdminDashboardScreen composing shell + live data"
```

---

## Task 9: Placeholder routes

**Files:**
- Modify: `lib/routing/router.dart`

- [ ] **Step 1: Replace the `_placeholders()` method**

In `lib/routing/router.dart`, replace the entire `_placeholders()` method (currently the `static Iterable<GoRoute> _placeholders() { ... }` block) with:

```dart
  static Iterable<GoRoute> _placeholders() {
    // Web-parity stubs (the React app also placeholders these two).
    const webParityStubs = <String, (String, String)>{
      '/logbook-version-management': (
        'Logbook Version Management',
        'Review, edit, add, change, and update logbook versions, version history, and logbook sections.',
      ),
      '/send-notifications-reminders': (
        'Send Notifications and Reminders',
        'Send notification and reminder workflows will be connected here once the rules and recipients are defined.',
      ),
    };
    // Admin shell destinations queued as their own sub-projects.
    const adminStubs = <String, (String, String)>{
      '/form-builder': (
        'Form Builder',
        'Coming soon — design and version dynamic forms. Part of the Form Builder sub-project (SP2).',
      ),
      '/appointment-builder': (
        'Appointment Builder',
        'Coming soon — build role-based appointment templates and letters. Part of the Appointment Builder sub-project (SP3).',
      ),
      '/reports/daily': (
        'Daily Reports',
        'Coming soon — daily compliance reporting and export. Part of the Reports sub-project (SP8).',
      ),
      '/reports/weekly': (
        'Weekly Reports',
        'Coming soon — weekly compliance reporting and export. Part of the Reports sub-project (SP8).',
      ),
      '/reports/monthly': (
        'Monthly Reports',
        'Coming soon — monthly compliance reporting and export. Part of the Reports sub-project (SP8).',
      ),
      '/setup/locations': (
        'Locations',
        'Coming soon — manage shafts, sections, and areas. Part of the Org Structure sub-project (SP5).',
      ),
      '/setup/gangs': (
        'Gangs',
        'Coming soon — manage work gangs, members, and role requirements. Part of the Org Structure sub-project (SP5).',
      ),
      '/setup/devices': (
        'Devices',
        'Coming soon — register and approve field devices. Part of the Device Management sub-project (SP6).',
      ),
      '/analytics': (
        'Analytics',
        'Coming soon — forms, appointments, user, and system analytics. Part of the Analytics sub-project (SP7).',
      ),
    };
    return [...webParityStubs.entries, ...adminStubs.entries].map(
      (e) => GoRoute(
        path: e.key,
        builder: (_, __) => PlaceholderScreen(
          title: e.value.$1,
          description: e.value.$2,
        ),
      ),
    );
  }
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/routing/router.dart`
Expected: No issues found.

- [ ] **Step 3: Commit**

```bash
git add lib/routing/router.dart
git commit -m "Add admin shell placeholder routes (builders, reports, setup)"
```

---

## Task 10: Route admin & super-admin to the new dashboard

**Files:**
- Modify: `lib/screens/home_screen.dart`

- [ ] **Step 1: Add the import**

In `lib/screens/home_screen.dart`, add to the imports (after the existing `../widgets/dashboards/...` imports):

```dart
import 'admin_dashboard_screen.dart';
```

- [ ] **Step 2: Short-circuit admin/super-admin in `build`**

In `HomeScreen.build`, immediately after these existing lines:

```dart
    final isAdminHome =
        profile?.userAccountType == 'Admin' || (profile?.isAdmin ?? false);
```

insert (before `final isMineLeadershipHome = ...`):

```dart
    // Admin & Super Admin get the sidebar-driven AdminShell dashboard, which is
    // its own full Scaffold — return it directly instead of the centered grid.
    if (isSuperAdminHome || isAdminHome) {
      return const AdminDashboardScreen();
    }
```

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/screens/home_screen.dart`
Expected: No issues found. (The existing `isSuperAdminHome`/`isAdminHome` branches in the `if/else` chain below are now unreachable for those roles but remain harmless; leaving them keeps the diff minimal. The unused `SuperAdminDashboard`/`AdminDashboard` imports are still referenced by that chain, so no import removal is needed.)

- [ ] **Step 4: Commit**

```bash
git add lib/screens/home_screen.dart
git commit -m "Route admin and super-admin to AdminDashboardScreen"
```

---

## Task 11: Full verification

- [ ] **Step 1: Analyze the whole project**

Run: `flutter analyze`
Expected: No issues found (0 errors, 0 warnings introduced by this work).

- [ ] **Step 2: Run the unit tests**

Run: `flutter test`
Expected: All tests pass (including the new `admin_dashboard_data_test.dart` and `admin_sidebar_test.dart`).

- [ ] **Step 3: Manual run on Windows**

Run: `flutter run -d windows`
Sign in as an Admin (or Super Admin) account and verify:
- Permanent left sidebar with the documented sections; collapsible sections expand/collapse; the active item (Dashboard) is highlighted.
- Four KPI cards show **real** counts (against current data: ~9 / 3 / 8 / 1). They show a spinner briefly while loading.
- Quick Actions grid renders; "Design Form" / "Mobile App" open the placeholder / dialog; others navigate.
- Demo-tip banner shows and dismisses (× button).
- Appointment Activity lists recent appointment submissions with real submitter names and status pills; "View All →" opens `/appointment-history-logs`.
- Placeholder routes (Form Builder, Appointment Builder, Reports ×3, Locations, Gangs, Devices, Analytics) open and read "Coming soon".
- "Logout" signs out; "Download Mobile App" opens the info dialog.
- Toggle dark mode in Settings → dashboard stays legible.

- [ ] **Step 4: Manual responsive check**

Resize the Windows window narrower than 1000 px:
- Sidebar collapses to a hamburger; opening the drawer shows the same nav; tapping an item navigates and closes the drawer.
- KPI cards reflow to 2 then 1 column.
- Below 720 px the bottom nav (Home/Appointments/Inbox/Profile) appears.

- [ ] **Step 5: Realtime check**

With the dashboard open, submit or sign an appointment form from another screen/session and confirm the KPI counts and activity feed update without a manual refresh.

- [ ] **Step 6: Final commit (if any tidy-ups were needed)**

```bash
git add -A
git commit -m "Verify admin shell + dashboard end-to-end"
```

---

## Self-Review notes (for the implementer)

- **StatusChip API:** Task 6 assumes `StatusChip(kind: StatusChipKind.complete, dense: true)` and the `label:` variant, copied from `admin_appointments_logbook_screen.dart`. If `flutter analyze` flags it, open `lib/widgets/mol_chips.dart` and match the real signature.
- **`.select()` return typing:** `loadAdminDashboard` casts query results with `(rows as List).cast<Map<String, dynamic>>()`, the same pattern used in `admin_appointments_logbook_screen.dart` — keep it identical if the analyzer complains about types.
- **No new dependencies, no "Claude"/AI strings, no `public.todos` writes** — confirm none were introduced.
```
