# SP3 — Appointment Builder + Letter Builder Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give admins a native authoring surface for legal appointment templates and their appointment letters (role catalog + field schema + `{{placeholder}}` letter body + PDF preview), authoring-only; issuance/lifecycle is SP4.

**Architecture:** Two new Supabase tables (`appointment_roles`, `appointment_templates`) with read-active/admin-write RLS. A pure Dart model (`appointment_template.dart`, reusing SP2's `FormFieldDef`) carries data + placeholder + validation logic. A data layer (`appointment_template_data.dart`) mirrors `custom_form_data.dart`/`org_data.dart`. A letter PDF generator renders substituted, lightly-marked-up letter text. An admin-gated builder screen (list + editor with Details/Fields and Letter views + a roles dialog) reuses the SP2 field editor and `kChainSignerLabels`. The `/appointment-builder` placeholder becomes a real route.

**Tech Stack:** Flutter (Material 3), `provider`, `go_router`, `supabase_flutter`, `pdf` + `printing`. No new dependencies.

## Global Constraints

- Windows + Android only. PDF uses `PdfPageFormat.letter`, millimetres where coordinates are used.
- No new dependencies (Material 3 + `Icons.*`, `pdf`, `printing`, `go_router`, `provider`, `supabase_flutter`, `signature`, `dynamic_color` only).
- No "Claude"/AI naming in code, UI strings, comments, or DB data.
- Git: never `git add -A`/`.`/`git reset --hard`/`git clean`. Stage explicit paths only.
- Supabase: write the migration file in `supabase/migrations/` AND apply it via the Management API (PAT in Windows Credential Manager `claude-supabase-pat-hhrnkzznpadrmyverhyb`, project ref `hhrnkzznpadrmyverhyb`). RLS gate `public.is_admin(auth.uid())`. `created_by` → `public.profiles(id) on delete set null`.
- Verify: `flutter analyze` clean, `flutter test` green, `flutter build windows --release` succeeds. `dart format` touched files before committing.
- Admin gate every admin surface via `isAdminProfile(profile)`.

## File Structure

- Create `supabase/migrations/20260621120000_create_appointment_templates.sql` — both tables + RLS + seed roles.
- Create `lib/models/appointment_template.dart` — `AppointmentRole`, `AppointmentTemplate`, `kStandardLetterTokens`, `extractPlaceholders`, `renderLetterBody`, `validateAppointmentTemplate`. Reuses `FormFieldDef` from `custom_form_template.dart`.
- Create `lib/utils/appointment_template_data.dart` — roles + templates CRUD against Supabase.
- Create `lib/pdf/generate_appointment_letter_pdf.dart` — `generateAppointmentLetterPdf(...)`.
- Create `lib/screens/setup/appointment_builder_screen.dart` — `AppointmentBuilderScreen` + private editor + roles dialog.
- Modify `lib/routing/router.dart` — remove `/appointment-builder` stub, add real route.
- Create `test/appointment_template_test.dart` — pure-logic unit tests.

---

### Task 1: Database migration (tables + RLS + seed)

**Files:**
- Create: `supabase/migrations/20260621120000_create_appointment_templates.sql`

**Interfaces:**
- Produces: tables `public.appointment_roles` (id, code, label, description, is_mandatory, is_active, sort_order, created_at, updated_at) and `public.appointment_templates` (id, code unique, name, description, role_id→appointment_roles, language, fields jsonb, letter_body text, required_signers jsonb, version, is_active, created_by→profiles, created_at, updated_at).

- [ ] **Step 1: Write the migration file**

```sql
-- SP3 Appointment Builder + Letter Builder: roles catalog + appointment templates
-- (form fields + letter body). Authoring only; issuance/lifecycle is SP4.

create table if not exists public.appointment_roles (
  id            uuid primary key default gen_random_uuid(),
  code          text,
  label         text not null,
  description   text,
  is_mandatory  boolean not null default false,
  is_active     boolean not null default true,
  sort_order    integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists public.appointment_templates (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique,
  name              text not null,
  description       text,
  role_id           uuid references public.appointment_roles(id) on delete set null,
  language          text not null default 'en',
  fields            jsonb not null default '[]'::jsonb,
  letter_body       text not null default '',
  required_signers  jsonb not null default '[]'::jsonb,
  version           integer not null default 1,
  is_active         boolean not null default true,
  created_by        uuid references public.profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists appointment_roles_active_idx
  on public.appointment_roles (is_active, sort_order);
create index if not exists appointment_templates_active_idx
  on public.appointment_templates (is_active, updated_at desc);

alter table public.appointment_roles enable row level security;
alter table public.appointment_templates enable row level security;

-- appointment_roles: authenticated read active (admins read all); admin write.
create policy "Read active appointment roles"
  on public.appointment_roles for select to authenticated
  using (is_active = true or public.is_admin(auth.uid()));
create policy "Admins insert appointment roles"
  on public.appointment_roles for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admins update appointment roles"
  on public.appointment_roles for update to authenticated
  using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- appointment_templates: authenticated read active (admins read all); admin write.
create policy "Read active appointment templates"
  on public.appointment_templates for select to authenticated
  using (is_active = true or public.is_admin(auth.uid()));
create policy "Admins insert appointment templates"
  on public.appointment_templates for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admins update appointment templates"
  on public.appointment_templates for update to authenticated
  using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- Seed the statutory roles the app uses today + core MHSA roles.
insert into public.appointment_roles (code, label, description, is_mandatory, sort_order)
values
  ('2.6.1',  'Mine Manager',                  'Appointed manager responsible for the mine under MHSA 2.6.1.', true,  10),
  ('2.9.2',  'Mine Overseer',                 'Mine overseer responsible for a portion of the mine under MHSA 2.9.2.', true,  20),
  ('2.13.1', 'Shift Supervisor (Shift Boss)', 'Shift supervisor responsible for a working place during a shift under MHSA 2.13.1.', true,  30),
  ('2.13.2', 'Engineer',                      'Engineer appointed under MHSA 2.13.2.', false, 40),
  (null,     'Miner (Competent A)',           'Competent miner responsible for blasting and a working place.', false, 50),
  (null,     'Relieving Miner',               'Miner appointed to relieve a competent miner.', false, 60)
on conflict do nothing;
```

- [ ] **Step 2: Apply via Management API**

Read the PAT from Windows Credential Manager target `claude-supabase-pat-hhrnkzznpadrmyverhyb` (UTF-16 decoded), then `POST https://api.supabase.com/v1/projects/hhrnkzznpadrmyverhyb/database/query` with the migration SQL as `{"query": "..."}`. Expected: HTTP 200/201, no error body.

- [ ] **Step 3: Verify tables exist**

Query via the same endpoint: `select count(*) from public.appointment_roles;` Expected: returns 6 (seeded rows). And `select to_regclass('public.appointment_templates');` Expected: non-null.

- [ ] **Step 4: Commit**

```bash
git add supabase/migrations/20260621120000_create_appointment_templates.sql
git commit -m "SP3: appointment_roles + appointment_templates tables (RLS + seed)"
```

---

### Task 2: Model — AppointmentRole, AppointmentTemplate, placeholder + validation logic (TDD)

**Files:**
- Create: `lib/models/appointment_template.dart`
- Test: `test/appointment_template_test.dart`

**Interfaces:**
- Consumes: `FormFieldDef`, `FormFieldType`, `validateTemplate` from `custom_form_template.dart`.
- Produces:
  - `class AppointmentRole { final String id, label; final String? code, description; final bool isMandatory, isActive; final int sortOrder; toMap(); fromMap(Map); }`
  - `class AppointmentTemplate { final String id, code, name; final String? description, roleId; final String language; final List<FormFieldDef> fields; final String letterBody; final List<String> requiredSigners; final int version; final bool isActive; final String? createdBy; toMap(); fromMap(Map); }`
  - `const List<String> kStandardLetterTokens` — `['full_name','first_name','last_name','employee_number','id_number','occupation','section','company','date']`
  - `List<String> extractPlaceholders(String body)` — distinct token names in `{{...}}`, in first-seen order.
  - `String renderLetterBody(String body, Map<String,String> values)` — replace `{{token}}` with `values[token]`; leave unknown tokens verbatim.
  - `List<String> validateAppointmentTemplate({required String name, String? roleId, required List<FormFieldDef> fields})` — errors list.

- [ ] **Step 1: Write the failing tests**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/appointment_template.dart';
import 'package:mine_online/models/custom_form_template.dart';

void main() {
  group('extractPlaceholders', () {
    test('returns distinct tokens in first-seen order', () {
      expect(
        extractPlaceholders('Dear {{full_name}}, ref {{employee_number}} / {{full_name}}.'),
        ['full_name', 'employee_number'],
      );
    });
    test('empty when no tokens', () {
      expect(extractPlaceholders('plain text'), <String>[]);
    });
  });

  group('renderLetterBody', () {
    test('substitutes known tokens', () {
      expect(
        renderLetterBody('Hi {{full_name}}', {'full_name': 'Jane Doe'}),
        'Hi Jane Doe',
      );
    });
    test('leaves unknown tokens verbatim', () {
      expect(renderLetterBody('Hi {{missing}}', {'full_name': 'x'}), 'Hi {{missing}}');
    });
  });

  group('validateAppointmentTemplate', () {
    test('flags empty name, missing role, and no fields', () {
      final errors = validateAppointmentTemplate(name: '  ', roleId: null, fields: const []);
      expect(errors, contains('Template name is required.'));
      expect(errors, contains('Select an appointment role.'));
      expect(errors, contains('Add at least one field.'));
    });
    test('passes a valid template', () {
      final errors = validateAppointmentTemplate(
        name: 'Shift Boss',
        roleId: 'role-1',
        fields: const [FormFieldDef(key: 'area', type: FormFieldType.text, label: 'Area', required: true)],
      );
      expect(errors, isEmpty);
    });
  });

  group('AppointmentTemplate round-trip', () {
    test('toMap/fromMap preserves fields and letterBody', () {
      const t = AppointmentTemplate(
        id: 'id1', code: 'appt_x', name: 'X', description: null, roleId: 'r1',
        language: 'en',
        fields: [FormFieldDef(key: 'a', type: FormFieldType.text, label: 'A', required: false)],
        letterBody: 'Hi {{a}}', requiredSigners: ['mine_overseer'], version: 2,
        isActive: true, createdBy: null,
      );
      final back = AppointmentTemplate.fromMap({...t.toMap(), 'id': 'id1'});
      expect(back.code, 'appt_x');
      expect(back.fields.single.key, 'a');
      expect(back.letterBody, 'Hi {{a}}');
      expect(back.requiredSigners, ['mine_overseer']);
    });
  });
}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `flutter test test/appointment_template_test.dart`
Expected: FAIL (target of URI doesn't exist / undefined symbols).

- [ ] **Step 3: Write the model**

```dart
// SP3 Appointment Builder + Letter Builder model. Pure data + validation; no
// Flutter/Supabase deps so it is fully unit-testable. `fields` reuses the SP2
// FormFieldDef shape and round-trips through appointment_templates.fields jsonb.

import 'custom_form_template.dart';

class AppointmentRole {
  const AppointmentRole({
    required this.id,
    required this.label,
    required this.code,
    required this.description,
    required this.isMandatory,
    required this.isActive,
    required this.sortOrder,
  });

  final String id;
  final String label;
  final String? code;
  final String? description;
  final bool isMandatory;
  final bool isActive;
  final int sortOrder;

  String get displayLabel => code == null || code!.isEmpty ? label : '$code — $label';

  Map<String, dynamic> toMap() => {
        'code': code,
        'label': label,
        'description': description,
        'is_mandatory': isMandatory,
        'is_active': isActive,
        'sort_order': sortOrder,
      };

  factory AppointmentRole.fromMap(Map<String, dynamic> m) => AppointmentRole(
        id: (m['id'] ?? '') as String,
        label: (m['label'] ?? '') as String,
        code: m['code'] as String?,
        description: m['description'] as String?,
        isMandatory: (m['is_mandatory'] ?? false) as bool,
        isActive: (m['is_active'] ?? true) as bool,
        sortOrder: (m['sort_order'] ?? 0) as int,
      );
}

class AppointmentTemplate {
  const AppointmentTemplate({
    required this.id,
    required this.code,
    required this.name,
    required this.description,
    required this.roleId,
    required this.language,
    required this.fields,
    required this.letterBody,
    required this.requiredSigners,
    required this.version,
    required this.isActive,
    required this.createdBy,
  });

  final String id;
  final String code;
  final String name;
  final String? description;
  final String? roleId;
  final String language;
  final List<FormFieldDef> fields;
  final String letterBody;
  final List<String> requiredSigners;
  final int version;
  final bool isActive;
  final String? createdBy;

  Map<String, dynamic> toMap() => {
        'code': code,
        'name': name,
        'description': description,
        'role_id': roleId,
        'language': language,
        'fields': fields.map((f) => f.toMap()).toList(),
        'letter_body': letterBody,
        'required_signers': requiredSigners,
        'version': version,
        'is_active': isActive,
        if (createdBy != null) 'created_by': createdBy,
      };

  factory AppointmentTemplate.fromMap(Map<String, dynamic> m) => AppointmentTemplate(
        id: (m['id'] ?? '') as String,
        code: (m['code'] ?? '') as String,
        name: (m['name'] ?? '') as String,
        description: m['description'] as String?,
        roleId: m['role_id'] as String?,
        language: (m['language'] ?? 'en') as String,
        fields: (m['fields'] as List? ?? const [])
            .map((e) => FormFieldDef.fromMap((e as Map).cast<String, dynamic>()))
            .toList(),
        letterBody: (m['letter_body'] ?? '') as String,
        requiredSigners:
            (m['required_signers'] as List? ?? const []).map((e) => e as String).toList(),
        version: (m['version'] ?? 1) as int,
        isActive: (m['is_active'] ?? true) as bool,
        createdBy: m['created_by'] as String?,
      );
}

/// Standard profile-derived tokens available to every letter (resolved from the
/// appointee's profile at issue time; sample data in SP3 preview).
const List<String> kStandardLetterTokens = [
  'full_name', 'first_name', 'last_name', 'employee_number', 'id_number',
  'occupation', 'section', 'company', 'date',
];

final RegExp _tokenRe = RegExp(r'\{\{\s*([a-zA-Z0-9_]+)\s*\}\}');

/// Distinct `{{token}}` names in first-seen order.
List<String> extractPlaceholders(String body) {
  final seen = <String>[];
  for (final m in _tokenRe.allMatches(body)) {
    final name = m.group(1)!;
    if (!seen.contains(name)) seen.add(name);
  }
  return seen;
}

/// Replace `{{token}}` with values[token]; unknown tokens are left verbatim.
String renderLetterBody(String body, Map<String, String> values) {
  return body.replaceAllMapped(_tokenRe, (m) {
    final name = m.group(1)!;
    return values.containsKey(name) ? values[name]! : m.group(0)!;
  });
}

/// Human-readable problems; empty means valid.
List<String> validateAppointmentTemplate({
  required String name,
  required String? roleId,
  required List<FormFieldDef> fields,
}) {
  final errors = <String>[];
  if (name.trim().isEmpty) errors.add('Template name is required.');
  if (roleId == null || roleId.isEmpty) errors.add('Select an appointment role.');
  // Reuse the SP2 field validator for field-level rules (keys, dropdowns, tables).
  errors.addAll(validateTemplate(name: name.trim().isEmpty ? 'x' : name, fields: fields)
      .where((e) => e != 'Form name is required.'));
  return errors.toSet().toList();
}
```

Note: `validateTemplate` emits "Add at least one field." when only sections/empty — reused here. The `.where` filter drops its name-specific message since this model has its own name rule.

- [ ] **Step 4: Run tests to verify they pass**

Run: `flutter test test/appointment_template_test.dart`
Expected: PASS (all groups).

- [ ] **Step 5: Format + commit**

```bash
dart format lib/models/appointment_template.dart test/appointment_template_test.dart
git add lib/models/appointment_template.dart test/appointment_template_test.dart
git commit -m "SP3: appointment template model + placeholder/validation logic"
```

---

### Task 3: Data layer — roles + templates CRUD

**Files:**
- Create: `lib/utils/appointment_template_data.dart`

**Interfaces:**
- Consumes: `supabase` from `config/supabase_client.dart`; model from Task 2; `FormFieldDef`.
- Produces:
  - `Future<List<AppointmentRole>> loadAppointmentRoles({bool includeArchived = false})`
  - `Future<void> saveAppointmentRole({String? id, String? code, required String label, String? description, required bool isMandatory, required int sortOrder})`
  - `Future<void> setAppointmentRoleActive(String id, bool active)`
  - `Future<List<AppointmentTemplate>> loadAppointmentTemplates({bool includeArchived = false})`
  - `Future<String> saveAppointmentTemplate({String? id, required String code, required String name, String? description, String? roleId, required String language, required List<FormFieldDef> fields, required String letterBody, required List<String> requiredSigners, required int version})`
  - `Future<void> setAppointmentTemplateActive(String id, bool active)`
  - `String appointmentTemplateCode(String name, String suffix)`

- [ ] **Step 1: Write the data layer**

```dart
// Supabase data access for appointment roles + templates (SP3). Mirrors
// custom_form_data.dart / org_data.dart.

import '../config/supabase_client.dart';
import '../models/appointment_template.dart';
import '../models/custom_form_template.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();

/// Lowercase slug + short suffix → a stable, unique appointment template code.
String appointmentTemplateCode(String name, String suffix) {
  final slug = name
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_+|_+$'), '');
  final base = slug.isEmpty ? 'appointment' : slug;
  return 'appt_${base}_$suffix';
}

Future<List<AppointmentRole>> loadAppointmentRoles({bool includeArchived = false}) async {
  var query = supabase.from('appointment_roles').select();
  if (!includeArchived) query = query.eq('is_active', true);
  final rows = await query.order('sort_order', ascending: true);
  return (rows as List).cast<Map<String, dynamic>>().map(AppointmentRole.fromMap).toList();
}

Future<void> saveAppointmentRole({
  String? id,
  String? code,
  required String label,
  String? description,
  required bool isMandatory,
  required int sortOrder,
}) async {
  final payload = <String, dynamic>{
    'code': (code == null || code.trim().isEmpty) ? null : code.trim(),
    'label': label.trim(),
    'description': (description == null || description.trim().isEmpty) ? null : description.trim(),
    'is_mandatory': isMandatory,
    'sort_order': sortOrder,
  };
  if (id == null) {
    await supabase.from('appointment_roles').insert(payload);
  } else {
    payload['updated_at'] = _nowUtc();
    await supabase.from('appointment_roles').update(payload).eq('id', id);
  }
}

Future<void> setAppointmentRoleActive(String id, bool active) async {
  await supabase.from('appointment_roles')
      .update({'is_active': active, 'updated_at': _nowUtc()}).eq('id', id);
}

Future<List<AppointmentTemplate>> loadAppointmentTemplates({bool includeArchived = false}) async {
  var query = supabase.from('appointment_templates').select();
  if (!includeArchived) query = query.eq('is_active', true);
  final rows = await query.order('updated_at', ascending: false);
  return (rows as List).cast<Map<String, dynamic>>().map(AppointmentTemplate.fromMap).toList();
}

Future<String> saveAppointmentTemplate({
  String? id,
  required String code,
  required String name,
  String? description,
  String? roleId,
  required String language,
  required List<FormFieldDef> fields,
  required String letterBody,
  required List<String> requiredSigners,
  required int version,
}) async {
  final user = supabase.auth.currentUser;
  final payload = <String, dynamic>{
    'code': code,
    'name': name,
    'description': description,
    'role_id': roleId,
    'language': language,
    'fields': fields.map((f) => f.toMap()).toList(),
    'letter_body': letterBody,
    'required_signers': requiredSigners,
  };
  if (id == null) {
    payload['version'] = 1;
    if (user != null) payload['created_by'] = user.id;
    final inserted =
        await supabase.from('appointment_templates').insert(payload).select('id').single();
    return inserted['id'] as String;
  } else {
    payload['version'] = version + 1;
    payload['updated_at'] = _nowUtc();
    await supabase.from('appointment_templates').update(payload).eq('id', id);
    return id;
  }
}

Future<void> setAppointmentTemplateActive(String id, bool active) async {
  await supabase.from('appointment_templates')
      .update({'is_active': active, 'updated_at': _nowUtc()}).eq('id', id);
}
```

- [ ] **Step 2: Analyze**

Run: `flutter analyze lib/utils/appointment_template_data.dart`
Expected: No issues (may need the model import path resolved — fix any).

- [ ] **Step 3: Format + commit**

```bash
dart format lib/utils/appointment_template_data.dart
git add lib/utils/appointment_template_data.dart
git commit -m "SP3: appointment roles + templates data layer"
```

---

### Task 4: Letter PDF generator

**Files:**
- Create: `lib/pdf/generate_appointment_letter_pdf.dart`

**Interfaces:**
- Consumes: `AppointmentTemplate`, `AppointmentRole`, `renderLetterBody`; `pdf`/`printing`; bundled Roboto fonts (`assets/fonts/Roboto-Regular.ttf`, `Roboto-Bold.ttf`).
- Produces: `Future<pw.Document> generateAppointmentLetterPdf(AppointmentTemplate template, Map<String, String> values, {AppointmentRole? role})`.

- [ ] **Step 1: Write the generator**

Render: title (role displayLabel or template name), the substituted letter body parsed for the markdown subset (`# heading` → centered bold; blank line → paragraph break; `**bold**` inline → bold spans), then a signature block per required signer + the appointee. Use `pw.MultiPage`, `PdfPageFormat.letter`, 36pt margins.

```dart
// SP3 letter PDF: substitutes {{placeholders}} into the template letter body and
// renders a formal appointment letter (minimal markdown: '# heading', '**bold**').

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/appointment_template.dart';

Future<pw.Document> generateAppointmentLetterPdf(
  AppointmentTemplate template,
  Map<String, String> values, {
  AppointmentRole? role,
}) async {
  final base = pw.Font.ttf(await rootBundle.load('assets/fonts/Roboto-Regular.ttf'));
  final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/Roboto-Bold.ttf'));
  final theme = pw.ThemeData.withFont(base: base, bold: bold);

  final title = (role?.displayLabel.isNotEmpty ?? false) ? role!.displayLabel : template.name;
  final rendered = renderLetterBody(template.letterBody, values);

  final blocks = <pw.Widget>[];
  for (final rawLine in rendered.split('\n')) {
    final line = rawLine.trimRight();
    if (line.trim().isEmpty) {
      blocks.add(pw.SizedBox(height: 8));
    } else if (line.startsWith('# ')) {
      blocks.add(pw.Center(
        child: pw.Text(line.substring(2).trim(),
            style: pw.TextStyle(font: bold, fontSize: 14)),
      ));
      blocks.add(pw.SizedBox(height: 6));
    } else {
      blocks.add(pw.RichText(text: pw.TextSpan(children: _inline(line, base, bold))));
      blocks.add(pw.SizedBox(height: 2));
    }
  }

  final signers = <String>[...template.requiredSigners, 'appointee'];
  blocks.add(pw.SizedBox(height: 24));
  for (final s in signers) {
    blocks.add(pw.Padding(
      padding: const pw.EdgeInsets.only(top: 18),
      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Container(width: 220, height: 0.8, color: PdfColors.black),
        pw.SizedBox(height: 2),
        pw.Text(_signerLabel(s), style: pw.TextStyle(font: base, fontSize: 9)),
      ]),
    ));
  }

  final doc = pw.Document();
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.letter,
    theme: theme,
    margin: const pw.EdgeInsets.all(36),
    header: (ctx) => ctx.pageNumber == 1
        ? pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 16),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
              pw.Text('LETTER OF APPOINTMENT', style: pw.TextStyle(font: bold, fontSize: 16)),
              pw.SizedBox(height: 4),
              pw.Text(title, style: pw.TextStyle(font: base, fontSize: 12)),
            ]),
          )
        : pw.SizedBox(),
    build: (ctx) => blocks,
  ));
  return doc;
}

List<pw.TextSpan> _inline(String line, pw.Font base, pw.Font bold) {
  final spans = <pw.TextSpan>[];
  final re = RegExp(r'\*\*(.+?)\*\*');
  var idx = 0;
  for (final m in re.allMatches(line)) {
    if (m.start > idx) {
      spans.add(pw.TextSpan(text: line.substring(idx, m.start), style: pw.TextStyle(font: base, fontSize: 11)));
    }
    spans.add(pw.TextSpan(text: m.group(1), style: pw.TextStyle(font: bold, fontSize: 11)));
    idx = m.end;
  }
  if (idx < line.length) {
    spans.add(pw.TextSpan(text: line.substring(idx), style: pw.TextStyle(font: base, fontSize: 11)));
  }
  return spans;
}

String _signerLabel(String key) {
  switch (key) {
    case 'appointee':
      return 'Signature of appointee';
    case 'mine_overseer':
      return 'Mine Overseer';
    case 'mine_manager':
      return 'Mine Manager';
    default:
      return key.replaceAll('_', ' ');
  }
}
```

Note: confirm the chain-signer keys by reading `kChainSignerLabels` in `lib/utils/dynamic_form_payload.dart` and align `_signerLabel` cases to those keys.

- [ ] **Step 2: Analyze**

Run: `flutter analyze lib/pdf/generate_appointment_letter_pdf.dart`
Expected: No issues.

- [ ] **Step 3: Format + commit**

```bash
dart format lib/pdf/generate_appointment_letter_pdf.dart
git add lib/pdf/generate_appointment_letter_pdf.dart
git commit -m "SP3: appointment letter PDF generator"
```

---

### Task 5: Appointment Builder screen (list + editor + roles dialog)

**Files:**
- Create: `lib/screens/setup/appointment_builder_screen.dart`

**Interfaces:**
- Consumes: model (Task 2), data layer (Task 3), PDF generator (Task 4), `FieldEditorList` (`lib/widgets/form_builder/field_editor.dart`), `kChainSignerLabels` (`lib/utils/dynamic_form_payload.dart`), `PageBody`, `commonAppBarActions`, `isAdminProfile`, `AuthProvider`, `Printing`.
- Produces: `class AppointmentBuilderScreen extends StatefulWidget` (public, no required args).

- [ ] **Step 1: Build the screen**

Mirror `form_builder_screen.dart` structure exactly:
- `AppointmentBuilderScreen` — admin gate (non-admin → "available to Admin and Super Admin accounts only." message); load `loadAppointmentTemplates(includeArchived: true)` + `loadAppointmentRoles(includeArchived: true)`; FAB "New appointment"; app bar actions: Refresh, a "Manage roles" `IconButton(Icons.badge_outlined)` opening `_RolesManagerDialog`, then `...commonAppBarActions()`; list of templates as Cards (title = name, subtitle = role label + field count + archived flag); PopupMenu Edit/Archive-Restore; tap → editor.
- `_AppointmentEditorScreen` — `DefaultTabController(length: 2)` with tabs "Details & fields" and "Letter":
  - **Details & fields tab** (`ListView`): role `DropdownButtonFormField<String>` (items from active roles, value = roleId), name, description, language (`DropdownButtonFormField` of `['en','af','zu','xh','st','tn']` default 'en'), required-signers `FilterChip`s from `kChainSignerLabels`, then `FieldEditorList(fields:_fields, onChanged: ...)`.
  - **Letter tab** (`Column`): a `TextField` (maxLines null, expands) bound to `_letterCtrl`; a horizontal wrap palette of `ActionChip`s — one per template field key (`{{key}}`) and one per `kStandardLetterTokens` token — each inserts `{{token}}` at the cursor; a "Preview" button that shows a live substituted preview (sample data) in an expandable panel; a "Preview PDF" button → `Printing.layoutPdf(onLayout: (_) async => (await generateAppointmentLetterPdf(_draftTemplate(), _sampleValues(), role: _selectedRole())).save())`.
  - App bar "Save": run `validateAppointmentTemplate`; on errors show the same AlertDialog pattern as form_builder; else `saveAppointmentTemplate(...)` with code = existing or `appointmentTemplateCode(name, microsecondsSinceEpoch.toRadixString(36))`; pop(true).
- `_RolesManagerDialog` — `AlertDialog` (or full-screen dialog) listing roles with add/edit (code, label, description, mandatory switch, sort order) and archive/restore; on change calls `saveAppointmentRole` / `setAppointmentRoleActive` and refreshes.

Sample values for preview/PDF: map each `kStandardLetterTokens` token to a placeholder sample (`full_name`→'Jane Doe', `employee_number`→'EMP001', `id_number`→'8001015009087', `occupation`→'Shift Supervisor', `section`→'Section A', `company`→'Mine Online', `date`→ a fixed string like '21 June 2026', `first_name`→'Jane', `last_name`→'Doe'); map each template field key to `'<Label sample>'`.

Cursor-insert helper:

```dart
void _insertToken(TextEditingController c, String token) {
  final text = c.text;
  final sel = c.selection;
  final start = sel.start < 0 ? text.length : sel.start;
  final end = sel.end < 0 ? text.length : sel.end;
  final insert = '{{$token}}';
  final next = text.replaceRange(start, end, insert);
  c.value = TextEditingValue(
    text: next,
    selection: TextSelection.collapsed(offset: start + insert.length),
  );
}
```

- [ ] **Step 2: Analyze**

Run: `flutter analyze lib/screens/setup/appointment_builder_screen.dart`
Expected: No issues. (Resolve any import / API mismatches against the real `FieldEditorList` and `kChainSignerLabels` signatures.)

- [ ] **Step 3: Format + commit**

```bash
dart format lib/screens/setup/appointment_builder_screen.dart
git add lib/screens/setup/appointment_builder_screen.dart
git commit -m "SP3: appointment builder screen (list + editor + roles dialog)"
```

---

### Task 6: Wire the route

**Files:**
- Modify: `lib/routing/router.dart` (remove `/appointment-builder` from `adminStubs`; add real `GoRoute`)

**Interfaces:**
- Consumes: `AppointmentBuilderScreen` from Task 5.

- [ ] **Step 1: Add the import**

Add near the other screen imports: `import '../screens/setup/appointment_builder_screen.dart';`

- [ ] **Step 2: Add the real route**

Insert before `..._placeholders()` (next to the other `/setup` and admin routes):

```dart
GoRoute(
  path: '/appointment-builder',
  builder: (_, __) => const AppointmentBuilderScreen(),
),
```

- [ ] **Step 3: Remove the stub**

Delete the `'/appointment-builder': (...)` entry from the `adminStubs` map in `_placeholders()`.

- [ ] **Step 4: Analyze**

Run: `flutter analyze lib/routing/router.dart`
Expected: No issues; no duplicate-route warnings.

- [ ] **Step 5: Format + commit**

```bash
dart format lib/routing/router.dart
git add lib/routing/router.dart
git commit -m "SP3: activate /appointment-builder route"
```

---

### Task 7: Full verification

- [ ] **Step 1: Analyze whole project**

Run: `flutter analyze`
Expected: "No issues found!"

- [ ] **Step 2: Run all tests**

Run: `flutter test`
Expected: all pass (existing 44 + new appointment-template tests).

- [ ] **Step 3: Windows release build**

Run: `flutter build windows --release`
Expected: "Building Windows application... ✓" and an exe under `build/windows/x64/runner/Release/`.

- [ ] **Step 4: Verify migration applied**

Via Management API: `select count(*) from public.appointment_roles where is_active;` Expected: 6.

No commit (verification only).

---

### Task 8: Merge + docs

- [ ] **Step 1: Update HANDOFF.md** — move SP3 to the DONE list; update "Immediate next action" to SP4; remove `/appointment-builder` from the live-placeholders line. Commit.
- [ ] **Step 2: Merge to main** — `git checkout main && git merge --no-ff sp3-appointment-letter-builder`; push; delete the branch.
- [ ] **Step 3: Update memory** — refresh `project_program_state.md` (SP3 done) per the memory rules.

## Self-Review

**Spec coverage:** roles catalog (Task 1 seed + Task 5 dialog) ✓; appointment builder (Tasks 2,3,5) ✓; letter builder + tokens + markdown subset (Tasks 2,4,5) ✓; PDF preview (Task 4,5) ✓; route (Task 6) ✓; tests (Task 2) ✓; RLS read-active/admin-write (Task 1) ✓; no edge-function wiring ✓; deferrals (issuance/lifecycle) not implemented ✓.

**Placeholder scan:** No TBD/TODO; all code shown. Two explicit "confirm against real signature" notes (Tasks 4,5) are verification instructions, not placeholders — the implementer reads `kChainSignerLabels`/`FieldEditorList` and aligns.

**Type consistency:** `AppointmentTemplate`/`AppointmentRole` fields and `saveAppointmentTemplate`/`saveAppointmentRole` signatures match across Tasks 2/3/5. `extractPlaceholders`/`renderLetterBody`/`validateAppointmentTemplate` signatures match Task 2 ↔ usage in Tasks 4/5. `generateAppointmentLetterPdf` signature matches Task 4 ↔ Task 5 call.
