# Form Template Studio FS1 — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship the Studio + lifecycle: Originals (read-only, clone-to-edit) and
Edited (drafts: edit / test / set active / delete) tabs, where the active draft
drives the real form and the original is the permanent fallback.

**Architecture:** An overlay draft is a `custom_form_templates` row with
`base_form_type` set + `is_active` flag. `loadFormOverlay(formType)` returns the
active draft (so all 26 forms + the PDF appendix use it; none active = original).
Lifecycle CRUD + a Studio screen wrap it; a process-global `formTestMode` gates
the two shared persist helpers for the fill+sign sandbox.

**Tech Stack:** Flutter, `supabase_flutter`, `go_router`, `provider`.

## Global Constraints

- No new dependencies. No "Claude"/AI naming. Originals never mutated/deleted.
- Override/active-draft null ⇒ forms render exactly as today.
- Admin-gated. Migration via `supabase/migrations/` + Management API.
- `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- `dart format` touched files; stage explicit paths only.

---

### Task 1: Migration — one active overlay draft per form

**Files:**
- Create: `supabase/migrations/20260626120000_fs1_template_lifecycle.sql`

- [ ] **Step 1: Write the migration**

```sql
-- FS1: at most one ACTIVE overlay draft per base form. Originals have no active
-- draft (loadFormOverlay returns null -> the bespoke form is the fallback).
create unique index if not exists custom_form_templates_one_active_overlay
  on public.custom_form_templates (base_form_type)
  where base_form_type is not null and is_active = true;
```

- [ ] **Step 2: Apply via Management API** (helper from the SP9 plan; `$Q` = file
body). Expected `[]`.

- [ ] **Step 3: Verify**

`$Q`:
```sql
select indexname from pg_indexes
where tablename='custom_form_templates'
  and indexname='custom_form_templates_one_active_overlay';
```
Expected: one row.

- [ ] **Step 4: Commit**

```bash
git add supabase/migrations/20260626120000_fs1_template_lifecycle.sql
git commit -m "FS1: migration — one active overlay draft per form"
```

---

### Task 2: Test sandbox — `formTestMode`

**Files:**
- Modify: `lib/utils/signature_workflow.dart`

**Interfaces:**
- Produces: top-level `bool formTestMode`; both `persistFormSubmission` and
  `saveFormSubmissionAndStartWorkflow` short-circuit when it is true.

- [ ] **Step 1: Add the flag + gates**

Near the top of `lib/utils/signature_workflow.dart` (after imports):
```dart
/// When true, a Studio "Test" form is open: submissions are NOT written — the
/// persist helpers return a fake id so the fill+sign flow completes for testing
/// without touching real data. Set/reset by the Form Studio around a Test push.
bool formTestMode = false;
```
As the FIRST statement inside `persistFormSubmission(...)`:
```dart
  if (formTestMode) {
    return 'test-${DateTime.now().microsecondsSinceEpoch}';
  }
```
As the FIRST statement inside `saveFormSubmissionAndStartWorkflow(...)`:
```dart
  if (formTestMode) {
    return 'test-${DateTime.now().microsecondsSinceEpoch}';
  }
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/utils/signature_workflow.dart`
Expected: No issues.

- [ ] **Step 3: Commit**

```bash
dart format lib/utils/signature_workflow.dart
git add lib/utils/signature_workflow.dart
git commit -m "FS1: formTestMode gates the shared submit helpers (test sandbox)"
```

---

### Task 3: Data layer — OverlayDraft model + lifecycle + active-draft load

**Files:**
- Modify: `lib/utils/form_overlay_data.dart`
- Test: `test/overlay_draft_test.dart`

**Interfaces:**
- Produces: `class OverlayDraft { id; baseFormType; name; isActive; overlay }`;
  `String? activeDraftName(List<OverlayDraft>, String baseFormType)`;
  `listOverlayDrafts()`, `createOverlayDraft(base, name)→id`,
  `saveOverlayDraft(id, {name, overlay})`, `deleteOverlayDraft(id)`,
  `setOverlayDraftActive(id, base)`, `deactivateOverlayForForm(base)`.
  `loadFormOverlay(formType)` now returns the **active** draft's overlay.

- [ ] **Step 1: Write the failing test**

```dart
// test/overlay_draft_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/form_overlay_data.dart';
import 'package:mine_online/models/form_overlay.dart';

OverlayDraft d(String id, String base, String name, bool active) => OverlayDraft(
  id: id,
  baseFormType: base,
  name: name,
  isActive: active,
  overlay: const FormOverlay(addedFields: [], addedPages: [], fieldOverrides: {}),
);

void main() {
  group('activeDraftName', () {
    final drafts = [
      d('1', 'shift_boss_appointment', 'Copy A', false),
      d('2', 'shift_boss_appointment', 'Copy B', true),
      d('3', 'miner_appointment', 'M', false),
    ];
    test('returns the active draft name for the form', () {
      expect(activeDraftName(drafts, 'shift_boss_appointment'), 'Copy B');
    });
    test('null when no active draft for the form', () {
      expect(activeDraftName(drafts, 'miner_appointment'), isNull);
      expect(activeDraftName(drafts, 'unknown'), isNull);
    });
  });
}
```

- [ ] **Step 2: Run → fail** (`flutter test test/overlay_draft_test.dart` → not defined).

- [ ] **Step 3: Implement**

In `lib/utils/form_overlay_data.dart`, replace the file body's overlay functions
with the draft model + lifecycle (keep `loadFieldOverrides`, `loadEditedFormTypes`
working off `loadFormOverlay`). Concretely:

Add the model + pure helper:
```dart
class OverlayDraft {
  const OverlayDraft({
    required this.id,
    required this.baseFormType,
    required this.name,
    required this.isActive,
    required this.overlay,
  });
  final String id;
  final String baseFormType;
  final String name;
  final bool isActive;
  final FormOverlay overlay;

  factory OverlayDraft.fromRow(Map<String, dynamic> r) => OverlayDraft(
    id: r['id'] as String,
    baseFormType: r['base_form_type'] as String? ?? '',
    name: (r['name'] as String?) ?? 'Untitled',
    isActive: (r['is_active'] as bool?) ?? false,
    overlay: r['overlay'] is Map
        ? FormOverlay.fromMap((r['overlay'] as Map).cast<String, dynamic>())
        : const FormOverlay(addedFields: [], addedPages: [], fieldOverrides: {}),
  );
}

/// Pure: the active draft's name for [baseFormType], or null.
String? activeDraftName(List<OverlayDraft> drafts, String baseFormType) {
  for (final d in drafts) {
    if (d.baseFormType == baseFormType && d.isActive) return d.name;
  }
  return null;
}
```

Replace `loadFormOverlay` to return the ACTIVE draft:
```dart
/// The active overlay draft for [formType], or null (original = fallback).
Future<FormOverlay?> loadFormOverlay(String formType) async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('overlay')
      .eq('base_form_type', formType)
      .eq('is_active', true)
      .limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  if (list.isEmpty) return null;
  final raw = list.first['overlay'];
  if (raw is! Map) return null;
  return FormOverlay.fromMap(raw.cast<String, dynamic>());
}
```

Add the lifecycle CRUD:
```dart
Future<List<OverlayDraft>> listOverlayDrafts() async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('id, base_form_type, name, is_active, overlay')
      .not('base_form_type', 'is', null)
      .order('base_form_type')
      .order('name');
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(OverlayDraft.fromRow)
      .toList();
}

Future<String> createOverlayDraft(String baseFormType, String name) async {
  final user = supabase.auth.currentUser;
  final row = await supabase
      .from('custom_form_templates')
      .insert({
        'code': 'ov_${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}',
        'name': name,
        'base_form_type': baseFormType,
        'fields': <dynamic>[],
        'overlay': const <String, dynamic>{},
        'is_active': false,
        if (user != null) 'created_by': user.id,
      })
      .select('id')
      .single();
  return row['id'] as String;
}

Future<void> saveOverlayDraft(
  String id, {
  required String name,
  required FormOverlay overlay,
}) async {
  await supabase
      .from('custom_form_templates')
      .update({
        'name': name,
        'overlay': overlay.toMap(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      })
      .eq('id', id);
}

Future<void> deleteOverlayDraft(String id) async {
  await supabase.from('custom_form_templates').delete().eq('id', id);
}

Future<void> setOverlayDraftActive(String id, String baseFormType) async {
  await supabase
      .from('custom_form_templates')
      .update({'is_active': false})
      .eq('base_form_type', baseFormType);
  await supabase
      .from('custom_form_templates')
      .update({'is_active': true})
      .eq('id', id);
}

Future<void> deactivateOverlayForForm(String baseFormType) async {
  await supabase
      .from('custom_form_templates')
      .update({'is_active': false})
      .eq('base_form_type', baseFormType);
}
```

**Remove** the old `saveFormOverlay(String, String, FormOverlay)` function
(superseded by `saveOverlayDraft`). Keep a draft-id loader for the editor:
```dart
Future<OverlayDraft?> loadOverlayDraft(String id) async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('id, base_form_type, name, is_active, overlay')
      .eq('id', id)
      .limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  return list.isEmpty ? null : OverlayDraft.fromRow(list.first);
}
```
`loadEditedFormTypes()` stays (it reads code+overlay where base_form_type not
null) — it now lists forms that have ANY draft; fine for the "Edited" chip.

- [ ] **Step 4: Run → pass** (`flutter test test/overlay_draft_test.dart`, 2 tests).

- [ ] **Step 5: Commit**

```bash
dart format lib/utils/form_overlay_data.dart test/overlay_draft_test.dart
git add lib/utils/form_overlay_data.dart test/overlay_draft_test.dart
git commit -m "FS1: overlay draft model + lifecycle CRUD; loadFormOverlay = active draft"
```

---

### Task 4: Rework the overlay editor to a draft (own file)

**Files:**
- Create: `lib/screens/form_builder/overlay_editor_screen.dart`
- Modify: `lib/screens/form_builder_screen.dart` (remove `_OverlayEditorScreen`,
  the "Current forms" body section, the ✎ action, `_pickCurrentForm`,
  `_openOverlayEditor`, `_edited` state, `loadEditedFormTypes` import use)

**Interfaces:**
- Consumes: `loadOverlayDraft`, `saveOverlayDraft`, `OverlayDraft` (Task 3);
  `reorderableBlockFor`, `catalogFor`, `applyFieldOrder`, `buildFormView`,
  `FormViewArgs`, `FormOverlay`, `FieldEditorList`, `kReorderableBlocks`.
- Produces: `class OverlayEditorScreen extends StatefulWidget { const OverlayEditorScreen({super.key, required this.draftId, required this.baseFormType}); }`.

- [ ] **Step 1: Move + rework the editor**

Cut the entire `_OverlayEditorScreen` + `_OverlayEditorScreenState` (incl.
`_previewPane`, `_existingFieldRow`, `_pageEditor`, `_build`, `_save`, `_load`,
the debounce state) out of `form_builder_screen.dart` into the new file
`lib/screens/form_builder/overlay_editor_screen.dart`, renamed public
`OverlayEditorScreen`. Apply these changes during the move:
- Constructor: `OverlayEditorScreen({required this.draftId, required this.baseFormType})` with
  `final String draftId; final String baseFormType;` (drop `meta`).
- Add `String _name = '';` state.
- `_load()` → `final draft = await loadOverlayDraft(widget.draftId);` then set
  `_addedFields/_pages/_overrides/_order` from `draft?.overlay` and
  `_name = draft?.name ?? ''`.
- Everywhere that referenced `widget.meta.formType` → `widget.baseFormType`;
  `widget.meta.title` → `_name` (or a fixed "Edit form" app-bar title).
- `_save()` → validate as before, then
  `await saveOverlayDraft(widget.draftId, name: _name, overlay: _build());`
  then `Navigator.pop(context, true)`.
- Add an editable **name** `TextField` at the top of the editor list
  (`onChanged: (v) => _name = v`).
- Imports: `package:flutter/material.dart`, `dart:async`,
  `../../models/custom_form_template.dart`, `../../models/form_overlay.dart`,
  `../../models/form_view_args.dart`, `../../utils/dynamic_form_payload.dart`
  show kChainSignerLabels, `../../utils/form_field_catalog.dart`,
  `../../utils/form_overlay_data.dart`, `../../utils/form_registry.dart`,
  `../../widgets/form_builder/field_editor.dart`, `../../widgets/page_body.dart`.
  (Mirror the imports the editor currently relies on.)

- [ ] **Step 2: Strip the removed pieces from `form_builder_screen.dart`**

Remove from `_FormBuilderScreenState`: the `_edited` field + its load; the
`_pickCurrentForm` + `_openOverlayEditor` methods; the ✎ app-bar `IconButton`;
and the entire "Current forms" section in the body (the `Text('Current forms')`
through the category/`_openOverlayEditor` loop) — leaving only the "Custom forms"
section (rename its heading back to a single list; drop the now-unused
`groupFormsByCategory`, `kFormMetadataRegistry`, `loadEditedFormTypes` imports if
no longer referenced). The screen returns to its pre-SP10a shape (custom forms
list + New form FAB).

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/screens/form_builder/overlay_editor_screen.dart lib/screens/form_builder_screen.dart`
Expected: No issues.

- [ ] **Step 4: Commit**

```bash
dart format lib/screens/form_builder/overlay_editor_screen.dart lib/screens/form_builder_screen.dart
git add lib/screens/form_builder/overlay_editor_screen.dart lib/screens/form_builder_screen.dart
git commit -m "FS1: extract overlay editor to its own file, operating on a draft id"
```

---

### Task 5: Form Studio screen (Originals / Edited tabs + lifecycle + test)

**Files:**
- Create: `lib/screens/templates/form_studio_screen.dart`

**Interfaces:**
- Consumes: `kFormMetadataRegistry`, `groupFormsByCategory` (form_metadata.dart);
  `listOverlayDrafts`, `createOverlayDraft`, `deleteOverlayDraft`,
  `setOverlayDraftActive`, `deactivateOverlayForForm`, `activeDraftName`,
  `OverlayDraft`, `formMetadataByType`; `OverlayEditorScreen` (Task 4);
  `buildFormView`, `FormViewArgs`; `formTestMode` (signature_workflow.dart);
  `isAdminProfile`, `AuthProvider`, `commonAppBarActions`, `PageBody`.
- Produces: `class FormStudioScreen extends StatefulWidget { const FormStudioScreen({super.key}); }`.

- [ ] **Step 1: Write the screen**

```dart
// lib/screens/templates/form_studio_screen.dart
// FS1 Form Template Studio: Originals (read-only, clone-to-edit) + Edited
// (drafts: edit / test / set active / delete). Active draft drives the real
// form (loadFormOverlay); the original is the permanent fallback.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../models/form_view_args.dart';
import '../../providers/auth_provider.dart';
import '../../utils/form_metadata.dart';
import '../../utils/form_overlay_data.dart';
import '../../utils/form_registry.dart';
import '../../utils/role_access.dart';
import '../../utils/signature_workflow.dart' show formTestMode;
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';
import '../form_builder/overlay_editor_screen.dart';

class FormStudioScreen extends StatefulWidget {
  const FormStudioScreen({super.key});

  @override
  State<FormStudioScreen> createState() => _FormStudioScreenState();
}

class _FormStudioScreenState extends State<FormStudioScreen> {
  bool _loading = true;
  String? _error;
  List<OverlayDraft> _drafts = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final drafts = await listOverlayDrafts();
      if (!mounted) return;
      setState(() {
        _drafts = drafts;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _editDraft(String id, String baseFormType) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) =>
            OverlayEditorScreen(draftId: id, baseFormType: baseFormType),
      ),
    );
    if (mounted) _load();
  }

  Future<void> _editOriginal(FormMetadata m) async {
    final id = await createOverlayDraft(m.formType, 'Copy of ${m.title}');
    if (!mounted) return;
    await _editDraft(id, m.formType);
  }

  Future<void> _test(OverlayDraft draft) async {
    final view = buildFormView(
      draft.baseFormType,
      FormViewArgs(overlayOverride: draft.overlay),
    );
    if (view == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No test view for this form.')),
      );
      return;
    }
    formTestMode = true;
    await Navigator.of(context)
        .push<void>(MaterialPageRoute(builder: (_) => view))
        .whenComplete(() => formTestMode = false);
  }

  Future<void> _setActive(OverlayDraft draft) async {
    await setOverlayDraftActive(draft.id, draft.baseFormType);
    if (mounted) _load();
  }

  Future<void> _deactivate(OverlayDraft draft) async {
    await deactivateOverlayForForm(draft.baseFormType);
    if (mounted) _load();
  }

  Future<void> _delete(OverlayDraft draft) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete edited form?'),
        content: Text('Delete "${draft.name}"? This cannot be undone. The '
            'original form is unaffected.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await deleteOverlayDraft(draft.id);
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Form Studio'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Form Studio is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Form Studio'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
          actions: [
            IconButton(
              tooltip: 'Refresh',
              onPressed: _loading ? null : _load,
              icon: const Icon(Icons.refresh),
            ),
            ...commonAppBarActions(),
          ],
          bottom: const TabBar(
            tabs: [Tab(text: 'Originals'), Tab(text: 'Edited')],
          ),
        ),
        body: SafeArea(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(_error!, style: TextStyle(color: scheme.error)),
                  ),
                )
              : TabBarView(children: [_originals(scheme), _edited(scheme)]),
        ),
      ),
    );
  }

  Widget _originals(ColorScheme scheme) {
    return PageBody.list(
      scrollable: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Tap Edit to make an editable copy. Originals are never changed or '
            'deleted.',
            style: TextStyle(color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: 8),
          for (final entry
              in groupFormsByCategory(kFormMetadataRegistry).entries) ...[
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 4),
              child: Text(
                entry.key,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
            for (final m in entry.value)
              Card(
                margin: const EdgeInsets.only(bottom: 6),
                child: ListTile(
                  title: Text(m.title),
                  subtitle: () {
                    final active = activeDraftName(_drafts, m.formType);
                    return active == null
                        ? Text(m.category)
                        : Text('${m.category} • Active: $active');
                  }(),
                  trailing: FilledButton.tonalIcon(
                    onPressed: () => _editOriginal(m),
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    label: const Text('Edit'),
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _edited(ColorScheme scheme) {
    if (_drafts.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'No edited forms yet. Edit an original to create one.',
            textAlign: TextAlign.center,
            style: TextStyle(color: scheme.onSurfaceVariant),
          ),
        ),
      );
    }
    return PageBody.list(
      scrollable: true,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final draft in _drafts)
            Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            draft.name,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        if (draft.isActive)
                          Chip(
                            label: const Text('Active'),
                            visualDensity: VisualDensity.compact,
                            backgroundColor: scheme.secondaryContainer,
                          ),
                      ],
                    ),
                    Text(
                      formMetadataByType(draft.baseFormType)?.title ??
                          draft.baseFormType,
                      style: TextStyle(
                        fontSize: 12,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () =>
                              _editDraft(draft.id, draft.baseFormType),
                          icon: const Icon(Icons.edit_outlined, size: 18),
                          label: const Text('Edit'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () => _test(draft),
                          icon: const Icon(Icons.play_arrow_outlined, size: 18),
                          label: const Text('Test'),
                        ),
                        if (draft.isActive)
                          OutlinedButton.icon(
                            onPressed: () => _deactivate(draft),
                            icon: const Icon(Icons.pause_outlined, size: 18),
                            label: const Text('Deactivate'),
                          )
                        else
                          FilledButton.tonalIcon(
                            onPressed: () => _setActive(draft),
                            icon: const Icon(Icons.check, size: 18),
                            label: const Text('Set active'),
                          ),
                        IconButton(
                          tooltip: 'Delete',
                          onPressed: () => _delete(draft),
                          icon: Icon(
                            Icons.delete_outline,
                            color: scheme.error,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/screens/templates/form_studio_screen.dart`
Expected: No issues. (If `formMetadataByType` isn't exported from
form_metadata.dart, confirm its name — it exists per the registry file.)

- [ ] **Step 3: Commit**

```bash
dart format lib/screens/templates/form_studio_screen.dart
git add lib/screens/templates/form_studio_screen.dart
git commit -m "FS1: Form Studio screen (Originals/Edited tabs + lifecycle + test)"
```

---

### Task 6: Route + sidebar

**Files:**
- Modify: `lib/routing/router.dart`
- Modify: `lib/widgets/admin/admin_sidebar.dart`

- [ ] **Step 1: Route**

Add the import (near the other template screens) and a route:
```dart
import '../screens/templates/form_studio_screen.dart';
```
```dart
        GoRoute(
          path: '/templates/studio',
          builder: (_, __) => const FormStudioScreen(),
        ),
```

- [ ] **Step 2: Sidebar leaf** (Templates section, before Form Builder):

```dart
    SidebarLeaf(
      'Form Studio',
      Icons.auto_awesome_motion_outlined,
      '/templates/studio',
      accent: 6,
    ),
```

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart`
Expected: No issues.

- [ ] **Step 4: Commit**

```bash
dart format lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart
git add lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart
git commit -m "FS1: /templates/studio route + Form Studio sidebar leaf"
```

---

### Task 7: Full verification + lifecycle smoke

- [ ] **Step 1:** `flutter analyze` → No issues.
- [ ] **Step 2:** `flutter test` → all pass (existing + 2 overlay_draft tests).
- [ ] **Step 3:** `flutter build windows --release` → Built.
- [ ] **Step 4: Management-API lifecycle smoke** — insert a draft for
  `shift_boss_appointment`, activate it, confirm one active row, then clean up:
```sql
insert into public.custom_form_templates (code, name, base_form_type, fields, overlay, is_active)
  values ('ov_smoke', 'Smoke copy', 'shift_boss_appointment', '[]'::jsonb, '{}'::jsonb, false);
update public.custom_form_templates set is_active=true where code='ov_smoke';
select count(*) as active from public.custom_form_templates
  where base_form_type='shift_boss_appointment' and is_active=true;  -- expect 1
delete from public.custom_form_templates where code='ov_smoke';      -- cleanup
```
- [ ] **Step 5:** Commit any verification fixes.

---

## Self-Review

**Spec coverage:** migration/index → T1; test sandbox → T2; draft model +
lifecycle + active-draft load + `activeDraftName` → T3; editor reworked to a draft
→ T4; Studio tabs (Originals clone-to-edit/no-delete, Edited
edit/test/active/delete) → T5; route + sidebar + SP10a removal → T4/T6;
verification → T7. ✓

**Placeholder scan:** No TBD/TODO; full code for new files; precise edit
instructions for the editor extraction (a move + rename, not a placeholder).

**Type consistency:** `OverlayDraft`, `activeDraftName`, `loadFormOverlay`
(now active-draft), `listOverlayDrafts`, `createOverlayDraft`, `saveOverlayDraft`,
`setOverlayDraftActive`, `deactivateOverlayForForm`, `loadOverlayDraft`,
`OverlayEditorScreen(draftId, baseFormType)`, `formTestMode`, `FormStudioScreen`
are consistent across T2–T6.
```
