# SP11 — Live Form-Edit Preview Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Render the whole form live in the overlay editor, reflecting unsaved
added fields/tables, hide/relabel, and reorder as the admin edits.

**Architecture:** Inject the in-progress `FormOverlay` via a new
`FormViewArgs.overlayOverride`; every overlay-aware path uses it instead of the
DB load. The override is null in all non-preview flows, so the 27 forms stay
byte-identical (the existing test suite guards this).

**Tech Stack:** Flutter, `provider`, `supabase_flutter`.

## Global Constraints

- No new dependencies. No "Claude"/AI naming. No migration, no PDF change.
- **Override null ⇒ byte-identical** to today in every normal flow — the sweep
  edits must be no-ops when `overlayOverride == null`.
- Preview is read-only (`FormMode.view`).
- `flutter analyze` clean; `flutter test` green (existing suite unchanged);
  `flutter build windows --release`.
- `dart format` touched files before each commit. Stage explicit paths only.

---

### Task 1: Core — `overlayOverride` on FormViewArgs + FormOverlayHost

**Files:**
- Modify: `lib/models/form_view_args.dart`
- Modify: `lib/widgets/form_builder/form_overlay_host.dart`

**Interfaces:**
- Produces: `FormViewArgs.overlayOverride` (`FormOverlay?`);
  `FormOverlayHost(... overlayOverride: FormOverlay?)`.

- [ ] **Step 1: Add `overlayOverride` to FormViewArgs**

In `lib/models/form_view_args.dart`, add the import
`import 'form_overlay.dart';`, then a field + ctor param:

```dart
  const FormViewArgs({
    this.mode = FormMode.edit,
    this.initialPayload,
    this.currentSignerRole,
    this.submissionId,
    this.requestId,
    this.onPendingSignatureChange,
    this.overlayOverride,
  });
```
and, with the other fields:
```dart
  /// When set, the form renders this in-memory overlay instead of loading the
  /// saved one from Supabase. Used by the Form Builder live preview so unsaved
  /// edits show immediately. Null in every normal flow.
  final FormOverlay? overlayOverride;
```

- [ ] **Step 2: Honor the override in FormOverlayHost**

In `lib/widgets/form_builder/form_overlay_host.dart`:

Add the param + field:
```dart
  const FormOverlayHost({
    super.key,
    required this.formType,
    required this.values,
    required this.onChanged,
    this.readOnly = false,
    this.overlayOverride,
  });
  ...
  final bool readOnly;
  final FormOverlay? overlayOverride;
```

Use it in `_load` and react to changes:
```dart
  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant FormOverlayHost old) {
    super.didUpdateWidget(old);
    if (old.overlayOverride != widget.overlayOverride) _load();
  }

  Future<void> _load() async {
    if (widget.overlayOverride != null) {
      setState(() {
        _overlay = widget.overlayOverride;
        _loaded = true;
      });
      return;
    }
    try {
      final o = await loadFormOverlay(widget.formType);
      if (!mounted) return;
      setState(() {
        _overlay = o;
        _loaded = true;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loaded = true);
    }
  }
```

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/models/form_view_args.dart lib/widgets/form_builder/form_overlay_host.dart`
Expected: No issues.

- [ ] **Step 4: Commit**

```bash
dart format lib/models/form_view_args.dart lib/widgets/form_builder/form_overlay_host.dart
git add lib/models/form_view_args.dart lib/widgets/form_builder/form_overlay_host.dart
git commit -m "SP11: FormViewArgs.overlayOverride + FormOverlayHost honors it"
```

---

### Task 2: Editor live-preview pane

**Files:**
- Modify: `lib/screens/form_builder_screen.dart` (`_OverlayEditorScreenState`)

**Interfaces:**
- Consumes: `FormViewArgs.overlayOverride` (Task 1); `buildFormView`
  (`form_registry.dart`, already imported); `_build()` (existing).

- [ ] **Step 1: Add a debounced preview revision**

Add `import 'dart:async';` at the top of the file (if not present).

In `_OverlayEditorScreenState`, add state:
```dart
  int _previewRev = 0;
  Timer? _previewDebounce;
```
Add a scheduler + dispose:
```dart
  void _schedulePreview() {
    _previewDebounce?.cancel();
    _previewDebounce = Timer(const Duration(milliseconds: 350), () {
      if (mounted) setState(() => _previewRev++);
    });
  }

  @override
  void dispose() {
    _previewDebounce?.cancel();
    super.dispose();
  }
```
Call `_schedulePreview()` at the end of every editor mutation: in
`_setOverride`, the reorder `onReorder` + "Reset order", `_addPage`, and pass it
to the `FieldEditorList.onChanged` and page editors (anywhere `setState` changes
`_addedFields`/`_pages`/`_overrides`/`_order`). Concretely, change e.g.:
```dart
FieldEditorList(
  fields: _addedFields,
  onChanged: (f) => setState(() {
    _addedFields = f;
    _schedulePreview();
  }),
),
```
and add `_schedulePreview();` inside `_setOverride`'s `setState`, the reorder
`onReorder` `setState`, the "Reset order" `onPressed` `setState`, and `_addPage`.

- [ ] **Step 2: Build the preview widget**

Add a helper:
```dart
  Widget _livePreview() {
    final view = buildFormView(
      widget.meta.formType,
      FormViewArgs(mode: FormMode.view, overlayOverride: _build()),
    );
    return KeyedSubtree(
      key: ValueKey('preview_$_previewRev'),
      child: view ?? const Center(child: Text('No preview for this form.')),
    );
  }
```

- [ ] **Step 3: Lay out editor + preview side by side / toggled**

The editor body is currently `PageBody.form(... child: ListView(children: [...]))`.
Wrap the existing editor `ListView` as `_editorList()` (extract it to a method
returning that `ListView`), then in `build`'s body use a `LayoutBuilder`:
```dart
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : LayoutBuilder(
                builder: (context, c) {
                  final wide = c.maxWidth >= 900;
                  if (wide) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: PageBody.form(
                            padding: const EdgeInsets.all(16),
                            child: _editorList(),
                          ),
                        ),
                        const VerticalDivider(width: 1),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  'Live preview',
                                  style: Theme.of(context).textTheme.titleSmall,
                                ),
                              ),
                              const Divider(height: 1),
                              Expanded(child: _livePreview()),
                            ],
                          ),
                        ),
                      ],
                    );
                  }
                  return DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        const TabBar(
                          tabs: [Tab(text: 'Edit'), Tab(text: 'Preview')],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              PageBody.form(
                                padding: const EdgeInsets.all(16),
                                child: _editorList(),
                              ),
                              _livePreview(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
```
`_editorList()` returns the existing `ListView(children: [...])` body verbatim
(the intro text, Existing fields, Reorder fields, Added fields, Added pages).
Keep the app-bar "Preview" + "Save" actions as-is.

- [ ] **Step 4: Verify analysis**

Run: `flutter analyze lib/screens/form_builder_screen.dart`
Expected: No issues.

- [ ] **Step 5: Commit**

```bash
dart format lib/screens/form_builder_screen.dart
git add lib/screens/form_builder_screen.dart
git commit -m "SP11: live preview pane in the overlay editor (side-by-side / tabbed)"
```

> After this task, the live preview already reflects **added fields/pages/tables**
> (via FormOverlayHost). Hide/relabel + reorder reflect after Task 3.

---

### Task 3: Screen sweep — prefer the override in the 26 form screens

**Files (Modify):** the 26 bespoke form screens listed in the spec
(`early_shift_record_form_screen.dart` … `action_log_underground_visits_form_screen.dart`).

**Interfaces:**
- Consumes: `FormViewArgs.overlayOverride`, `FormOverlayHost.overlayOverride`
  (Task 1).

Each screen gets the same two inert edits. **Run as parallel subagents** (one per
screen, or small batches) using the dispatching-parallel-agents pattern — each
subagent applies the recipe to ONE file and reports back.

**Per-screen recipe:**

(a) In the screen's `FormOverlayHost(` call, add the param:
```dart
                          FormOverlayHost(
                            formType: '<form_type>',
                            values: ...,            // unchanged
                            readOnly: _isViewMode,  // unchanged
                            onChanged: (v) => _overlayValues = v, // unchanged
                            overlayOverride: widget.viewArgs?.overlayOverride,
                          ),
```

(b) If the screen has a `_loadOverrides()` (or equivalently named) method that
calls `loadFieldOverrides('<form_type>')`, prefer the override first:
```dart
  Future<void> _loadOverrides() async {
    final override = widget.viewArgs?.overlayOverride;
    if (override != null) {
      setState(() => _overrides = override.fieldOverrides);
      return;
    }
    final o = await loadFieldOverrides('<form_type>');
    if (!mounted || o.isEmpty) return;
    setState(() => _overrides = o);
  }
```
- `early_shift_record_form_screen.dart` keeps its `loadFormOverlay` DB branch and
  additionally, in the override branch, sets `_order = override.order`:
  ```dart
    if (override != null) {
      setState(() {
        _overrides = override.fieldOverrides;
        _order = override.order;
      });
      return;
    }
  ```
- If a screen's override state field is not named `_overrides`, use that screen's
  actual field name (read the file first). If a screen has **no** override method
  (only added fields), apply (a) only.
- Import note: `widget.viewArgs` already exists on these screens (the
  `FormViewArgs? viewArgs` ctor param). `FormOverlay`/`overlayOverride` need no new
  import in the screen — `overlayOverride` is accessed off `viewArgs`.

**Per-screen steps (each subagent):**

- [ ] **Step 1:** Read the target screen; find the `FormOverlayHost(` call and the
  override-load method (if any) and its override state field name.
- [ ] **Step 2:** Apply (a) the `overlayOverride:` host param and (b) the
  override-preference branch (using the real field name).
- [ ] **Step 3:** `flutter analyze <file>` → No issues.
- [ ] **Step 4:** `dart format <file>`.

- [ ] **Step 5 (after all screens): single commit for the sweep**

```bash
flutter analyze
git add <the 26 screen paths>
git commit -m "SP11: forms prefer overlayOverride for live preview (inert when null)"
```

> Correctness guard: because every edit is gated on `overlayOverride != null`, the
> existing test suite (payload parity etc.) must still pass unchanged — that proves
> the sweep didn't alter normal form behavior.

---

### Task 4: Full verification

**Files:** none.

- [ ] **Step 1: Analyze**

Run: `flutter analyze`
Expected: No issues found.

- [ ] **Step 2: Test suite**

Run: `flutter test`
Expected: all pass, **same count as before SP11** (the sweep is inert when the
override is null; payload-parity tests prove forms are unchanged).

- [ ] **Step 3: Windows release build**

Run: `flutter build windows --release`
Expected: `Built build\windows\x64\runner\Release\mine_online.exe`.

- [ ] **Step 4: Commit (only if verification required edits)**

```bash
git add <explicit paths>
git commit -m "SP11: fixes from verification"
```

---

## Self-Review

**Spec coverage:**
- `FormViewArgs.overlayOverride` → Task 1. ✓
- `FormOverlayHost.overlayOverride` + didUpdateWidget → Task 1. ✓
- Live preview pane (side-by-side / tabbed, debounced) → Task 2. ✓
- 26-screen inert sweep (host param + override-preference) → Task 3. ✓
- Override-null = byte-identical (guarded by unchanged test suite) → Task 3 guard
  + Task 4 Step 2. ✓
- analyze + test + build → Task 4. ✓

**Placeholder scan:** No TBD/TODO; code shown for every code step. Task 3's
per-screen field-name note is a real per-file variation handled by reading each
file, not a placeholder.

**Type consistency:** `overlayOverride` (`FormOverlay?`) is used consistently on
`FormViewArgs` (Task 1), `FormOverlayHost` (Task 1), the preview `FormViewArgs(...)`
(Task 2), and the screen sweep (Task 3). `_build()`, `_schedulePreview`,
`_previewRev`, `_editorList()`, `_livePreview()` are defined and used within
Task 2.
```
