# Form Builder SP2.1a — Data + Builder Authoring — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Admins/Super Admins can create, edit, archive, and restore custom form templates (all field types) stored in a new `custom_form_templates` Supabase table. (Filling/submitting those forms is the next plan, SP2.1b.)

**Architecture:** A new self-contained `custom_form_templates` table (JSONB `fields` + `audience` + `required_signers`). Pure model/validation logic (`CustomFormTemplate`, `validateTemplate`, `audienceAllows`) is unit-tested; the data layer wraps Supabase; a `FormBuilderScreen` (admin-gated) hosts a reorderable field editor. The signature-chain `required_signers` is authored but not enforced (SP2.3).

**Tech Stack:** Flutter (Material 3), `supabase_flutter ^2.8.0`, `go_router`, `provider`. Existing helpers reused: `isAdminProfile`, `AdminShell`, `MolTones`, `PageBody`, `commonAppBarActions`, `kUserAccountTypes`, `ComboBoxField`.

**Spec:** `docs/superpowers/specs/2026-06-16-form-builder-sp2-1-design.md`

**Note on migration application:** Task 1 only writes the migration FILE. The **controller applies it to the live DB** (via the Supabase Management API using the credential-manager PAT, or `npx supabase db push`) — implementer subagents do not have DB credentials. Do not block implementation tasks on the live table existing; the Dart code compiles and unit tests run without it.

---

## File Structure

New:
- `supabase/migrations/20260617090000_create_custom_form_templates.sql`
- `lib/models/custom_form_template.dart` — `FormFieldType` enum, `FormFieldDef`, `CustomFormTemplate`, `validateTemplate()`, `audienceAllows()`.
- `lib/utils/custom_form_data.dart` — `loadTemplates()`, `saveTemplate()`, `setTemplateActive()`, `slugifyCode()`.
- `lib/widgets/form_builder/field_editor.dart` — `FieldEditorList` (reorderable add/edit/remove of `FormFieldDef`).
- `lib/screens/form_builder_screen.dart` — `/form-builder` admin screen.
- `test/custom_form_template_test.dart` — model + validation + audience + slug unit tests.

Modified:
- `lib/routing/router.dart` — replace `/form-builder` placeholder with `FormBuilderScreen`.

---

## Task 1: Migration file for `custom_form_templates`

**Files:**
- Create: `supabase/migrations/20260617090000_create_custom_form_templates.sql`

- [ ] **Step 1: Write the migration**

```sql
-- Form Builder SP2.1: dynamic, admin-authored form templates. Self-contained;
-- does not touch the existing form_templates registry or form_submissions.
-- Submissions of these forms go to form_submissions with form_type = code.

create table if not exists public.custom_form_templates (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique,
  name              text not null,
  description       text,
  category          text,
  fields            jsonb not null default '[]'::jsonb,
  audience          jsonb not null default '[]'::jsonb,
  required_signers  jsonb not null default '[]'::jsonb,
  version           integer not null default 1,
  is_active         boolean not null default true,
  created_by        uuid references public.profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists custom_form_templates_active_idx
  on public.custom_form_templates (is_active, updated_at desc);

alter table public.custom_form_templates enable row level security;

-- Any authenticated user may read active templates; admins read all.
create policy "Read active custom form templates"
  on public.custom_form_templates
  for select
  to authenticated
  using (is_active = true or public.is_admin(auth.uid()));

-- Only admins/super-admins may create/update.
create policy "Admins insert custom form templates"
  on public.custom_form_templates
  for insert
  to authenticated
  with check (public.is_admin(auth.uid()));

create policy "Admins update custom form templates"
  on public.custom_form_templates
  for update
  to authenticated
  using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));
```

- [ ] **Step 2: Commit the migration file**

```bash
git add supabase/migrations/20260617090000_create_custom_form_templates.sql
git commit -m "Add custom_form_templates migration (Form Builder SP2.1)"
```

- [ ] **Step 3: Controller applies the migration**

(Controller task — not the implementer.) Apply the migration to project `hhrnkzznpadrmyverhyb` via the Supabase Management API (PAT in Windows Credential Manager target `claude-supabase-pat-hhrnkzznpadrmyverhyb`) or `npx supabase db push`. Verify with:
`select count(*) from public.custom_form_templates;` → returns 0 (table exists). Confirm `public.is_admin(uuid)` exists (it is used by the todos policies).

---

## Task 2: Model + validation (TDD)

**Files:**
- Create: `lib/models/custom_form_template.dart`
- Test: `test/custom_form_template_test.dart`

- [ ] **Step 1: Write the failing test**

Create `test/custom_form_template_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';

void main() {
  FormFieldDef text(String key) =>
      FormFieldDef(key: key, type: FormFieldType.text, label: key, required: false);

  CustomFormTemplate template(List<FormFieldDef> fields, {List<String> audience = const []}) =>
      CustomFormTemplate(
        id: 't1', code: 'custom_x', name: 'X', description: null, category: null,
        fields: fields, audience: audience, requiredSigners: const [],
        version: 1, isActive: true, createdBy: null,
      );

  test('toMap/fromMap round-trips fields and audience', () {
    final t = template([
      FormFieldDef(key: 'name', type: FormFieldType.text, label: 'Name', required: true),
      FormFieldDef(key: 'shift', type: FormFieldType.dropdown, label: 'Shift', required: true, options: ['A', 'B']),
      FormFieldDef(key: 'items', type: FormFieldType.table, label: 'Items', required: false,
          columns: [FormFieldColumn(key: 'item', label: 'Item', type: 'text')]),
    ], audience: ['Shift Boss']);
    final back = CustomFormTemplate.fromMap(t.toMap()..['id'] = 't1');
    expect(back.fields.length, 3);
    expect(back.fields[1].type, FormFieldType.dropdown);
    expect(back.fields[1].options, ['A', 'B']);
    expect(back.fields[2].columns!.first.key, 'item');
    expect(back.audience, ['Shift Boss']);
  });

  test('validateTemplate flags empty name', () {
    final errs = validateTemplate(name: '', fields: [text('a')]);
    expect(errs, contains('Form name is required.'));
  });

  test('validateTemplate flags no fields', () {
    final errs = validateTemplate(name: 'X', fields: const []);
    expect(errs.any((e) => e.contains('at least one field')), isTrue);
  });

  test('validateTemplate flags duplicate keys', () {
    final errs = validateTemplate(name: 'X', fields: [text('a'), text('a')]);
    expect(errs.any((e) => e.contains('Duplicate field key')), isTrue);
  });

  test('validateTemplate flags empty label and missing key', () {
    final errs = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: '', type: FormFieldType.text, label: '', required: false),
    ]);
    expect(errs.any((e) => e.contains('label')), isTrue);
    expect(errs.any((e) => e.contains('key')), isTrue);
  });

  test('validateTemplate flags dropdown without options', () {
    final errs = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: 'd', type: FormFieldType.dropdown, label: 'D', required: false, options: const []),
    ]);
    expect(errs.any((e) => e.contains('at least one option')), isTrue);
  });

  test('validateTemplate flags table without columns', () {
    final errs = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: 't', type: FormFieldType.table, label: 'T', required: false, columns: const []),
    ]);
    expect(errs.any((e) => e.contains('at least one column')), isTrue);
  });

  test('section field is exempt from key/label-as-input rules but needs a label', () {
    final ok = validateTemplate(name: 'X', fields: [
      FormFieldDef(key: 'sec1', type: FormFieldType.section, label: 'Part A', required: false),
      text('a'),
    ]);
    expect(ok, isEmpty);
  });

  test('audienceAllows: empty audience = everyone', () {
    expect(audienceAllows(const [], 'Shift Boss'), isTrue);
    expect(audienceAllows(const [], null), isTrue);
  });

  test('audienceAllows: matches account type', () {
    expect(audienceAllows(['Admin', 'Shift Boss'], 'Shift Boss'), isTrue);
    expect(audienceAllows(['Admin'], 'Shift Boss'), isFalse);
    expect(audienceAllows(['Admin'], null), isFalse);
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/custom_form_template_test.dart`
Expected: FAIL — URI `custom_form_template.dart` doesn't exist.

- [ ] **Step 3: Write the implementation**

Create `lib/models/custom_form_template.dart`:

```dart
// Form Builder SP2.1 model. Pure data + validation; no Flutter/Supabase deps so
// it is fully unit-testable. `fields`/`audience`/`requiredSigners` round-trip
// through the JSONB columns on custom_form_templates.

enum FormFieldType { text, multiline, number, date, dropdown, boolean, signature, section, table }

FormFieldType _typeFromString(String? s) {
  return FormFieldType.values.firstWhere(
    (t) => t.name == s,
    orElse: () => FormFieldType.text,
  );
}

class FormFieldColumn {
  const FormFieldColumn({required this.key, required this.label, required this.type});
  final String key;
  final String label;
  final String type; // 'text' | 'number'

  Map<String, dynamic> toMap() => {'key': key, 'label': label, 'type': type};

  factory FormFieldColumn.fromMap(Map<String, dynamic> m) => FormFieldColumn(
        key: (m['key'] ?? '') as String,
        label: (m['label'] ?? '') as String,
        type: (m['type'] ?? 'text') as String,
      );
}

class FormFieldDef {
  const FormFieldDef({
    required this.key,
    required this.type,
    required this.label,
    required this.required,
    this.help,
    this.options,
    this.columns,
  });

  final String key;
  final FormFieldType type;
  final String label;
  final bool required;
  final String? help;
  final List<String>? options;            // dropdown
  final List<FormFieldColumn>? columns;   // table

  Map<String, dynamic> toMap() => {
        'key': key,
        'type': type.name,
        'label': label,
        'required': required,
        if (help != null) 'help': help,
        if (options != null) 'options': options,
        if (columns != null) 'columns': columns!.map((c) => c.toMap()).toList(),
      };

  factory FormFieldDef.fromMap(Map<String, dynamic> m) => FormFieldDef(
        key: (m['key'] ?? '') as String,
        type: _typeFromString(m['type'] as String?),
        label: (m['label'] ?? '') as String,
        required: (m['required'] ?? false) as bool,
        help: m['help'] as String?,
        options: (m['options'] as List?)?.map((e) => e as String).toList(),
        columns: (m['columns'] as List?)
            ?.map((e) => FormFieldColumn.fromMap((e as Map).cast<String, dynamic>()))
            .toList(),
      );
}

class CustomFormTemplate {
  const CustomFormTemplate({
    required this.id,
    required this.code,
    required this.name,
    required this.description,
    required this.category,
    required this.fields,
    required this.audience,
    required this.requiredSigners,
    required this.version,
    required this.isActive,
    required this.createdBy,
  });

  final String id;
  final String code;
  final String name;
  final String? description;
  final String? category;
  final List<FormFieldDef> fields;
  final List<String> audience;
  final List<String> requiredSigners;
  final int version;
  final bool isActive;
  final String? createdBy;

  Map<String, dynamic> toMap() => {
        'code': code,
        'name': name,
        'description': description,
        'category': category,
        'fields': fields.map((f) => f.toMap()).toList(),
        'audience': audience,
        'required_signers': requiredSigners,
        'version': version,
        'is_active': isActive,
        if (createdBy != null) 'created_by': createdBy,
      };

  factory CustomFormTemplate.fromMap(Map<String, dynamic> m) => CustomFormTemplate(
        id: (m['id'] ?? '') as String,
        code: (m['code'] ?? '') as String,
        name: (m['name'] ?? '') as String,
        description: m['description'] as String?,
        category: m['category'] as String?,
        fields: (m['fields'] as List? ?? const [])
            .map((e) => FormFieldDef.fromMap((e as Map).cast<String, dynamic>()))
            .toList(),
        audience: (m['audience'] as List? ?? const []).map((e) => e as String).toList(),
        requiredSigners:
            (m['required_signers'] as List? ?? const []).map((e) => e as String).toList(),
        version: (m['version'] ?? 1) as int,
        isActive: (m['is_active'] ?? true) as bool,
        createdBy: m['created_by'] as String?,
      );
}

/// Returns a list of human-readable problems; empty list means valid.
List<String> validateTemplate({
  required String name,
  required List<FormFieldDef> fields,
}) {
  final errors = <String>[];
  if (name.trim().isEmpty) errors.add('Form name is required.');
  final inputFields = fields.where((f) => f.type != FormFieldType.section).toList();
  if (inputFields.isEmpty) errors.add('Add at least one field.');

  final seenKeys = <String>{};
  for (final f in fields) {
    if (f.label.trim().isEmpty) {
      errors.add('Every field needs a label.');
    }
    if (f.type == FormFieldType.section) continue;
    if (f.key.trim().isEmpty) {
      errors.add('Field "${f.label}" needs a key.');
    } else if (!seenKeys.add(f.key)) {
      errors.add('Duplicate field key: ${f.key}');
    }
    if (f.type == FormFieldType.dropdown && (f.options == null || f.options!.isEmpty)) {
      errors.add('Dropdown "${f.label}" needs at least one option.');
    }
    if (f.type == FormFieldType.table && (f.columns == null || f.columns!.isEmpty)) {
      errors.add('Table "${f.label}" needs at least one column.');
    }
  }
  return errors.toSet().toList(); // de-dupe identical messages
}

/// Empty audience means everyone. Otherwise the user's account type must be in
/// the list (a null account type is only allowed when audience is empty).
bool audienceAllows(List<String> audience, String? accountType) {
  if (audience.isEmpty) return true;
  if (accountType == null) return false;
  return audience.contains(accountType);
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/custom_form_template_test.dart`
Expected: PASS (all tests).

- [ ] **Step 5: Commit**

```bash
git add lib/models/custom_form_template.dart test/custom_form_template_test.dart
git commit -m "Add CustomFormTemplate model + validation (Form Builder SP2.1)"
```

---

## Task 3: Data layer (Supabase reads/writes)

**Files:**
- Create: `lib/utils/custom_form_data.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/utils/custom_form_data.dart`:

```dart
// Supabase data access for custom form templates. Mirrors the query/cast
// pattern used elsewhere (admin_appointments_logbook_screen.dart).

import '../config/supabase_client.dart';
import '../models/custom_form_template.dart';

/// Lowercase slug + short suffix → a stable, unique-ish form_type code.
/// e.g. slugifyCode('Daily Safety Check', '1a2b') -> 'custom_daily_safety_check_1a2b'.
String slugifyCode(String name, String suffix) {
  final slug = name
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
      .replaceAll(RegExp(r'^_+|_+$'), '');
  final base = slug.isEmpty ? 'form' : slug;
  return 'custom_${base}_$suffix';
}

/// Loads templates. [includeArchived] = true returns inactive ones too
/// (admin builder view); false returns only active.
Future<List<CustomFormTemplate>> loadTemplates({bool includeArchived = false}) async {
  var query = supabase.from('custom_form_templates').select();
  if (!includeArchived) {
    query = query.eq('is_active', true);
  }
  final rows = await query.order('updated_at', ascending: false);
  return (rows as List)
      .cast<Map<String, dynamic>>()
      .map(CustomFormTemplate.fromMap)
      .toList();
}

/// Inserts a new template (when [id] is null) or updates an existing one.
/// Returns the saved row's id. On update, bumps version and sets updated_at.
Future<String> saveTemplate({
  String? id,
  required String code,
  required String name,
  String? description,
  String? category,
  required List<FormFieldDef> fields,
  required List<String> audience,
  required List<String> requiredSigners,
  required int version,
}) async {
  final user = supabase.auth.currentUser;
  final payload = <String, dynamic>{
    'code': code,
    'name': name,
    'description': description,
    'category': category,
    'fields': fields.map((f) => f.toMap()).toList(),
    'audience': audience,
    'required_signers': requiredSigners,
  };
  if (id == null) {
    payload['version'] = 1;
    if (user != null) payload['created_by'] = user.id;
    final inserted =
        await supabase.from('custom_form_templates').insert(payload).select('id').single();
    return inserted['id'] as String;
  } else {
    payload['version'] = version + 1;
    payload['updated_at'] = DateTime.now().toUtc().toIso8601String();
    await supabase.from('custom_form_templates').update(payload).eq('id', id);
    return id;
  }
}

Future<void> setTemplateActive(String id, bool active) async {
  await supabase.from('custom_form_templates').update({
    'is_active': active,
    'updated_at': DateTime.now().toUtc().toIso8601String(),
  }).eq('id', id);
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/utils/custom_form_data.dart`
Expected: No issues found. (If the analyzer objects to reassigning `query` due to builder return types, change the pattern to build the filter inline like `admin_appointments_logbook_screen.dart` does — declare `var query = supabase.from(...).select();` then conditionally `query = query.eq(...)`, which matches the existing working pattern there.)

- [ ] **Step 3: Commit**

```bash
git add lib/utils/custom_form_data.dart
git commit -m "Add custom form template data layer (Form Builder SP2.1)"
```

---

## Task 4: Field editor widget

**Files:**
- Create: `lib/widgets/form_builder/field_editor.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/form_builder/field_editor.dart`:

```dart
// Reorderable list of field definitions for the form builder. Each row edits
// one FormFieldDef in place; the parent owns the list and is notified via
// onChanged with a fresh list on every mutation.

import 'package:flutter/material.dart';

import '../../models/custom_form_template.dart';

class FieldEditorList extends StatelessWidget {
  const FieldEditorList({super.key, required this.fields, required this.onChanged});

  final List<FormFieldDef> fields;
  final ValueChanged<List<FormFieldDef>> onChanged;

  void _update(int i, FormFieldDef next) {
    final copy = [...fields];
    copy[i] = next;
    onChanged(copy);
  }

  void _remove(int i) {
    final copy = [...fields]..removeAt(i);
    onChanged(copy);
  }

  void _add(FormFieldType type) {
    final n = fields.length + 1;
    onChanged([
      ...fields,
      FormFieldDef(
        key: type == FormFieldType.section ? 'section_$n' : 'field_$n',
        type: type,
        label: type == FormFieldType.section ? 'Section' : 'Field $n',
        required: false,
        options: type == FormFieldType.dropdown ? const [] : null,
        columns: type == FormFieldType.table ? const [] : null,
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ReorderableListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          buildDefaultDragHandles: true,
          itemCount: fields.length,
          onReorder: (oldI, newI) {
            final copy = [...fields];
            if (newI > oldI) newI -= 1;
            copy.insert(newI, copy.removeAt(oldI));
            onChanged(copy);
          },
          itemBuilder: (context, i) => _FieldEditorRow(
            key: ValueKey('field_$i'),
            field: fields[i],
            onChanged: (f) => _update(i, f),
            onRemove: () => _remove(i),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final t in FormFieldType.values)
              OutlinedButton.icon(
                icon: const Icon(Icons.add, size: 16),
                label: Text(_typeLabel(t)),
                onPressed: () => _add(t),
              ),
          ],
        ),
      ],
    );
  }
}

String _typeLabel(FormFieldType t) {
  switch (t) {
    case FormFieldType.text:
      return 'Text';
    case FormFieldType.multiline:
      return 'Paragraph';
    case FormFieldType.number:
      return 'Number';
    case FormFieldType.date:
      return 'Date';
    case FormFieldType.dropdown:
      return 'Dropdown';
    case FormFieldType.boolean:
      return 'Yes/No';
    case FormFieldType.signature:
      return 'Signature';
    case FormFieldType.section:
      return 'Section heading';
    case FormFieldType.table:
      return 'Table';
  }
}

class _FieldEditorRow extends StatelessWidget {
  const _FieldEditorRow({
    super.key,
    required this.field,
    required this.onChanged,
    required this.onRemove,
  });

  final FormFieldDef field;
  final ValueChanged<FormFieldDef> onChanged;
  final VoidCallback onRemove;

  FormFieldDef _copy({
    String? key,
    String? label,
    bool? required,
    List<String>? options,
    List<FormFieldColumn>? columns,
  }) =>
      FormFieldDef(
        key: key ?? field.key,
        type: field.type,
        label: label ?? field.label,
        required: required ?? field.required,
        help: field.help,
        options: options ?? field.options,
        columns: columns ?? field.columns,
      );

  @override
  Widget build(BuildContext context) {
    final isSection = field.type == FormFieldType.section;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Chip(label: Text(_typeLabel(field.type)), visualDensity: VisualDensity.compact),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  tooltip: 'Remove field',
                  onPressed: onRemove,
                ),
              ],
            ),
            TextFormField(
              initialValue: field.label,
              decoration: const InputDecoration(labelText: 'Label'),
              onChanged: (v) => onChanged(_copy(label: v)),
            ),
            if (!isSection) ...[
              const SizedBox(height: 8),
              TextFormField(
                initialValue: field.key,
                decoration: const InputDecoration(
                  labelText: 'Key (payload field name)',
                  helperText: 'lowercase, no spaces',
                ),
                onChanged: (v) => onChanged(_copy(key: v)),
              ),
              Row(
                children: [
                  Checkbox(
                    value: field.required,
                    onChanged: (v) => onChanged(_copy(required: v ?? false)),
                  ),
                  const Text('Required'),
                ],
              ),
            ],
            if (field.type == FormFieldType.dropdown)
              _OptionsEditor(
                options: field.options ?? const [],
                onChanged: (opts) => onChanged(_copy(options: opts)),
              ),
            if (field.type == FormFieldType.table)
              _ColumnsEditor(
                columns: field.columns ?? const [],
                onChanged: (cols) => onChanged(_copy(columns: cols)),
              ),
          ],
        ),
      ),
    );
  }
}

class _OptionsEditor extends StatelessWidget {
  const _OptionsEditor({required this.options, required this.onChanged});
  final List<String> options;
  final ValueChanged<List<String>> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        const Text('Options', style: TextStyle(fontWeight: FontWeight.w600)),
        for (var i = 0; i < options.length; i++)
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  initialValue: options[i],
                  decoration: const InputDecoration(isDense: true),
                  onChanged: (v) {
                    final copy = [...options];
                    copy[i] = v;
                    onChanged(copy);
                  },
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18),
                onPressed: () => onChanged([...options]..removeAt(i)),
              ),
            ],
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add option'),
            onPressed: () => onChanged([...options, '']),
          ),
        ),
      ],
    );
  }
}

class _ColumnsEditor extends StatelessWidget {
  const _ColumnsEditor({required this.columns, required this.onChanged});
  final List<FormFieldColumn> columns;
  final ValueChanged<List<FormFieldColumn>> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        const Text('Columns', style: TextStyle(fontWeight: FontWeight.w600)),
        for (var i = 0; i < columns.length; i++)
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  initialValue: columns[i].label,
                  decoration: const InputDecoration(isDense: true, labelText: 'Column label'),
                  onChanged: (v) {
                    final copy = [...columns];
                    copy[i] = FormFieldColumn(
                      key: v.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_'),
                      label: v,
                      type: columns[i].type,
                    );
                    onChanged(copy);
                  },
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18),
                onPressed: () => onChanged([...columns]..removeAt(i)),
              ),
            ],
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add column'),
            onPressed: () =>
                onChanged([...columns, const FormFieldColumn(key: '', label: '', type: 'text')]),
          ),
        ),
      ],
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/widgets/form_builder/field_editor.dart`
Expected: No issues found.

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/form_builder/field_editor.dart
git commit -m "Add form builder field editor widget (Form Builder SP2.1)"
```

---

## Task 5: Form Builder screen

**Files:**
- Create: `lib/screens/form_builder_screen.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/screens/form_builder_screen.dart`:

```dart
// Admin/super-admin screen to list, create, edit, archive, and restore custom
// form templates. Filling them lives in CustomFormsScreen (SP2.1b).

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../constants/account_types.dart';
import '../models/custom_form_template.dart';
import '../providers/auth_provider.dart';
import '../utils/custom_form_data.dart';
import '../utils/role_access.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/form_builder/field_editor.dart';
import '../widgets/page_body.dart';

class FormBuilderScreen extends StatefulWidget {
  const FormBuilderScreen({super.key});

  @override
  State<FormBuilderScreen> createState() => _FormBuilderScreenState();
}

class _FormBuilderScreenState extends State<FormBuilderScreen> {
  bool _loading = true;
  String? _error;
  List<CustomFormTemplate> _templates = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final list = await loadTemplates(includeArchived: true);
      if (!mounted) return;
      setState(() {
        _templates = list;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  Future<void> _openEditor([CustomFormTemplate? existing]) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => _TemplateEditorScreen(existing: existing)),
    );
    if (saved == true) _load();
  }

  Future<void> _toggleActive(CustomFormTemplate t) async {
    await setTemplateActive(t.id, !t.isActive);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;

    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Form Builder'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Form Builder is available to Admin and Super Admin accounts only.',
                textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant)),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Form Builder'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(onPressed: _loading ? null : _load, icon: const Icon(Icons.refresh)),
          ...commonAppBarActions(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('New form'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(16), child: Text(_error!, style: TextStyle(color: scheme.error))))
                : PageBody.list(
                    padding: const EdgeInsets.all(16),
                    child: _templates.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.only(top: 64),
                            child: Text('No custom forms yet. Tap “New form” to build one.',
                                textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant)),
                          )
                        : ListView.separated(
                            shrinkWrap: true,
                            itemCount: _templates.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (_, i) {
                              final t = _templates[i];
                              return Card(
                                child: ListTile(
                                  title: Text(t.name),
                                  subtitle: Text(
                                    '${t.fields.where((f) => f.type != FormFieldType.section).length} fields'
                                    '${t.category != null && t.category!.isNotEmpty ? ' • ${t.category}' : ''}'
                                    '${t.isActive ? '' : ' • archived'}',
                                  ),
                                  onTap: () => _openEditor(t),
                                  trailing: PopupMenuButton<String>(
                                    onSelected: (v) {
                                      if (v == 'edit') _openEditor(t);
                                      if (v == 'toggle') _toggleActive(t);
                                    },
                                    itemBuilder: (_) => [
                                      const PopupMenuItem(value: 'edit', child: Text('Edit')),
                                      PopupMenuItem(value: 'toggle', child: Text(t.isActive ? 'Archive' : 'Restore')),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
      ),
    );
  }
}

class _TemplateEditorScreen extends StatefulWidget {
  const _TemplateEditorScreen({this.existing});
  final CustomFormTemplate? existing;

  @override
  State<_TemplateEditorScreen> createState() => _TemplateEditorScreenState();
}

class _TemplateEditorScreenState extends State<_TemplateEditorScreen> {
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _category;
  late List<FormFieldDef> _fields;
  late List<String> _audience;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _description = TextEditingController(text: e?.description ?? '');
    _category = TextEditingController(text: e?.category ?? '');
    _fields = e == null ? [] : [...e.fields];
    _audience = e == null ? [] : [...e.audience];
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _category.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final errors = validateTemplate(name: _name.text, fields: _fields);
    if (errors.isNotEmpty) {
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Fix these first'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [for (final e in errors) Text('• $e')],
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      final e = widget.existing;
      final code = e?.code ??
          slugifyCode(_name.text, DateTime.now().microsecondsSinceEpoch.toRadixString(36));
      await saveTemplate(
        id: e?.id,
        code: code,
        name: _name.text.trim(),
        description: _description.text.trim().isEmpty ? null : _description.text.trim(),
        category: _category.text.trim().isEmpty ? null : _category.text.trim(),
        fields: _fields,
        audience: _audience,
        requiredSigners: e?.requiredSigners ?? const [],
        version: e?.version ?? 1,
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (err) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'New form' : 'Edit form'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Save'),
          ),
        ],
      ),
      body: SafeArea(
        child: PageBody.form(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              TextField(controller: _name, decoration: const InputDecoration(labelText: 'Form name')),
              const SizedBox(height: 12),
              TextField(controller: _description, decoration: const InputDecoration(labelText: 'Description (optional)')),
              const SizedBox(height: 12),
              TextField(controller: _category, decoration: const InputDecoration(labelText: 'Category (optional)')),
              const SizedBox(height: 16),
              const Text('Who can fill this form', style: TextStyle(fontWeight: FontWeight.w600)),
              const Text('Leave all unchecked = everyone', style: TextStyle(fontSize: 12)),
              Wrap(
                spacing: 8,
                children: [
                  for (final at in kUserAccountTypes)
                    FilterChip(
                      label: Text(at),
                      selected: _audience.contains(at),
                      onSelected: (sel) => setState(() {
                        if (sel) {
                          _audience = [..._audience, at];
                        } else {
                          _audience = _audience.where((a) => a != at).toList();
                        }
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              const Text('Fields', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 8),
              FieldEditorList(
                fields: _fields,
                onChanged: (f) => setState(() => _fields = f),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/screens/form_builder_screen.dart`
Expected: No issues found. (If `PageBody.form`/`PageBody.list` don't accept a `padding` argument in your tree, they do — see `lib/widgets/page_body.dart` factories which take `padding`.)

- [ ] **Step 3: Commit**

```bash
git add lib/screens/form_builder_screen.dart
git commit -m "Add Form Builder screen (list + create/edit/archive) — SP2.1"
```

---

## Task 6: Wire the route

**Files:**
- Modify: `lib/routing/router.dart`

- [ ] **Step 1: Add the import**

In `lib/routing/router.dart` imports, add (alphabetically near the other screen imports):

```dart
import '../screens/form_builder_screen.dart';
```

- [ ] **Step 2: Add the real route and remove the placeholder entry**

(a) Add a real `GoRoute` for `/form-builder` next to the other top-level routes (e.g. after the `/settings` route):

```dart
        GoRoute(
          path: '/form-builder',
          builder: (_, __) => const FormBuilderScreen(),
        ),
```

(b) In the `_placeholders()` method, delete the `'/form-builder'` entry from the `adminStubs` map (leave the other 8 admin stubs intact). This prevents a duplicate-route registration.

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/routing/router.dart`
Expected: No issues found.

- [ ] **Step 4: Commit**

```bash
git add lib/routing/router.dart
git commit -m "Route /form-builder to the real Form Builder screen — SP2.1"
```

---

## Task 7: Full verification

- [ ] **Step 1: Analyze + test**

Run: `flutter analyze` → Expected: No issues found.
Run: `flutter test` → Expected: all pass (incl. `custom_form_template_test.dart`).

- [ ] **Step 2: Build**

Run: `flutter build windows --release` → Expected: builds.

- [ ] **Step 3: Manual run (controller must have applied the migration first)**

Run: `flutter run -d windows`, sign in as Admin:
- Sidebar/Quick-Action "Form Builder" / "Design Form" opens the builder.
- "New form": add one of every field type (text, paragraph, number, date, dropdown with 2 options, yes/no, signature, section heading, table with 2 columns), set name + an audience (e.g. Shift Boss), Save.
- Validation: try saving with an empty name / a dropdown with no options → the "Fix these first" dialog lists the problems.
- The new form appears in the list with its field count; Archive then Restore via the row menu works after a refresh.
- Sign in as a NON-admin → `/form-builder` shows the access-required message.

- [ ] **Step 4: Commit any tidy-ups**

```bash
git add -A && git commit -m "Verify Form Builder authoring (SP2.1a)"
```

---

## Self-Review notes (for the implementer)

- **Migration is applied by the controller**, not the implementer. Implementer tasks only need the Dart to compile + unit tests to pass; the live table is needed only for the manual run (Task 7 Step 3).
- **Supabase filter-builder typing:** if reassigning `query` trips the analyzer in `custom_form_data.dart`, copy the exact pattern from `admin_appointments_logbook_screen.dart` (`var query = supabase.from(...).select(); if (...) query = query.eq(...);`).
- **No new dependencies, no "Claude"/AI strings, no `public.todos` writes.**
- `required_signers` is stored but unused here — that is intentional (SP2.3 enforces it). Do not wire it into any workflow in this plan.
