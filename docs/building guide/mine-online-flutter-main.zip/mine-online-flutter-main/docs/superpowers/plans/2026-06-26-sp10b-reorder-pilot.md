# SP10b — Field Reorder Pilot Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let an admin drag-reorder the top identity/timing block of Early Shift
Record; the on-screen fill form honors the saved order (PDF untouched, empty
overlay = identical).

**Architecture:** Reuse `FormOverlay.order`. A pure `applyFieldOrder` computes the
effective order. A `kReorderableBlocks` catalog names the pilot block's fields
(single source of truth for screen + editor). The pilot screen renders that block
from an id-keyed builder map in effective order; the overlay editor gains a
`ReorderableListView` writing `overlay.order`.

**Tech Stack:** Flutter (`ReorderableListView` is core), `supabase_flutter`.

## Global Constraints

- No new dependencies. No "Claude"/AI naming. No migration (overlay + `order`
  already exist).
- **PDF generators untouched.** Reorder affects on-screen fill only.
- **Empty `order` → byte-identical** to today (primary safety property).
- Only the bounded top block is reorderable; everything below the divider is
  unchanged.
- `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- `dart format` touched files before each commit. Stage explicit paths only.

---

### Task 1: `applyFieldOrder` (pure, TDD)

**Files:**
- Modify: `lib/models/form_overlay.dart`
- Test: `test/form_overlay_test.dart`

**Interfaces:**
- Produces: `List<String> applyFieldOrder(List<String> natural, List<String> order)`.

- [ ] **Step 1: Write the failing test**

```dart
// test/form_overlay_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/form_overlay.dart';

void main() {
  group('applyFieldOrder', () {
    const natural = ['a', 'b', 'c', 'd'];

    test('empty order keeps natural order', () {
      expect(applyFieldOrder(natural, const []), natural);
    });
    test('full permutation is honored', () {
      expect(applyFieldOrder(natural, ['d', 'c', 'b', 'a']),
          ['d', 'c', 'b', 'a']);
    });
    test('partial order: named first, rest appended in natural order', () {
      expect(applyFieldOrder(natural, ['c', 'a']), ['c', 'a', 'b', 'd']);
    });
    test('unknown ids in order are ignored', () {
      expect(applyFieldOrder(natural, ['x', 'b', 'z']),
          ['b', 'a', 'c', 'd']);
    });
    test('idempotent', () {
      final once = applyFieldOrder(natural, ['c', 'a']);
      expect(applyFieldOrder(natural, once), once);
    });
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/form_overlay_test.dart`
Expected: FAIL — `applyFieldOrder` not defined.

- [ ] **Step 3: Implement**

Append to `lib/models/form_overlay.dart`:

```dart
/// The effective field order: ids named in [order] first (in that order,
/// ignoring any not in [natural]), then any [natural] ids not named in [order],
/// in natural order. Empty [order] → [natural] unchanged.
List<String> applyFieldOrder(List<String> natural, List<String> order) {
  final naturalSet = natural.toSet();
  final used = <String>{};
  final out = <String>[];
  for (final id in order) {
    if (naturalSet.contains(id) && used.add(id)) out.add(id);
  }
  for (final id in natural) {
    if (used.add(id)) out.add(id);
  }
  return out;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/form_overlay_test.dart`
Expected: PASS (5 tests).

- [ ] **Step 5: Commit**

```bash
dart format lib/models/form_overlay.dart test/form_overlay_test.dart
git add lib/models/form_overlay.dart test/form_overlay_test.dart
git commit -m "SP10b: applyFieldOrder (pure, TDD)"
```

---

### Task 2: Reorderable-block catalog + editor reorder UI

**Files:**
- Modify: `lib/utils/form_field_catalog.dart`
- Modify: `lib/screens/form_builder_screen.dart` (`_OverlayEditorScreenState`)

**Interfaces:**
- Consumes: `applyFieldOrder` (Task 1), `FormFieldRef`.
- Produces: `kReorderableBlocks` map; editor saves `order` into the overlay.

- [ ] **Step 1: Add the reorderable-block catalog**

Append to `lib/utils/form_field_catalog.dart`:

```dart
/// Per-form ordered list of fields that the overlay editor can drag-reorder
/// (a bounded, contiguous, no-conditional block). Single source of truth for
/// the screen's natural id order and the editor's reorder list. SP10b pilot.
const Map<String, List<FormFieldRef>> kReorderableBlocks = {
  'early_shift_record': [
    FormFieldRef('section', 'Section'),
    FormFieldRef('strike', 'Strike'),
    FormFieldRef('date', 'Date'),
    FormFieldRef('wentUndergroundAt', 'Went underground at (am/pm)'),
    FormFieldRef('arrivedAtWaitingPlace', 'Arrived at waiting place at (am/pm)'),
    FormFieldRef('minerArrivedAt', 'Miner arrived at (am/pm)'),
    FormFieldRef('minerCoyNo', 'Miner Coy No.'),
    FormFieldRef('waitingPlaceLocation', 'Waiting place location'),
  ],
};

/// The reorderable block for [formType] (empty when none).
List<FormFieldRef> reorderableBlockFor(String formType) =>
    kReorderableBlocks[formType] ?? const [];
```

- [ ] **Step 2: Add `_order` state to the editor + include it in load/build**

In `_OverlayEditorScreenState` (form_builder_screen.dart), add a field beside
`_overrides`:

```dart
  List<String> _order = const [];
```

In `_load`, after setting `_overrides`, also set the order (normalized to the
block's effective order):

```dart
      _overrides = overlay == null ? {} : {...overlay.fieldOverrides};
      final blockIds = reorderableBlockFor(
        widget.meta.formType,
      ).map((r) => r.id).toList();
      _order = blockIds.isEmpty
          ? const []
          : applyFieldOrder(blockIds, overlay?.order ?? const []);
```

In `_build()`, include the order (omit when the form has no block, so unrelated
forms keep an empty order):

```dart
  FormOverlay _build() => FormOverlay(
    addedFields: _addedFields,
    addedPages: _pages,
    fieldOverrides: _overrides,
    order: reorderableBlockFor(widget.meta.formType).isEmpty ? const [] : _order,
  );
```

> Requires importing `applyFieldOrder` (same `form_overlay.dart` already imported
> via `models/form_overlay.dart`) and `reorderableBlockFor`
> (`utils/form_field_catalog.dart`, already imported). Add imports only if
> `flutter analyze` reports them missing.

- [ ] **Step 3: Render a "Reorder fields" section in the editor body**

In the editor `build`'s `ListView` children, insert this block right after the
"Existing fields" section (after the
`for (final ref in catalogFor(widget.meta.formType)) _existingFieldRow(ref),`
closing `],`, before the `const SizedBox(height: 16)` that precedes "Added
fields"):

```dart
                    if (reorderableBlockFor(widget.meta.formType)
                        .isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Reorder fields',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: () => setState(
                              () => _order = reorderableBlockFor(
                                widget.meta.formType,
                              ).map((r) => r.id).toList(),
                            ),
                            child: const Text('Reset order'),
                          ),
                        ],
                      ),
                      const Text(
                        'Drag to change the order these fields appear in when '
                        'filling the form. The PDF layout is unchanged.',
                        style: TextStyle(fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      ReorderableListView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        buildDefaultDragHandles: true,
                        onReorder: (oldIndex, newIndex) {
                          setState(() {
                            final ids = [..._order];
                            if (newIndex > oldIndex) newIndex -= 1;
                            final moved = ids.removeAt(oldIndex);
                            ids.insert(newIndex, moved);
                            _order = ids;
                          });
                        },
                        children: [
                          for (final id in _order)
                            ListTile(
                              key: ValueKey('reorder_$id'),
                              dense: true,
                              leading: const Icon(Icons.drag_handle),
                              title: Text(
                                reorderableBlockFor(widget.meta.formType)
                                    .firstWhere((r) => r.id == id)
                                    .label,
                              ),
                            ),
                        ],
                      ),
                    ],
```

- [ ] **Step 4: Verify analysis**

Run: `flutter analyze lib/utils/form_field_catalog.dart lib/screens/form_builder_screen.dart`
Expected: No issues.

- [ ] **Step 5: Commit**

```bash
dart format lib/utils/form_field_catalog.dart lib/screens/form_builder_screen.dart
git add lib/utils/form_field_catalog.dart lib/screens/form_builder_screen.dart
git commit -m "SP10b: kReorderableBlocks + overlay editor drag-reorder UI"
```

---

### Task 3: Pilot screen — render the top block in effective order

**Files:**
- Modify: `lib/screens/early_shift_record_form_screen.dart`

**Interfaces:**
- Consumes: `applyFieldOrder` (Task 1), `reorderableBlockFor` (Task 2),
  `loadFormOverlay` (existing).

- [ ] **Step 1: Load the overlay order alongside overrides**

Find the override load (`final o = await loadFieldOverrides('early_shift_record'); ... setState(() => _overrides = o);`, ~line 54). Replace with loading the full
overlay:

```dart
    final overlay = await loadFormOverlay('early_shift_record');
    if (!mounted) return;
    setState(() {
      _overrides = overlay?.fieldOverrides ?? const {};
      _order = overlay?.order ?? const [];
    });
```

Add a state field beside `_overrides`:

```dart
  List<String> _order = const [];
```

Add the imports at the top if missing:
`import '../models/form_overlay.dart';` (for `applyFieldOrder`),
`import '../utils/form_field_catalog.dart';` (for `reorderableBlockFor`),
and ensure `loadFormOverlay` is available (it's in
`../utils/form_overlay_data.dart`, likely already imported for
`loadFieldOverrides`). Adjust only what `flutter analyze` flags.

- [ ] **Step 2: Replace the hardcoded top block with an ordered render**

Replace the contiguous top block in `build` — from the first field
`_tf('Section', ...)` through `_tf('Waiting place location', ...)` and its
trailing `const SizedBox(height: 16), const Divider(), const SizedBox(height: 8),`
(screen lines ~234–289) — with a builder map + ordered loop. The widgets are
byte-identical to today; only their iteration order changes:

```dart
                          ...(() {
                            final blockBuilders = <String, Widget>{
                              'section': _tf(
                                'Section',
                                _data.section,
                                (v) => _data.section = v,
                                id: 'section',
                              ),
                              'strike': _tf(
                                'Strike',
                                _data.strike,
                                (v) => _data.strike = v,
                                id: 'strike',
                              ),
                              'date': DatePickerField(
                                value: _data.date,
                                onChanged: (v) =>
                                    setState(() => _data.date = v),
                              ),
                              'wentUndergroundAt': _tf(
                                'Went underground at (am/pm)',
                                _data.wentUndergroundAt,
                                (v) => _data.wentUndergroundAt = v,
                                id: 'wentUndergroundAt',
                              ),
                              'arrivedAtWaitingPlace': _tf(
                                'Arrived at waiting place at (am/pm)',
                                _data.arrivedAtWaitingPlace,
                                (v) => _data.arrivedAtWaitingPlace = v,
                                id: 'arrivedAtWaitingPlace',
                              ),
                              'minerArrivedAt': _tf(
                                'Miner arrived at (am/pm)',
                                _data.minerArrivedAt,
                                (v) => _data.minerArrivedAt = v,
                                id: 'minerArrivedAt',
                              ),
                              'minerCoyNo': _tf(
                                'Miner Coy No.',
                                _data.minerCoyNo,
                                (v) => _data.minerCoyNo = v,
                                id: 'minerCoyNo',
                              ),
                              'waitingPlaceLocation': _tf(
                                'Waiting place location',
                                _data.waitingPlaceLocation,
                                (v) => _data.waitingPlaceLocation = v,
                                id: 'waitingPlaceLocation',
                              ),
                            };
                            final blockIds = reorderableBlockFor(
                              'early_shift_record',
                            ).map((r) => r.id).toList();
                            final ordered = applyFieldOrder(blockIds, _order);
                            return <Widget>[
                              for (var i = 0; i < ordered.length; i++) ...[
                                blockBuilders[ordered[i]]!,
                                if (i < ordered.length - 1)
                                  const SizedBox(height: 12),
                              ],
                            ];
                          })()),
                          const SizedBox(height: 16),
                          const Divider(),
                          const SizedBox(height: 8),
```

> The block ends exactly where the original did: `SizedBox(16)` → `Divider()` →
> `SizedBox(8)`, then the unchanged yes/no section continues. Confirm against the
> current source that no other widget sat between `waitingPlaceLocation` and the
> `Divider()` (it was `SizedBox(16)` only).

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/screens/early_shift_record_form_screen.dart`
Expected: No issues.

- [ ] **Step 4: Sanity-read the diff**

Run: `git diff lib/screens/early_shift_record_form_screen.dart`
Confirm: only the top block changed; the eight builder widgets match the
originals 1:1; the `id:` params are unchanged; nothing below the `Divider()` was
touched.

- [ ] **Step 5: Commit**

```bash
dart format lib/screens/early_shift_record_form_screen.dart
git add lib/screens/early_shift_record_form_screen.dart
git commit -m "SP10b: Early Shift Record renders top block in overlay order"
```

---

### Task 4: Full verification

**Files:** none.

- [ ] **Step 1: Analyze**

Run: `flutter analyze`
Expected: No issues found.

- [ ] **Step 2: Test suite**

Run: `flutter test`
Expected: all pass (prior suite + 5 `applyFieldOrder` tests).

- [ ] **Step 3: Windows release build**

Run: `flutter build windows --release`
Expected: `Built build\windows\x64\runner\Release\mine_online.exe`.

- [ ] **Step 4: Commit (only if verification required edits)**

```bash
git add <explicit paths>
git commit -m "SP10b: fixes from verification"
```

---

## Self-Review

**Spec coverage:**
- `applyFieldOrder` pure + tested → Task 1. ✓
- `kReorderableBlocks` catalog → Task 2. ✓
- Editor `_order` load/build + `ReorderableListView` + Reset → Task 2. ✓
- Pilot screen renders top block in effective order, empty order = identical
  → Task 3. ✓
- PDF untouched / below-divider unchanged → Tasks 3 (scope) + no PDF file edited. ✓
- analyze + test + build → Task 4. ✓

**Placeholder scan:** No TBD/TODO; full code shown for every code step. The two
"adjust imports only if analyze flags" notes are real (the files may already
import the targets) — not placeholders.

**Type consistency:** `applyFieldOrder(List<String>, List<String>) →
List<String>`, `reorderableBlockFor(String) → List<FormFieldRef>`,
`kReorderableBlocks`, `FormOverlay.order`, `_order` are used consistently across
Tasks 1–3. The eight block ids match between `kReorderableBlocks` (Task 2) and the
screen builder map (Task 3).
```
