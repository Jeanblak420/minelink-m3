# SP4.6 — Builder 1: legacy-style form designer Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans. Steps use checkbox (`- [ ]`) syntax.

**Goal:** A faithful legacy-style form designer (3-column manager+designer, legacy field types, data-linked "dynamic dropdowns", version/archive) authoring into the existing `custom_form_templates` / `appointment_templates` storage.

**Architecture:** Extend SP2's `FormFieldDef` with optional legacy layout/config (`section`/`row`/`rowOrder`/`tabIndex`/`dropdownSource`) + a `dynamicDropdown` type. A new `form_dropdown_sources` allowlist table backs data-linked dropdowns (read via `supabase.from(...)`, never raw SQL). A new designer screen provides the legacy UX over existing storage; the dynamic renderer + custom-form PDF gain dynamic-dropdown + section/row support. Additive — existing templates/forms render exactly as today.

**Tech Stack:** Flutter Material 3, `provider`, `go_router`, `supabase_flutter`, `pdf`. No new dependencies.

## Global Constraints

- No new dependencies. No "Claude"/AI naming. Windows + Android. `dart format` touched files.
- Additive: existing SP2 custom forms (no section/row) render linearly as today; nothing in SP1–SP4.5 changes.
- Supabase: migration file in `supabase/migrations/` AND applied via Management API (PAT `claude-supabase-pat-hhrnkzznpadrmyverhyb`, ref `hhrnkzznpadrmyverhyb`). RLS: read-active to authenticated, admin-write via `public.is_admin(auth.uid())`.
- Dynamic-dropdown reads are restricted to the seeded `form_dropdown_sources` allowlist (no arbitrary table access).
- Verify: `flutter analyze` clean, `flutter test` green, `flutter build windows --release`.
- Reuse: `custom_form_data.dart` (general), `appointment_template_data.dart` (appointment) for template CRUD; `isAdminProfile`, `PageBody`, `commonAppBarActions`.

## File Structure

- Create `supabase/migrations/20260622160000_form_dropdown_sources.sql`.
- Modify `lib/models/custom_form_template.dart` — extend `FormFieldDef` + `FormFieldType.dynamicDropdown` + `groupFieldsBySection` helper.
- Create `lib/utils/form_dropdown_data.dart` — sources + options.
- Modify `lib/widgets/form_builder/dynamic_form_renderer.dart` — `dynamicDropdown` case + section/row grouping.
- Modify `lib/pdf/generate_custom_form_pdf.dart` — `dynamicDropdown` prints its value (default kv branch already covers it; confirm).
- Create `lib/screens/form_designer_screen.dart` — manager + 3-column designer.
- Modify `lib/routing/router.dart` + `lib/widgets/admin/admin_sidebar.dart`.
- Create `test/form_designer_test.dart`.

---

### Task 1: Migration — form_dropdown_sources (+ seed)

**Files:** Create `supabase/migrations/20260622160000_form_dropdown_sources.sql`

- [ ] **Step 1: Write**

```sql
-- SP4.6: allowlist catalog of data-linked dropdown sources for the legacy-style
-- form designer. Reads are restricted to these seeded, admin-safe tables.
create table if not exists public.form_dropdown_sources (
  id            uuid primary key default gen_random_uuid(),
  key           text not null unique,
  table_name    text not null,
  value_column  text not null,
  label_column  text not null,
  display_name  text not null,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
alter table public.form_dropdown_sources enable row level security;
create policy "Read active dropdown sources"
  on public.form_dropdown_sources for select to authenticated
  using (is_active = true or public.is_admin(auth.uid()));
create policy "Admins insert dropdown sources"
  on public.form_dropdown_sources for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admins update dropdown sources"
  on public.form_dropdown_sources for update to authenticated
  using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

insert into public.form_dropdown_sources (key, table_name, value_column, label_column, display_name)
values
  ('shafts',            'shafts',            'id', 'name',      'Shafts'),
  ('sections',          'sections',          'id', 'name',      'Sections'),
  ('areas',             'areas',             'id', 'name',      'Areas'),
  ('gangs',             'gangs',             'id', 'name',      'Gangs'),
  ('shifts',            'shifts',            'id', 'name',      'Shifts'),
  ('appointment_roles', 'appointment_roles', 'id', 'label',     'Appointment Roles'),
  ('profiles',          'profiles',          'id', 'full_name', 'People')
on conflict do nothing;
```

- [ ] **Step 2: Apply via Management API.** Expected 200/201.
- [ ] **Step 3: Verify** — `select count(*) from public.form_dropdown_sources;` → 7; table + policies exist.
- [ ] **Step 4: Commit** `git add supabase/migrations/20260622160000_form_dropdown_sources.sql && git commit -m "SP4.6: form_dropdown_sources allowlist + seed"`

### Task 2: Model extension + tests (TDD)

**Files:** Modify `lib/models/custom_form_template.dart`; Test `test/form_designer_test.dart`

**Interfaces:**
- `FormFieldType` gains `dynamicDropdown`.
- `FormFieldDef` gains `final String? section, row; final int? rowOrder, tabIndex; final String? dropdownSource;` (all optional) — round-tripped in `toMap`/`fromMap`.
- `List<List<FormFieldDef>> groupFieldsBySection(...)` is NOT needed; instead `List<({String section, List<({String row, List<FormFieldDef> fields})> rows})> groupForPreview(List<FormFieldDef> fields)` sorts section→row→rowOrder. Keep it simpler: `List<MapEntry<String, List<FormFieldDef>>> groupBySection(List<FormFieldDef> fields)` returning sections (in first-seen order) each with its fields sorted by (row, rowOrder, tabIndex). Fields with no section group under '' (rendered linearly).

- [ ] **Step 1: Failing tests**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';

void main() {
  test('FormFieldDef round-trips legacy layout props + dynamicDropdown', () {
    const f = FormFieldDef(
      key: 'shaft', type: FormFieldType.dynamicDropdown, label: 'Shaft',
      required: true, section: 'Location', row: 'r1', rowOrder: 2, tabIndex: 3,
      dropdownSource: 'shafts',
    );
    final back = FormFieldDef.fromMap(f.toMap());
    expect(back.type, FormFieldType.dynamicDropdown);
    expect(back.section, 'Location');
    expect(back.row, 'r1');
    expect(back.rowOrder, 2);
    expect(back.tabIndex, 3);
    expect(back.dropdownSource, 'shafts');
  });

  test('legacy props absent → null (existing templates unaffected)', () {
    final back = FormFieldDef.fromMap(const {
      'key': 'a', 'type': 'text', 'label': 'A', 'required': false,
    });
    expect(back.section, isNull);
    expect(back.rowOrder, isNull);
    expect(back.dropdownSource, isNull);
  });

  test('groupBySection: no section → single empty group; sorted by row/order', () {
    const a = FormFieldDef(key: 'a', type: FormFieldType.text, label: 'A', required: false);
    const b = FormFieldDef(key: 'b', type: FormFieldType.text, label: 'B', required: false,
      section: 'S', row: 'r1', rowOrder: 2);
    const c = FormFieldDef(key: 'c', type: FormFieldType.text, label: 'C', required: false,
      section: 'S', row: 'r1', rowOrder: 1);
    final g = groupBySection([a, b, c]);
    expect(g.first.key, ''); // a -> empty section first (first-seen)
    final s = g.firstWhere((e) => e.key == 'S');
    expect(s.value.map((f) => f.key).toList(), ['c', 'b']); // rowOrder 1 before 2
  });
}
```

- [ ] **Step 2: Run → fail.** `flutter test test/form_designer_test.dart`
- [ ] **Step 3: Implement** — add `dynamicDropdown` to the enum; add the 5 optional fields to `FormFieldDef` (constructor, fields, `toMap` with `if (x != null)`, `fromMap` reading them); add:

```dart
/// Groups fields by section (first-seen order; no section → '' group first),
/// each section's fields sorted by (row, rowOrder, tabIndex). Used by the
/// legacy designer's live preview and grouped fill rendering.
List<MapEntry<String, List<FormFieldDef>>> groupBySection(List<FormFieldDef> fields) {
  final order = <String>[];
  final map = <String, List<FormFieldDef>>{};
  for (final f in fields) {
    final s = f.section ?? '';
    if (!map.containsKey(s)) { order.add(s); map[s] = []; }
    map[s]!.add(f);
  }
  int cmp(FormFieldDef a, FormFieldDef b) {
    final r = (a.row ?? '').compareTo(b.row ?? '');
    if (r != 0) return r;
    final o = (a.rowOrder ?? 0).compareTo(b.rowOrder ?? 0);
    if (o != 0) return o;
    return (a.tabIndex ?? 0).compareTo(b.tabIndex ?? 0);
  }
  return [for (final s in order) MapEntry(s, [...map[s]!]..sort(cmp))];
}
```

Note: `_typeFromString` already falls back to text for unknown — fine. Keep `validateTemplate` as-is (a `dynamicDropdown` with no source is checked in the screen, Task 6).

- [ ] **Step 4: Run → pass.**
- [ ] **Step 5: Format + commit** `SP4.6: extend FormFieldDef (legacy layout + dynamicDropdown) + groupBySection`

### Task 3: Dropdown data layer

**Files:** Create `lib/utils/form_dropdown_data.dart`

**Interfaces:**
- `class DropdownSource { final String key, tableName, valueColumn, labelColumn, displayName; fromMap; }`
- `Future<List<DropdownSource>> loadDropdownSources()` — active sources.
- `Future<List<({String value, String label})>> loadDropdownOptions(DropdownSource s)` — `supabase.from(s.tableName).select('${s.valueColumn},${s.labelColumn}')` mapped; tolerant of nulls. Cap 500, order by label.

- [ ] **Step 1: Implement** (mirror `org_data.dart`). The select uses the source's own columns; since sources are the seeded allowlist, this is safe.
- [ ] **Step 2: Analyze** `flutter analyze lib/utils/form_dropdown_data.dart` → clean.
- [ ] **Step 3: Format + commit** `SP4.6: dropdown sources + options data layer`

### Task 4: Renderer — dynamicDropdown + section grouping

**Files:** Modify `lib/widgets/form_builder/dynamic_form_renderer.dart`

- [ ] **Step 1:** Add a `dynamicDropdown` case: a stateful sub-widget that loads `loadDropdownOptions` for the field's `dropdownSource` and renders a `DropdownButtonFormField`; on select, `onChanged(f.key, value)` AND stash the resolved label in the payload under `'${f.key}__label'` (so the PDF can show the label). While loading → disabled dropdown.
- [ ] **Step 2:** Add an optional `bool grouped` param (default false). When true, render via `groupBySection(fields)` — a bold section header per non-empty section, then its fields. Default false keeps today's linear rendering for all existing callers.
- [ ] **Step 3: Analyze** → clean. **Format + commit** `SP4.6: renderer supports dynamic dropdowns + section grouping`

### Task 5: PDF — dynamic dropdown value

**Files:** Modify `lib/pdf/generate_custom_form_pdf.dart`

- [ ] **Step 1:** In the field switch, `dynamicDropdown` falls through the `default` kv branch already (it prints `payload[f.key]`). Add: if a `'${f.key}__label'` exists in the payload, print that instead of the raw value. (One-line lookup before `_kvRow`.) Confirm `customPdfValueString` handles it.
- [ ] **Step 2: Analyze** → clean. **Format + commit** `SP4.6: custom-form PDF prints dynamic-dropdown labels`

### Task 6: Legacy designer screen

**Files:** Create `lib/screens/form_designer_screen.dart`

**Interfaces:** Consumes model (Task 2), `loadDropdownSources` (Task 3), `DynamicFormRenderer(grouped: true)` (Task 4), `loadTemplates`/`saveTemplate` (custom_form_data), `loadAppointmentTemplates`/`saveAppointmentTemplate` (appointment_template_data), `isAdminProfile`, `PageBody`, `commonAppBarActions`.

- [ ] **Step 1: Build** `FormDesignerScreen` (admin-gated):
  - **Manager view:** a segmented control General vs Appointment; "Create New Form"; search; Active/Archived sections; rows with Edit / Archive / Restore (calls `setTemplateActive` or `setAppointmentTemplateActive`).
  - **Designer view** `_DesignerScreen(kind, existing)`: a responsive three-pane (Row on wide ≥1000px; stacked tabs on narrow):
    - **Left "Form Fields":** `ListView` of fields (label or "(no label)" + type); selected highlighted; "+ Add Field" appends a default `text` field and selects it.
    - **Center "Live Preview":** `DynamicFormRenderer(fields: _fields, grouped: true, values: _previewValues, onChanged: ...)` in an `AbsorbPointer` (preview only).
    - **Right "Edit Field":** for the selected field — Label, Name (key), Section, Row, Row Order (number), Tab Index (number), Field Type dropdown (all `FormFieldType` values incl. Dynamic Dropdown), Required switch; for `dropdown` → comma-separated Static Options; for `dynamicDropdown` → a Dynamic Source dropdown (from `loadDropdownSources`); "Remove Field".
    - **Metadata header:** Form Name, Version, Language; + Role (appointment, from `loadAppointmentRoles`) or Category + Description (general).
    - **Save:** validate (name present; ≥1 input field; every `dynamicDropdown` has a source; unique keys); on pass, `saveTemplate(...)` (general) or `saveAppointmentTemplate(...)` (appointment) with the `_fields`; pop.
- [ ] **Step 2: Analyze** → clean. **Format + commit** `SP4.6: legacy-style 3-column form designer screen`

### Task 7: Routes + sidebar

**Files:** Modify `lib/routing/router.dart`, `lib/widgets/admin/admin_sidebar.dart`

- [ ] **Step 1:** Import + `GoRoute(path: '/form-designer', builder: (_, __) => const FormDesignerScreen())`.
- [ ] **Step 2:** Add `SidebarLeaf('Form Designer', Icons.design_services_outlined, '/form-designer', accent: 8)` in the Templates section.
- [ ] **Step 3: Analyze** → clean. **Format + commit** `SP4.6: route + sidebar for form designer`

### Task 8: Verify + merge

- [ ] `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- [ ] Migration verified via Management API.
- [ ] Update `HANDOFF.md` + memory (SP4.6 done; both builders shipped). Merge `sp4_6-legacy-form-designer` → `main`; push; delete branch.

## Self-Review

**Spec coverage:** 3-column designer (Task 6) ✓; field types incl. dynamicDropdown (Tasks 2,4,6) ✓; field config section/row/rowOrder/tabIndex/required/options/source (Tasks 2,6) ✓; live preview grouped (Tasks 2,4,6) ✓; dynamic dropdowns + allowlist (Tasks 1,3,4) ✓; version/archive (Task 6 reuse) ✓; authoring into existing storage (Task 6) ✓; fill/PDF support (Tasks 4,5) ✓; routes/sidebar (Task 7) ✓; additive/no-change-to-existing (Tasks 2,4 defaults) ✓.

**Placeholder scan:** Migration timestamp is the real filename. No TBDs; model/migration/data carry full code; screen task enumerates exact panels/controls.

**Type consistency:** `FormFieldDef` new props (`section/row/rowOrder/tabIndex/dropdownSource`) + `FormFieldType.dynamicDropdown` used consistently across Tasks 2/4/5/6. `groupBySection` signature matches Task 2 ↔ Task 4/6 usage. `DropdownSource` + `loadDropdownOptions` signatures match Task 3 ↔ Task 4. `DynamicFormRenderer(grouped:)` added in Task 4, used in Task 6. Payload label convention `'${key}__label'` written in Task 4, read in Task 5.
