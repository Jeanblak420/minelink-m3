# Form Builder SP2.1b — Renderer + Fill — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let the targeted audience open a published custom form, fill it (all field types), and submit it into `form_submissions` — completing the SP2.1 capture loop. Built on SP2.1a (model, data layer, builder).

**Architecture:** A pure payload module (required-check + payload build, unit-tested) + a stateless `DynamicFormRenderer` (parent owns the values map) + a `CustomFormsScreen` (audience-filtered list → fill screen → `persistFormSubmission`). Entry points added to the admin sidebar and the non-admin dashboards.

**Tech Stack:** Flutter (Material 3), `supabase_flutter`, `go_router`, `provider`. Reuses `SignatureCanvasField`, `DatePickerField`, `CustomFormTemplate`/`FormFieldDef`/`audienceAllows`, `loadTemplates`, `persistFormSubmission`, `PageBody`, `commonAppBarActions`, `DashboardCardData`.

**Spec:** `docs/superpowers/specs/2026-06-16-form-builder-sp2-1-design.md` (SP2.1 portion). Depends on SP2.1a (already merged into this branch).

---

## File Structure

New:
- `lib/utils/dynamic_form_payload.dart` — `missingRequiredFields()`, `buildSubmissionPayload()`.
- `lib/widgets/form_builder/dynamic_form_renderer.dart` — `DynamicFormRenderer`.
- `lib/screens/custom_forms_screen.dart` — `CustomFormsScreen` (list) + `_FillFormScreen`.
- `test/dynamic_form_payload_test.dart`.

Modified:
- `lib/routing/router.dart` — add `/custom-forms`.
- `lib/widgets/admin/admin_sidebar.dart` — add a "Custom Forms" leaf.
- `lib/screens/home_screen.dart` — add a Custom Forms card to `_defaultCards`.
- `lib/widgets/dashboards/shift_boss_dashboard.dart` and `lib/widgets/dashboards/mine_leadership_dashboard.dart` — add a Custom Forms card.

---

## Task 1: Payload helpers (TDD)

**Files:**
- Create: `lib/utils/dynamic_form_payload.dart`
- Test: `test/dynamic_form_payload_test.dart`

- [ ] **Step 1: Write the failing test**

Create `test/dynamic_form_payload_test.dart`:

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/custom_form_template.dart';
import 'package:mine_online/utils/dynamic_form_payload.dart';

void main() {
  final fields = <FormFieldDef>[
    FormFieldDef(key: 'sec', type: FormFieldType.section, label: 'Section', required: false),
    FormFieldDef(key: 'name', type: FormFieldType.text, label: 'Name', required: true),
    FormFieldDef(key: 'note', type: FormFieldType.multiline, label: 'Note', required: false),
    FormFieldDef(key: 'ok', type: FormFieldType.boolean, label: 'OK?', required: true),
    FormFieldDef(key: 'rows', type: FormFieldType.table, label: 'Rows', required: false,
        columns: [FormFieldColumn(key: 'c', label: 'C', type: 'text')]),
  ];

  test('missingRequiredFields: required empty text is missing; section/optional ignored', () {
    final missing = missingRequiredFields(fields, {'ok': false});
    expect(missing, ['Name']); // name required+empty; ok=false is a real answer
  });

  test('missingRequiredFields: filled required passes', () {
    final missing = missingRequiredFields(fields, {'name': 'Al', 'ok': true});
    expect(missing, isEmpty);
  });

  test('missingRequiredFields: whitespace-only string is missing', () {
    final missing = missingRequiredFields(fields, {'name': '   ', 'ok': true});
    expect(missing, ['Name']);
  });

  test('buildSubmissionPayload omits section, defaults types', () {
    final payload = buildSubmissionPayload(fields, {'name': 'Al', 'ok': true});
    expect(payload.containsKey('sec'), isFalse);
    expect(payload['name'], 'Al');
    expect(payload['note'], ''); // missing text -> ''
    expect(payload['ok'], true);
    expect(payload['rows'], isA<List>());
    expect(payload['rows'], isEmpty);
  });

  test('buildSubmissionPayload keeps table rows', () {
    final rows = [
      {'c': 'one'},
      {'c': 'two'},
    ];
    final payload = buildSubmissionPayload(fields, {'name': 'Al', 'ok': false, 'rows': rows});
    expect(payload['rows'], rows);
    expect(payload['ok'], false);
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/dynamic_form_payload_test.dart`
Expected: FAIL — URI `dynamic_form_payload.dart` doesn't exist.

- [ ] **Step 3: Write the implementation**

Create `lib/utils/dynamic_form_payload.dart`:

```dart
// Pure helpers for filling/submitting custom forms. No Flutter/Supabase deps.

import '../models/custom_form_template.dart';

bool _isEmpty(dynamic v) {
  if (v == null) return true;
  if (v is String) return v.trim().isEmpty;
  if (v is List) return v.isEmpty;
  return false; // numbers, bools (incl. false) count as answered
}

/// Labels of required, non-section fields that have no value in [values].
List<String> missingRequiredFields(
    List<FormFieldDef> fields, Map<String, dynamic> values) {
  final missing = <String>[];
  for (final f in fields) {
    if (f.type == FormFieldType.section || !f.required) continue;
    if (_isEmpty(values[f.key])) missing.add(f.label);
  }
  return missing;
}

/// Builds the `form_submissions.payload` map: one entry per non-section field,
/// keyed by field key, with type-appropriate defaults for blanks.
Map<String, dynamic> buildSubmissionPayload(
    List<FormFieldDef> fields, Map<String, dynamic> values) {
  final out = <String, dynamic>{};
  for (final f in fields) {
    if (f.type == FormFieldType.section) continue;
    final v = values[f.key];
    switch (f.type) {
      case FormFieldType.boolean:
        out[f.key] = v == true;
        break;
      case FormFieldType.table:
        out[f.key] = (v is List) ? v : <Map<String, dynamic>>[];
        break;
      default:
        out[f.key] = v ?? '';
    }
  }
  return out;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/dynamic_form_payload_test.dart`
Expected: PASS (5 tests).

- [ ] **Step 5: Commit**

```bash
git add lib/utils/dynamic_form_payload.dart test/dynamic_form_payload_test.dart
git commit -m "Add dynamic form payload helpers (Form Builder SP2.1b)"
```

---

## Task 2: Dynamic form renderer

**Files:**
- Create: `lib/widgets/form_builder/dynamic_form_renderer.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/widgets/form_builder/dynamic_form_renderer.dart`:

```dart
// Renders a fillable form from a CustomFormTemplate. Stateless: the parent owns
// the values map and is notified of edits via onChanged(key, value). The table
// field edits the list value via onChanged with a fresh list.

import 'package:flutter/material.dart';

import '../../models/custom_form_template.dart';
import '../date_picker_field.dart';
import '../signature_canvas.dart';

class DynamicFormRenderer extends StatelessWidget {
  const DynamicFormRenderer({
    super.key,
    required this.fields,
    required this.values,
    required this.onChanged,
  });

  final List<FormFieldDef> fields;
  final Map<String, dynamic> values;
  final void Function(String key, dynamic value) onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final f in fields) ...[
          _field(context, f),
          const SizedBox(height: 16),
        ],
      ],
    );
  }

  Widget _field(BuildContext context, FormFieldDef f) {
    final label = f.required ? '${f.label} *' : f.label;
    switch (f.type) {
      case FormFieldType.section:
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(f.label,
              style: Theme.of(context).textTheme.titleMedium),
        );
      case FormFieldType.text:
        return TextFormField(
          initialValue: (values[f.key] as String?) ?? '',
          decoration: InputDecoration(labelText: label, helperText: f.help),
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.multiline:
        return TextFormField(
          initialValue: (values[f.key] as String?) ?? '',
          minLines: 3,
          maxLines: 6,
          decoration: InputDecoration(labelText: label, helperText: f.help),
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.number:
        return TextFormField(
          initialValue: values[f.key] == null ? '' : '${values[f.key]}',
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: label, helperText: f.help),
          onChanged: (v) =>
              onChanged(f.key, v.trim().isEmpty ? null : num.tryParse(v.trim())),
        );
      case FormFieldType.date:
        return DatePickerField(
          label: label,
          value: (values[f.key] as String?) ?? '',
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.dropdown:
        final options = f.options ?? const [];
        final current = values[f.key] as String?;
        return DropdownButtonFormField<String>(
          initialValue: (current != null && options.contains(current)) ? current : null,
          decoration: InputDecoration(labelText: label, helperText: f.help),
          items: [
            for (final o in options) DropdownMenuItem(value: o, child: Text(o)),
          ],
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.boolean:
        return SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(label),
          subtitle: f.help == null ? null : Text(f.help!),
          value: values[f.key] == true,
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.signature:
        return SignatureCanvasField(
          label: label,
          value: (values[f.key] as String?) ?? '',
          onChanged: (v) => onChanged(f.key, v),
        );
      case FormFieldType.table:
        return _TableField(field: f, value: values[f.key], onChanged: (rows) => onChanged(f.key, rows));
    }
  }
}

class _TableField extends StatelessWidget {
  const _TableField({required this.field, required this.value, required this.onChanged});

  final FormFieldDef field;
  final dynamic value;
  final ValueChanged<List<Map<String, dynamic>>> onChanged;

  List<Map<String, dynamic>> get _rows =>
      (value is List)
          ? (value as List).map((e) => (e as Map).cast<String, dynamic>()).toList()
          : <Map<String, dynamic>>[];

  @override
  Widget build(BuildContext context) {
    final cols = field.columns ?? const [];
    final rows = _rows;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(field.required ? '${field.label} *' : field.label,
            style: Theme.of(context).textTheme.titleSmall),
        for (var r = 0; r < rows.length; r++)
          Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                children: [
                  for (final c in cols)
                    TextFormField(
                      initialValue: (rows[r][c.key] as String?) ?? '',
                      keyboardType: c.type == 'number'
                          ? const TextInputType.numberWithOptions(decimal: true)
                          : TextInputType.text,
                      decoration: InputDecoration(labelText: c.label, isDense: true),
                      onChanged: (v) {
                        final next = [for (final row in rows) {...row}];
                        next[r][c.key] = v;
                        onChanged(next);
                      },
                    ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      icon: const Icon(Icons.close, size: 16),
                      label: const Text('Remove row'),
                      onPressed: () {
                        final next = [for (final row in rows) {...row}]..removeAt(r);
                        onChanged(next);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add row'),
            onPressed: () {
              final next = [for (final row in rows) {...row}, <String, dynamic>{}];
              onChanged(next);
            },
          ),
        ),
      ],
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/widgets/form_builder/dynamic_form_renderer.dart`
Expected: No issues found. (If `DropdownButtonFormField` in your Flutter version uses `value:` instead of `initialValue:`, switch that one argument name; everything else is stable API.)

- [ ] **Step 3: Commit**

```bash
git add lib/widgets/form_builder/dynamic_form_renderer.dart
git commit -m "Add dynamic form renderer (Form Builder SP2.1b)"
```

---

## Task 3: Custom Forms list + fill screen

**Files:**
- Create: `lib/screens/custom_forms_screen.dart`

- [ ] **Step 1: Write the implementation**

Create `lib/screens/custom_forms_screen.dart`:

```dart
// Audience-facing list of fillable custom forms + the fill screen. Submits into
// form_submissions via persistFormSubmission (non-chain; SP2.1b).

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/custom_form_template.dart';
import '../providers/auth_provider.dart';
import '../utils/custom_form_data.dart';
import '../utils/dynamic_form_payload.dart';
import '../utils/signature_workflow.dart';
import '../widgets/app_bar_actions.dart';
import '../widgets/form_builder/dynamic_form_renderer.dart';
import '../widgets/page_body.dart';

class CustomFormsScreen extends StatefulWidget {
  const CustomFormsScreen({super.key});

  @override
  State<CustomFormsScreen> createState() => _CustomFormsScreenState();
}

class _CustomFormsScreenState extends State<CustomFormsScreen> {
  bool _loading = true;
  String? _error;
  List<CustomFormTemplate> _forms = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final accountType = context.read<AuthProvider>().profile?.userAccountType;
      final all = await loadTemplates(includeArchived: false);
      final visible =
          all.where((t) => audienceAllows(t.audience, accountType)).toList();
      if (!mounted) return;
      setState(() {
        _forms = visible;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom Forms'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(onPressed: _loading ? null : _load, icon: const Icon(Icons.refresh)),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(16), child: Text(_error!, style: TextStyle(color: scheme.error))))
                : PageBody.list(
                    padding: const EdgeInsets.all(16),
                    child: _forms.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.only(top: 64),
                            child: Text('No forms are available for you to fill right now.',
                                textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant)),
                          )
                        : ListView.separated(
                            shrinkWrap: true,
                            itemCount: _forms.length,
                            separatorBuilder: (_, _) => const SizedBox(height: 8),
                            itemBuilder: (_, i) {
                              final t = _forms[i];
                              return Card(
                                child: ListTile(
                                  leading: const Icon(Icons.assignment_outlined),
                                  title: Text(t.name),
                                  subtitle: (t.description != null && t.description!.isNotEmpty)
                                      ? Text(t.description!)
                                      : (t.category != null && t.category!.isNotEmpty ? Text(t.category!) : null),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () => Navigator.of(context).push(
                                    MaterialPageRoute(builder: (_) => _FillFormScreen(template: t)),
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
      ),
    );
  }
}

class _FillFormScreen extends StatefulWidget {
  const _FillFormScreen({required this.template});
  final CustomFormTemplate template;

  @override
  State<_FillFormScreen> createState() => _FillFormScreenState();
}

class _FillFormScreenState extends State<_FillFormScreen> {
  final Map<String, dynamic> _values = {};
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    // Seed defaults so booleans/tables have stable types.
    for (final f in widget.template.fields) {
      if (f.type == FormFieldType.boolean) _values[f.key] = false;
      if (f.type == FormFieldType.table) _values[f.key] = <Map<String, dynamic>>[];
    }
  }

  Future<void> _submit() async {
    final missing = missingRequiredFields(widget.template.fields, _values);
    if (missing.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please complete: ${missing.join(', ')}')),
      );
      return;
    }
    setState(() => _submitting = true);
    try {
      final payload = buildSubmissionPayload(widget.template.fields, _values);
      final id = await persistFormSubmission(
          widget.template.code, widget.template.name, payload);
      if (!mounted) return;
      if (id == null) {
        setState(() => _submitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not submit. Please try again.')),
        );
        return;
      }
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${widget.template.name} submitted.')),
      );
    } catch (err) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Submit failed: $err')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.template.name),
        actions: [
          TextButton(
            onPressed: _submitting ? null : _submit,
            child: _submitting
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Submit'),
          ),
        ],
      ),
      body: SafeArea(
        child: PageBody.form(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              DynamicFormRenderer(
                fields: widget.template.fields,
                values: _values,
                onChanged: (key, value) => setState(() => _values[key] = value),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

- [ ] **Step 2: Verify analysis**

Run: `flutter analyze lib/screens/custom_forms_screen.dart`
Expected: No issues found. (If `separatorBuilder: (_, _)` triggers a lint in your SDK, use `(_, __)` — match whatever the rest of the repo uses; both have appeared.)

- [ ] **Step 3: Commit**

```bash
git add lib/screens/custom_forms_screen.dart
git commit -m "Add Custom Forms list + fill screen (Form Builder SP2.1b)"
```

---

## Task 4: Wire route + entry points

**Files:**
- Modify: `lib/routing/router.dart`, `lib/widgets/admin/admin_sidebar.dart`, `lib/screens/home_screen.dart`, `lib/widgets/dashboards/shift_boss_dashboard.dart`, `lib/widgets/dashboards/mine_leadership_dashboard.dart`

- [ ] **Step 1: Add the route**

In `lib/routing/router.dart`: add the import `import '../screens/custom_forms_screen.dart';` near the other screen imports, and add a route next to `/form-builder`:

```dart
        GoRoute(
          path: '/custom-forms',
          builder: (_, __) => const CustomFormsScreen(),
        ),
```

- [ ] **Step 2: Add the admin sidebar leaf**

In `lib/widgets/admin/admin_sidebar.dart`, inside the `_navItems` list, add a top-level leaf right after the `SidebarLeaf('Report History', ...)` entry:

```dart
  SidebarLeaf('Custom Forms', Icons.list_alt_outlined, '/custom-forms'),
```

- [ ] **Step 3: Add a Custom Forms card to the default fallback cards**

In `lib/screens/home_screen.dart`, in the `_defaultCards` list (inside `_defaultCards({required bool isAdmin})`), add as the first entry:

```dart
      const DashboardCardData(
        route: '/custom-forms',
        icon: Icons.list_alt_outlined,
        title: 'Custom Forms',
        description: 'Fill out forms published for your role.',
      ),
```

- [ ] **Step 4: Add a Custom Forms card to the Shift Boss and Mine Leadership dashboards**

Open `lib/widgets/dashboards/shift_boss_dashboard.dart` and `lib/widgets/dashboards/mine_leadership_dashboard.dart`. Each has a `const _cards = <DashboardCardData>[ ... ];` list. Add this entry as the first element of each list:

```dart
  DashboardCardData(
      route: '/custom-forms',
      icon: Icons.list_alt_outlined,
      title: 'Custom Forms',
      description: 'Fill out forms published for your role.'),
```

(Match the existing punctuation/formatting in each file — if the file's entries use trailing commas and no `const` per-item because the list is already `const`, follow that style so it stays a single `const` list.)

- [ ] **Step 5: Verify analysis**

Run: `flutter analyze lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart lib/screens/home_screen.dart lib/widgets/dashboards/shift_boss_dashboard.dart lib/widgets/dashboards/mine_leadership_dashboard.dart`
Expected: No issues found.

- [ ] **Step 6: Commit**

```bash
git add lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart lib/screens/home_screen.dart lib/widgets/dashboards/shift_boss_dashboard.dart lib/widgets/dashboards/mine_leadership_dashboard.dart
git commit -m "Wire /custom-forms into sidebar + dashboards (Form Builder SP2.1b)"
```

---

## Task 5: Full verification

- [ ] **Step 1: Analyze + test**

Run: `flutter analyze` → Expected: No issues found.
Run: `flutter test` → Expected: all pass (incl. `dynamic_form_payload_test.dart`).

- [ ] **Step 2: Build**

Run: `flutter build windows --release` → Expected: builds.

- [ ] **Step 3: Manual run (end-to-end with SP2.1a)**

`flutter run -d windows`:
- As Admin: build a form with several field types, set audience = "Shift Boss", save (SP2.1a).
- Still as Admin: open "Custom Forms" from the sidebar — the form shows; fill every field; Submit; confirm the success SnackBar.
- Open `/current-logbook` or completed history — the submission appears (form_type = the template code).
- Required validation: leave a required field blank → Submit shows "Please complete: …".
- As a Shift Boss account: "Custom Forms" card appears on the dashboard; the targeted form is listed and fillable.
- As an account NOT in the audience: the form is not listed.

- [ ] **Step 4: Commit any tidy-ups**

```bash
git add -A && git commit -m "Verify Form Builder fill loop (SP2.1b)"
```

---

## Self-Review notes (for the implementer)

- The renderer is **stateless**; the fill screen owns `_values` and rebuilds on `onChanged`. Do not add controllers inside the renderer (the input widgets manage their own).
- `persistFormSubmission` lives in `lib/utils/signature_workflow.dart` and returns `Future<String?>` (null = not signed in / failed). Handle the null path (shown in `_submit`).
- Dashboard card lists are `const` — keep them const; add the new `DashboardCardData` entry without breaking constness.
- No new dependencies, no "Claude"/AI strings, no `public.todos` writes.
- `required_signers` remains unused (SP2.3). Non-chain submission only.
