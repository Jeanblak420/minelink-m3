# SP9a — User Lifecycle + Audit Trail Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let Super Admins disable/re-enable accounts and change roles with an
audit trail, and give Admins a read-only Audit Log screen — built on the existing
live `public.audit_log` table.

**Architecture:** Reuse the populated `audit_log` table. A migration adds
`profiles.disabled`, tightens the audit read policy to admins, and adds a
role-change audit trigger. The shared `admin-create-user` edge function gains an
additive `set_disabled` action (ban + profile flag + audit). Flutter adds a pure
audit-entry describer, a disable action, an AuthProvider lockout, and two screen
touches (User Management + a new Audit Log screen).

**Tech Stack:** Flutter, `supabase_flutter`, `go_router`, `provider`; Supabase
Postgres + Deno edge function; Management API + Supabase CLI for apply/deploy.

## Global Constraints

- No new Flutter dependencies.
- No "Claude"/AI naming anywhere in code, comments, data, or migration text.
- Existing forms/PDFs stay byte-identical — additive work only.
- Lifecycle WRITES (disable/enable, role change) are **Super-Admin**-gated;
  Audit-Log VIEWING is **Admin**-gated. Mirror the DB policies in the UI.
- Migrations: write to `supabase/migrations/` AND apply via the Management API
  (PAT in Windows Credential Manager `claude-supabase-pat-hhrnkzznpadrmyverhyb`,
  project ref `hhrnkzznpadrmyverhyb`). Edge function deploy via Supabase CLL.
- `flutter analyze` clean; `flutter test` green; then `flutter build windows --release`.
- `dart format` touched files before each commit.
- Git: stage explicit paths only — NEVER `git add -A`/`.`/`git reset --hard`.

### Management-API SQL helper (used by Tasks 1 & 8)

The PAT is a generic credential; read it then POST SQL to the query endpoint.
Run this PowerShell shape (substitute the `$Q` SQL per step):

```powershell
$sig = @'
using System; using System.Runtime.InteropServices;
public class Cred {
  [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
  static extern bool CredRead(string t, int ty, int f, out IntPtr c);
  [DllImport("advapi32.dll")] static extern void CredFree(IntPtr c);
  [StructLayout(LayoutKind.Sequential)] struct CREDENTIAL { public int Flags; public int Type;
    public IntPtr TargetName; public IntPtr Comment; public long LastWritten; public int CredentialBlobSize;
    public IntPtr CredentialBlob; public int Persist; public int AttributeCount; public IntPtr Attributes;
    public IntPtr TargetAlias; public IntPtr UserName; }
  public static string Get(string t){ IntPtr p; if(!CredRead(t,1,0,out p)) return null;
    var c=(CREDENTIAL)Marshal.PtrToStructure(p,typeof(CREDENTIAL));
    string s=Marshal.PtrToStringUni(c.CredentialBlob,c.CredentialBlobSize/2); CredFree(p); return s; }
}
'@
Add-Type -TypeDefinition $sig -Language CSharp
$pat=[Cred]::Get('claude-supabase-pat-hhrnkzznpadrmyverhyb'); $ref='hhrnkzznpadrmyverhyb'
$h=@{Authorization="Bearer $pat";'Content-Type'='application/json'}
$body=@{query=$Q}|ConvertTo-Json
Invoke-RestMethod -Method Post -Uri "https://api.supabase.com/v1/projects/$ref/database/query" -Headers $h -Body $body | ConvertTo-Json -Compress
```

---

### Task 1: Database migration (profiles.disabled + audit read policy + role trigger)

**Files:**
- Create: `supabase/migrations/20260625120000_sp9_user_lifecycle_audit.sql`

**Interfaces:**
- Produces: `profiles.disabled boolean`, `profiles.disabled_at timestamptz`;
  audit_log SELECT restricted to `public.is_admin(auth.uid())`; trigger
  `trg_profiles_audit_role` writing `audit_log` rows with `action='user.role_change'`.

- [ ] **Step 1: Write the migration file**

```sql
-- supabase/migrations/20260625120000_sp9_user_lifecycle_audit.sql
-- SP9a: user lifecycle + audit trail.
-- 1) profiles disable flags; 2) tighten audit_log read to admins;
-- 3) audit role changes made via the profile-edit path.

alter table public.profiles
  add column if not exists disabled boolean not null default false,
  add column if not exists disabled_at timestamptz;

-- audit_log was world-readable ("Allow public read audit_log" USING true).
-- Restrict to admins. Writes remain service-role / SECURITY DEFINER only.
drop policy if exists "Allow public read audit_log" on public.audit_log;
drop policy if exists "Admins read audit_log" on public.audit_log;
create policy "Admins read audit_log" on public.audit_log
  for select to authenticated
  using (public.is_admin(auth.uid()));

create or replace function public.fn_audit_profile_role_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.user_account_type is distinct from old.user_account_type then
    insert into public.audit_log
      (user_id, action, entity_type, entity_id, old_values, new_values)
    values
      (auth.uid(), 'user.role_change', 'user', new.id,
       jsonb_build_object('user_account_type', old.user_account_type),
       jsonb_build_object('user_account_type', new.user_account_type));
  end if;
  return new;
end;
$$;

drop trigger if exists trg_profiles_audit_role on public.profiles;
create trigger trg_profiles_audit_role
  after update on public.profiles
  for each row execute function public.fn_audit_profile_role_change();
```

- [ ] **Step 2: Apply it via the Management API**

Run the Management-API helper with `$Q` set to the entire migration file body
(the `alter`, the two `drop policy`, the `create policy`, the
`create or replace function`, and the `drop`/`create trigger`). Submit as one
query string.
Expected: a JSON array result (no error object).

- [ ] **Step 3: Verify the schema landed**

Run the helper with:
```sql
select
  (select count(*) from information_schema.columns
     where table_schema='public' and table_name='profiles'
       and column_name in ('disabled','disabled_at')) as profile_cols,
  (select policyname from pg_policies
     where schemaname='public' and tablename='audit_log' and cmd='SELECT') as read_policy,
  (select count(*) from pg_trigger
     where tgname='trg_profiles_audit_role') as role_trigger;
```
Expected: `profile_cols = 2`, `read_policy = "Admins read audit_log"`,
`role_trigger = 1`.

- [ ] **Step 4: Commit**

```bash
git add supabase/migrations/20260625120000_sp9_user_lifecycle_audit.sql
git commit -m "SP9a: migration — profiles.disabled, admin-only audit read, role-change trigger"
```

---

### Task 2: Edge function `set_disabled` action

**Files:**
- Modify: `supabase/functions/admin-create-user/index.ts` (add an action branch
  before the final `Unknown action` return, ~line 257)

**Interfaces:**
- Produces: POST `{action:'set_disabled', userId, disabled:boolean}` → bans/unbans
  the auth user, sets `profiles.disabled`/`disabled_at`, writes `audit_log`
  (`user.disable`/`user.enable`). Returns `{success:true}` or `{error}`.

- [ ] **Step 1: Add the action branch**

Insert immediately before `return new Response(JSON.stringify({ error: "Unknown action" })...`:

```ts
    if (action === "set_disabled") {
      if (!userId || typeof body.disabled !== "boolean") {
        return new Response(
          JSON.stringify({ error: "userId and disabled (boolean) required" }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }

      const disabled = body.disabled as boolean;

      const { error: banErr } = await supabaseAdmin.auth.admin.updateUserById(
        userId,
        { ban_duration: disabled ? "876000h" : "none" },
      );
      if (banErr) {
        return new Response(JSON.stringify({ error: banErr.message }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      await supabaseAdmin
        .from("profiles")
        .update({
          disabled,
          disabled_at: disabled ? new Date().toISOString() : null,
        })
        .eq("id", userId);

      await writeAuditLog(supabaseAdmin, callerUser.id, {
        action: disabled ? "user.disable" : "user.enable",
        entity_id: userId,
      });

      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
```

- [ ] **Step 2: Deploy via the Supabase CLI**

Read the PAT (Task-1 helper, first 3 lines through `$pat=...`), then:
```powershell
$env:SUPABASE_ACCESS_TOKEN = $pat
npx supabase functions deploy admin-create-user --project-ref hhrnkzznpadrmyverhyb
```
Expected: `Deployed Functions on project hhrnkzznpadrmyverhyb: admin-create-user`.
If the CLI requires `--use-api` (no Docker) it will say so — re-run with
`npx supabase functions deploy admin-create-user --project-ref hhrnkzznpadrmyverhyb --use-api`.

- [ ] **Step 3: Commit**

```bash
git add supabase/functions/admin-create-user/index.ts
git commit -m "SP9a: edge function set_disabled action (ban + profile flag + audit)"
```

---

### Task 3: Audit data layer — `describeAuditEntry` (pure, TDD) + loaders

**Files:**
- Create: `lib/utils/audit_data.dart`
- Test: `test/audit_test.dart`

**Interfaces:**
- Consumes: `supabase` from `lib/config/supabase_client.dart`.
- Produces:
  - `class AuditEntry { id; actorId; action; entityType; entityId; oldValues; newValues; createdAt; ... AuditEntry.fromMap(Map) }`
  - `String describeAuditEntry(AuditEntry e, {String? actorName, String? targetName})`
  - `Future<List<AuditEntry>> loadAuditLog({int limit = 200, String? action})`
  - `Future<Map<String,String>> loadAuditNames(List<AuditEntry> entries)`

- [ ] **Step 1: Write the failing test**

```dart
// test/audit_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/audit_data.dart';

AuditEntry e(
  String action, {
  Map<String, dynamic>? oldV,
  Map<String, dynamic>? newV,
}) => AuditEntry.fromMap({
  'id': '00000000-0000-0000-0000-000000000001',
  'user_id': 'actor-1',
  'action': action,
  'entity_type': 'user',
  'entity_id': 'target-1',
  'old_values': oldV,
  'new_values': newV,
  'created_at': '2026-06-25T10:00:00Z',
});

void main() {
  group('describeAuditEntry', () {
    const names = {'actor-1': 'Jean Burger', 'target-1': 'Bob Miner'};
    String d(AuditEntry entry) => describeAuditEntry(
      entry,
      actorName: names[entry.actorId],
      targetName: names[entry.entityId],
    );

    test('create', () {
      expect(d(e('user.create')),
          'Jean Burger created an account for Bob Miner');
    });
    test('delete', () {
      expect(d(e('user.delete')), "Jean Burger deleted Bob Miner's account");
    });
    test('password', () {
      expect(d(e('user.update_password')),
          "Jean Burger reset Bob Miner's password");
    });
    test('disable', () {
      expect(d(e('user.disable')), "Jean Burger disabled Bob Miner's account");
    });
    test('enable', () {
      expect(d(e('user.enable')),
          "Jean Burger re-enabled Bob Miner's account");
    });
    test('role_change reads old/new', () {
      final entry = e(
        'user.role_change',
        oldV: {'user_account_type': 'Miner'},
        newV: {'user_account_type': 'Shift Boss'},
      );
      expect(d(entry),
          "Jean Burger changed Bob Miner's role from Miner to Shift Boss");
    });
    test('unknown action falls back', () {
      expect(d(e('widget.frobnicate')),
          'Jean Burger performed widget.frobnicate on user Bob Miner');
    });
    test('missing names degrade', () {
      final entry = e('user.disable');
      expect(describeAuditEntry(entry),
          "An administrator disabled a user's account");
    });
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/audit_test.dart`
Expected: FAIL — `audit_data.dart` / `AuditEntry` not defined.

- [ ] **Step 3: Write the implementation**

```dart
// lib/utils/audit_data.dart
// SP9a Audit trail — reads the existing public.audit_log. describeAuditEntry is
// pure and unit-tested; the loaders fetch rows + resolve actor/target names.

import '../config/supabase_client.dart';

class AuditEntry {
  const AuditEntry({
    required this.id,
    required this.actorId,
    required this.action,
    required this.entityType,
    required this.entityId,
    required this.oldValues,
    required this.newValues,
    required this.createdAt,
  });

  final String id;
  final String? actorId;
  final String action;
  final String? entityType;
  final String? entityId;
  final Map<String, dynamic>? oldValues;
  final Map<String, dynamic>? newValues;
  final DateTime? createdAt;

  factory AuditEntry.fromMap(Map<String, dynamic> m) {
    Map<String, dynamic>? asMap(dynamic v) =>
        v is Map ? v.cast<String, dynamic>() : null;
    DateTime? parse(dynamic v) =>
        v is String && v.isNotEmpty ? DateTime.tryParse(v) : null;
    return AuditEntry(
      id: m['id'] as String? ?? '',
      actorId: m['user_id'] as String?,
      action: m['action'] as String? ?? '',
      entityType: m['entity_type'] as String?,
      entityId: m['entity_id'] as String?,
      oldValues: asMap(m['old_values']),
      newValues: asMap(m['new_values']),
      createdAt: parse(m['created_at']),
    );
  }
}

/// Pure: a human sentence for an audit entry. Names degrade gracefully.
String describeAuditEntry(
  AuditEntry e, {
  String? actorName,
  String? targetName,
}) {
  final actor = (actorName == null || actorName.trim().isEmpty)
      ? 'An administrator'
      : actorName.trim();
  final target = (targetName == null || targetName.trim().isEmpty)
      ? 'a user'
      : targetName.trim();
  switch (e.action) {
    case 'user.create':
      return '$actor created an account for $target';
    case 'user.delete':
      return "$actor deleted $target's account";
    case 'user.update_password':
      return "$actor reset $target's password";
    case 'user.disable':
      return "$actor disabled $target's account";
    case 'user.enable':
      return "$actor re-enabled $target's account";
    case 'user.role_change':
      final from = e.oldValues?['user_account_type'] as String? ?? '—';
      final to = e.newValues?['user_account_type'] as String? ?? '—';
      return "$actor changed $target's role from $from to $to";
    default:
      final ent = e.entityType ?? 'record';
      return '$actor performed ${e.action} on $ent $target';
  }
}

Future<List<AuditEntry>> loadAuditLog({int limit = 200, String? action}) async {
  var query = supabase
      .from('audit_log')
      .select('id, user_id, action, entity_type, entity_id, '
          'old_values, new_values, created_at');
  if (action != null && action.isNotEmpty) {
    query = query.eq('action', action);
  }
  final rows = (await query.order('created_at', ascending: false).limit(limit))
      .cast<Map<String, dynamic>>();
  return rows.map(AuditEntry.fromMap).toList();
}

/// Resolves actor + target ids to display names in one profiles read.
Future<Map<String, String>> loadAuditNames(List<AuditEntry> entries) async {
  final ids = <String>{
    for (final e in entries) ...[
      if (e.actorId != null) e.actorId!,
      if (e.entityId != null) e.entityId!,
    ],
  }.toList();
  if (ids.isEmpty) return {};
  final rows = (await supabase
          .from('profiles')
          .select('id, full_name, email')
          .inFilter('id', ids))
      .cast<Map<String, dynamic>>();
  final out = <String, String>{};
  for (final r in rows) {
    final name = ((r['full_name'] as String?)?.trim().isNotEmpty == true)
        ? (r['full_name'] as String).trim()
        : (r['email'] as String? ?? '').trim();
    if (name.isNotEmpty) out[r['id'] as String] = name;
  }
  return out;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/audit_test.dart`
Expected: PASS (8 tests).

- [ ] **Step 5: Commit**

```bash
dart format lib/utils/audit_data.dart test/audit_test.dart
git add lib/utils/audit_data.dart test/audit_test.dart
git commit -m "SP9a: audit data layer — describeAuditEntry (TDD) + loaders"
```

---

### Task 4: Model + helpers (`disabled`, `isSuperAdminProfile`, `adminSetUserDisabled`)

**Files:**
- Modify: `lib/models/user_profile.dart`
- Modify: `lib/utils/role_access.dart`
- Modify: `lib/utils/admin_user.dart`

**Interfaces:**
- Produces: `UserProfile.disabled` (bool); `isSuperAdminProfile(UserProfile?)`;
  `adminSetUserDisabled({required String userId, required bool disabled})`.

- [ ] **Step 1: Add `disabled` to UserProfile**

In `lib/models/user_profile.dart`: add the field after `isSuperAdmin`
(line 13): `final bool disabled;`. Add to the constructor (after
`required this.isSuperAdmin,`): `this.disabled = false,`. Add to `fromMap`
(after the `isSuperAdmin:` line 76): `disabled: (map['disabled'] as bool?) ?? false,`.
Add to the `copyWith` map (after `'is_super_admin': isSuperAdmin,` line 109):
`'disabled': disabled,`.

- [ ] **Step 2: Add `isSuperAdminProfile`**

Append to `lib/utils/role_access.dart`:

```dart
bool isSuperAdminProfile(UserProfile? profile) {
  if (profile == null) return false;
  return profile.isSuperAdmin || profile.userAccountType == 'Super Admin';
}
```

- [ ] **Step 3: Add `adminSetUserDisabled`**

Append inside `lib/utils/admin_user.dart` (after `adminDeleteUser`, line 71):

```dart
/// Disable (ban) or re-enable a user. Server-side bans the auth user, flips
/// `profiles.disabled`, and writes an audit_log entry.
Future<AdminUserResult> adminSetUserDisabled({
  required String userId,
  required bool disabled,
}) =>
    _invoke({'action': 'set_disabled', 'userId': userId, 'disabled': disabled});
```

- [ ] **Step 4: Verify analysis**

Run: `flutter analyze lib/models/user_profile.dart lib/utils/role_access.dart lib/utils/admin_user.dart`
Expected: No issues.

- [ ] **Step 5: Commit**

```bash
dart format lib/models/user_profile.dart lib/utils/role_access.dart lib/utils/admin_user.dart
git add lib/models/user_profile.dart lib/utils/role_access.dart lib/utils/admin_user.dart
git commit -m "SP9a: UserProfile.disabled + isSuperAdminProfile + adminSetUserDisabled"
```

---

### Task 5: AuthProvider disable-lockout

**Files:**
- Modify: `lib/providers/auth_provider.dart`

**Interfaces:**
- Consumes: `UserProfile.disabled` (Task 4).
- Produces: `String? lockoutMessage` getter on AuthProvider; auto-`signOut()`
  when the active profile is `disabled`.

- [ ] **Step 1: Add the lockout field + helper**

Add a private field near the other state (e.g. beside `_error`):
`String? _lockoutMessage;` and a getter `String? get lockoutMessage => _lockoutMessage;`.

Add a helper method to the class:

```dart
/// If the freshly-loaded/updated profile is disabled, lock the session out.
/// Returns true if a lockout sign-out was triggered.
bool _enforceDisabled() {
  if (_user != null && _profile != null && _profile!.disabled) {
    _lockoutMessage =
        'Your account has been disabled. Contact an administrator.';
    // Fire-and-forget; the auth state listener will clear _user/_profile.
    supabase.auth.signOut();
    return true;
  }
  return false;
}
```

- [ ] **Step 2: Call it after profile load + on realtime update**

In `_fetchProfile`, after `_profile = data == null ? null : UserProfile.fromMap(data);`
(line 120), add: `_enforceDisabled();`.

In `_subscribeToProfile`'s update callback, after
`_profile = UserProfile.fromMap(payload.newRecord);` (line 143), add:
`_enforceDisabled();` (before `_safeNotify();`).

Clear the message on a fresh successful sign-in: in `signIn`, before the
return, set `_lockoutMessage = null;`. (Change the body to capture and return.)

```dart
Future<AuthResponse> signIn(String email, String password) async {
  _lockoutMessage = null;
  return supabase.auth.signInWithPassword(email: email, password: password);
}
```

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/providers/auth_provider.dart`
Expected: No issues.

- [ ] **Step 4: Commit**

```bash
dart format lib/providers/auth_provider.dart
git add lib/providers/auth_provider.dart
git commit -m "SP9a: AuthProvider locks out disabled accounts (immediate sign-out)"
```

---

### Task 6: Audit Log screen + route + sidebar

**Files:**
- Create: `lib/screens/setup/audit_log_screen.dart`
- Modify: `lib/routing/router.dart`
- Modify: `lib/widgets/admin/admin_sidebar.dart`

**Interfaces:**
- Consumes: `loadAuditLog`, `loadAuditNames`, `describeAuditEntry`, `AuditEntry`
  (Task 3); `isAdminProfile`, `AuthProvider`, `commonAppBarActions`, `PageBody`.
- Produces: `class AuditLogScreen extends StatefulWidget { const AuditLogScreen({super.key}); }`.

- [ ] **Step 1: Write the screen**

```dart
// lib/screens/setup/audit_log_screen.dart
// SP9a Audit Log — admin-gated read-only feed over public.audit_log, rendered
// as human sentences via describeAuditEntry. Action filter chips.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../utils/audit_data.dart';
import '../../utils/role_access.dart';
import '../../widgets/app_bar_actions.dart';
import '../../widgets/page_body.dart';

class AuditLogScreen extends StatefulWidget {
  const AuditLogScreen({super.key});

  @override
  State<AuditLogScreen> createState() => _AuditLogScreenState();
}

class _Filter {
  const _Filter(this.label, this.action);
  final String label;
  final String? action; // null = all
}

const _filters = [
  _Filter('All', null),
  _Filter('Role changes', 'user.role_change'),
  _Filter('Disabled', 'user.disable'),
  _Filter('Re-enabled', 'user.enable'),
  _Filter('Created', 'user.create'),
  _Filter('Deleted', 'user.delete'),
  _Filter('Passwords', 'user.update_password'),
];

class _AuditLogScreenState extends State<AuditLogScreen> {
  bool _loading = true;
  String? _error;
  List<AuditEntry> _entries = const [];
  Map<String, String> _names = const {};
  String? _action;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final entries = await loadAuditLog(action: _action);
      final names = await loadAuditNames(entries);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _names = names;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }

  static String _fmt(DateTime? d) {
    if (d == null) return '';
    final l = d.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${l.year}-${two(l.month)}-${two(l.day)} ${two(l.hour)}:${two(l.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final profile = context.watch<AuthProvider>().profile;
    if (!isAdminProfile(profile)) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Audit Log'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => context.canPop() ? context.pop() : context.go('/'),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'The audit log is available to Admin and Super Admin accounts only.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Audit Log'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          ...commonAppBarActions(),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final f in _filters)
                    ChoiceChip(
                      label: Text(f.label),
                      selected: _action == f.action,
                      onSelected: (_) {
                        setState(() => _action = f.action);
                        _load();
                      },
                    ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(_error!,
                            style: TextStyle(color: scheme.error)),
                      ),
                    )
                  : _entries.isEmpty
                  ? Center(
                      child: Text('No audit entries.',
                          style: TextStyle(color: scheme.onSurfaceVariant)),
                    )
                  : PageBody.list(
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCOUNT_PLACEHOLDER
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final e = _entries[i];
                          return ListTile(
                            leading: const Icon(Icons.fact_check_outlined),
                            title: Text(describeAuditEntry(
                              e,
                              actorName: _names[e.actorId],
                              targetName: _names[e.entityId],
                            )),
                            subtitle: Text(_fmt(e.createdAt)),
                            dense: true,
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
```

> When implementing, replace the `itemCOUNT_PLACEHOLDER` marker line with
> `itemCount: _entries.length,` (the marker only exists so you don't miss it —
> the real param is `itemCount: _entries.length,`).

- [ ] **Step 2: Add the route**

In `lib/routing/router.dart`, add the import next to the other setup screens:
`import '../screens/setup/audit_log_screen.dart';`
and a route near `/setup/devices`:

```dart
        GoRoute(
          path: '/setup/audit-log',
          builder: (_, __) => const AuditLogScreen(),
        ),
```

- [ ] **Step 3: Add the sidebar leaf**

In `lib/widgets/admin/admin_sidebar.dart`, inside the `'Setup'` `SidebarSection`
children list (after the Devices leaf, ~line 125), add:

```dart
    SidebarLeaf(
      'Audit Log',
      Icons.fact_check_outlined,
      '/setup/audit-log',
      accent: 3,
    ),
```

- [ ] **Step 4: Verify analysis**

Run: `flutter analyze lib/screens/setup/audit_log_screen.dart lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart`
Expected: No issues. (Confirm you replaced the `itemCOUNT_PLACEHOLDER` marker
with `itemCount: _entries.length,`.)

- [ ] **Step 5: Commit**

```bash
dart format lib/screens/setup/audit_log_screen.dart lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart
git add lib/screens/setup/audit_log_screen.dart lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart
git commit -m "SP9a: Audit Log screen + /setup/audit-log route + sidebar leaf"
```

---

### Task 7: User Management — disable/enable + disabled badge

**Files:**
- Modify: `lib/screens/profiles_screen.dart`

**Interfaces:**
- Consumes: `adminSetUserDisabled` (Task 4), `isSuperAdminProfile` (Task 4).

The row widget is `_ProfileRow` (constructor ~line 280) built in the list
`itemBuilder` (~line 259). The parent already has `_confirmDelete` (~line 125)
to model a new `_confirmToggleDisabled`. The `build` method computes
`isAdmin = isAdminProfile(me)` (~line 161).

- [ ] **Step 1: Add a super-admin flag + disable handler in the parent state**

In `build` (after `final isAdmin = isAdminProfile(me);`, ~line 161) add:
`final isSuperAdmin = isSuperAdminProfile(me);`

Add this method to the state class (next to `_confirmDelete`):

```dart
Future<void> _confirmToggleDisabled(Map<String, dynamic> row) async {
  final disabled = (row['disabled'] as bool?) ?? false;
  final name = row['full_name'] ?? row['email'];
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(disabled ? 'Re-enable user?' : 'Disable user?'),
      content: Text(disabled
          ? 'This will restore access for $name.'
          : 'This will block $name from signing in. They are signed out '
              'immediately and cannot log back in until re-enabled.'),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(disabled ? 'Re-enable' : 'Disable'),
        ),
      ],
    ),
  );
  if (ok != true) return;
  final res = await adminSetUserDisabled(
    userId: row['id'] as String,
    disabled: !disabled,
  );
  if (!mounted) return;
  if (!res.success) {
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.error ?? 'Update failed')));
    return;
  }
  await _load();
}
```

- [ ] **Step 2: Pass the new props into `_ProfileRow`**

In the `itemBuilder` `_ProfileRow(...)` (~line 259), add two args:

```dart
                                    return _ProfileRow(
                                      row: row,
                                      online: _presence
                                          .isOnline(row['id'] as String),
                                      isAdmin: isAdmin,
                                      canDisable: isSuperAdmin,
                                      onEdit: () => _openEdit(row),
                                      onDelete: () => _confirmDelete(row),
                                      onToggleDisabled: () =>
                                          _confirmToggleDisabled(row),
                                    );
```

- [ ] **Step 3: Extend `_ProfileRow` to accept + render them**

In `_ProfileRow` (constructor ~line 280) add fields/params:

```dart
class _ProfileRow extends StatefulWidget {
  const _ProfileRow({
    required this.row,
    required this.online,
    required this.isAdmin,
    required this.onEdit,
    required this.onDelete,
    this.canDisable = false,
    this.onToggleDisabled,
  });

  final Map<String, dynamic> row;
  final bool online;
  final bool isAdmin;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final bool canDisable;
  final VoidCallback? onToggleDisabled;
```

In the row `build`, after `final accountType = ...` (~line 318) add:
`final rowDisabled = (row['disabled'] as bool?) ?? false;`

Add a "Disabled" badge in the `title` Row, after the admin shield block
(after the `if (rowIsAdmin) ...[ ... ]` block, ~line 360):

```dart
              if (rowDisabled) ...[
                const SizedBox(width: 6),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: scheme.errorContainer,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text('Disabled',
                      style: TextStyle(
                          fontSize: 11, color: scheme.onErrorContainer)),
                ),
              ],
```

In the `trailing` admin `Row` children (after the delete `IconButton`,
~line 394) add a disable/enable toggle, shown only to super admins:

```dart
                    if (widget.canDisable && widget.onToggleDisabled != null)
                      IconButton(
                        icon: Icon(rowDisabled
                            ? Icons.lock_open_outlined
                            : Icons.block_outlined),
                        color: rowDisabled ? null : scheme.error,
                        onPressed: widget.onToggleDisabled,
                        tooltip: rowDisabled ? 'Re-enable' : 'Disable',
                      ),
```

- [ ] **Step 4: Confirm `_load` selects `disabled`**

Open `_load` (the profiles fetch). If it uses `.select()` (all columns), no
change is needed — `disabled` arrives automatically. If it lists explicit
columns, add `disabled` to the list. Verify by reading the select call.

- [ ] **Step 5: Verify analysis**

Run: `flutter analyze lib/screens/profiles_screen.dart`
Expected: No issues.

- [ ] **Step 6: Commit**

```bash
dart format lib/screens/profiles_screen.dart
git add lib/screens/profiles_screen.dart
git commit -m "SP9a: User Management — disable/enable action + Disabled badge (super-admin)"
```

---

### Task 8: Full verification + audit smoke test

**Files:** none (verification only).

- [ ] **Step 1: Analyze**

Run: `flutter analyze`
Expected: No issues found.

- [ ] **Step 2: Test suite**

Run: `flutter test`
Expected: all pass (prior suite + 8 new audit tests).

- [ ] **Step 3: Windows release build**

Run: `flutter build windows --release`
Expected: `Built build\windows\x64\runner\Release\mine_online.exe`.

- [ ] **Step 4: Audit-log read policy smoke (Management API)**

Run the helper with:
```sql
select polname, pg_get_expr(polqual, polrelid) as using_expr
from pg_policy
where polrelid = 'public.audit_log'::regclass and polcmd = 'r';
```
Expected: one row, `polname='Admins read audit_log'`, `using_expr` references
`is_admin`.

- [ ] **Step 5: Commit (only if verification required edits)**

```bash
git add <explicit paths>
git commit -m "SP9a: fixes from verification"
```

---

## Self-Review

**Spec coverage:**
- profiles.disabled columns → Task 1. ✓
- audit_log admin-only read (security fix) → Task 1 + Task 8 smoke. ✓
- role-change audit trigger → Task 1. ✓
- set_disabled edge action (ban + flag + audit) + deploy → Task 2. ✓
- describeAuditEntry (pure, all actions + fallback + degrade) → Task 3. ✓
- audit loaders → Task 3. ✓
- UserProfile.disabled, isSuperAdminProfile, adminSetUserDisabled → Task 4. ✓
- AuthProvider lockout → Task 5. ✓
- Audit Log screen + route + sidebar → Task 6. ✓
- User Management disable/enable + badge (super-admin) → Task 7. ✓
- analyze + test + build verification → Task 8. ✓

**Placeholder scan:** No TBD/TODO. The single intentional marker
(`itemCOUNT_PLACEHOLDER`) is called out twice with its exact replacement
(`itemCount: _entries.length,`) so it cannot be missed.

**Type consistency:** `AuditEntry`, `describeAuditEntry(e, {actorName,
targetName})`, `loadAuditLog({limit, action})`, `loadAuditNames(...)`,
`adminSetUserDisabled({userId, disabled})`, `isSuperAdminProfile(...)`,
`UserProfile.disabled`, `AuditLogScreen`, `_ProfileRow(canDisable,
onToggleDisabled)` are used consistently across Tasks 3–7.
```
