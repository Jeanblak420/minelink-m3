# SP9c — Broader Audit Feed Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Log appointment + device lifecycle actions into the existing
`audit_log` and surface them in the Audit Log screen under Appointments / Devices
filters.

**Architecture:** Two `SECURITY DEFINER` triggers write `audit_log` rows for
appointment status changes and device approve/revoke/restore. Flutter extends the
pure `describeAuditEntry` with cases and lets the Audit Log screen filter by a
list of actions (group chips). No new screen, no new dependency.

**Tech Stack:** Supabase Postgres triggers; Flutter `supabase_flutter`; the
existing `audit_data.dart` + `audit_log_screen.dart`.

## Global Constraints

- No new Flutter dependencies. No "Claude"/AI naming in code, data, or SQL.
- Triggers are additive + `SECURITY DEFINER`; do not touch the existing
  `trg_appointments_notify` / `trg_devices_guard` / `trg_devices_notify`.
- Migration written to `supabase/migrations/` AND applied via the Management API
  (PAT `claude-supabase-pat-hhrnkzznpadrmyverhyb`, ref `hhrnkzznpadrmyverhyb`).
  Use the Management-API PowerShell helper from
  `docs/superpowers/plans/2026-06-25-sp9-user-lifecycle-audit.md` (set `$Q`).
- `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- `dart format` touched files before each commit. Stage explicit paths only.

---

### Task 1: Migration — appointment + device audit triggers

**Files:**
- Create: `supabase/migrations/20260625140000_sp9c_broader_audit.sql`

**Interfaces:**
- Produces: functions `public.fn_audit_appointment()`, `public.fn_audit_device()`
  and triggers `trg_appointments_audit` (insert/update on appointments),
  `trg_devices_audit` (update on devices) writing `audit_log` rows with actions
  `appointment.issued|accepted|activated|declined|resigned`,
  `device.approved|revoked|restored`.

- [ ] **Step 1: Write the migration file**

```sql
-- supabase/migrations/20260625140000_sp9c_broader_audit.sql
-- SP9c: audit appointment + device lifecycle into the existing audit_log.
-- Additive SECURITY DEFINER triggers; existing notify/guard triggers untouched.

create or replace function public.fn_audit_appointment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
  v_appointee text;
begin
  if tg_op = 'INSERT' then
    v_action := 'appointment.issued';
  elsif new.status is distinct from old.status then
    v_action := case new.status
      when 'pending_signoff' then 'appointment.accepted'
      when 'active'          then 'appointment.activated'
      when 'declined'        then 'appointment.declined'
      when 'resigned'        then 'appointment.resigned'
      else null
    end;
  else
    v_action := null;
  end if;

  if v_action is null then
    return new;
  end if;

  select full_name into v_appointee
    from public.profiles where id = new.appointee_id;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, new_values)
  values (
    coalesce(auth.uid(),
             case when tg_op = 'INSERT' then new.issued_by else null end),
    v_action, 'appointment', new.id,
    jsonb_build_object('role_code', new.role_code,
                       'appointee_name', v_appointee,
                       'status', new.status)
  );
  return new;
end;
$$;

drop trigger if exists trg_appointments_audit on public.appointments;
create trigger trg_appointments_audit
  after insert or update on public.appointments
  for each row execute function public.fn_audit_appointment();

create or replace function public.fn_audit_device()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
begin
  if new.approved = true and coalesce(old.approved, false) = false then
    v_action := 'device.approved';
  elsif new.is_active = false and coalesce(old.is_active, true) = true then
    v_action := 'device.revoked';
  elsif new.is_active = true and coalesce(old.is_active, true) = false then
    v_action := 'device.restored';
  else
    v_action := null;
  end if;

  if v_action is null then
    return new;
  end if;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, new_values)
  values (
    auth.uid(), v_action, 'device', new.id,
    jsonb_build_object('platform', new.platform,
                       'device_name', new.device_name)
  );
  return new;
end;
$$;

drop trigger if exists trg_devices_audit on public.devices;
create trigger trg_devices_audit
  after update on public.devices
  for each row execute function public.fn_audit_device();
```

- [ ] **Step 2: Apply via the Management API**

Run the helper with `$Q` set to the entire file body. Expected: `[]`.

- [ ] **Step 3: Verify the triggers exist**

Run the helper with:
```sql
select tgname from pg_trigger
where tgname in ('trg_appointments_audit','trg_devices_audit')
order by tgname;
```
Expected: two rows — `trg_appointments_audit`, `trg_devices_audit`.

- [ ] **Step 4: Commit**

```bash
git add supabase/migrations/20260625140000_sp9c_broader_audit.sql
git commit -m "SP9c: migration — appointment + device audit triggers"
```

---

### Task 2: `describeAuditEntry` appointment + device cases (TDD)

**Files:**
- Modify: `lib/utils/audit_data.dart`
- Test: `test/audit_test.dart`

**Interfaces:**
- Extends the existing `describeAuditEntry` (SP9a/SP9b).

- [ ] **Step 1: Add failing tests**

Append inside `group('describeAuditEntry', ...)` in `test/audit_test.dart`:

```dart
    AuditEntry ev(String action, Map<String, dynamic> newV, {String? actor}) =>
        AuditEntry.fromMap({
          'id': 'x',
          'user_id': actor,
          'action': action,
          'entity_type': action.split('.').first,
          'entity_id': 'e1',
          'old_values': null,
          'new_values': newV,
          'created_at': '2026-06-25T10:00:00Z',
        });

    test('appointment.issued names role + appointee', () {
      final e = ev('appointment.issued',
          {'role_code': 'Shift Boss', 'appointee_name': 'Bob Miner'},
          actor: 'actor-1');
      expect(describeAuditEntry(e, actorName: 'Jean Burger'),
          'Jean Burger issued a Shift Boss appointment to Bob Miner');
    });
    test('appointment.issued without appointee degrades', () {
      final e = ev('appointment.issued', {'role_code': 'Shift Boss'});
      expect(describeAuditEntry(e),
          'An administrator issued a Shift Boss appointment to an appointee');
    });
    test('appointment.activated has no actor', () {
      final e = ev('appointment.activated', {'role_code': 'Shift Boss'});
      expect(describeAuditEntry(e),
          'A Shift Boss appointment became active');
    });
    test('appointment.resigned', () {
      final e = ev('appointment.resigned', {'role_code': 'Miner'});
      expect(describeAuditEntry(e, actorName: 'Bob Miner'),
          'Bob Miner resigned from a Miner appointment');
    });
    test('device.approved names platform', () {
      final e = ev('device.approved', {'platform': 'windows'});
      expect(describeAuditEntry(e, actorName: 'Jean Burger'),
          'Jean Burger approved a device (windows)');
    });
    test('device.revoked', () {
      final e = ev('device.revoked', {'platform': 'android'});
      expect(describeAuditEntry(e, actorName: 'Jean Burger'),
          'Jean Burger revoked a device (android)');
    });
```

- [ ] **Step 2: Run to verify they fail**

Run: `flutter test test/audit_test.dart`
Expected: FAIL — these actions currently hit the generic fallback.

- [ ] **Step 3: Add the cases**

In `lib/utils/audit_data.dart`, add two small private helpers above
`describeAuditEntry`:

```dart
String _appt(AuditEntry e) {
  final role = (e.newValues?['role_code'] as String?)?.trim();
  return (role == null || role.isEmpty) ? 'an appointment' : '$role appointment';
}

String _platform(AuditEntry e) {
  final p = (e.newValues?['platform'] as String?)?.trim();
  return (p == null || p.isEmpty) ? 'a device' : 'a device ($p)';
}
```

In the `switch`, add before `default:`:

```dart
    case 'appointment.issued':
      final who = (e.newValues?['appointee_name'] as String?)?.trim();
      return '$actor issued a ${_appt(e)} to '
          '${(who == null || who.isEmpty) ? 'an appointee' : who}';
    case 'appointment.accepted':
      return '$actor accepted a ${_appt(e)}';
    case 'appointment.declined':
      return '$actor declined a ${_appt(e)}';
    case 'appointment.resigned':
      return '$actor resigned from a ${_appt(e)}';
    case 'appointment.activated':
      final role = (e.newValues?['role_code'] as String?)?.trim();
      return (role == null || role.isEmpty)
          ? 'An appointment became active'
          : 'A $role appointment became active';
    case 'device.approved':
      return '$actor approved ${_platform(e)}';
    case 'device.revoked':
      return '$actor revoked ${_platform(e)}';
    case 'device.restored':
      return '$actor restored ${_platform(e)}';
```

> The `_appt` helper yields "Shift Boss appointment" so "a ${_appt(e)}" reads
> "a Shift Boss appointment". The `_platform` helper yields "a device (windows)"
> so "approved ${_platform(e)}" reads "approved a device (windows)".

- [ ] **Step 4: Run to verify pass**

Run: `flutter test test/audit_test.dart`
Expected: PASS (16 tests).

- [ ] **Step 5: Commit**

```bash
dart format lib/utils/audit_data.dart test/audit_test.dart
git add lib/utils/audit_data.dart test/audit_test.dart
git commit -m "SP9c: describeAuditEntry handles appointment + device actions"
```

---

### Task 3: Audit Log screen — action-list filter + group chips

**Files:**
- Modify: `lib/utils/audit_data.dart` (`loadAuditLog` signature)
- Modify: `lib/screens/setup/audit_log_screen.dart`

**Interfaces:**
- Consumes: `loadAuditLog`, `loadAuditNames` (SP9a).
- Produces: `loadAuditLog({int limit = 200, List<String>? actions})`.

- [ ] **Step 1: Refactor `loadAuditLog` to a list of actions**

In `lib/utils/audit_data.dart`, replace the `loadAuditLog` signature + filter:

```dart
Future<List<AuditEntry>> loadAuditLog({
  int limit = 200,
  List<String>? actions,
}) async {
  var query = supabase
      .from('audit_log')
      .select(
        'id, user_id, action, entity_type, entity_id, '
        'old_values, new_values, created_at',
      );
  if (actions != null && actions.isNotEmpty) {
    query = query.inFilter('action', actions);
  }
  final rows = (await query.order('created_at', ascending: false).limit(limit))
      .cast<Map<String, dynamic>>();
  return rows.map(AuditEntry.fromMap).toList();
}
```

- [ ] **Step 2: Update the screen's filter model + chips**

In `lib/screens/setup/audit_log_screen.dart`:

Replace the `_Filter` class and `_filters` list with:

```dart
class _Filter {
  const _Filter(this.label, this.actions);
  final String label;
  final List<String>? actions; // null = all
}

const _filters = [
  _Filter('All', null),
  _Filter('Role changes', ['user.role_change']),
  _Filter('Disabled', ['user.disable']),
  _Filter('Re-enabled', ['user.enable']),
  _Filter('Created', ['user.create']),
  _Filter('Deleted', ['user.delete']),
  _Filter('Passwords', ['user.update_password']),
  _Filter('Submission reviews', ['submission.review']),
  _Filter('Appointments', [
    'appointment.issued',
    'appointment.accepted',
    'appointment.declined',
    'appointment.activated',
    'appointment.resigned',
  ]),
  _Filter('Devices', ['device.approved', 'device.revoked', 'device.restored']),
];
```

Change the selection state from `String? _action` to a selected label, and the
load call. Replace the field `String? _action;` with `String _filterLabel = 'All';`
and update `_load` + the chip builder:

```dart
  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final f = _filters.firstWhere((x) => x.label == _filterLabel);
      final entries = await loadAuditLog(actions: f.actions);
      final names = await loadAuditNames(entries);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _names = names;
        _loading = false;
      });
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _error = err.toString();
        _loading = false;
      });
    }
  }
```

And the chip loop:

```dart
                  for (final f in _filters)
                    ChoiceChip(
                      label: Text(f.label),
                      selected: _filterLabel == f.label,
                      onSelected: (_) {
                        setState(() => _filterLabel = f.label);
                        _load();
                      },
                    ),
```

- [ ] **Step 3: Verify analysis**

Run: `flutter analyze lib/utils/audit_data.dart lib/screens/setup/audit_log_screen.dart`
Expected: No issues. (Confirm no remaining reference to the old `_action` field
or the old single-`action` `_Filter`.)

- [ ] **Step 4: Commit**

```bash
dart format lib/utils/audit_data.dart lib/screens/setup/audit_log_screen.dart
git add lib/utils/audit_data.dart lib/screens/setup/audit_log_screen.dart
git commit -m "SP9c: Audit Log screen — action-list filter + Appointments/Devices chips"
```

---

### Task 4: Full verification

**Files:** none.

- [ ] **Step 1: Analyze**

Run: `flutter analyze`
Expected: No issues found.

- [ ] **Step 2: Test suite**

Run: `flutter test`
Expected: all pass (prior suite + 6 new audit tests).

- [ ] **Step 3: Windows release build**

Run: `flutter build windows --release`
Expected: `Built build\windows\x64\runner\Release\mine_online.exe`.

- [ ] **Step 4: Trigger-existence smoke (Management API)**

Run the helper with:
```sql
select tgname from pg_trigger
where tgname in ('trg_appointments_audit','trg_devices_audit') order by tgname;
```
Expected: both rows present. (Live write rows are exercised by the user's in-app
pass — issue/accept an appointment, approve/revoke a device.)

- [ ] **Step 5: Commit (only if verification required edits)**

```bash
git add <explicit paths>
git commit -m "SP9c: fixes from verification"
```

---

## Self-Review

**Spec coverage:**
- appointment audit trigger (issued/accepted/activated/declined/resigned) → Task 1. ✓
- device audit trigger (approved/revoked/restored) → Task 1. ✓
- describeAuditEntry cases → Task 2. ✓
- loadAuditLog action-list + group chips → Task 3. ✓
- analyze + test + build + trigger smoke → Task 4. ✓
- no device-registration logging (trigger is UPDATE-only, approve/revoke/restore) → Task 1. ✓

**Placeholder scan:** No TBD/TODO; all code shown. The trigger-existence smoke
honestly notes the live-write path is the in-app pass (the Management-API
connection has `auth.uid()` null and wouldn't be a representative actor).

**Type consistency:** `loadAuditLog({limit, actions})` (Task 3) matches the
single caller updated in Task 3; `_Filter(label, actions)` is used consistently;
`describeAuditEntry` cases read `new_values` keys (`role_code`, `appointee_name`,
`platform`) that exactly match the JSON the Task 1 triggers write.
```
