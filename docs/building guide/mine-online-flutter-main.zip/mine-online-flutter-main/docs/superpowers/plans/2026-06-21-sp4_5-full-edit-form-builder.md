# SP4.5 — Full-edit Form Builder (overlay) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans. Steps use checkbox (`- [ ]`) syntax.

**Goal:** Let admins fully edit every current form (27 built-ins + appointment forms) — add fields, add pages, hide/relabel/retype/reorder — while untouched content stays pixel-identical on screen and in PDF.

**Architecture:** An **edit overlay** per form (stored on `custom_form_templates`, keyed by `code = form_type`). Bespoke screens/PDFs remain the baseline renderer; a shared **overlay host** (screen) and **overlay appendix** (PDF) render added fields/pages and, in Phase B, apply per-field overrides. Added/edited fields reuse `DynamicFormRenderer` (the same primitives as custom forms) so they look native. Empty overlay → nothing renders → byte-identical.

**Tech stack:** Flutter Material 3, `provider`, `go_router`, `supabase_flutter`, `pdf`+`printing`. No new dependencies.

## Global Constraints

- Pixel-identity: with an empty overlay, every form screen + PDF is unchanged. The overlay host/appendix render nothing when empty.
- No new dependencies. No "Claude"/AI naming. Windows + Android.
- Git: stage explicit paths only; never `git add -A`/`reset --hard`. Verify with `flutter analyze` + `flutter test` + `flutter build windows --release`; `dart format` touched files.
- Supabase: migration file in `supabase/migrations/` AND applied via Management API (PAT `claude-supabase-pat-hhrnkzznpadrmyverhyb`, ref `hhrnkzznpadrmyverhyb`).
- Overlay never changes a form's `form_type`, submission semantics, or signature chain. Overlay values live under `payload['overlay']`.
- Reuse: `FormFieldDef`/`FormFieldType` + `validateTemplate` (custom_form_template.dart), `DynamicFormRenderer`, `FieldEditorList`, `buildSubmissionPayload`.

## File Structure

**New:**
- `supabase/migrations/20260622120000_form_overlays.sql` — `overlay` jsonb + `base_form_type` text on `custom_form_templates`.
- `lib/models/form_overlay.dart` — `FormOverlay` (+ added pages/fields/overrides/order) pure model + helpers.
- `lib/utils/form_metadata.dart` — `FormMetadata` + `kFormMetadataRegistry` (all current forms).
- `lib/utils/form_overlay_data.dart` — load/save overlay rows.
- `lib/widgets/form_builder/form_overlay_host.dart` — screen-side applicator (renders added fields/pages; Phase B: override lookup).
- `lib/pdf/pdf_overlay_appendix.dart` — PDF-side appendix builder.
- `test/form_overlay_test.dart` — model + payload tests.

**Modified (Phase A foundation):**
- `lib/screens/form_builder_screen.dart` — add "Edit a current form" entry + overlay editor.
- `lib/utils/form_registry.dart` — pass overlay to screens/PDFs.

**Modified (Phase A rollout — per form, mechanical):** each `lib/screens/*_form_screen.dart` (27 + appointment) gets a one-block `FormOverlayHost` insert + payload merge; each `lib/pdf/generate_*_pdf.dart` gets an `appendOverlay(...)` call.

---

## Phase A — Foundation

### Task A1: Migration (overlay columns)

**Files:** Create `supabase/migrations/20260622120000_form_overlays.sql`

- [ ] **Step 1: Write**

```sql
-- SP4.5: per-form edit overlay (added fields/pages + per-field overrides) for
-- the current built-in + appointment forms. Reuses custom_form_templates keyed
-- by code = form_type. base_form_type marks an overlay row (vs a standalone
-- SP2 custom form, where it stays null).
alter table public.custom_form_templates
  add column if not exists overlay jsonb not null default '{}'::jsonb;
alter table public.custom_form_templates
  add column if not exists base_form_type text;
```

- [ ] **Step 2: Apply via Management API.** Expected 200/201.
- [ ] **Step 3: Verify** columns exist (`information_schema.columns`).
- [ ] **Step 4: Commit** `git add supabase/migrations/20260622120000_form_overlays.sql && git commit -m "SP4.5: overlay + base_form_type columns on custom_form_templates"`

### Task A2: Overlay model + tests (TDD)

**Files:** Create `lib/models/form_overlay.dart`, `test/form_overlay_test.dart`

**Interfaces:**
- `class OverlayPage { final String id, title; final List<FormFieldDef> fields; toMap/fromMap; }`
- `class FormOverlay { final List<FormFieldDef> addedFields; final List<OverlayPage> addedPages; final Map<String,FieldOverride> fieldOverrides; toMap/fromMap; bool get hasContent; }`
- `class FieldOverride { final bool hidden; final String? label; final String? type; final bool? required; toMap/fromMap; }`
- `Map<String,dynamic> overlayValuesFromPayload(Map payload)` → `payload['overlay'] as Map? ?? {}`
- `List<FormFieldDef> allOverlayFields(FormOverlay o)` → addedFields + every page's fields (for payload build + PDF).

- [ ] **Step 1: failing tests** — round-trip `FormOverlay.fromMap(toMap())` preserves addedFields/addedPages/overrides; `hasContent` false for empty; `allOverlayFields` flattens pages+fields.
- [ ] **Step 2: run → fail.**
- [ ] **Step 3: implement model** (pure; reuse `FormFieldDef`).
- [ ] **Step 4: run → pass.**
- [ ] **Step 5: format + commit** `SP4.5: form overlay model + tests (TDD)`

### Task A3: Overlay data layer

**Files:** Create `lib/utils/form_overlay_data.dart`

**Interfaces:**
- `Future<FormOverlay?> loadFormOverlay(String formType)` — selects the `custom_form_templates` row where `code = formType` (and `base_form_type` not null), returns its `overlay` as `FormOverlay`, or null.
- `Future<void> saveFormOverlay(String formType, String title, FormOverlay overlay)` — upsert by code: insert (code=formType, name=title, base_form_type=formType, fields=[], overlay=...) or update overlay+updated_at.

- [ ] Implement (mirror `custom_form_data.dart`; use `supabase.from('custom_form_templates')`). Analyze clean. Commit `SP4.5: overlay data layer`.

### Task A4: Screen overlay host

**Files:** Create `lib/widgets/form_builder/form_overlay_host.dart`

**Interfaces:**
- `class FormOverlayHost extends StatefulWidget { final String formType; final Map<String,dynamic> values; final ValueChanged<Map<String,dynamic>> onChanged; final bool readOnly; }` — loads the overlay for `formType`; if empty/none, renders `SizedBox.shrink()` (→ zero visual change). Else renders a `Divider` + each added page (title + its fields) + appended added fields, via `DynamicFormRenderer` (wrapped in `AbsorbPointer(absorbing: readOnly)`). Holds its own values map seeded from `values['…']`, calls `onChanged` with the merged overlay-values map for the host screen to fold into the payload under `payload['overlay']`.

- [ ] Implement. Renders nothing when overlay empty. Analyze clean. Commit `SP4.5: screen-side overlay host`.

### Task A5: PDF overlay appendix

**Files:** Create `lib/pdf/pdf_overlay_appendix.dart`

**Interfaces:**
- `Future<void> appendOverlayToPdf(pw.Document doc, String formType, Map<String,dynamic> payload)` — loads the overlay; if it has content + the payload has `overlay` values, adds a `pw.MultiPage` "Additional information" appendix (reusing the block-building style from `generate_custom_form_pdf.dart`: section headers per added page, key/value + signature/table blocks). No-op when empty. (Extract a shared `List<pw.Widget> buildFieldBlocks(fields, values, base, bold)` so this and `generateCustomFormPdf` agree.)

- [ ] Implement (refactor the block builder out of `generate_custom_form_pdf.dart` into a shared `pdf_field_blocks.dart`, used by both). Analyze clean. Commit `SP4.5: PDF overlay appendix + shared field blocks`.

### Task A6: Form registry (all current forms)

**Files:** Create `lib/utils/form_metadata.dart`

**Interfaces:**
- `class FormMetadata { final String formType, title, route; final String? category; final bool isAppointmentForm; }`
- `const List<FormMetadata> kFormMetadataRegistry` — one entry per current form. Source the list from `appointments_screen.dart` `_cards` + the `buildFormView` switch in `form_registry.dart` (every `case` is a form_type; the route comes from `router.dart`). Include the 3 appointment forms.

- [ ] Build the registry (enumerate every `form_type` handled by `buildFormView`). Analyze clean. Commit `SP4.5: current-form metadata registry`.

### Task A7: Builder UI — "Edit a current form"

**Files:** Modify `lib/screens/form_builder_screen.dart`

- [ ] Add a second FAB/menu "Edit a current form" → a picker (from `kFormMetadataRegistry`) → `_OverlayEditorScreen(formType, title)`:
  - Loads the overlay via `loadFormOverlay`. Shows a `FieldEditorList` bound to the overlay's `addedFields`, an "Add page" control building `OverlayPage`s (each with its own `FieldEditorList`), and (Phase B placeholder) a list of the form's existing fields for override — omitted in Phase A.
  - Save → `saveFormOverlay(formType, title, overlay)`. Validates added fields via `validateTemplate`.
  - A "Preview" button pushes the real form screen (via `buildFormView(formType, FormViewArgs(...))`) so the admin sees the overlay applied.
- [ ] Analyze clean. Commit `SP4.5: builder UI to edit current forms (add fields/pages)`.

### Task A8: Registry wiring

**Files:** Modify `lib/utils/form_registry.dart`

- [ ] `generatePdfForFormType`: after building the bespoke `pw.Document`, call `await appendOverlayToPdf(doc, formType, payload)` before returning (for the non-custom branch). Analyze clean. Commit `SP4.5: apply overlay appendix in generatePdfForFormType`.

---

## Phase A rollout — wire every form (mechanical recipe)

For EACH bespoke form screen `lib/screens/<x>_form_screen.dart` and its generator `lib/pdf/generate_<x>_pdf.dart`:

**Screen recipe** (one block, renders nothing when no overlay):
- [ ] Add state `Map<String,dynamic> _overlayValues = {};`
- [ ] In the form body `Column`, after the last existing child (before the submit/PDF buttons), insert:
```dart
FormOverlayHost(
  formType: '<form_type>',
  values: widget.viewArgs?.initialPayload?['overlay'] as Map<String, dynamic>? ?? const {},
  readOnly: _isViewMode,
  onChanged: (v) => _overlayValues = v,
),
```
- [ ] In `_submit()` (and PDF preview), before submit: `final payload = _data.toMap(); if (_overlayValues.isNotEmpty) payload['overlay'] = _overlayValues;` and submit `payload`.

**PDF recipe:** the screen's own "Generate PDF" already calls `generate_<x>_pdf`; the regenerate path (`generatePdfForFormType`) appends the overlay via Task A8. For the on-screen "Generate PDF" button to include the overlay too, route it through `generatePdfForFormType('<form_type>', payload)` OR call `appendOverlayToPdf` after building the doc. Use whichever the screen already does; prefer `generatePdfForFormType` for one code path.

- [ ] Do this for all forms in `buildFormView` (27) + the 3 appointment screens. Batch-commit in groups of ~6 forms: `SP4.5: overlay host in <group> forms`.
- [ ] After each batch: `flutter analyze` clean.

**Milestone (end of Phase A):** every current form supports admin-added fields + pages, pixel-identical when none added. Verify: `flutter analyze`, `flutter test`, `flutter build windows --release`. Empty-overlay golden test for a sample form's PDF.

---

## Phase B — Per-field overrides (progressive)

Adds hide/relabel/retype/reorder of EXISTING fields. Requires giving existing
fields stable ids the overlay targets.

**Per-form recipe:**
- [ ] In the form's model/screen, expose a stable `fieldId` per editable existing field (a const map `<fieldId, label>` for that form).
- [ ] The bespoke field widget consults `FormOverlayHost`'s override for its id: hidden → skip; label override → use it; type override → render the alternate primitive; reorder → host orders the editable region.
- [ ] Builder overlay editor (Task A7) shows the form's existing field ids with hide/relabel/retype/reorder controls, writing `fieldOverrides`/`order`.
- [ ] Per form: analyze + manual visual check (only the overridden field changes). Commit `SP4.5 Phase B: overrides for <form>`.

Roll out form by form; each is independently shippable. Untouched fields never move.

---

## Final

- [ ] `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- [ ] Update `HANDOFF.md` (SP4.5 done / progress; SP4.6 legacy clone next) + memory. Merge to `main`; delete branch.

## Self-Review

**Spec coverage:** overlay model+storage (A1–A3) ✓; registry (A6) ✓; builder UI add fields/pages (A7) ✓; screen application (A4 + rollout) ✓; PDF application (A5, A8 + rollout) ✓; payload namespacing under `overlay` (rollout recipe) ✓; pixel-identity by empty-overlay no-op (A4/A5) ✓; phasing A then B ✓; Builder 1 deferred (not in plan) ✓.

**Placeholder scan:** Phase B per-field id maps are per-form and enumerated at implementation (the recipe is explicit); migration timestamp is the real file name. No TBDs in foundation code.

**Type consistency:** `FormOverlay`/`OverlayPage`/`FieldOverride` shapes match across model (A2), data (A3), host (A4), appendix (A5), builder (A7). `FormOverlayHost(formType, values, onChanged, readOnly)` signature matches rollout inserts. `appendOverlayToPdf(doc, formType, payload)` matches A8 call. Overlay values keyed under `payload['overlay']` consistently in host, rollout, and appendix.
