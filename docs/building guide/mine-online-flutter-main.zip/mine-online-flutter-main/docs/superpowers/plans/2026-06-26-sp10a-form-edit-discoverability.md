# SP10a — Form-edit Discoverability Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Show the 27 built-in forms as a visible, tappable edit list in Form
Builder (grouped by category, with "Edited" chips), opening the existing overlay
editor.

**Architecture:** A pure `groupFormsByCategory` + a bulk `loadEditedFormTypes`
loader feed a restructured Form Builder body that renders a "Current forms"
section above the existing "Custom forms" list. No form/PDF/editor changes.

**Tech Stack:** Flutter, `supabase_flutter`, `go_router`, `provider`.

## Global Constraints

- No new dependencies. No "Claude"/AI naming. No DB change.
- Existing forms, the overlay editor, and PDFs are untouched.
- Admin-gated (the screen already gates on `isAdminProfile`).
- `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- `dart format` touched files before each commit. Stage explicit paths only.

---

### Task 1: `groupFormsByCategory` (pure, TDD) + `loadEditedFormTypes`

**Files:**
- Modify: `lib/utils/form_metadata.dart` (add `groupFormsByCategory`)
- Modify: `lib/utils/form_overlay_data.dart` (add `loadEditedFormTypes`)
- Test: `test/form_metadata_test.dart`

**Interfaces:**
- Produces: `Map<String, List<FormMetadata>> groupFormsByCategory(List<FormMetadata> forms)`;
  `Future<Set<String>> loadEditedFormTypes()`.

- [ ] **Step 1: Write the failing test**

```dart
// test/form_metadata_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/form_metadata.dart';

void main() {
  group('groupFormsByCategory', () {
    test('preserves first-seen category order and within-category order', () {
      const forms = [
        FormMetadata(formType: 'a', title: 'A', route: '/a', category: 'X'),
        FormMetadata(formType: 'b', title: 'B', route: '/b', category: 'Y'),
        FormMetadata(formType: 'c', title: 'C', route: '/c', category: 'X'),
      ];
      final g = groupFormsByCategory(forms);
      expect(g.keys.toList(), ['X', 'Y']);
      expect(g['X']!.map((f) => f.formType).toList(), ['a', 'c']);
      expect(g['Y']!.map((f) => f.formType).toList(), ['b']);
    });

    test('empty input yields empty map', () {
      expect(groupFormsByCategory(const []), isEmpty);
    });

    test('real registry groups every form', () {
      final g = groupFormsByCategory(kFormMetadataRegistry);
      final total = g.values.fold<int>(0, (n, l) => n + l.length);
      expect(total, kFormMetadataRegistry.length);
    });
  });
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `flutter test test/form_metadata_test.dart`
Expected: FAIL — `groupFormsByCategory` not defined.

- [ ] **Step 3: Implement `groupFormsByCategory`**

Append to `lib/utils/form_metadata.dart`:

```dart
/// Groups forms by `category`, preserving first-seen category order and the
/// within-category order of [forms].
Map<String, List<FormMetadata>> groupFormsByCategory(
  List<FormMetadata> forms,
) {
  final out = <String, List<FormMetadata>>{};
  for (final f in forms) {
    (out[f.category] ??= <FormMetadata>[]).add(f);
  }
  return out;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `flutter test test/form_metadata_test.dart`
Expected: PASS (3 tests).

- [ ] **Step 5: Add `loadEditedFormTypes`**

Append to `lib/utils/form_overlay_data.dart` (it already imports
`supabase_client.dart` + `form_overlay.dart`):

```dart
/// form_types whose saved overlay actually customizes the form (non-empty).
Future<Set<String>> loadEditedFormTypes() async {
  final rows = await supabase
      .from('custom_form_templates')
      .select('code, overlay')
      .not('base_form_type', 'is', null);
  final out = <String>{};
  for (final r in (rows as List).cast<Map<String, dynamic>>()) {
    final code = r['code'] as String?;
    final raw = r['overlay'];
    if (code == null || raw is! Map) continue;
    if (FormOverlay.fromMap(raw.cast<String, dynamic>()).hasContent) {
      out.add(code);
    }
  }
  return out;
}
```

- [ ] **Step 6: Verify analysis**

Run: `flutter analyze lib/utils/form_metadata.dart lib/utils/form_overlay_data.dart test/form_metadata_test.dart`
Expected: No issues.

- [ ] **Step 7: Commit**

```bash
dart format lib/utils/form_metadata.dart lib/utils/form_overlay_data.dart test/form_metadata_test.dart
git add lib/utils/form_metadata.dart lib/utils/form_overlay_data.dart test/form_metadata_test.dart
git commit -m "SP10a: groupFormsByCategory (TDD) + loadEditedFormTypes"
```

---

### Task 2: Form Builder — visible "Current forms" section

**Files:**
- Modify: `lib/screens/form_builder_screen.dart`

**Interfaces:**
- Consumes: `groupFormsByCategory`, `kFormMetadataRegistry`, `loadEditedFormTypes`
  (Task 1); the existing `_OverlayEditorScreen` + `FormMetadata`.

- [ ] **Step 1: Add edited-set state + load it**

In `_FormBuilderScreenState`, add a field after `_templates`:

```dart
  Set<String> _edited = const {};
```

In `_load`, fetch both (the edited set is best-effort — never blocks the list):

```dart
    try {
      final list = await loadTemplates(includeArchived: true);
      Set<String> edited = const {};
      try {
        edited = await loadEditedFormTypes();
      } catch (_) {
        edited = const {};
      }
      if (!mounted) return;
      setState(() {
        _templates = list;
        _edited = edited;
        _loading = false;
      });
    } catch (err) {
```

- [ ] **Step 2: Extract a shared overlay-editor opener**

Replace the push at the end of `_pickCurrentForm` (the
`await Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => _OverlayEditorScreen(meta: picked)));`)
with a call to a new helper, and add the helper:

```dart
  Future<void> _openOverlayEditor(FormMetadata meta) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => _OverlayEditorScreen(meta: meta)),
    );
    if (mounted) _load(); // refresh "Edited" chips
  }
```

So `_pickCurrentForm` ends with:

```dart
    if (picked == null || !mounted) return;
    await _openOverlayEditor(picked);
```

- [ ] **Step 3: Restructure the body into two sections**

Replace the body child (currently
`child: _templates.isEmpty ? <empty text> : ListView.separated(...)`) with a
`Column` holding the Current-forms section then the Custom-forms section. Replace
the whole `PageBody.list(padding: ..., child: ...)` child expression with:

```dart
            : PageBody.list(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Current forms',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 2, bottom: 8),
                      child: Text(
                        'Tap a form to add fields, or hide / relabel its '
                        'existing ones.',
                        style: TextStyle(color: scheme.onSurfaceVariant),
                      ),
                    ),
                    for (final entry
                        in groupFormsByCategory(kFormMetadataRegistry).entries) ...[
                      Padding(
                        padding: const EdgeInsets.only(top: 8, bottom: 4),
                        child: Text(
                          entry.key,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                      for (final m in entry.value)
                        Card(
                          margin: const EdgeInsets.only(bottom: 6),
                          child: ListTile(
                            title: Text(m.title),
                            subtitle: Text(m.category),
                            onTap: () => _openOverlayEditor(m),
                            trailing: _edited.contains(m.formType)
                                ? Chip(
                                    label: const Text('Edited'),
                                    visualDensity: VisualDensity.compact,
                                    backgroundColor: scheme.secondaryContainer,
                                  )
                                : const Icon(Icons.edit_outlined),
                          ),
                        ),
                    ],
                    const Divider(height: 32),
                    Text(
                      'Custom forms',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (_templates.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        child: Text(
                          'No custom forms yet. Tap "New form" to build one.',
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      )
                    else
                      for (final t in _templates)
                        Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            title: Text(t.name),
                            subtitle: Text(
                              '${t.fields.where((f) => f.type != FormFieldType.section).length} fields'
                              '${t.category != null && t.category!.isNotEmpty ? ' • ${t.category}' : ''}'
                              '${t.isActive ? '' : ' • archived'}',
                            ),
                            onTap: () => _openEditor(t),
                            trailing: PopupMenuButton<String>(
                              onSelected: (v) {
                                if (v == 'edit') _openEditor(t);
                                if (v == 'toggle') _toggleActive(t);
                              },
                              itemBuilder: (_) => [
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Edit'),
                                ),
                                PopupMenuItem(
                                  value: 'toggle',
                                  child: Text(t.isActive ? 'Archive' : 'Restore'),
                                ),
                              ],
                            ),
                          ),
                        ),
                  ],
                ),
              ),
```

> This removes the old `ListView.separated` (its `_templates.isEmpty` ternary is
> now folded into the Custom-forms section). `PageBody.list` already scrolls, so
> the body is a plain `Column` — no nested scroll view.

- [ ] **Step 4: Verify analysis**

Run: `flutter analyze lib/screens/form_builder_screen.dart`
Expected: No issues. (If `_OverlayEditorScreen`/`FormMetadata` names differ,
match the file — they are defined/imported in this same file already.)

- [ ] **Step 5: Commit**

```bash
dart format lib/screens/form_builder_screen.dart
git add lib/screens/form_builder_screen.dart
git commit -m "SP10a: Form Builder shows current forms as a tappable edit list"
```

---

### Task 3: Full verification

**Files:** none.

- [ ] **Step 1: Analyze**

Run: `flutter analyze`
Expected: No issues found.

- [ ] **Step 2: Test suite**

Run: `flutter test`
Expected: all pass (prior suite + 3 grouping tests).

- [ ] **Step 3: Windows release build**

Run: `flutter build windows --release`
Expected: `Built build\windows\x64\runner\Release\mine_online.exe`.

- [ ] **Step 4: Commit (only if verification required edits)**

```bash
git add <explicit paths>
git commit -m "SP10a: fixes from verification"
```

---

## Self-Review

**Spec coverage:**
- `loadEditedFormTypes` bulk loader → Task 1. ✓
- `groupFormsByCategory` pure + tested → Task 1. ✓
- Visible "Current forms" list grouped by category, tappable to editor → Task 2. ✓
- "Edited" chip on customized forms → Task 2. ✓
- Custom-forms section retained → Task 2. ✓
- Shared `_openOverlayEditor` used by both the ✎ icon and the list → Task 2. ✓
- analyze + test + build → Task 3. ✓

**Placeholder scan:** No TBD/TODO; full code shown for every code step.

**Type consistency:** `groupFormsByCategory(List<FormMetadata>)` →
`Map<String, List<FormMetadata>>`, `loadEditedFormTypes()` → `Set<String>`,
`_openOverlayEditor(FormMetadata)` are used consistently across Tasks 1–2.
`_OverlayEditorScreen` + `_openEditor` + `_toggleActive` are existing members of
the screen reused unchanged.
```
