# SP7 — Analytics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans or subagent-driven-development. Steps use checkbox (`- [ ]`).

**Goal:** Admin analytics dashboard at `/analytics` — KPIs + hand-rolled bar/trend charts over forms, appointments, users/devices, signatures, with a date-range filter.

**Architecture:** A pure `computeAnalytics(...)` over date-windowed rows (client-side aggregation, mirroring `admin_dashboard_data.dart`) + an async `loadAnalytics({days})`. Two CustomPaint-free/CustomPaint chart widgets. A screen reusing `KpiStatCard`. No new deps, no migration.

**Tech Stack:** Flutter Material 3, `supabase_flutter`, `provider`, `go_router`.

## Global Constraints

- No new dependencies. No migration (read-only over existing tables). No "Claude"/AI naming. `dart format` touched files.
- Aggregation client-side; cap fetches at `.limit(5000)`. Admin-gated screen via `isAdminProfile`.
- Reuse `KpiStatCard` (`lib/widgets/admin/kpi_stat_card.dart`) + `MolTones.of(context)` (`.info/.success/.warning/.danger`, each `.tint/.accent/.fg`).
- Verify: `flutter analyze` + `flutter test` + `flutter build windows --release`.

## File Structure

- Create `lib/utils/analytics_data.dart` — `AnalyticsSummary` + `computeAnalytics` + `loadAnalytics` + `sortedDesc`.
- Create `lib/widgets/analytics/mini_bar_chart.dart`, `lib/widgets/analytics/trend_sparkline.dart`.
- Create `lib/screens/analytics_screen.dart`.
- Modify `lib/routing/router.dart` (real route).
- Create `test/analytics_test.dart`.

---

### Task 1: Data layer + tests (TDD)

**Files:** Create `lib/utils/analytics_data.dart`, `test/analytics_test.dart`.

**Interfaces:**
- `List<MapEntry<String,int>> sortedDesc(Map<String,int> m)`.
- `class AnalyticsSummary { formsTotal:int; formsChangePct:num?; formsByType/formsByStatus:Map<String,int>; formsPerDay:List<int>; apptTotal:int; apptByStatus/apptByRole:Map<String,int>; apptAcceptanceRate:double; profilesByAccountType:Map<String,int>; devicesTotal:int; devicesByPlatform:Map<String,int>; devicesPending:int; sigPendingByRole:Map<String,int>; sigCompletionRate:double; }`
- `AnalyticsSummary computeAnalytics({required DateTime now, required int days, required List<Map<String,dynamic>> submissions, required int priorSubmissionsCount, required List<Map<String,dynamic>> appointments, required List<Map<String,dynamic>> profiles, required List<Map<String,dynamic>> devices, required List<Map<String,dynamic>> signatureRequests})`.
- `Future<AnalyticsSummary> loadAnalytics({int days = 30})`.

- [ ] **Step 1: Failing tests**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/utils/analytics_data.dart';

void main() {
  final now = DateTime.utc(2026, 6, 22, 12);
  String iso(int dAgo) => now.subtract(Duration(days: dAgo)).toIso8601String();

  test('forms: counts by type/status, per-day, % change', () {
    final summary = computeAnalytics(
      now: now, days: 7, priorSubmissionsCount: 2,
      submissions: [
        {'form_type': 'early_shift_record', 'workflow_status': 'fully_signed', 'created_at': iso(0)},
        {'form_type': 'early_shift_record', 'workflow_status': 'submitted', 'created_at': iso(1)},
        {'form_type': 'gassing_incident', 'workflow_status': 'submitted', 'created_at': iso(0)},
      ],
      appointments: const [], profiles: const [], devices: const [], signatureRequests: const [],
    );
    expect(summary.formsTotal, 3);
    expect(summary.formsByType['early_shift_record'], 2);
    expect(summary.formsByStatus['submitted'], 2);
    expect(summary.formsPerDay.length, 7);
    expect(summary.formsPerDay.last, 2); // today (dAgo 0): 2 submissions
    expect(summary.formsChangePct, 50); // (3-2)/2*100
  });

  test('appointments: status/role + acceptance rate', () {
    final s = computeAnalytics(
      now: now, days: 30, priorSubmissionsCount: 0, submissions: const [],
      appointments: [
        {'status': 'active', 'role_code': '2.13.1', 'accepted_at': iso(1)},
        {'status': 'declined', 'role_code': '2.13.1', 'accepted_at': null},
      ],
      profiles: const [], devices: const [], signatureRequests: const [],
    );
    expect(s.apptTotal, 2);
    expect(s.apptByRole['2.13.1'], 2);
    expect(s.apptAcceptanceRate, 0.5);
  });

  test('signatures completion + devices pending', () {
    final s = computeAnalytics(
      now: now, days: 30, priorSubmissionsCount: 0, submissions: const [], appointments: const [],
      profiles: [{'user_account_type': 'Shift Boss'}, {'user_account_type': 'Shift Boss'}],
      devices: [{'platform': 'windows', 'approved': false, 'is_active': true}],
      signatureRequests: [{'requested_role': 'Mine Overseer', 'status': 'signed'}, {'requested_role': 'Mine Overseer', 'status': 'pending'}],
    );
    expect(s.profilesByAccountType['Shift Boss'], 2);
    expect(s.devicesPending, 1);
    expect(s.sigPendingByRole['Mine Overseer'], 1);
    expect(s.sigCompletionRate, 0.5);
  });

  test('sortedDesc', () {
    expect(sortedDesc({'a': 1, 'b': 3, 'c': 2}).map((e) => e.key).toList(), ['b', 'c', 'a']);
  });
}
```

- [ ] **Step 2: Run → fail.** `flutter test test/analytics_test.dart`
- [ ] **Step 3: Implement** `lib/utils/analytics_data.dart`:
  - `sortedDesc` sorts entries by value desc (stable enough).
  - `computeAnalytics`: increment maps; `formsPerDay` = list of length `days`, index 0 = oldest day, last = today, bucket each submission by `now.difference(created).inDays` (skip out-of-range); `formsChangePct` = `priorSubmissionsCount == 0 ? null-or-100 : (formsTotal - prior)/prior*100` (use `priorSubmissionsCount==0 ? null : ...`; test passes prior=2 → 50). For the appointments test prior=0 and submissions empty → formsChangePct null (not asserted). Parse dates with `DateTime.parse(...).toUtc()`. Rates: `total==0 ? 0.0 : matched/total`.
  - `loadAnalytics`: fetch current-window submissions (`created_at >= now-days`), prior-window count (`created_at in [now-2d, now-d)`), appointments (`issued_at >= now-days`), all profiles (account types), all devices, signature_requests (`created_at >= now-days`); `.limit(5000)`; call compute with `now = DateTime.now().toUtc()`.
- [ ] **Step 4: Run → pass.**
- [ ] **Step 5: Format + commit** `SP7: analytics data layer + computeAnalytics tests (TDD)`.

### Task 2: Chart widgets

**Files:** Create `lib/widgets/analytics/mini_bar_chart.dart`, `lib/widgets/analytics/trend_sparkline.dart`.

- [ ] **MiniBarChart** — `MiniBarChart({required List<MapEntry<String,int>> data, required Color color, int maxBars = 6})`: for the top `maxBars` entries render a `Row(label 120px, Expanded(stack: track + FractionallySizedBox bar width = value/max), value)`. Empty data → a muted "No data" text.
- [ ] **TrendSparkline** — `TrendSparkline({required List<int> values, required Color color, double height = 48})`: a `CustomPaint` drawing an area+line across the values (normalized to max); flat baseline when all zero.
- [ ] **Analyze** → clean. **Format + commit** `SP7: mini bar chart + trend sparkline widgets`.

### Task 3: Screen + route

**Files:** Create `lib/screens/analytics_screen.dart`; Modify `lib/routing/router.dart`.

- [ ] **Build** `AnalyticsScreen` (admin-gated; mirror `appointments_admin_screen.dart` scaffolding): state `_days` (default 30), `_summary`, `_loading`, `_error`. `initState`→`_load()`; range `ChoiceChip`s (7/30/90/365) re-load. Sections as `Card`s:
  - **Forms**: a `Wrap` of `KpiStatCard`s (Total `formsTotal` info; plus a small "vs prev" text using `formsChangePct`); `TrendSparkline(formsPerDay)`; `MiniBarChart(sortedDesc(formsByType))`; status `MiniBarChart(sortedDesc(formsByStatus))`.
  - **Appointments**: `KpiStatCard`s (Total; Acceptance `${(rate*100).round()}%` — KpiStatCard takes int value, so show via a small stat row instead for the %); `MiniBarChart(apptByStatus)` + `MiniBarChart(apptByRole)`.
  - **Users & Devices**: `MiniBarChart(profilesByAccountType)`; devices KPI (`devicesTotal`, `devicesPending`) + `MiniBarChart(devicesByPlatform)`.
  - **Signatures**: completion-rate stat + `MiniBarChart(sigPendingByRole)`.
  - Use `MolTones.of(context)` for tones; `PageBody.list`; Refresh action + `commonAppBarActions()`.
- [ ] **Route**: import `AnalyticsScreen`; add `GoRoute(path: '/analytics', builder: (_, __) => const AnalyticsScreen())`; remove `/analytics` from `_placeholders()`.
- [ ] **Analyze** → clean. **Format + commit** `SP7: analytics screen + live /analytics route`.

### Task 4: Verify + merge

- [ ] `flutter analyze` clean; `flutter test` green; `flutter build windows --release`.
- [ ] Update `HANDOFF.md` + memory (SP7 done; next SP8). Merge `sp7-analytics` → main; push; delete branch.

## Self-Review

**Spec coverage:** data layer + pure compute + loader (T1) ✓; hand-rolled charts no-dep (T2) ✓; four sections + range filter + KPI reuse (T3) ✓; route (T3) ✓; tests (T1) ✓; no migration/deps ✓; system-perf out of scope (not built) ✓.

**Placeholder scan:** all code shown or precisely specified (screen enumerates each section's widgets); no TBDs.

**Type consistency:** `AnalyticsSummary` fields + `computeAnalytics`/`loadAnalytics`/`sortedDesc` signatures (T1) used in T3. `MiniBarChart({data:List<MapEntry<String,int>>, color, maxBars})` + `TrendSparkline({values:List<int>, color})` (T2) match T3 usage. `KpiStatCard(label,value:int,icon,tone,loading)` reused per its real signature.
