# SP4 — Appointments Lifecycle Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Issue appointments from SP3 templates to people, have them accept-and-sign, co-sign via the existing Mine Overseer/Mine Manager chain, go active, and resign — with one-live-per-person/role/shaft/month enforced.

**Architecture:** A new `appointments` lifecycle table + two SECURITY DEFINER triggers (lifecycle notifications; auto-activate when the linked co-sign submission is fully signed). Acceptance reuses `saveFormSubmissionAndStartWorkflow` + `applyCustomChainSignatureFields` so the **existing** `signature-workflow` edge function drives co-signing — it is not modified. Two screens: admin issue+monitor (`/setup/appointments`) and appointee inbox (`/my-appointments`).

**Tech Stack:** Flutter (Material 3), `provider`, `go_router`, `supabase_flutter`, `pdf`+`printing`, `signature`. No new dependencies.

## Global Constraints

- Windows + Android only. No new dependencies.
- No "Claude"/AI naming in code, UI strings, comments, or DB data.
- Git: never `git add -A`/`.`/`reset --hard`/`clean`. Stage explicit paths only.
- Supabase: write the migration in `supabase/migrations/` AND apply via Management API (PAT in Windows Credential Manager `claude-supabase-pat-hhrnkzznpadrmyverhyb`, project ref `hhrnkzznpadrmyverhyb`). RLS gate `public.is_admin(auth.uid())`.
- All PKs uuid. FKs: `appointee_id`/`issued_by` → `public.profiles(id)`, `shaft_id` → `public.shafts(id)`, `template_id`→`appointment_templates(id)`, `role_id`→`appointment_roles(id)`, `submission_id`→`form_submissions(id)`.
- `notifications` insert columns: `user_id` (uuid, req), `type` (varchar, default 'system'), `title` (varchar, req), `body` (text, default ''), `action_url` (text), `metadata` (jsonb default '{}').
- Verify: `flutter analyze` clean, `flutter test` green (current 56), `flutter build windows --release`. `dart format` touched files before commit.

## File Structure

- Create `supabase/migrations/20260621140000_create_appointments.sql` — table, generated `period_month`, partial unique index, RLS, 2 triggers.
- Create `lib/models/appointment.dart` — `AppointmentStatus` enum, `Appointment` model, pure helpers (`isLiveStatus`, `mergeLetterValues`), validation.
- Create `lib/utils/appointment_data.dart` — issue/accept/decline/resign + loads + uniqueness pre-check + standard-token builder.
- Modify `lib/utils/form_registry.dart` — `appt_` branch in `generatePdfForFormType`.
- Create `lib/screens/setup/appointments_admin_screen.dart` — admin issue + monitor.
- Create `lib/screens/my_appointments_screen.dart` — appointee inbox.
- Modify `lib/screens/signature_requests_screen.dart` — `appt_` request → "View letter PDF", hide form-view button.
- Modify `lib/routing/router.dart` — add `/setup/appointments` + `/my-appointments`.
- Modify `lib/widgets/admin/admin_sidebar.dart` — add "Appointments" + "My Appointments" leaves.
- Modify `lib/screens/appointments_screen.dart` — "My Appointments" entry card (discoverability for non-admins).
- Create `test/appointment_lifecycle_test.dart`.

---

### Task 1: Database migration (table + RLS + uniqueness + triggers)

**Files:** Create `supabase/migrations/20260621140000_create_appointments.sql`

**Interfaces:**
- Produces: table `public.appointments`; partial unique index `appointments_one_live_per_slot`; triggers `appointments_notify` (on appointments) + `appointments_activate_on_signoff` (on form_submissions).

- [ ] **Step 1: Write the migration**

```sql
-- SP4 Appointments lifecycle: issued appointments + accept/sign/co-sign/resign.
-- Co-signing reuses the signature-workflow edge function via form_submissions;
-- this migration adds the lifecycle record + notification/activation triggers.

create table if not exists public.appointments (
  id              uuid primary key default gen_random_uuid(),
  template_id     uuid references public.appointment_templates(id) on delete set null,
  role_id         uuid references public.appointment_roles(id) on delete set null,
  role_code       text not null,
  appointee_id    uuid not null references public.profiles(id) on delete cascade,
  issued_by       uuid references public.profiles(id) on delete set null,
  shaft_id        uuid references public.shafts(id) on delete set null,
  section         text,
  cycle           text,
  effective_date  date not null,
  period_month    date generated always as (date_trunc('month', effective_date)::date) stored,
  status          text not null default 'pending_acceptance'
                    check (status in ('pending_acceptance','pending_signoff','active','declined','resigned')),
  payload         jsonb not null default '{}'::jsonb,
  submission_id   uuid references public.form_submissions(id) on delete set null,
  resign_reason   text,
  issued_at       timestamptz not null default now(),
  accepted_at     timestamptz,
  declined_at     timestamptz,
  activated_at    timestamptz,
  resigned_at     timestamptz,
  updated_at      timestamptz not null default now()
);

create index if not exists appointments_appointee_idx
  on public.appointments (appointee_id, status);
create index if not exists appointments_submission_idx
  on public.appointments (submission_id);
create unique index if not exists appointments_one_live_per_slot
  on public.appointments (appointee_id, role_code, shaft_id, period_month)
  where status in ('pending_acceptance','pending_signoff','active');

alter table public.appointments enable row level security;

create policy "Read own or admin appointments"
  on public.appointments for select to authenticated
  using (appointee_id = auth.uid() or public.is_admin(auth.uid()));
create policy "Admins insert appointments"
  on public.appointments for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admin or appointee update appointments"
  on public.appointments for update to authenticated
  using (appointee_id = auth.uid() or public.is_admin(auth.uid()))
  with check (appointee_id = auth.uid() or public.is_admin(auth.uid()));

-- Lifecycle notifications (cross-user inserts need definer rights).
create or replace function public.appointments_notify()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT') then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    values (new.appointee_id, 'message', 'New appointment',
            coalesce(new.role_code,'Appointment') || ' appointment pending your acceptance',
            '/my-appointments',
            jsonb_build_object('appointmentId', new.id, 'roleCode', new.role_code, 'status', new.status));
    return new;
  elsif (tg_op = 'UPDATE' and new.status is distinct from old.status) then
    if (new.status in ('pending_signoff','active') and old.status = 'pending_acceptance' and new.issued_by is not null) then
      insert into public.notifications (user_id, type, title, body, action_url, metadata)
      values (new.issued_by, 'success', 'Appointment accepted',
              'An appointee accepted their ' || coalesce(new.role_code,'') || ' appointment',
              '/setup/appointments',
              jsonb_build_object('appointmentId', new.id, 'status', new.status));
    elsif (new.status = 'declined' and new.issued_by is not null) then
      insert into public.notifications (user_id, type, title, body, action_url, metadata)
      values (new.issued_by, 'warning', 'Appointment declined',
              'An appointee declined their ' || coalesce(new.role_code,'') || ' appointment',
              '/setup/appointments',
              jsonb_build_object('appointmentId', new.id, 'status', new.status));
    elsif (new.status = 'resigned' and new.issued_by is not null) then
      insert into public.notifications (user_id, type, title, body, action_url, metadata)
      values (new.issued_by, 'warning', 'Appointment resigned',
              coalesce(new.role_code,'') || ' appointment resigned',
              '/setup/appointments',
              jsonb_build_object('appointmentId', new.id, 'status', new.status, 'reason', coalesce(new.resign_reason,'')));
    end if;
    return new;
  end if;
  return new;
end $$;

drop trigger if exists trg_appointments_notify on public.appointments;
create trigger trg_appointments_notify
  after insert or update of status on public.appointments
  for each row execute function public.appointments_notify();

-- Flip a pending_signoff appointment to active when its co-sign submission completes.
create or replace function public.appointments_activate_on_signoff()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (new.workflow_status = 'fully_signed' and old.workflow_status is distinct from 'fully_signed') then
    update public.appointments
       set status = 'active', activated_at = now(), updated_at = now()
     where submission_id = new.id and status = 'pending_signoff';
  end if;
  return new;
end $$;

drop trigger if exists trg_appointments_activate on public.form_submissions;
create trigger trg_appointments_activate
  after update of workflow_status on public.form_submissions
  for each row execute function public.appointments_activate_on_signoff();
```

- [ ] **Step 2: Apply via Management API** (read PAT from Credential Manager, POST to `/v1/projects/hhrnkzznpadrmyverhyb/database/query`). Expected: 200/201.

- [ ] **Step 3: Verify** — `select to_regclass('public.appointments');` non-null; `select tgname from pg_trigger where tgname in ('trg_appointments_notify','trg_appointments_activate');` returns 2 rows; `select indexname from pg_indexes where indexname='appointments_one_live_per_slot';` returns 1.

- [ ] **Step 4: Commit**

```bash
git add supabase/migrations/20260621140000_create_appointments.sql
git commit -m "SP4: appointments table + RLS + uniqueness + lifecycle triggers"
```

---

### Task 2: Model + unit tests (TDD)

**Files:** Create `lib/models/appointment.dart`; Test `test/appointment_lifecycle_test.dart`

**Interfaces:**
- Produces:
  - `enum AppointmentStatus { pendingAcceptance, pendingSignoff, active, declined, resigned }` with `String get wire`, `static AppointmentStatus fromWire(String)`, `String get label`.
  - `bool isLiveStatus(AppointmentStatus s)` — true for pendingAcceptance/pendingSignoff/active.
  - `Map<String,String> mergeLetterValues(Map<String,String> standard, Map<String,String> fieldValues)` — field keys win.
  - `class Appointment` with `fromMap`/`toMap`, getters `canAccept` (status==pendingAcceptance), `canResign` (status∈{pendingSignoff,active}), `canDecline` (status==pendingAcceptance).

- [ ] **Step 1: Write the failing tests**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mine_online/models/appointment.dart';

void main() {
  group('AppointmentStatus', () {
    test('wire/fromWire round-trip', () {
      for (final s in AppointmentStatus.values) {
        expect(AppointmentStatus.fromWire(s.wire), s);
      }
    });
    test('fromWire falls back to pendingAcceptance on junk', () {
      expect(AppointmentStatus.fromWire('nonsense'), AppointmentStatus.pendingAcceptance);
    });
  });

  group('isLiveStatus', () {
    test('live for acceptance/signoff/active, not declined/resigned', () {
      expect(isLiveStatus(AppointmentStatus.pendingAcceptance), true);
      expect(isLiveStatus(AppointmentStatus.pendingSignoff), true);
      expect(isLiveStatus(AppointmentStatus.active), true);
      expect(isLiveStatus(AppointmentStatus.declined), false);
      expect(isLiveStatus(AppointmentStatus.resigned), false);
    });
  });

  group('mergeLetterValues', () {
    test('field keys take precedence over standard tokens', () {
      final out = mergeLetterValues({'section': 'Std'}, {'section': 'Field'});
      expect(out['section'], 'Field');
    });
    test('union of both maps', () {
      final out = mergeLetterValues({'full_name': 'Jane'}, {'area': 'A'});
      expect(out['full_name'], 'Jane');
      expect(out['area'], 'A');
    });
  });

  group('Appointment transitions', () {
    Appointment make(AppointmentStatus s) => Appointment.fromMap({
          'id': 'a', 'role_code': 'R', 'appointee_id': 'u', 'effective_date': '2026-06-21',
          'status': s.wire, 'payload': {}, 'issued_at': '2026-06-21T00:00:00Z',
        });
    test('canAccept/canDecline only when pending_acceptance', () {
      expect(make(AppointmentStatus.pendingAcceptance).canAccept, true);
      expect(make(AppointmentStatus.active).canAccept, false);
      expect(make(AppointmentStatus.pendingAcceptance).canDecline, true);
    });
    test('canResign when pending_signoff or active', () {
      expect(make(AppointmentStatus.active).canResign, true);
      expect(make(AppointmentStatus.pendingSignoff).canResign, true);
      expect(make(AppointmentStatus.declined).canResign, false);
    });
  });
}
```

- [ ] **Step 2: Run to verify fail** — `flutter test test/appointment_lifecycle_test.dart` → FAIL (URI/symbols undefined).

- [ ] **Step 3: Write the model**

```dart
// SP4 Appointments lifecycle model. Pure data + transitions; no Flutter/Supabase
// deps so it is fully unit-testable.

enum AppointmentStatus { pendingAcceptance, pendingSignoff, active, declined, resigned }

extension AppointmentStatusX on AppointmentStatus {
  String get wire {
    switch (this) {
      case AppointmentStatus.pendingAcceptance:
        return 'pending_acceptance';
      case AppointmentStatus.pendingSignoff:
        return 'pending_signoff';
      case AppointmentStatus.active:
        return 'active';
      case AppointmentStatus.declined:
        return 'declined';
      case AppointmentStatus.resigned:
        return 'resigned';
    }
  }

  String get label {
    switch (this) {
      case AppointmentStatus.pendingAcceptance:
        return 'Pending acceptance';
      case AppointmentStatus.pendingSignoff:
        return 'Awaiting sign-off';
      case AppointmentStatus.active:
        return 'Active';
      case AppointmentStatus.declined:
        return 'Declined';
      case AppointmentStatus.resigned:
        return 'Resigned';
    }
  }

  static AppointmentStatus fromWire(String s) => AppointmentStatus.values.firstWhere(
        (v) => v.wire == s,
        orElse: () => AppointmentStatus.pendingAcceptance,
      );
}

bool isLiveStatus(AppointmentStatus s) =>
    s == AppointmentStatus.pendingAcceptance ||
    s == AppointmentStatus.pendingSignoff ||
    s == AppointmentStatus.active;

/// Letter token values: standard profile tokens overlaid by template field values
/// (field keys win on collision).
Map<String, String> mergeLetterValues(
  Map<String, String> standard,
  Map<String, String> fieldValues,
) => {...standard, ...fieldValues};

class Appointment {
  const Appointment({
    required this.id,
    required this.templateId,
    required this.roleId,
    required this.roleCode,
    required this.appointeeId,
    required this.issuedBy,
    required this.shaftId,
    required this.section,
    required this.cycle,
    required this.effectiveDate,
    required this.status,
    required this.payload,
    required this.submissionId,
    required this.resignReason,
    required this.issuedAt,
    required this.acceptedAt,
    required this.activatedAt,
    required this.resignedAt,
  });

  final String id;
  final String? templateId;
  final String? roleId;
  final String roleCode;
  final String appointeeId;
  final String? issuedBy;
  final String? shaftId;
  final String? section;
  final String? cycle;
  final DateTime effectiveDate;
  final AppointmentStatus status;
  final Map<String, dynamic> payload;
  final String? submissionId;
  final String? resignReason;
  final DateTime issuedAt;
  final DateTime? acceptedAt;
  final DateTime? activatedAt;
  final DateTime? resignedAt;

  bool get canAccept => status == AppointmentStatus.pendingAcceptance;
  bool get canDecline => status == AppointmentStatus.pendingAcceptance;
  bool get canResign =>
      status == AppointmentStatus.pendingSignoff || status == AppointmentStatus.active;

  static DateTime _d(dynamic v) => DateTime.parse(v as String);
  static DateTime? _dn(dynamic v) => v == null ? null : DateTime.parse(v as String);

  factory Appointment.fromMap(Map<String, dynamic> m) => Appointment(
        id: (m['id'] ?? '') as String,
        templateId: m['template_id'] as String?,
        roleId: m['role_id'] as String?,
        roleCode: (m['role_code'] ?? '') as String,
        appointeeId: (m['appointee_id'] ?? '') as String,
        issuedBy: m['issued_by'] as String?,
        shaftId: m['shaft_id'] as String?,
        section: m['section'] as String?,
        cycle: m['cycle'] as String?,
        effectiveDate: _d(m['effective_date']),
        status: AppointmentStatusX.fromWire((m['status'] ?? 'pending_acceptance') as String),
        payload: (m['payload'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{},
        submissionId: m['submission_id'] as String?,
        resignReason: m['resign_reason'] as String?,
        issuedAt: _d(m['issued_at']),
        acceptedAt: _dn(m['accepted_at']),
        activatedAt: _dn(m['activated_at']),
        resignedAt: _dn(m['resigned_at']),
      );

  Map<String, dynamic> toMap() => {
        'template_id': templateId,
        'role_id': roleId,
        'role_code': roleCode,
        'appointee_id': appointeeId,
        'issued_by': issuedBy,
        'shaft_id': shaftId,
        'section': section,
        'cycle': cycle,
        'effective_date': effectiveDate.toIso8601String().substring(0, 10),
        'status': status.wire,
        'payload': payload,
        'submission_id': submissionId,
        'resign_reason': resignReason,
      };
}
```

- [ ] **Step 4: Run to verify pass** — `flutter test test/appointment_lifecycle_test.dart` → PASS.

- [ ] **Step 5: Format + commit**

```bash
dart format lib/models/appointment.dart test/appointment_lifecycle_test.dart
git add lib/models/appointment.dart test/appointment_lifecycle_test.dart
git commit -m "SP4: appointment lifecycle model + transition tests (TDD)"
```

---

### Task 3: Data layer

**Files:** Create `lib/utils/appointment_data.dart`

**Interfaces:**
- Consumes: `supabase`; `Appointment`/`AppointmentStatus`; `AppointmentTemplate`/`AppointmentRole` (SP3); `UserProfile`; `applyCustomChainSignatureFields`, `buildSubmissionPayload`; `saveFormSubmissionAndStartWorkflow`; `kStandardLetterTokens`, `mergeLetterValues`.
- Produces:
  - `Future<List<Appointment>> loadAllAppointments()` (admin) / `Future<List<Appointment>> loadMyAppointments()`.
  - `Future<String?> appointmentUniquenessConflict({required String appointeeId, required String roleCode, required String? shaftId, required DateTime effectiveDate})` — returns a human message if a live row exists, else null.
  - `Future<void> issueAppointment({required AppointmentTemplate template, required AppointmentRole? role, required UserProfile appointee, required String? shaftId, String? section, String? cycle, required DateTime effectiveDate, required Map<String,dynamic> fieldValues})`.
  - `Future<void> acceptAppointment({required Appointment appt, required AppointmentTemplate template, required UserProfile me, required String signature})`.
  - `Future<void> declineAppointment(Appointment appt)`.
  - `Future<void> resignAppointment(Appointment appt, String reason)`.
  - `Map<String,String> standardLetterTokens(UserProfile p, {String? section, required DateTime effectiveDate})`.

- [ ] **Step 1: Write the data layer**

```dart
// Supabase data access for the appointments lifecycle (SP4). Co-signing reuses
// saveFormSubmissionAndStartWorkflow + the signature-workflow edge function.

import '../config/supabase_client.dart';
import '../models/appointment.dart';
import '../models/appointment_template.dart';
import '../models/user_profile.dart';
import 'dynamic_form_payload.dart' show applyCustomChainSignatureFields, buildSubmissionPayload;
import 'signature_workflow.dart';

String _nowUtc() => DateTime.now().toUtc().toIso8601String();
String _dateOnly(DateTime d) => d.toIso8601String().substring(0, 10);

Future<List<Appointment>> loadAllAppointments() async {
  final rows = await supabase.from('appointments').select().order('issued_at', ascending: false);
  return (rows as List).cast<Map<String, dynamic>>().map(Appointment.fromMap).toList();
}

Future<List<Appointment>> loadMyAppointments() async {
  final uid = supabase.auth.currentUser?.id;
  if (uid == null) return const [];
  final rows = await supabase
      .from('appointments')
      .select()
      .eq('appointee_id', uid)
      .order('issued_at', ascending: false);
  return (rows as List).cast<Map<String, dynamic>>().map(Appointment.fromMap).toList();
}

Future<String?> appointmentUniquenessConflict({
  required String appointeeId,
  required String roleCode,
  required String? shaftId,
  required DateTime effectiveDate,
}) async {
  final periodStart = DateTime(effectiveDate.year, effectiveDate.month, 1);
  final periodEnd = DateTime(effectiveDate.year, effectiveDate.month + 1, 1);
  var q = supabase
      .from('appointments')
      .select('id')
      .eq('appointee_id', appointeeId)
      .eq('role_code', roleCode)
      .inFilter('status', ['pending_acceptance', 'pending_signoff', 'active'])
      .gte('effective_date', _dateOnly(periodStart))
      .lt('effective_date', _dateOnly(periodEnd));
  if (shaftId != null) q = q.eq('shaft_id', shaftId);
  final rows = await q.limit(1);
  if ((rows as List).isNotEmpty) {
    return 'This person already has a live "$roleCode" appointment for this shaft this month.';
  }
  return null;
}

/// Standard letter tokens resolved from the appointee profile + issue context.
Map<String, String> standardLetterTokens(
  UserProfile p, {
  String? section,
  required DateTime effectiveDate,
}) {
  final full = p.fullName.trim();
  final first = p.firstName.trim();
  final last = full.startsWith(first) ? full.substring(first.length).trim() : '';
  return {
    'full_name': full,
    'first_name': first,
    'last_name': last,
    'employee_number': p.employeeNumber ?? '',
    'id_number': p.saIdNumber ?? '',
    'occupation': p.occupation ?? '',
    'section': section ?? p.sectionShaft ?? '',
    'company': p.company ?? '',
    'date': _dateOnly(effectiveDate),
  };
}

Future<void> issueAppointment({
  required AppointmentTemplate template,
  required AppointmentRole? role,
  required UserProfile appointee,
  required String? shaftId,
  String? section,
  String? cycle,
  required DateTime effectiveDate,
  required Map<String, dynamic> fieldValues,
}) async {
  final fieldPayload = buildSubmissionPayload(template.fields, fieldValues);
  final fieldStrings = <String, String>{
    for (final e in fieldPayload.entries) e.key: '${e.value}',
  };
  final letterValues = mergeLetterValues(
    standardLetterTokens(appointee, section: section, effectiveDate: effectiveDate),
    fieldStrings,
  );
  final payload = <String, dynamic>{
    'fields': fieldPayload,
    'letterValues': letterValues,
    'signatures': <String, dynamic>{},
  };
  await supabase.from('appointments').insert({
    'template_id': template.id,
    'role_id': role?.id ?? template.roleId,
    'role_code': role?.code ?? role?.label ?? template.name,
    'appointee_id': appointee.id,
    'issued_by': supabase.auth.currentUser?.id,
    'shaft_id': shaftId,
    'section': section,
    'cycle': cycle,
    'effective_date': _dateOnly(effectiveDate),
    'status': 'pending_acceptance',
    'payload': payload,
  });
}

Future<void> acceptAppointment({
  required Appointment appt,
  required AppointmentTemplate template,
  required UserProfile me,
  required String signature,
}) async {
  final payload = Map<String, dynamic>.from(appt.payload);
  final sig = (payload['signatures'] is Map)
      ? Map<String, dynamic>.from(payload['signatures'] as Map)
      : <String, dynamic>{};
  sig['appointeeSignature'] = signature;
  sig['appointeeDate'] = _dateOnly(DateTime.now());
  payload['signatures'] = sig;

  final hasCosign = applyCustomChainSignatureFields(template.requiredSigners, payload);

  if (!hasCosign) {
    await supabase.from('appointments').update({
      'status': 'active',
      'payload': payload,
      'accepted_at': _nowUtc(),
      'activated_at': _nowUtc(),
      'updated_at': _nowUtc(),
    }).eq('id', appt.id);
    return;
  }

  final title = 'Appointment: ${appt.roleCode} — ${me.fullName}';
  final submissionId = await saveFormSubmissionAndStartWorkflow(
    template.code,
    title,
    payload,
    profile: me,
  );
  await supabase.from('appointments').update({
    'status': 'pending_signoff',
    'payload': payload,
    'submission_id': submissionId,
    'accepted_at': _nowUtc(),
    'updated_at': _nowUtc(),
  }).eq('id', appt.id);
}

Future<void> declineAppointment(Appointment appt) async {
  await supabase.from('appointments').update({
    'status': 'declined',
    'declined_at': _nowUtc(),
    'updated_at': _nowUtc(),
  }).eq('id', appt.id);
}

Future<void> resignAppointment(Appointment appt, String reason) async {
  await supabase.from('appointments').update({
    'status': 'resigned',
    'resigned_at': _nowUtc(),
    'resign_reason': reason,
    'updated_at': _nowUtc(),
  }).eq('id', appt.id);
}
```

- [ ] **Step 2: Analyze** — `flutter analyze lib/utils/appointment_data.dart`. Resolve any Supabase query-builder type issues (e.g. `inFilter` chain typing — if the chained `.eq` after `.inFilter` complains, build the filter before `.limit`). Expected: No issues.

- [ ] **Step 3: Format + commit**

```bash
dart format lib/utils/appointment_data.dart
git add lib/utils/appointment_data.dart
git commit -m "SP4: appointments data layer (issue/accept/decline/resign + uniqueness)"
```

---

### Task 4: Letter PDF branch in form_registry

**Files:** Modify `lib/utils/form_registry.dart`

**Interfaces:**
- Consumes: `loadAppointmentTemplateByCode` (add to SP3 data layer if absent — see step), `generateAppointmentLetterPdf`, `loadAppointmentRoles`.
- Produces: `generatePdfForFormType` handles `appt_` prefixed types.

- [ ] **Step 1: Add a code-lookup to SP3 data layer if missing**

In `lib/utils/appointment_template_data.dart` add:

```dart
Future<AppointmentTemplate?> loadAppointmentTemplateByCode(String code) async {
  final rows = await supabase.from('appointment_templates').select().eq('code', code).limit(1);
  final list = (rows as List).cast<Map<String, dynamic>>();
  return list.isEmpty ? null : AppointmentTemplate.fromMap(list.first);
}
```

- [ ] **Step 2: Add the branch** in `generatePdfForFormType` (before the existing `custom_`/switch handling), reading `payload['letterValues']`:

```dart
if (formType.startsWith('appt_')) {
  final template = await loadAppointmentTemplateByCode(formType);
  if (template == null) return null;
  final lv = (payload['letterValues'] as Map?)?.cast<String, dynamic>() ?? const {};
  final values = <String, String>{for (final e in lv.entries) e.key: '${e.value}'};
  AppointmentRole? role;
  if (template.roleId != null) {
    final roles = await loadAppointmentRoles(includeArchived: true);
    for (final r in roles) {
      if (r.id == template.roleId) { role = r; break; }
    }
  }
  return generateAppointmentLetterPdf(template, values, role: role);
}
```

Add imports for `appointment_template_data.dart`, `appointment_template.dart`, `generate_appointment_letter_pdf.dart` as needed.

- [ ] **Step 3: Analyze** — `flutter analyze lib/utils/form_registry.dart lib/utils/appointment_template_data.dart`. Expected: No issues.

- [ ] **Step 4: Format + commit**

```bash
dart format lib/utils/form_registry.dart lib/utils/appointment_template_data.dart
git add lib/utils/form_registry.dart lib/utils/appointment_template_data.dart
git commit -m "SP4: render appointment letter PDF for appt_ submissions"
```

---

### Task 5: Admin issue + monitor screen

**Files:** Create `lib/screens/setup/appointments_admin_screen.dart`

**Interfaces:**
- Consumes: `loadAllAppointments`, `issueAppointment`, `resignAppointment`, `appointmentUniquenessConflict`; SP3 `loadAppointmentTemplates`/`loadAppointmentRoles`; `loadShafts` (org_data) + `loadProfilesForPicker` (see note); `generatePdfForFormType`; `isAdminProfile`; `PageBody`, `commonAppBarActions`, `Printing`, `DatePickerField`, `FieldEditorList` is NOT used here (we render INPUTS, not field editors — build inputs from `template.fields`).
- Produces: `class AppointmentsAdminScreen extends StatefulWidget`.

- [ ] **Step 1: Build the screen**

Structure (mirror `appointment_builder_screen.dart` for the list + admin gate; mirror `form_builder`/`custom_forms` fill screens for dynamic inputs):
- `AppointmentsAdminScreen` — admin gate; load appointments + templates + roles + shafts; status filter `FilterChip`s (All / Pending / Awaiting sign-off / Active / Declined / Resigned); list Cards (appointee name via a profiles lookup map, role, status badge, effective date); FAB "Issue appointment"; row PopupMenu: "View letter PDF" (→ `generatePdfForFormType(submissionFormTypeOrTemplateCode, appt.payload)` using the template `code`), "Resign" (reason dialog → `resignAppointment`).
- Appointee/profiles list: query `profiles` (id, full_name) for the picker — add a small helper in this file: `Future<List<({String id, String name})>> _loadProfiles()` selecting `id, full_name` ordered by `full_name`. (Mirrors how `profiles_screen.dart` loads people.)
- `_IssueAppointmentDialog` (full-screen dialog or pushed route): template `DropdownButtonFormField` (active templates) → on pick, render its `fields` as inputs (text/multiline/number/date/dropdown/boolean) into a `Map<String,dynamic> _values`; appointee `DropdownButtonFormField` (profiles); shaft `DropdownButtonFormField` (active shafts); section + cycle `TextField`; effective date via `DatePickerField`. On "Issue": run `appointmentUniquenessConflict`; if message, show dialog; else `issueAppointment(...)`, pop, reload.

For dynamic inputs reuse the input-building approach already used by the custom-forms fill screen — read `lib/screens/custom_forms_screen.dart` for the field→widget switch and copy its shape (text controllers per key, dropdowns, switches, date pickers). Keep section fields as headings.

PDF view uses the template `code` as form_type: `generatePdfForFormType(template.code, appt.payload)`.

- [ ] **Step 2: Analyze** — `flutter analyze lib/screens/setup/appointments_admin_screen.dart`. Expected: No issues.

- [ ] **Step 3: Format + commit**

```bash
dart format lib/screens/setup/appointments_admin_screen.dart
git add lib/screens/setup/appointments_admin_screen.dart
git commit -m "SP4: admin issue + monitor appointments screen"
```

---

### Task 6: Appointee inbox screen

**Files:** Create `lib/screens/my_appointments_screen.dart`

**Interfaces:**
- Consumes: `loadMyAppointments`, `acceptAppointment`, `declineAppointment`, `resignAppointment`; `loadAppointmentTemplateByCode`/`loadAppointmentTemplates`; `generatePdfForFormType`; `SignatureCanvasField`; `AuthProvider` (current `UserProfile`); `PageBody`, `commonAppBarActions`, `Printing`, `go_router`.
- Produces: `class MyAppointmentsScreen extends StatefulWidget` (no admin gate).

- [ ] **Step 1: Build the screen**

- Load the user's appointments + a `Map<String,AppointmentTemplate>` by code/id for the templates referenced (load active templates once, index by id). For each appointment, the template is needed at accept time (its `requiredSigners` + `code`).
- Cards per appointment: title = role + status badge; subtitle = effective date + section.
  - `canAccept` → "Accept & sign" + "Decline". "Accept & sign" opens a dialog with a `SignatureCanvasField` prefilled from `profile.signatureData` (value: profile.signatureData ?? ''); on confirm with a non-empty signature → `acceptAppointment(appt, template, me, signature)`; if signature empty and profile has none, block with a message. "Decline" → confirm → `declineAppointment`.
  - `canResign` → "View letter" (→ `generatePdfForFormType(template.code, appt.payload)`) + "Resign" (reason dialog → `resignAppointment`).
  - `pending_signoff` → show "Awaiting Mine Overseer / Mine Manager sign-off" hint + a button to `/signature-requests` for visibility.
- On any action, reload.

- [ ] **Step 2: Analyze** — `flutter analyze lib/screens/my_appointments_screen.dart`. Expected: No issues.

- [ ] **Step 3: Format + commit**

```bash
dart format lib/screens/my_appointments_screen.dart
git add lib/screens/my_appointments_screen.dart
git commit -m "SP4: my-appointments inbox (accept/sign/decline/resign)"
```

---

### Task 7: Signature-requests screen appt_ handling

**Files:** Modify `lib/screens/signature_requests_screen.dart`

**Interfaces:** Consumes `generatePdfForFormType` (already used). For requests whose submission `form_type` starts with `appt_`, the "Open form (view mode)" button must be hidden (no form view widget for appointments); "View PDF" already works via the Task 4 branch.

- [ ] **Step 1: Read the screen** to find where it renders the per-request action buttons and where the form_type is available (`request.documentType` or the linked submission's form_type in `request_metadata`).

- [ ] **Step 2: Guard the form-view button** — wrap the "Open form (view mode)" button in `if (!formType.startsWith('appt_')) ...`. Leave "View PDF" unconditional.

- [ ] **Step 3: Analyze + format + commit**

```bash
flutter analyze lib/screens/signature_requests_screen.dart
dart format lib/screens/signature_requests_screen.dart
git add lib/screens/signature_requests_screen.dart
git commit -m "SP4: signature screen shows letter PDF (not form view) for appt_ requests"
```

---

### Task 8: Routes + sidebar + hub entry

**Files:** Modify `lib/routing/router.dart`, `lib/widgets/admin/admin_sidebar.dart`, `lib/screens/appointments_screen.dart`

- [ ] **Step 1: Routes** — import the two screens; add inside the route list (next to other `/setup/*`):

```dart
GoRoute(path: '/setup/appointments', builder: (_, __) => const AppointmentsAdminScreen()),
GoRoute(path: '/my-appointments', builder: (_, __) => const MyAppointmentsScreen()),
```

- [ ] **Step 2: Sidebar** — in the "Setup" `SidebarSection` add after Gangs:

```dart
SidebarLeaf('Appointments', Icons.assignment_ind_outlined, '/setup/appointments', accent: 2),
```

and add a top-level leaf reachable by all admins for their own inbox (place after "Custom Forms"):

```dart
SidebarLeaf('My Appointments', Icons.how_to_reg_outlined, '/my-appointments', accent: 7),
```

(Adjust `accent:` indices to avoid duplicates per the existing palette usage; pick any 0–11.)

- [ ] **Step 3: Hub entry for non-admins** — in `appointments_screen.dart`, add a `Card` at the top of the body linking to `/my-appointments` ("My Appointments — view and accept appointments issued to you") via `context.go('/my-appointments')`, so non-admin users have a path.

- [ ] **Step 4: Analyze** — `flutter analyze lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart lib/screens/appointments_screen.dart`. Expected: No issues (no duplicate routes).

- [ ] **Step 5: Format + commit**

```bash
dart format lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart lib/screens/appointments_screen.dart
git add lib/routing/router.dart lib/widgets/admin/admin_sidebar.dart lib/screens/appointments_screen.dart
git commit -m "SP4: routes + sidebar + hub entry for appointments lifecycle"
```

---

### Task 9: Full verification

- [ ] **Step 1:** `flutter analyze` → "No issues found!"
- [ ] **Step 2:** `flutter test` → all pass (56 + new lifecycle tests).
- [ ] **Step 3:** `flutter build windows --release` → builds exe.
- [ ] **Step 4 (DB smoke):** via Management API, in a transaction that is rolled back: insert a scratch `appointments` row (status pending_signoff with a fake submission_id pointing to a real fully-signable submission is overkill — instead) simply assert the triggers exist (done in Task 1) and that a direct `update appointments set status='active'` on a scratch row works, then `rollback`. No commit.

---

### Task 10: Merge + docs

- [ ] **Step 1: Update HANDOFF.md** — move SP4 to DONE; set next action to SP6 Devices; note the appointments lifecycle tables/screens/triggers. Commit.
- [ ] **Step 2: Merge** — `git checkout main && git merge --no-ff sp4-appointments-lifecycle`; push; delete branch.
- [ ] **Step 3: Update memory** `project_program_state.md` (SP4 done, SP6 next).

## Addendum — built-in appointment forms (user direction 2026-06-21)

Extends the plan so the 3 hardcoded appointment forms run the lifecycle too.
SP4.5 (all-forms→builder unification) is a separate future sub-project.

- **A1. Migration v2** — `supabase/migrations/20260621150000_appointments_form_type.sql`: `alter table public.appointments add column if not exists form_type text;` Apply via Management API. Commit.
- **A2. Model** — add `final String? formType;` to `Appointment` (+ `form_type` in `fromMap`/`toMap`). Keep tests green.
- **A3. Catalog** — `lib/utils/appointable_forms.dart`: `class AppointableForm { final String code, label; final bool hasChain; Widget Function({ValueChanged<String>? onSubmitted}) openBuilder; }` and `const`/getter list of the 3 built-ins, each `openBuilder` returning the matching form screen with an `onSubmitted` hook (Task A6 adds that param). `hasChain: true` for all 3.
- **A4. Data layer** — make `issueAppointment` descriptor-based: params `{required String formType, String? templateId, String? roleId, required String roleCode, AppointmentTemplate? template, required UserProfile appointee, String? shaftId, String? section, String? cycle, required DateTime effectiveDate, required Map<String,dynamic> fieldValues}`. When `template == null` (built-in): payload = `{ 'letterValues': standardLetterTokens(...), 'signatures': {} }`, store `form_type`. When template != null (dynamic): as before, also store `form_type = template.code`. Add `Future<void> linkAppointmentSubmission(Appointment appt, String submissionId, {required bool hasChain})` → set `submission_id`, `accepted_at`, status `pending_signoff` (hasChain) or `active`+`activated_at` (else). Keep `acceptAppointment` (dynamic signature path) unchanged.
- **A5. Admin issue screen** — issue picker merges active dynamic templates + the built-in catalog. Built-in pick skips field inputs (only appointee/shaft/section/cycle/date), calls `issueAppointment(formType: f.code, template: null, roleCode: f.label, ...)`.
- **A6. Form-screen hooks** — add optional `final ValueChanged<String>? onSubmitted;` constructor param to `ShiftBossFormScreen`, `MinerAppointmentFormScreen`, `RelievingMinerFormScreen`; after a successful `_submit()` (id != null) call `widget.onSubmitted?.call(id)`. No behavior change when null.
- **A7. Inbox accept branch** — for an appointment whose `formType` is a built-in (not `appt_`): "Accept & complete form" opens the catalog screen with `onSubmitted: (id) => linkAppointmentSubmission(appt, id, hasChain: true)` then pops + reloads. Dynamic appts keep the signature-pad accept.
- **A8. Monitor letter/PDF** — `generatePdfForFormType(appt.formType ?? template.code, appt.payload)` already handles built-in + `appt_` types; built-in PDFs render from the linked submission's payload (load via `submission_id` when present).

## Self-Review

**Spec coverage:** appointments table + generated period_month + partial unique index (Task 1) ✓; RLS read-own/admin, admin-insert, appointee-or-admin-update (Task 1) ✓; notify trigger issue/accept/decline/resign (Task 1) ✓; activate-on-signoff trigger (Task 1) ✓; state machine model (Task 2) ✓; issue/accept/decline/resign + uniqueness pre-check (Task 3) ✓; chain reuse via `saveFormSubmissionAndStartWorkflow` + `applyCustomChainSignatureFields` (Task 3) ✓; appt_ letter PDF (Task 4) ✓; admin issue+monitor (Task 5) ✓; appointee inbox (Task 6) ✓; signature-screen appt_ handling (Task 7) ✓; routes/sidebar/hub (Task 8) ✓; tests (Task 2) ✓; deferrals (audit table, gang capacity) untouched ✓.

**Placeholder scan:** Tasks 5/6/7 reference reading sibling screens (`custom_forms_screen.dart`, `signature_requests_screen.dart`) to copy the field-input and button patterns — these are explicit "read then mirror" instructions for established patterns, not unfilled gaps; the data-layer/model/migration tasks carry full code.

**Type consistency:** `acceptAppointment({appt, template, me, signature})`, `issueAppointment({template, role, appointee, shaftId, section, cycle, effectiveDate, fieldValues})`, `resignAppointment(appt, reason)` signatures match across Tasks 3/5/6. `AppointmentStatus.wire` strings match the SQL CHECK values (`pending_acceptance`/`pending_signoff`/`active`/`declined`/`resigned`). `generatePdfForFormType(template.code, payload)` uses the `appt_`-prefixed code consistent with Task 4's branch. `payload['letterValues']` written in Task 3 issue is read in Task 4.
