# Mine Online — Flutter

Flutter mirror of the React/TypeScript Mine Online "Shift Boss Management System" for Assmang Black Rock Mine Operations.

Targets **Windows** + **Android**. Connects to the same Supabase backend as the existing web app — both apps share users, profiles, form submissions, signature workflow, and notifications.

## Quick start

```
flutter pub get
flutter run -d windows     # Windows desktop
flutter run -d android     # Android device/emulator
```

> **Heads up — Windows builds and the folder name "NEW PROJECT HERE":**
> Flutter's Windows build toolchain has a known issue with project paths that contain spaces — the install-prefix override breaks and CMake tries to install to `C:\Program Files\mine_online`, failing with "Maybe need administrative privileges." The code itself is fine (it builds cleanly when copied to a no-spaces path). Easiest fix is to rename the folder to remove spaces.

See `CLAUDE.md` for detailed architecture, porting recipe, and known issues. See `PORTING_STATUS.md` for the current per-form porting checklist.

## Required env (`.env` at project root)

```
SUPABASE_URL=https://hhrnkzznpadrmyverhyb.supabase.co
SUPABASE_ANON_KEY=...   # same anon key the web app uses
```
