# VERIFICATION — runtime parity checklist

The 10 audit rounds locked in static parity (data shapes, model fields, render
bindings, helper functions, edge function call shapes). This document is the
runtime half: every step gives you an exact input to type, the exact backend
state to expect, and one checkbox to tick. If any box stays unticked, that's
a defect.

Two paths:

- **Path 1 — the smoke test (Option B)** — automated. `dart run bin/parity_smoke.dart`
  exercises one chain form end-to-end against the live Supabase project. ~30 sec.
  Catches deployed-edge-function bugs, RLS regressions, realtime publication
  drift. Run this first.
- **Path 2 — the manual UI checklist (this file, sections 1-9)** — human in the
  loop. Catches anything the smoke test can't see: wrong navigation, stuck
  buttons, missing toasts, render glitches. ~45 min for a full pass.

---

## Path 1 — automated smoke test

**Preconditions**

- [ ] `.env` at the project root has valid `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
- [ ] The `signature-workflow` edge function is deployed to project
      `hhrnkzznpadrmyverhyb`.
- [ ] You have a test user account (the smoke test signs in as that user, submits
      one row tagged `PARITY-SMOKE-SHIFTBOSS-<timestamp>`, then deletes it).

**Run**

```
cd "C:\Users\Somebody Someone\Desktop\PrayforPlauge\NEW PROJECT HERE"
dart run bin/parity_smoke.dart --email=<test-email> --password=<test-password>
```

**Expected output**

```
✓ Signed in as <email> (user_id=…).
✓ Inserted form_submissions id=… title=PARITY-SMOKE-SHIFTBOSS-….
✓ Edge function start_workflow returned 200.
✓ Workflow started: signature_request <id> pending for Mine Overseer.
✓ form_submissions row in pending_signature / Mine Overseer state.
✓ Notification row visible: "…"  (or ⚠ note if the next signer is a different user)
✓ Cleanup: submission … deleted.

ALL CHECKS PASSED.
```

**If the smoke test fails**

- `signIn failed (400)` → wrong creds, or auth is disabled for this user.
- `insert form_submissions failed (401|403)` → RLS denies INSERT for this user
  (check the policy that allows `auth.uid() = user_id`).
- `signature-workflow start failed (4xx)` → the edge function is not deployed,
  or its body shape changed. Check
  `npx supabase functions list --project-ref hhrnkzznpadrmyverhyb`.
- `No signature_requests row appeared` → migration `20260510233006_signature_approval_workflow.sql`
  was not applied, or the workflow function's logic was changed.
- `fetch form_submissions … not visible` → realtime publication or RLS gap.

**Add `--keep` to skip cleanup** if you want to inspect the row manually after
the test completes.

- [ ] Path 1 passes.

---

## Path 2 — manual UI checklist

### 0. Preconditions

- [ ] `flutter analyze` reports **No issues found**.
- [ ] `flutter test` reports `All tests passed!` (including the 11 payload-parity tests).
- [ ] If on Windows: build folder path has no spaces, or use the junction
      workaround from section 1 below.

### 1. Path-with-spaces — already fixed at the project level

`windows/CMakeLists.txt` forces `CMAKE_INSTALL_PREFIX` to the build bundle dir
unconditionally, so the Windows build no longer cares whether the source path
contains spaces. You can run all Windows commands directly from the original
`NEW PROJECT HERE\` folder. If anyone ever re-introduces the
`if(CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)` guard from the stock Flutter
scaffold, this section will need to come back. Until then, skip ahead to step 2.

### 2. Static + build sanity

- [ ] `flutter analyze` → clean
- [ ] `flutter test` → `All tests passed!`
- [ ] `flutter build apk --debug` succeeds (Android)
- [ ] `flutter build windows --release` succeeds (Windows; only from a no-spaces path)
- [ ] `flutter run -d windows` launches the app

### 3. Login + role-specific home

- [ ] Sign in as `jean@cyberhouse.co.za` (Super Admin)
- [ ] Home renders the **Super Admin dashboard** (14 cards)
- [ ] Tap the account avatar (top-right of every screen) → menu opens →
      My Profile / Settings / Sign out all work
- [ ] Tap the bell on every screen → routes to `/notifications`
- [ ] If unread notifications exist, the bell badge shows the count (capped at "9+")

For the other roles, sign in with a user of that role and verify:

- [ ] Admin dashboard: **10 cards**
- [ ] Mine Leadership dashboard: **8 cards**
- [ ] Shift Boss dashboard: **5 cards**
- [ ] Default (everyone else): **5-card default grid**

### 4. /my-profile — ComboBoxes + SA ID digit-strip

- [ ] Open `/my-profile`
- [ ] In **Department**, start typing — suggestions filter by substring
- [ ] Type a department that's not in the list — the "Add: <value>" affordance appears
- [ ] As Super Admin, the **Occupation** field allows adding new values
- [ ] As a non-admin, the Occupation field does NOT show "Add:" — only existing options
- [ ] In **SA ID Number**, try to paste `abc1234567890efgh` — the field strips
      non-digits and caps at 13 chars; visible text equals stored value
- [ ] **Save** → verify in Supabase:
      ```sql
      select department, occupation, sa_id_number
      from profiles where email = '<your email>';
      ```

### 5. /profiles — full admin CRUD (Super Admin / Admin only)

- [ ] Open `/profiles`
- [ ] List loads with all profiles
- [ ] **Search box** filters across email / full_name / cost_centre / company_number / job_title / department
- [ ] **All / Online / Offline** chips filter by the 2-minute `user_presence` window
- [ ] Online users show a **green dot** on their avatar; offline shows grey
- [ ] **Your own** avatar shows green (the presence heartbeat is upserting every 60s)
- [ ] Tap a row → edit modal opens with all profile fields populated
- [ ] Edit + Save → confirm changes land in the `profiles` row
- [ ] Change `user_account_type` to Admin → `is_admin = true` in the row
- [ ] Tap **Add user** FAB → fill form → Create
- [ ] New row appears in `auth.users` AND `profiles` (verify via Supabase SQL)
- [ ] **Change password** on the edit modal — pick a non-critical account; call succeeds
- [ ] **Delete user** → confirmation dialog → confirm → row disappears from
      `auth.users` (the cascade also removes the `profiles` row)

### 6. /signature-requests — view, sign, transition

**Pre-requisite**: have one pending Shift Boss / Miner / Relieving Miner
submission in flight (submit from the web app and don't sign as MO yet).

- [ ] Open `/signature-requests`
- [ ] Pending request appears in the left list with submitter's name
- [ ] Tap it → detail panel shows: submitter profile card, "Mine Overseer
      signature required", "Sign and Submit" button
- [ ] Tap **View PDF** → preview opens via `Printing.layoutPdf` — visually
      compare side-by-side with the web app's PDF
- [ ] Tap **Open form (view mode)** → form opens in a new route, fields
      pre-filled from the payload, entire form non-interactive (AbsorbPointer)
- [ ] Tap **Sign and Submit** as the Mine Overseer:
  - [ ] toast / success banner appears
  - [ ] list refreshes — this request is gone, next signer's request appears
        (if there is one — Mine Manager for the 3-signer chain)
  - [ ] Verify in Supabase: the signed `signature_requests` row now has
        `status='signed'` and `signed_at` populated; the next role's row is
        `status='pending'`

### 7. /current-logbook — live updates

- [ ] Sign in as the original submitter
- [ ] Open `/current-logbook`
- [ ] The row updated by section 6's sign-and-submit shows the new status
      chip ("Pending: Mine Manager" or "Fully signed")
- [ ] If the realtime channel is alive, the chip changes **without** manual refresh

### 8. /signature-requests — full chain completion

Continue from section 6 with a Mine Manager-only submission (Shift Boss
appointment, Miner appointment, Relieving Miner appointment — the three with
`requiredSigners: ['Mine Overseer', 'Mine Manager']`).

- [ ] Sign in as Mine Manager
- [ ] Open `/signature-requests` — Mine Manager pending request is there
- [ ] Sign and Submit
- [ ] The submission's `form_submissions.workflow_status` transitions to
      `fully_signed`, `completed_at` is set
- [ ] In `/current-logbook` (back as the submitter) the row reads
      "Fully signed"

### 9. HIBP sanity check (sign-up flow)

- [ ] On the login screen, toggle to "Create one"
- [ ] Sign up a new test user with a weak password (e.g. `password123`) — the
      HIBP check rejects it with **"This password has appeared in a known data
      breach"**
- [ ] With device offline (toggle Wi-Fi), retry — error shows **"Password
      safety check unavailable. Try again later."** (not a raw exception)

---

## Reporting failures

If any box stays unticked:

1. Note the section number above
2. Capture the exact error message / screenshot
3. Dump the relevant Supabase row state via MCP or psql:
   ```sql
   select id, form_type, workflow_status, current_signature_role, completed_at
   from form_submissions
   where title like 'PARITY-SMOKE%' or id = '<your submission id>';
   ```
4. Re-run the corresponding round of static parity audit — most live failures
   trace back to a static-side gap (model field name, edge function payload
   shape, RLS policy mismatch).

The full static-side history is in this repo's commit log and the round-by-round
findings table at the end of CLAUDE.md.
