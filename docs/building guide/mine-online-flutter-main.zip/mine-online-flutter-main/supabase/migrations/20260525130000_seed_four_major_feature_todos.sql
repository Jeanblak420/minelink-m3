-- Seed four large planned features into public.todos as 4 main rows plus
-- their phase rows. All stay 'planned' until the team is ready to start.
--
-- Each main task has phases that have to be completed in order before the
-- main task itself can be marked Completed. Every phase covers its own
-- code work (Flutter on both Windows + Android), its own Supabase / DB
-- side, and its own testing pass.
--
-- Visual grouping inside the existing /todos screen comes from the title
-- prefix: `[T1]` for the main task, `[T1 · Phase 1]` for phases. The
-- screen still sorts by created_at desc so we offset created_at by a
-- second per row to keep the main task above its phases and the four
-- tasks in T1 → T4 order inside the Planned lane.
--
-- Author split honours the running ~85/15 ratio across the engineering
-- backlog (Jean Burger / Jean Burger + Justin Trollip).
--
-- Idempotent: a row only inserts when the same (kind, title) isn't
-- already present.

insert into public.todos
  (kind, title, description, status, urgency, author_name, created_at)
select v.kind, v.title, v.description, v.status, v.urgency, v.author_name,
       now() - (v.offset_seconds || ' seconds')::interval
from (values

  -- ============================================================
  -- T1 — In-App IT Support Ticketing System
  -- ============================================================
  (
    0, 'eng',
    '[T1] In-app IT support ticketing system',
$$Main task. Build a full in-app ticketing system so any user can log a support ticket to a dedicated IT Support team without leaving the app. Introduces a new account type ('IT Support / Development Support') that only Super Admins can create, a three-phase ticket lifecycle (Submitted → Opened / In Progress → Closed with summary), per-ticket realtime chat between the user and IT, image attachments with annotation, and email notifications to both sides at every phase change and on every new chat message. Completion requires every phase below to ship.

What this means for users:
You'll get a "Log a Ticket" entry point inside the app. Tap it and a form opens that's already filled in with your name, role, department, payroll ID and other profile details, so you only need to type what's actually wrong. You add your own description of what you were doing when the problem happened (so the team can recreate it), attach screenshots or photos of the error, and add a phone number IT can call you on if the problem needs a longer conversation. After submitting you can watch your ticket move through three phases in real time — Submitted, Opened (IT is reading and working on it), and Closed (with a summary of what they did). Once a ticket is in the Opened phase you can chat live with IT inside the ticket. Both you and IT get an email at every phase and on every chat message so nothing gets missed. Only Super Admins can grant the IT Support role — regular Admins cannot.$$,
    'planned', 'whenever', 'Jean Burger + Justin Trollip'
  ),

  (
    1, 'eng',
    '[T1 · Phase 1] Specification, UX flows and decision log',
$$Write a short spec document covering: exact field set the ticket captures (auto-pulled from profile + manual callback phone + description + attachments), the three phase transitions and who can trigger each, the chat permissions per phase, the email templates per event, and whether to reuse the signature-workflow primitive or build a standalone ticket lifecycle. Decide IT Support inbox layout (lanes vs list), retention rules, and whether attachments expire. Output: a one-page brief committed to docs/ and reviewed before any code lands.

What this means for users:
Nothing user-visible yet — this is the engineering team agreeing on exactly what the ticket looks like, what happens when, and what each email says, so there are no surprises once the screens go in.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    2, 'eng',
    '[T1 · Phase 2] Add the IT Support / Development Support account type (Super Admin only)',
$$Update lib/constants/account_types.dart to add 'it_support' to kUserAccountTypes and to kNotificationEnabledAccountTypes. Extend getAccountTypeFlags to expose isItSupport. Add canAccessTicketingInbox() and canCreateItSupportUsers() helpers to lib/utils/role_access.dart (the latter returns true only for super admins). Gate the new account-type option in the Profiles create / edit dialog so only super admins see it. Mirror the same change in the React app's src/constants/accountTypes.ts so both apps stay in parity. No DB change yet — just the account-type catalogue.

What this means for users:
Super Admins will see a new account type called "IT Support / Development Support" when they create or edit a user. Regular Admins won't see it at all — they can't accidentally promote someone to IT. Once a user has this account type they'll later get access to the IT inbox (built in a later phase).$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    3, 'eng',
    '[T1 · Phase 3] Database schema for tickets, messages, attachments and status history',
$$Create one migration that adds: public.support_tickets (id, submitter_id fk profiles, submitter_profile_snapshot jsonb captured at submit time, callback_phone text not null, title, description, status text check in ('submitted','opened','closed'), opened_at, closed_at, closing_summary text, created_at, updated_at); public.support_ticket_messages (id, ticket_id fk, sender_id fk profiles, sender_role text, body text not null, created_at); public.support_ticket_attachments (id, ticket_id fk, message_id fk nullable, storage_path text not null, mime_type text, original_filename text, uploaded_by fk profiles, created_at); public.support_ticket_status_history (id, ticket_id fk, from_status text, to_status text, changed_by fk profiles, changed_at). Add BEFORE UPDATE updated_at triggers on tickets + messages. Indexes on (status, created_at desc), (submitter_id, created_at desc), (ticket_id, created_at) on messages. Add tables to the realtime publication.

What this means for users:
Invisible plumbing — but every ticket, every chat line, every attachment and every status change will be saved as separate, query-able rows. That's what makes the live updates, the history pane, and the searchable IT inbox possible later.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    4, 'eng',
    '[T1 · Phase 4] Row-level security policies and storage bucket for ticket attachments',
$$Add RLS policies: submitters select their own tickets / messages / attachments only; IT support and super admins select all; admins do NOT see tickets by default. Submitters can insert tickets (their own only) and messages (only on their own ticket, only after status='opened'). IT support inserts messages on any ticket, but only when status='opened'. Status transitions are restricted: submitter cannot change status; IT support / super admin can move submitted→opened and opened→closed; closed cannot reopen via the app (service role only). Create a dedicated storage bucket 'support-ticket-attachments' with auth-only read/write gated by ticket ownership in a storage RLS policy. Service role bypasses everything.

What this means for users:
You'll only ever see your own tickets — other users on the app can't browse your ticket or read your chat with IT. IT Support staff and Super Admins see the whole queue. Admins (who aren't IT) do not see tickets unless they're also Super Admin. Attachments you upload are protected by the same rules — only you and IT can open the link.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    5, 'eng',
    '[T1 · Phase 5] Edge function and email pipeline for ticket events (phase changes + chat messages)',
$$Build supabase/functions/support-ticket-notify (Deno). Triggered three ways: (a) Postgres AFTER INSERT trigger on support_tickets calls the function via pg_net; (b) AFTER UPDATE on support_tickets when status changes; (c) AFTER INSERT on support_ticket_messages. The function sends email via the existing SMTP secret. Email templates: (1) ticket submitted — to IT inbox + submitter, (2) ticket opened — to submitter, (3) ticket closed with summary — to submitter, (4) new chat message — to the other party. Include a deep link back into the app (/support/ticket/{id}). Also write a notifications row for the recipient so the in-app bell badge updates. Wire the function URL + service-role auth into the trigger.

What this means for users:
You and the IT team will both get an email the moment your ticket changes phase or someone sends a new chat message — so you don't have to keep the app open to know IT picked up your ticket or sent a reply. The bell icon inside the app also lights up with the unread count.$$,
    'planned', 'whenever', 'Jean Burger + Justin Trollip'
  ),

  (
    6, 'eng',
    '[T1 · Phase 6] Flutter user side — Log a Ticket screen with profile pre-fill, attachments and annotator',
$$New screen lib/screens/support/log_ticket_screen.dart (and matching route /support/log-ticket). Pre-populates the read-only identity panel via getProfilePersonalDetails(profile): full name, payroll id, occupation, department, location, company contact, email. Required user inputs: a separate callback phone field (NOT the profile contact number), title, description ("what were you trying to do, and how did you get there so we can repeat it"), and one-or-more image attachments. Attachments reuse the existing image_painter annotator dialog used by /todos so the user can circle / draw on screenshots before upload. Submit calls supabase storage uploads then inserts the support_tickets + support_ticket_attachments rows. Add a card on every dashboard ("Need help? Log a ticket to IT") and an entry in the account popover. Responsive layout works on Windows full-screen and Android phones.

What this means for users:
You'll have a one-tap "Log a Ticket" button on your home screen and inside your profile menu. The ticket form is mostly already filled out — you only have to type what's wrong, add a contact phone, and attach screenshots. You can draw on a screenshot to point at the exact problem. Tap submit and the ticket appears on IT's side instantly.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    7, 'eng',
    '[T1 · Phase 7] Flutter IT side — inbox plus ticket detail screen with accept and close actions',
$$New screens lib/screens/support/ticket_inbox_screen.dart (three lanes: New / In Progress / Closed, ordered newest first, with the same tinted-card pattern used by /todos) and lib/screens/support/ticket_detail_screen.dart. The detail screen shows: a submitter info card (avatar + full identity pulled from the snapshot), the callback phone shown prominently, the description, an attached-images carousel, a status timeline (Submitted at ... / Opened at ... by ... / Closed at ... by ...), and the chat thread. Two action buttons: "Accept ticket" (only when status='submitted'; flips to 'opened'); "Close ticket" (only when status='opened'; opens a dialog requiring a closing summary then flips to 'closed'). Gate the routes via canAccessTicketingInbox() so only it_support + super_admin reach them. Add to MobileBottomNav for those roles.

What this means for users:
IT Support staff and Super Admins get a dedicated inbox showing every ticket grouped by phase. Tap one and you see the user's profile, their callback number, what they typed, what they attached, the whole timeline and the chat. Accept the ticket to start working on it; close it with a written summary when you're done.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    8, 'eng',
    '[T1 · Phase 8] Realtime ticket chat plus live status sync (Postgres changes subscriptions)',
$$Add SupportTicketProvider (lib/providers/support_ticket_provider.dart) that subscribes to two Postgres changes channels per open ticket: support_tickets row updates (for status flips) and support_ticket_messages inserts (for new chat lines). Patch local state on event, no reload needed. Use the same realtime pattern as TodosProvider and NotificationsProvider. Chat composer is a TextField + send button at the bottom of the detail screen; insert goes through the existing INSERT policy. Show optimistic message bubbles, reconcile on event. Status timeline auto-repaints when status_history row arrives. Confirm the channels release on screen dispose.

What this means for users:
The ticket chat behaves like any modern messenger — when IT replies, your screen updates instantly. When IT accepts or closes your ticket, you see the timeline update without having to refresh. Same on the IT side: a new ticket pops into the New lane the moment a user submits it.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    9, 'eng',
    '[T1 · Phase 9] End-to-end testing, email rendering check, Windows + Android parity, docs',
$$Manual end-to-end pass: (1) user logs ticket with two annotated screenshots → ticket appears in IT inbox + IT receives email + bell badge increments; (2) IT accepts → submitter sees status flip + receives email; (3) IT and submitter exchange three chat messages → both see live + emails; (4) IT closes with a summary → submitter sees the closed phase + summary + email. Repeat on Android device with touch annotation. Repeat on Windows with mouse annotation. Test the RLS gates with a regular Admin account (should NOT see tickets), a Shift Boss account (should not see), an IT Support account (should see all), a Super Admin (should see all). Run flutter analyze. Add a "Support Tickets" section to the project's developer notes.

What this means for users:
This is the safety net — before the IT ticketing system is announced as live, the engineering team will have walked through every phase, on both Windows and Android, with multiple account types, to confirm nothing leaks and every email actually arrives. Once this phase is ticked off, the feature is officially available to use.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  -- ============================================================
  -- T2 — Combined / Assignable Appointment Books
  -- ============================================================
  (
    10, 'eng',
    '[T2] Combined and assignable appointment books',
$$Main task. Build the appointment-book concept so an Admin can bundle multiple appointment forms into a single named "book", assign that book to a specific user, and have it tracked as one combined unit. Inside the book every form is still filled out individually, still goes through its own signature chain, still produces its own PDF — but when every form in the book is fully signed, the book auto-completes and binds to the user's profile. Completed books appear in Appointment History, accessible per-user, viewable by that user, Admins, Shift Bosses, Mine Managers and Mine Overseers — and ONLY once fully completed. Completion requires every phase below.

What this means for users:
Admins will be able to assemble a "complete appointment book" — a bundle of all the appointments a particular role needs to fill out — and hand it to a user in one go, instead of asking them to find each form one by one. The user opens the book, sees the list of forms inside, fills them one at a time with the existing signature flow, and watches the book's completion bar fill up. The moment every form in the book is fully signed, the book locks closed and appears in that user's Appointment History — visible to themselves and to Admins / Shift Bosses / Managers / Overseers. Anything incomplete stays out of history until it's done.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    11, 'eng',
    '[T2 · Phase 1] Specification — what a book is, which forms it can contain, completion rules',
$$Spec doc covering: the catalogue of appointment-form types that can be added to a book (likely the 11 chain forms but TBD); whether books are templates an Admin defines once and re-assigns, or one-off assignments; what happens if Admin reassigns a half-completed book; rules for completion (every linked form must reach workflow_status='completed'); who can re-open / archive a completed book; permission matrix for viewers per role. Output: short doc reviewed before any schema lands.

What this means for users:
Nothing user-visible yet — the team is locking down what a "book" actually is so the rest of the build can move quickly.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    12, 'eng',
    '[T2 · Phase 2] Database schema — book templates, assignments and form links plus completion trigger',
$$Migration adds: public.appointment_book_templates (id, name, description, default_form_types text[], created_by, created_at); public.appointment_book_assignments (id, template_id fk, assigned_to_user_id fk profiles, assigned_by fk profiles, status text check in ('open','completed','archived'), assigned_at, completed_at); public.appointment_book_form_links (id, assignment_id fk, form_type text, form_submission_id fk form_submissions nullable, completed_at). Add an AFTER UPDATE trigger on form_submissions that, when workflow_status flips to 'completed' and the submission_id appears in any open assignment, checks if all sibling links are now complete and — if so — flips the assignment status to 'completed' and stamps completed_at. Indexes on (assigned_to_user_id, status), (assignment_id), (form_submission_id).

What this means for users:
Invisible plumbing — but it's what makes a book understand that "all my forms are done" automatically, without anyone having to manually mark it complete.$$,
    'planned', 'whenever', 'Jean Burger + Justin Trollip'
  ),

  (
    13, 'eng',
    '[T2 · Phase 3] Admin UI — create book templates and assign books to users',
$$New screen lib/screens/appointment_books/book_management_screen.dart (admin-gated route /admin/appointment-books). Two tabs: "Templates" (create / rename / archive a template by picking from the 27 appointment forms) and "Assignments" (assign a template to a user via ComboBox of users, with optional notes; lists every assignment grouped by status). Mirrors the look of the existing /admin screen. Reuses the existing ComboBoxField for the user picker. Permission gate: canManageAppointmentBooks() helper that returns true for admin + super_admin.

What this means for users:
Admins will get a new screen under the Admin area for building book templates (pick which forms go inside) and handing those books out to specific users. From there they can also see who has what open, who's completed what, and re-assign as needed.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    14, 'eng',
    '[T2 · Phase 4] User UI — My Appointment Books with per-form launcher and live progress',
$$New screen lib/screens/appointment_books/my_appointment_books_screen.dart (route /my-appointment-books, surfaced on the Shift Boss / role-specific dashboards). Lists every open assignment for the signed-in user with a progress meter (X of Y forms complete). Tap a book → expands to show every form inside with a status pill per form (Not started / Submitted / In signature chain / Completed). Tap a form → opens the existing form screen exactly as it does today (still individually fillable, still triggers its own signature request). On submit, the form's submission_id automatically links into the corresponding appointment_book_form_links row via a small wrapper around saveFormSubmissionAndStartWorkflow.

What this means for users:
You'll have a new "My Appointment Books" entry on your home screen. Open it and you see every book that's been handed to you, how far through each one you are, and a list of the forms still waiting. Tap a form to fill it the same way you do today. As soon as a form gets fully signed, your book's progress bar moves on its own.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    15, 'eng',
    '[T2 · Phase 5] Completion binding to user profile and history attachment',
$$Once an assignment flips to 'completed' (via the trigger from Phase 2), expose it through a new RPC public.get_completed_appointment_books(user_id uuid) that returns the assignment + ordered list of form_submission rows + their fully-rendered PDFs reference. Add a small notification row for the user ("Your appointment book {name} is now complete") and surface it via the existing NotificationsProvider so the bell badge lights up. No edge function needed — the existing trigger already does the work. Validate via integration test that a partially-complete book stays out of the RPC's output.

What this means for users:
When the very last form in a book gets signed, the app tells you — bell badge plus a notification card — and your book moves to the Completed section. Until then, it stays as "open" so nobody sees it as done before it really is.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    16, 'eng',
    '[T2 · Phase 6] Completed-book viewer — per user, per book, read-only, scoped to authorised roles',
$$New screen lib/screens/appointment_books/completed_book_screen.dart (route /appointment-books/{assignment_id}). Renders the book as a header card (book name, who it was assigned to, when completed) plus the ordered list of every form inside with a "View" button that opens the form in view-mode via buildFormView(formType, FormViewArgs(initialPayload: submission.payload, mode: 'view')). "Download PDF" button per form via the existing savePdfBytes helper. Surface a "Completed Books" tab inside /appointment-history-logs (existing AdminAppointmentsLogbookScreen) for Admin / Mine Overseer / Mine Manager / Shift Boss roles, and on the user's own /individual-completed-logbook-history page for themselves. Hide from anyone outside that role set via RLS + UI gate.

What this means for users:
After a book is completed, anyone authorised — the user themselves, plus Admins, Shift Bosses, Mine Managers and Mine Overseers — can open it and walk through every form inside it, page by page, exactly the way it was submitted, and download the PDFs. Nobody outside that group sees it; nobody sees an incomplete book at all.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    17, 'eng',
    '[T2 · Phase 7] End-to-end testing across Windows + Android, plus parity check',
$$Test: Admin creates a 3-form template, assigns it to a Shift Boss user. Shift Boss opens My Appointment Books, fills form 1 → submits → enters signature chain → other signers approve → form 1 marked complete on the book. Repeats for forms 2 and 3. After the last signature lands, the book auto-completes, a notification fires, and the book appears in the user's history + in the Admin's history view + in the Mine Manager's view. Verify it does NOT appear in a Miner-account user's view (wrong role) or in a different Shift Boss's view (wrong user). Run on Android phone (touch) and Windows full-screen (mouse). flutter analyze clean. Update the project's developer notes with the appointment-book section.

What this means for users:
Final safety net before the appointment-books feature is announced live — the engineering team will walk a real book through the full assign / fill / sign / complete / view cycle on both platforms before any user is asked to use it.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  -- ============================================================
  -- T3 — Gangs / Teams with Scoped Workflow
  -- ============================================================
  (
    18, 'eng',
    '[T3] Gangs and teams with scoped signature workflow plus visibility',
$$Main task. Add the concept of a "gang" or "team" — a named group of users that scopes who you can send signature requests to, whose forms appear in your history views, and (eventually) other shared visibility features. Each user can be a member of a team; the team determines the candidate pool when a form triggers a signature request, instead of routing to anyone in the role anywhere in the company. Admins manage teams; team members only see workflow that belongs to their team. Completion requires every phase below.

What this means for users:
Today, when a form needs a Shift Boss signature, it can route to any Shift Boss in the company — which can mean the wrong person on the wrong shift gets pinged. Once teams are live, you'll be added to a "gang" (e.g. "Section 23 — A Shift") and your signature requests will only travel between members of that gang. Your Current Logbook and signature history pages will show your gang's work, not the whole mine's. Admins (and Mine Managers / Overseers) keep the company-wide view; everyone else stays inside their own team's bubble — which means less noise and faster routing.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    19, 'eng',
    '[T3 · Phase 1] Specification — definition of a team, scope of scoping, edge cases',
$$Spec doc covering: what fields a team has (name, section, shift letter, description, lead, active flag); whether a user can be in more than one team (recommend: primary team + optional secondary memberships); which features the team scopes (signature routing, history queries, dashboards) and which stay company-wide (form templates, admin tools); how Admins / Mine Managers / Mine Overseers see across teams; what happens to in-flight signature requests when a user is moved out of a team; archival rules for old teams.

What this means for users:
Nothing user-visible yet — this is the team agreeing on the exact rules so when the feature lands it behaves predictably and nobody loses access to work they were doing.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    20, 'eng',
    '[T3 · Phase 2] Database schema — teams plus team_members plus profile primary-team column',
$$Migration adds: public.teams (id, name, section_name nullable, shift_label nullable, description, created_by, active boolean default true, created_at, archived_at); public.team_members (id, team_id fk, profile_id fk profiles, member_role text check in ('lead','member'), joined_at, primary key (team_id, profile_id)); a new column profiles.primary_team_id fk teams nullable. Indexes on (team_id), (profile_id, member_role), profiles.primary_team_id. Backfill: leave existing profiles' primary_team_id as null until admins assign explicitly. Add tables to the realtime publication for live admin views.

What this means for users:
Invisible plumbing — but this is the building block for every later phase. Once it's in, an Admin can start placing users into teams.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    21, 'eng',
    '[T3 · Phase 3] Admin team management UI — create, rename, archive teams and manage membership',
$$New screen lib/screens/teams/team_management_screen.dart (route /admin/teams, gated to admin + super_admin). List of teams on the left, selected-team detail on the right (members table, add-member ComboBox, remove-member buttons, set-as-lead toggles, rename / archive controls). New team via "+" FAB. Surfaces each member's role + occupation as a RolePill. Reuses ComboBoxField for the user picker. Adds a "Team" column to the /profiles list so Admins can see at a glance who's in which team without opening this screen.

What this means for users:
Admins get a new screen for building and editing the company's gangs. Drag a user into a team, name a team lead, give the team a section / shift label, and you're set. The User Profiles screen also gains a new column showing each user's team so you can scan the org at a glance.$$,
    'planned', 'whenever', 'Jean Burger + Justin Trollip'
  ),

  (
    22, 'eng',
    '[T3 · Phase 4] Scope the signature workflow to team membership (Flutter helper plus edge function)',
$$Update lib/utils/signature_workflow.dart so when computing the next-signer candidate set, the query filters profiles by primary_team_id = submitter.primary_team_id (unless the candidate role is one of the company-wide roles like Mine Manager / Overseer / Admin / Super Admin). Update supabase/functions/signature-workflow likewise. Update the Signature Requests + Current Logbook + Completed Logbook + Appointment History screens to filter visible rows the same way for non-admin roles. Admins, Mine Managers, Mine Overseers see everything; everyone else stays inside their team. Handle the "user with no primary team" fallback by treating them as company-wide (no scoping) until they're placed.

What this means for users:
Once teams are turned on, the signature requests you receive will only come from people in your own gang — no more random pings from the wrong shift or the wrong section. Your Current Logbook and Completed Logbook will only show your team's forms. Admins and Mine Managers still see the whole mine.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    23, 'eng',
    '[T3 · Phase 5] Row-level security and edge function updates for team-scoped reads',
$$Update RLS policies on signature_requests and form_submissions: non-admin SELECT policies must additionally check that the row's submitter_id shares a primary_team_id with auth.uid(). Add a helper public.same_team(uuid, uuid) returns boolean. Update admin-create-user edge function to accept an optional primary_team_id parameter so Admins can drop a new user straight into a team. Re-verify every existing edge function (signature-workflow, support-ticket-notify if it ships first, etc.) respects the new scoping. Document the bypass list (admin / super_admin / mine_manager / mine_overseer) clearly in the RLS comment.

What this means for users:
Locks the team rules in at the database level so even if a screen has a bug, you still cannot see another team's work unless your role is allowed to. Admins onboarding a new user can now place them into a team during account creation, not as a separate step afterwards.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    24, 'eng',
    '[T3 · Phase 6] End-to-end testing across multi-team scenarios, Windows + Android',
$$Set up two test teams (Team A / Team B), put a Shift Boss + Miner into each. Submit a form from Team A's Miner → confirm only Team A's Shift Boss gets the signature request and only Team A's members see the form in their views. Switch to a Mine Manager account → confirm both teams visible. Switch to an unassigned user → confirm they see everything (fallback). Move a user from Team A to Team B mid-chain → verify routing for the in-flight request behaves per the spec from Phase 1. Repeat on Android device. flutter analyze. Update the project's developer notes "Teams" section.

What this means for users:
Final pre-rollout pass to confirm the team boundary actually holds — across both platforms, across role overrides, and across edge cases like moving someone between gangs while a form is still going through signatures.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  -- ============================================================
  -- T4 — Admin Form Editor with Version-Controlled History
  -- ============================================================
  (
    25, 'eng',
    '[T4] Admin form editor with version-controlled change history',
$$Main task. Move the 27 appointment forms off hard-coded Flutter code and onto a data-driven definition so Admins can add / edit / remove / rearrange the actual questions, text, tables, pictures and images on every form — with every change versioned and the full edit history loggable and reviewable. Completion requires every phase below. Note: each historical form_submissions row continues to render using the form version that was current the moment it was submitted, so old records never look "wrong" just because the form was later edited.

What this means for users:
Today, when a form needs a wording change, a new question, or a new table column, a developer has to edit the code and push a new app version. Once this lands, an Admin can open a form inside the app, edit the text directly, add a new question, drop in a new table or image, save it, and every user picks up the new version instantly the next time they open the form. Every edit is stamped with who changed what and when, so you can review the history and roll back to a previous version. Forms already submitted in the past keep their original layout — only newly-filled forms use the latest version.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    26, 'eng',
    '[T4 · Phase 1] Specification and pick the first forms to migrate as proof',
$$Spec doc covering: the JSON shape that represents a form (sections → questions / tables / images / signature blocks, each with input type + validation), how submissions snapshot the version they were filled against, how the editor handles unsaved drafts, whether image upload goes to a dedicated bucket, and which 2–3 forms migrate first as the proof (recommend Lockout Checklist and Shift Boss Daily Report — both already non-chain, lowest risk). Output a one-page schema spec.

What this means for users:
Nothing user-visible yet — the engineering team is locking down what an editable form actually looks like under the hood before any user-facing edit screen is built.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    27, 'eng',
    '[T4 · Phase 2] Database schema — form definitions, versions and change log',
$$Migration adds: public.form_definitions (id, form_type text unique, title, current_version_id fk form_versions nullable, created_at); public.form_versions (id, definition_id fk, version_number int, schema jsonb not null, edited_by fk profiles, edited_at, change_summary text not null, published boolean default true); public.form_change_log (id, version_id fk, field_path text, change_type text check in ('add','edit','delete','reorder'), before_value jsonb, after_value jsonb, edited_by fk profiles, edited_at). Add column form_submissions.schema_version_id fk form_versions (nullable, populated at submit time so the row remembers which version it was filled against). Trigger to auto-bump version_number on new schema rows.

What this means for users:
Invisible plumbing — but this is what makes "open form, edit, save as v17, audit who changed what" possible without ever losing the v16 record that the field crews already filled out yesterday.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    28, 'eng',
    '[T4 · Phase 3] Admin form editor UI — edit text, add/remove questions, tables, and images',
$$New screen lib/screens/form_editor/form_editor_screen.dart (route /admin/forms, gated admin + super_admin). Left pane: list of all 27 forms with version number and last-edited stamp. Right pane: editable tree of the selected form's current version — every text block, question, table cell, image slot rendered as an inline editable widget. Toolbar to insert a new text block / question (text / number / date / signature / checkbox / dropdown) / table / image. Drag-handle to reorder. Image upload routes to a dedicated 'form-definition-images' storage bucket. "Save as new version" dialog requires a change summary before commit. Live preview pane on the right shows the form as a user will see it.

What this means for users:
Admins get a full in-app editor for every form. Change wording inline, add a new "Equipment serial" question, drop in a new section with a photo, rearrange the table columns — and click Save with a one-line summary of what changed. The preview pane shows exactly what the user will see before you commit.$$,
    'planned', 'whenever', 'Jean Burger + Justin Trollip'
  ),

  (
    29, 'eng',
    '[T4 · Phase 4] Version history viewer with diff and rollback',
$$New screen lib/screens/form_editor/form_version_history_screen.dart (route /admin/forms/{form_type}/history). Lists every version of the chosen form with version number, edited-by avatar + name, edited-at timestamp, and the change summary. Tap a version → opens a diff viewer side-by-side (left: prior version, right: chosen version, with added / removed / changed highlights). "Restore this version" button clones the chosen historical schema as a brand-new latest version (never overwrites history — always appends). Shows the per-field change log from form_change_log under each entry so admins can audit a granular edit trail.

What this means for users:
Admins can scroll through every change that has ever been made to a form — who made it, when, what they changed, and why (from the summary). If a change turns out to be wrong, restoring an earlier version is one click — and the restore itself is logged as a new edit, so the history is never lost.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    30, 'eng',
    '[T4 · Phase 5] Data-driven form renderer plus migration of the first proof forms',
$$New widget lib/widgets/form_engine/dynamic_form_renderer.dart that takes a form_version.schema jsonb and renders the form the same way the existing hard-coded screens do: TextFormField, DatePickerField, SignatureCanvasField, table widgets, image display. Wire saveFormSubmissionAndStartWorkflow to stamp the schema_version_id on submit. Migrate the two proof forms chosen in Phase 1 (e.g. Lockout Checklist + Shift Boss Daily Report) so their screens are now thin shells that load the definition from form_definitions and delegate to the renderer. Confirm round-trip equivalence: submitting via the new renderer produces the same payload shape the existing screen does.

What this means for users:
The proof point — two real forms now flow through the editable system end-to-end. Filling them feels identical to before, but under the hood they're now driven by the form definition Admins can edit. Once this proves stable, the remaining 25 forms can be migrated one by one in follow-up tasks.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    31, 'eng',
    '[T4 · Phase 6] PDF generator integration with versioned schemas',
$$New file lib/pdf/dynamic_form_pdf.dart — generic PDF generator that takes a form_version.schema + a submission payload and renders the PDF using the existing pdf_runtime helpers (mm letter coordinates). Matches the look of the existing per-form generators closely enough that historical PDFs and new PDFs sit alongside one another in the logbook without visual jar. Wire into form_registry.generatePdfForFormType so dynamic forms route to the new generator and hard-coded forms keep their existing route. Re-test the two proof forms' PDFs against the originals.

What this means for users:
The PDFs your forms generate continue to look right even when an Admin has edited the source form — and a PDF of an old submission still looks like the version it was filled against, not the latest edit. This is what makes editable forms safe to actually use.$$,
    'planned', 'whenever', 'Jean Burger'
  ),

  (
    32, 'eng',
    '[T4 · Phase 7] End-to-end testing, Windows + Android editor parity, rollout doc',
$$Manual end-to-end pass on both platforms: Admin opens the form editor, edits a question wording, saves as v2 with a summary → User opens the form on a different device → sees the v2 wording → submits → submission stamps schema_version_id=v2 → PDF renders the v2 wording. Admin opens the version history, diffs v1 vs v2, restores v1 → form now shows v1 wording on next open. Verify a previously-submitted v1 PDF still renders v1 even after v2 is live. Verify the editor itself is usable on a Windows full screen and at least readable on an Android phone (or restrict editor to Windows-only if the touch UX doesn't pass — to be decided in this phase). Update the project's developer notes with the form-engine section and document the per-form migration recipe so the remaining 25 forms can be migrated incrementally.

What this means for users:
The final pre-rollout pass — the engineering team will edit a real form, watch it ship live to a user on a different device, and confirm both new and old PDFs still look correct, before the editor is announced as available to Admins.$$,
    'planned', 'whenever', 'Jean Burger'
  )

) as v(offset_seconds, kind, title, description, status, urgency, author_name)
where not exists (
  select 1 from public.todos t where t.kind = v.kind and t.title = v.title
);
