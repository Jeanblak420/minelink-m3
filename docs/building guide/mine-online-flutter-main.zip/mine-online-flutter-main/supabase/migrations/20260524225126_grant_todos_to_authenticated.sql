-- Bugfix — public.todos was created with RLS enabled and the right policies,
-- but the authenticated / anon roles never had base table grants. In
-- Supabase you need BOTH the GRANT and the RLS policy; without the GRANT
-- the PostgREST layer returns 0 rows to the client (no error, just empty).
-- This is why every signed-in user was seeing "0 total" on /todos even
-- though the table has 56 rows. Granting now makes the existing RLS
-- policies effective.

grant select, insert, update, delete on public.todos to authenticated;
grant usage on schema public to authenticated;
