-- SP4.5: per-form edit overlay (added fields/pages + per-field overrides) for the
-- current built-in + appointment forms. Reuses custom_form_templates keyed by
-- code = form_type. base_form_type marks an overlay row (vs a standalone SP2
-- custom form, where it stays null). Existing columns/policies are unchanged.
alter table public.custom_form_templates
  add column if not exists overlay jsonb not null default '{}'::jsonb;
alter table public.custom_form_templates
  add column if not exists base_form_type text;
