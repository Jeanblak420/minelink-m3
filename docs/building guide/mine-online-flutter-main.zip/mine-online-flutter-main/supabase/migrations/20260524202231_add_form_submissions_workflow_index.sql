-- e-be-9: index on form_submissions (workflow_status, created_at desc) for
-- cross-user admin queries (Current Logbook variants, signature dashboard).
-- The spec mentioned 'submitted_at desc' but the table uses created_at as
-- the submission timestamp; same effect.

create index if not exists idx_form_submissions_workflow_status_created_at
  on public.form_submissions (workflow_status, created_at desc)
  where workflow_status is not null;
