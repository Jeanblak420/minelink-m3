-- One-off copy normalisation for a stale meta-todo row.
-- The upstream seed migration in this repo now writes the final wording
-- directly, so on a fresh replay this UPDATE is a defensive no-op. Kept
-- so any legacy environment where the original row still exists with the
-- old copy gets corrected on the next migration pass.

update public.todos
set
  title = 'Normalise authorship and section copy in the To-Do List',
  description = $body$Engineering todos now consistently show 'Jean Burger' or 'Jean Burger + Justin Trollip' as the author, and the Engineering section subtitle reads 'Tasks added automatically by the engineering system as work ships. Visible to all account types.' An internal seed file header was tidied at the same time.

What this means for users: the To-Do List presents engineering entries with a single, consistent voice — the authorship and section copy line up with how the engineering team actually ships work.$body$
where id = '8a2e59ce-1636-4a10-a867-8e44fe5908b5';
