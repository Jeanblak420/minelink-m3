-- Group the flat backlog of completed engineering todos under nine topic
-- parents so the /todos Completed lane nests + collapses like the Planned
-- [T1]..[T4] tasks. The 63 done rows were seeded parent-less; this adds the
-- category parents and re-parents each done row beneath the right one.
--
-- Idempotent: parent inserts use ON CONFLICT DO NOTHING (fixed UUIDs) and the
-- re-parenting UPDATEs are keyed on the existing child ids.

-- 1. Category parent rows (kind='eng', status='done' so they live in the
--    Completed lane). created_at staggered so they read top-to-bottom in a
--    sensible order (newest first in the forest sort).
insert into public.todos (id, kind, title, description, status, author_name, parent_id, created_at, updated_at)
values
  ('11111111-1111-4111-8111-111111111111', 'eng', 'Database & migrations',     'Schema, RLS, triggers, storage buckets, type generation and backfills behind the app.', 'done', 'Jean Burger', null, '2026-05-25 09:09:00+00', '2026-05-25 09:09:00+00'),
  ('22222222-2222-4222-8222-222222222222', 'eng', 'Edge functions & realtime', 'Edge functions and realtime channels powering notifications, signatures and todos.',     'done', 'Jean Burger', null, '2026-05-25 09:08:00+00', '2026-05-25 09:08:00+00'),
  ('33333333-3333-4333-8333-333333333333', 'eng', 'Forms & signatures',        'Form submission flow, sign-mode and the signature chain UI.',                            'done', 'Jean Burger', null, '2026-05-25 09:07:00+00', '2026-05-25 09:07:00+00'),
  ('44444444-4444-4444-8444-444444444444', 'eng', 'Theming',                   'Light, dark and custom theming, brand palette and font registration.',                   'done', 'Jean Burger', null, '2026-05-25 09:06:00+00', '2026-05-25 09:06:00+00'),
  ('55555555-5555-4555-8555-555555555555', 'eng', 'Notifications',             'Notification layout, deep-link routing, push and the unread badge.',                     'done', 'Jean Burger', null, '2026-05-25 09:05:00+00', '2026-05-25 09:05:00+00'),
  ('66666666-6666-4666-8666-666666666666', 'eng', 'Components & widgets',      'Shared chips, EmptyState, snackbars and input hints.',                                   'done', 'Jean Burger', null, '2026-05-25 09:04:00+00', '2026-05-25 09:04:00+00'),
  ('77777777-7777-4777-8777-777777777777', 'eng', 'Layout & navigation',       'App bar, bottom nav, back-arrow behaviour, page centering and account menu.',            'done', 'Jean Burger', null, '2026-05-25 09:03:00+00', '2026-05-25 09:03:00+00'),
  ('88888888-8888-4888-8888-888888888888', 'eng', 'Screens & lists',           'List-screen polish across profiles, logbooks, appointments and signature requests.',     'done', 'Jean Burger', null, '2026-05-25 09:02:00+00', '2026-05-25 09:02:00+00'),
  ('99999999-9999-4999-8999-999999999999', 'eng', 'To-Do list',                'The To-Do List screen, entry points and attachment annotation.',                         'done', 'Jean Burger', null, '2026-05-25 09:01:00+00', '2026-05-25 09:01:00+00')
on conflict (id) do nothing;

-- 2. Re-parent each completed engineering todo under its category.
update public.todos set parent_id = '11111111-1111-4111-8111-111111111111' where id in (
  '2e93b5b9-7c26-4784-ad45-b10fb3997fe5','9ad802fd-004d-461f-a1af-54e4f5cd7da7','fbd052f7-b98d-447f-a792-04f096ac84ba',
  '472bf096-33cc-46f9-85d0-1198a566cc7d','a80a54aa-1550-463e-bf35-07ce6ca67ca2','c26163b0-fab6-4af0-b960-8bdc8a778e39',
  'a9618c79-43d6-45a0-98c8-1eb67d5ddecb','4d7da524-734c-4baa-81d0-ad8f6b7fc704','2449152b-3298-431e-a131-0f4ce18d670b',
  '4eaacfae-18bd-4389-ba51-8199d31d3db2','0fee6500-6b8a-4264-812e-c60362a09c92','964d67f6-de95-4a01-b2e0-e460768737de',
  'be9103e3-acc2-45d9-99dc-07f135526d01','9db3ec00-03b0-4769-bbf7-afda006d1a91','604232df-cf05-4412-8be8-f26a699a0faa',
  'a833f65c-13b9-464d-9469-331687a105e3'
);

update public.todos set parent_id = '22222222-2222-4222-8222-222222222222' where id in (
  '733df435-f6a0-45bb-90d9-1556493614e6','5a3d738b-b0dc-44b5-af76-98ebf003acd4','ef483b43-65aa-4544-9540-da7bb89be05f',
  '5323e874-99d0-4353-82e8-3daf1cccefb5','0e2b8b69-fc81-4645-9986-75f2e7158d0f'
);

update public.todos set parent_id = '33333333-3333-4333-8333-333333333333' where id in (
  '7f5244d3-d1d3-43a5-973f-06c79d52fd7a','19d3ba0d-6dd5-4366-b33d-2c091d12b62e','0c0882e8-bf53-4310-b372-7732ad447121',
  '1c3e835c-78b7-4b69-855e-147bcbbe5279'
);

update public.todos set parent_id = '44444444-4444-4444-8444-444444444444' where id in (
  '1c405887-3412-483c-b89f-e7e7e9810e3e','e0d7a7d0-6bde-4289-9ab3-271c50f2af90','c0dc5844-9a54-45fa-aae8-e540017abb4c',
  '548f8253-a599-438d-98d0-515280e6d642','ac0beeb1-c287-4161-9885-802e0f6b1cda','c5057c1f-32d1-451c-bcc2-839fdc3112b1',
  'b50b4273-bf9f-4764-82ca-25cda79b7333'
);

update public.todos set parent_id = '55555555-5555-4555-8555-555555555555' where id in (
  '11d13980-449b-475b-9f14-c5eb0838579a','691fec5f-d11b-403a-aa8f-2bcfffd3e513','69e256c6-13f2-4296-be96-45478ecb0fd6',
  '1b773507-4dc9-402a-8e63-d655338538d7','c771b4d8-f0e3-4acf-8149-acebb8f019c7'
);

update public.todos set parent_id = '66666666-6666-4666-8666-666666666666' where id in (
  '83828852-0871-41f8-92f2-f1c67d9d9c99','8482293c-90ec-435e-9257-48694655cec8','cf47df55-b22d-4b7b-aab9-8cbd6f8598da',
  '8b83bc74-5bae-4aa6-9501-f657f905d2d4','f98ba6b5-ea99-4cc3-9f20-7ad0a6068140'
);

update public.todos set parent_id = '77777777-7777-4777-8777-777777777777' where id in (
  'dfdb0fc1-5f7f-43a7-bf7d-c40575adecff','d97841c2-de9a-4c71-89a0-9a7ba95072cc','b1b89a20-4029-47a1-826d-cee5de7b8935',
  '374463c2-1505-444a-96b2-6dbb41cbee6f','8add9fa6-0817-49ae-ae45-243b15269299','a24246c8-de7f-48f2-a1c3-e0bbb393b1a9',
  '7237af51-2822-4abb-a852-b08d01519517','2e94bac0-3e0b-4fe4-b665-861b8cebe677'
);

update public.todos set parent_id = '88888888-8888-4888-8888-888888888888' where id in (
  '93721d75-1031-4f03-b8f9-d2f4d22e3593','bcabee86-8835-4186-8c47-cef1948e868a','95b48599-bda8-44be-b75e-20c0e57d82e7',
  '9d21337a-ce66-45f2-9920-fb16b35d85c7','204e2f85-44be-4942-a4d6-e3967f4784c8','69be3c8c-9ae2-4b93-9756-cf0ee6554e22',
  '65aa0cb5-c30e-43c1-9e9e-510b01d69f2c'
);

update public.todos set parent_id = '99999999-9999-4999-8999-999999999999' where id in (
  'ac08f70d-2be6-4de3-9938-21378cb42a57','41c7b30d-63cb-4323-b550-ef5c31d93d7d','b50b6fd2-c089-4d55-8a71-d1b5f9c2fb22',
  '24f7dfe9-7965-4f1f-bc8e-d530f5b62b31','8a2e59ce-1636-4a10-a867-8e44fe5908b5','4a4b99bb-5585-4176-a7f6-386a68d00e4f'
);
