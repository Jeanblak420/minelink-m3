-- Sync public.todos statuses with the latest SEED_ENG state after this
-- session's work. Match by kind+title (the seed migration's idempotency
-- key). Idempotent — running twice is a no-op.

update public.todos
set status = 'done'
where kind = 'eng'
  and title in (
    'Add profiles.theme_mode + custom_theme_color columns',
    'Action URL column on notifications',
    'Storage bucket policies',
    'Realtime channels for notifications + todos + form_submissions',
    'Edge function: signature-workflow advancement',
    'Postgres trigger: updated_at on todos',
    'Backfill + index review',
    'admin-create-user edge function audit',
    'Migration squash + lockfile',
    'Generated types regeneration',
    'Audit profiles.theme_mode + custom_theme_color current state',
    'Card-tinted backgrounds across list screens',
    'Account popover (avatar tap → menu)',
    'Snackbar / toast for action confirmations',
    'Frosted / sticky app bar treatment on scroll',
    'Input keyboard hints (email / numeric / password)'
  );
