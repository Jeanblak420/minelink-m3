-- Engineering log: this session's work on the e-cards-1 list-screen
-- tinted-card treatment. Five new entries (4 Jean Burger / 1 Jean Burger
-- + Justin Trollip) so the on-app /todos feed keeps up with the code.
--
-- Every description includes both the technical block (what changed,
-- where, and how) and a "What this means for users" plain-English block
-- so non-coding users can read the same feed and understand what they
-- can now do or expect to see.
--
-- Idempotent: each row only inserts if the same (kind, title) isn't
-- already in public.todos.

insert into public.todos (kind, title, description, status, urgency, author_name)
select v.kind, v.title, v.description, v.status, v.urgency, v.author_name
from (values
  (
    'eng',
    'Signature Requests: warning-tinted cards + amber accent stripe',
    'Updated lib/screens/signature_requests_screen.dart so every request tile renders inside a Material with MolTones.warning.tint background (selected -> warning.soft) and a left amber accent stripe (warning.accent). Signed-recently tiles use the same shape with success tones. Headings remain plain; the tinted-card pattern now matches the design system''s Tokens.jsx + the React UI-kit prototype. flutter analyze: clean.

What this means for users:
When you open Signature Requests, every request that''s waiting for someone to sign now stands out with a soft amber background and a vertical amber stripe down the left edge of the card. Requests you''ve already signed appear with a soft green background. This makes it instant to scan the list and see which ones still need attention -- you don''t have to read every row to find pending work. Selecting a request darkens its background a bit so you can tell which one you''re currently viewing.',
    'done',
    'whenever',
    'Jean Burger'
  ),
  (
    'eng',
    'Profiles list: elevated card + hover tint + RolePill',
    'Updated lib/screens/profiles_screen.dart so the list of users is wrapped in a single elevated Card (instead of a flat ListView with dividers). Each row is a MouseRegion -> Material that tints to MolTones.bgMuted on hover. The user''s account type is now rendered with the shared RolePill widget (lib/widgets/mol_chips.dart) rather than plain primary-coloured caps text; role colour comes from the same tone tokens (super = danger, admin = info, manager/overseer = warning, shift boss = success). Empty state replaced with the shared EmptyState widget.

What this means for users:
The User Profiles screen now feels like one continuous panel with rows you can hover over -- when you move your mouse over a row, it lightens up so you know exactly which one you''re about to click. Each user''s role appears as a small coloured pill instead of plain text, so at a glance you can tell who''s an Admin, who''s a Mine Manager, who''s a Shift Boss, etc. Different roles use different colours (Super Admin = red, Admin = blue, Manager / Overseer = amber, Shift Boss = green) so you can scan the list and spot the right person without reading every name.',
    'done',
    'whenever',
    'Jean Burger + Justin Trollip'
  ),
  (
    'eng',
    'Completed Logbook + Individual Completed History: elevated card + StatusChip',
    'Updated lib/screens/form_submission_history_screen.dart so submitted forms render inside an elevated Card with hover-tinted rows (MouseRegion -> Material -> bgMuted). The workflow status (fully signed / pending / submitted) is shown via the shared StatusChip widget with proper success / pending / info tones. Tapping a row now opens SubmissionViewerDialog (previously did nothing). Empty-state uses the shared EmptyState widget. The screen backs two routes: /completed-logbook-history and /individual-completed-logbook-history.

What this means for users:
The Completed Logbook History screen (and the per-user Individual Completed History screen) now show every saved form inside one neat panel, with each row lighting up as you hover. Beside each form you''ll see a small coloured pill telling you the signing status -- green if fully signed, amber if it''s still waiting for a signer, blue if it was just submitted. Tapping a row opens the saved form so you can review the original payload and download the PDF; before, the rows were just text with no action.',
    'done',
    'whenever',
    'Jean Burger'
  ),
  (
    'eng',
    'Appointment History + Active Individual Current Logbook: elevated card + RolePill + StatusChip',
    'Updated lib/screens/admin_appointments_logbook_screen.dart so both variants (history + active) render the per-user group list inside a single elevated Card. Each user-group header has a hover tint (MolTones.bgMuted) and a RolePill rendered from the user''s occupation/job title. The local _statusBadge helper now returns the shared StatusChip widget (success/pending/doing tones); the local _chip helper is gone except for an info-toned count chip showing "N forms". Submissions inside the expanded user group render in compact bgMuted cards with the same StatusChip status badge. Empty states use the shared EmptyState widget.

What this means for users:
The Appointment History Logs and Active Individual Current Logbook screens -- both used by Admins / Mine Overseers / Mine Managers -- now feel like one organised panel. Each user is one row that lights up on hover; their occupation appears as a small coloured pill so you can tell roles apart. Tap a user to expand and see every form they''ve ever submitted (history) or every form they currently have moving through the signature workflow (active). Each form shows a status pill: green for fully signed, amber for pending the next signer, blue for just submitted -- so you can scan a busy team without reading every row.',
    'done',
    'whenever',
    'Jean Burger'
  ),
  (
    'eng',
    '/appointments hub: brand-tinted hover tiles + 1px navy border',
    'Updated lib/screens/appointments_screen.dart so each of the 27 form tiles is a self-contained AnimatedContainer with: a 1 px MolTones.line border that thickens to navy on hover; a soft navy box-shadow that grows on hover; the icon circle uses navySoft + navy (instead of the previous primaryContainer / onPrimaryContainer); hover background fades to navySoft for tactile feedback. The shift-boss filter (canAccessShiftBossDocuments) is preserved -- the Shift Boss Appointment card still hides for non-shift-boss roles. Empty search state uses the shared EmptyState widget.

What this means for users:
When you visit Appointments, every form tile now sits on its own with a thin grey outline and lifts up with a soft shadow + a navy outline whenever your mouse passes over it -- you always know exactly which form you''re about to open. The icon at the top of each tile uses the Mine Online brand navy colour, so the page feels consistent with the rest of the app''s brand palette. Tapping a tile opens that form. The list still adapts to your screen size: four columns on a wide Windows screen, down to one column on a phone, so the layout never feels cramped or wasted.',
    'done',
    'whenever',
    'Jean Burger'
  )
) as v(kind, title, description, status, urgency, author_name)
where not exists (
  select 1 from public.todos t where t.kind = v.kind and t.title = v.title
);
