-- SP4.6: allowlist catalog of data-linked dropdown sources for the legacy-style
-- form designer. Reads are restricted to these seeded, admin-safe tables.
create table if not exists public.form_dropdown_sources (
  id            uuid primary key default gen_random_uuid(),
  key           text not null unique,
  table_name    text not null,
  value_column  text not null,
  label_column  text not null,
  display_name  text not null,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
alter table public.form_dropdown_sources enable row level security;
create policy "Read active dropdown sources"
  on public.form_dropdown_sources for select to authenticated
  using (is_active = true or public.is_admin(auth.uid()));
create policy "Admins insert dropdown sources"
  on public.form_dropdown_sources for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admins update dropdown sources"
  on public.form_dropdown_sources for update to authenticated
  using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

insert into public.form_dropdown_sources (key, table_name, value_column, label_column, display_name)
values
  ('shafts',            'shafts',            'id', 'name',      'Shafts'),
  ('sections',          'sections',          'id', 'name',      'Sections'),
  ('areas',             'areas',             'id', 'name',      'Areas'),
  ('gangs',             'gangs',             'id', 'name',      'Gangs'),
  ('shifts',            'shifts',            'id', 'name',      'Shifts'),
  ('appointment_roles', 'appointment_roles', 'id', 'label',     'Appointment Roles'),
  ('profiles',          'profiles',          'id', 'full_name', 'People')
on conflict do nothing;
