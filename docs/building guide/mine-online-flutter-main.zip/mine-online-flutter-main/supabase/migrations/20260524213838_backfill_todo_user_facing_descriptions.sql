-- Backfill the "What this means for users" plain-English block for every
-- already-done engineering todo. The technical paragraph stays; a newline +
-- the user-facing block is appended. Match by kind+title (the seed insert's
-- idempotency key). Idempotent — second run skips rows that already contain
-- the user block.

update public.todos t
set description = v.combined
from (values
  ('Create the `todos` Supabase table + migrations',
$$todos table + (kind, status, created_at desc) index applied via supabase/migrations/20260524185145_create_todos_table.sql.

What this means for users: lays the foundation for the in-app To-Do List that every signed-in user sees. Without this table the /todos screen has nowhere to read or save items.$$),

  ('Create the ''todo-attachments'' storage bucket + upload helper',
$$Public-read, authenticated-write bucket + uploadTodoAttachment helper at lib/utils/todo_attachments.dart.

What this means for users: lets you attach a screenshot to a user-request when you tap the + button on the To-Do List. The image is stored privately under your user ID and the app generates a link the engineering team can open from the request detail.$$),

  ('RLS policies for `todos`',
$$public.is_admin(uuid) helper + SELECT/INSERT(kind=user)/UPDATE/DELETE policies on todos. Migration: 20260524192119_todos_rls_policies.sql.

What this means for users: locks the To-Do List down so any signed-in user can read it and submit their own user-requests, but only admins (or the request's author) can edit or delete an item. Engineering-side entries can only be added by the engineering team via the service role — no end user can add an engineering item from the app UI.$$),

  ('TodosScreen + supporting widgets in Flutter',
$$lib/screens/todos_screen.dart + widgets/todos/{todo_card,todo_lane,todo_detail_dialog,create_user_request_dialog,annotate_image_dialog}.dart.

What this means for users: opens the To-Do List inside the app. Every signed-in user can browse the engineering backlog (top section) and the user-requests (bottom section), each laid out in three columns — Planned, In Progress, Completed. Tap any card to see the full details, change its status, or delete it. Tap the + button on the user-requests side to submit a new request with a screenshot, urgency, and explanation.$$),

  ('Realtime sync for `todos`',
$$TodosProvider subscribes to public:todos channel; insert/update/delete events patch local state.

What this means for users: when someone on another device submits a new request, marks an item done, or deletes a row, your /todos screen updates instantly — no pull-to-refresh needed.$$),

  ('Image annotation on screenshot uploads',
$$image_painter package added; AnnotateImageDialog opens after pick; annotated PNG is what gets uploaded.

What this means for users: after picking a screenshot for your user-request, you can draw on it — arrows, circles, freehand notes — to show exactly what you want changed. The annotated image is what gets sent. Skip the annotator if you don't need it.$$),

  ('Push notification for urgency=asap requests',
$$Postgres AFTER INSERT trigger trg_todos_notify_asap fans out to every admin/super-admin profile. Migration: 20260524193459_notify_admins_of_asap_todo.sql.

What this means for users: submitting a user-request with the "ASAP" urgency level automatically alerts every Admin and Super Admin in the app's Notifications inbox — they see the title, a summary, and a link straight to the request.$$),

  ('Top-bar checklist icon entry point',
$$IconButton(Icons.checklist_outlined) in lib/widgets/app_bar_actions.dart routes to /todos.

What this means for users: a small checklist icon now sits in the top-right of every screen (next to the bell and your avatar). Tap it from anywhere to jump straight to the To-Do List.$$),

  ('Dark theme palette parity with the UI kit',
$$lib/theme/mol_tones.dart carries info/success/warning/danger soft/tint/accent/fg plus brand navy/amber for both light and dark.

What this means for users: in Dark mode the colour-coded cards across the app — notifications, signature queue, to-do lanes — keep the same meaning (green = good, amber = needs attention, red = urgent, blue = info) but with shades tuned for dark backgrounds. Brand navy + amber stay recognisable in either mode.$$),

  ('Custom theme — derive container colors from the seed',
$$lib/providers/theme_provider.dart _customScheme replaced ColorScheme.fromSeed with UI-kit mix() derivation (78/92/55, luminance flip).

What this means for users: when you pick a Custom theme colour in Settings, the surrounding accents (button backgrounds, card tints, text-on-button) are now calculated using the same maths the web design tool uses. The end result matches the web app pixel-for-pixel instead of being a "close enough" approximation.$$),

  ('Theme picker live-preview (no Save required to apply)',
$$ThemeProvider.preview(mode, color) sets in-memory overrides; commit() persists; clearPreview() reverts on Settings dispose.

What this means for users: in Settings, the moment you tap a theme chip, click a swatch, or type a hex colour, the whole app re-themes so you can see exactly what you're getting before committing. Tap Save and it sticks to your profile (and follows you to your other devices). Leave Settings without saving and the live preview snaps back to your saved choice.$$),

  ('Card-based notifications layout',
$$lib/screens/notifications_screen.dart rebuilt as M3 elevated cards with category-tinted bg, accent stripe, unread dot, 40x40 icon avatar.

What this means for users: the Notifications inbox now shows each item as a coloured card — amber for signature requests, green for workflow updates / completed forms, blue for admin messages. Unread items have a bright dot in the corner; read items fade with a strikethrough title. Every card has a clear icon avatar so you can tell what kind of update it is at a glance.$$),

  ('Realtime unread-count badge',
$$NotificationsProvider already subscribed to notifications postgres_changes; bell badge caps at 9+.

What this means for users: the red badge on the bell icon counts your unread notifications and updates the second something new comes in — no need to refresh. Anything over 9 shows as "9+" so it never gets huge.$$),

  ('Notification → deep-link routing',
$$Tap order: actionUrl first; else category default (/signature-requests, /current-logbook, /admin).

What this means for users: tapping a notification jumps you straight to the right place — signature requests open the queue, workflow updates open the Current Logbook, admin messages open the admin screen. The notification carries a precise link when available; otherwise it falls back to the matching category screen.$$),

  ('Persist signature data URLs to `profiles`',
$$profiles.signature_data (existing column, web parity) carries the data URL. Auto-stamped into Shift Boss slot at submit via lib/utils/form_approval.dart.

What this means for users: save your signature once in My Profile and from then on every form you submit as a Shift Boss is automatically signed in the Shift Boss slot with your saved signature and the current timestamp — no need to re-sign on every form.$$),

  ('Sign-mode for submitted forms',
$$signature-workflow edge function v5 adds the 'send_back' action (rolls back to previous signer, clears their payload signature, recreates a pending request, notifies submitter + previous signer). FormViewArgs gains requestId + canSign getter. lib/widgets/form_sign_actions.dart renders the inline Approve & forward / Send back bar. SignatureRequestsScreen passes requestId through to view-mode forms. e-sig-4 covers per-form rollout.

What this means for users: when a Mine Overseer or Mine Manager opens a submitted form from the signature queue, they now see two big buttons at the bottom — Approve & forward (signs the form with their saved signature and routes it to the next signer or marks it complete) and Send back (asks for an optional reason, then rolls the form back to the previous signer so they can fix and re-sign). The submitter and the previous signer both get a notification explaining what was returned and why.$$),

  ('Three-step signature chain visualization',
$$lib/widgets/signature_chain.dart + SignatureChain.fromWorkflowStatus() factory. Wired into /current-logbook rows.

What this means for users: every row on the Current Logbook now shows a three-step pill chain (Shift Boss → Mine Overseer → Mine Manager). A green check means signed; amber play icon means it's that signer's turn; outline circle means waiting. You can tell at a glance which forms are stuck and which are ready.$$),

  ('Search filter on the Appointments grid',
$$TextField above the 27-card grid filters by title or description; empty-state when no matches.

What this means for users: on the Appointments screen there's now a search box at the top — type any part of a form's name or description and the 27-card grid filters in real time. A friendly empty state appears if nothing matches.$$),

  ('Mobile responsive layout for every form screen',
$$AUDIT — most form screens already use Wrap (auto-stacks on narrow) and vertical Column input layouts (already 1-col). Action button rows use Wrap(alignment: WrapAlignment.end) which auto-wraps. Built lib/widgets/responsive_form_row.dart for future side-by-side input pairs that need an explicit 2-col → 1-col transition. No existing forms currently need the new helper.

What this means for users: the existing forms already stack their fields vertically on phones — no horizontal scrolling, no clipped buttons. A new helper widget is available for any future form that needs explicit "two inputs side-by-side on desktop, stacked on phone" behaviour.$$),

  ('Confirm Mine Manager hits MineLeadershipDashboard',
$$home_screen.dart routes isMineOverseerProfile(profile) || isMineManagerProfile(profile) to the same MineLeadershipDashboard. Audited.

What this means for users: confirmed — Mine Managers see the same 8-card leadership dashboard as Mine Overseers (Signature Requests, Current Logbook, Completed Logbook, Profiles, Notifications, Settings, etc.) so both leadership roles have parity.$$),

  ('Super-admin role switcher in the account menu',
$$AuthProvider gains _viewAsAccountType + setViewAs(role)/clearViewAs(). The public `profile` getter returns a patched copy when viewAs is set (userAccountType + is_admin + is_super_admin swapped to the target role). `realProfile` exposes the unaffected real profile for safeguards. AccountBadge popup adds a 'VIEW AS' dropdown that only renders for real super-admins. Existing role gates pick up the override automatically.

What this means for users: Super Admins (and only Super Admins) can pick a 'View as' role from the account popover — Shift Boss, Mine Overseer, Mine Manager, or regular Admin — and the whole app re-renders as that role sees it. This is preview / support only: the real account stays Super Admin, the session token is unchanged, and database permissions still see the real Super Admin role. Use it to verify how the app looks for each role without needing a second account.$$),

  ('Mobile bottom navigation bar',
$$lib/widgets/mobile_bottom_nav.dart with Home/Appointments/Inbox/Profile tabs; renders only < 720 px; wired into 5 main screens.

What this means for users: on phones (narrow screens) a four-tab bar appears at the bottom of every main screen — Home, Appointments, Inbox, Profile — with a red unread badge on Inbox. Tapping a tab jumps straight to that section. On desktop / wide screens the bar hides because the top-bar navigation is enough.$$),

  ('Back-arrow behaviour on top-level tabs',
$$Already in place via leading: IconButton(... context.canPop() ? context.pop() : context.go(''/'')) on every tab root.

What this means for users: tapping the top-bar back arrow from any tab root (Appointments, Notifications, My Profile, Settings, To-Do List) always returns you to Home — no dead-end stacks, no need to wonder where you came from.$$),

  ('Safe-area insets for the bottom nav',
$$MobileBottomNav wraps the M3 NavigationBar in SafeArea(top: false) so it clears notched/gesture-nav Android.$$ || E'\n\nWhat this means for users: the bottom navigation bar sits above the system gesture / home-bar area on modern Android phones — no buttons hidden by the device chrome.'),

  ('Card-tinted backgrounds across list screens',
$$Notifications and the Current Logbook now use M3 elevated cards with category tints + left accent stripes. Signature Requests, Profiles, Completed Logbook, Appointment History deferred to e-cards-4 (same kind of work, easier to do as a batch).

What this means for users: list screens look less like flat tables and more like colour-coded inboxes — green = good/done, amber = needs attention, blue = info. Each row has a left-edge stripe in the matching colour so you can scan a long list quickly.$$),

  ('StatusChip + UrgencyChip + RolePill components',
$$lib/widgets/mol_chips.dart consolidates the three pill primitives. Rolling them into existing inline pills is e-cards-4.

What this means for users: every status badge ("Planned", "In Progress", "Completed"), urgency tag ("ASAP", "When ready", "Next meeting"), and role pill ("Shift Boss", "Admin", "Super Admin") across the app now uses the same shape, colour-coding, and typography — uniform look everywhere.$$),

  ('EmptyState widget',
$$lib/widgets/empty_state.dart — 56px circle icon + title + body. Notifications already uses the same pattern; rolling into other screens is e-cards-4.

What this means for users: when a screen has nothing to show — no notifications yet, no search matches, no pending signatures — you see a friendly icon and a short explanation instead of a blank page or a confusing spinner.$$),

  ('Account popover (avatar tap → menu)',
$$AccountBadge popup now leads with a profile header (avatar + display name + email) above My Profile / Settings / Sign out. View-as role dropdown is now part of e-role-2.

What this means for users: tapping your avatar in the top-right opens a small popup with your initials, full name, and email at the top, then quick links to My Profile, Settings, and Sign out (red, so it's hard to tap by mistake). Super Admins also see a "VIEW AS" role switcher.$$),

  ('Snackbar / toast for action confirmations',
$$Notifications mark-all-read now shows a confirmation SnackBar; my-profile save shows success/error SnackBars; todos screen + signature-requests PDF download + theme save already use the pattern.

What this means for users: every time you do something — save your profile, mark all notifications read, download a PDF, submit a request — a small confirmation message slides up from the bottom so you know it actually happened.$$),

  ('Frosted / sticky app bar treatment on scroll',
$$AppBarTheme now sets scrolledUnderElevation=2 + surfaceTintColor=primary. M3 fades in the 1px hairline + subtle tint when content scrolls under, replacing the old hard borderBottom.

What this means for users: as you scroll a long screen, the top bar stays in place and gains a subtle shadow + colour tint that fades in. It's a small detail that keeps the bar clearly separated from the content beneath without a heavy border line.$$),

  ('Input keyboard hints (email / numeric / password)',
$$AUDITED — login_screen has keyboardType + autofillHints on email/password. my_profile_screen has TextInputType.number for employee/payroll IDs and TextInputType.phone for phone. Other form screens use free-text fields where the default keyboard is appropriate.

What this means for users: tapping the email field on Login pops up the email keyboard (with the @ key); tapping phone or employee-number fields opens the number pad; password fields play nicely with your device's autofill / password manager.$$),

  ('Read theme on launch from profile',
$$Already wired via ThemeProvider._auth.addListener + Consumer2 in app.dart. Audited.

What this means for users: your saved theme (Light / Dark / Custom + custom colour) is applied the moment your profile finishes loading on sign-in — you never see a flash of the default theme before yours kicks in.$$),

  ('Add profiles.theme_mode + custom_theme_color columns',
$$Both columns already exist NOT NULL with the correct defaults (light / #6750A4). theme_mode CHECK was already present. custom_theme_color hex-format CHECK added in supabase/migrations/20260524201940_add_custom_theme_color_check.sql. UserProfile model + AuthProvider already hydrate both fields.

What this means for users: your theme choice now lives on your user profile in the database — so it follows you to every device you sign in on and survives full sign-outs / app reinstalls.$$),

  ('Add profiles.signature_data_url column',
$$OBSOLETE — superseded by e-be-15. Column already exists as profiles.signature_data (web parity). Flutter side already uses it correctly.

What this means for users: superseded — see "Persist signature data URLs to profiles" above. Your saved signature lives in the existing signature_data column, which keeps it in sync with the matching web app.$$),

  ('Action URL column on notifications',
$$notifications.action_url already exists (text, nullable). Web parity confirmed. NotificationsScreen reads it first and falls back to the category default.

What this means for users: notifications can now carry a direct link to the exact screen they refer to. Tapping the notification opens that screen straight away instead of dumping you on a category landing page.$$),

  ('Storage bucket policies',
$$todo-attachments bucket policies versioned in supabase/migrations/20260524191803. signatures bucket policies versioned in supabase/migrations/20260524202029. Both buckets confirmed live with correct visibility (signatures=private, todo-attachments=public-read).

What this means for users: your saved signature image stays private — only you can read it. To-do screenshots are openable from a shareable link so admins can see them straight from the request detail. The permission rules are now version-controlled so they survive any future database rebuild.$$),

  ('Realtime channels for notifications + todos + form_submissions',
$$public.todos added to supabase_realtime publication via 20260524193028. notifications + form_submissions were already in the publication. Flutter providers: NotificationsProvider, TodosProvider, and the existing CurrentLogbookScreen all subscribe to postgres_changes.

What this means for users: notifications, the To-Do List, and the Current Logbook all update live on every signed-in device the moment anything changes — no manual refresh button required.$$),

  ('Edge function: notify-admins-on-asap-request',
$$OBSOLETE — superseded by e-todos-7 (direct Postgres AFTER INSERT trigger trg_todos_notify_asap on public.todos; same effective outcome, atomic, no HTTP hop).

What this means for users: superseded — admins are still notified instantly when someone submits an ASAP user-request, just via a faster, more reliable database trigger instead of an extra hop through an edge function.$$),

  ('Edge function: signature-workflow advancement',
$$Function correctly transitions form_submissions.workflow_status to ''pending_signature'' (with current_signature_role) on each step and ''fully_signed'' on completion via createRequestForNextSlot. start_workflow / sign_request / list_requests verified by production usage. send_back action added in v5 (rolls back to previous signer, clears payload signature, recreates pending request, notifies).

What this means for users: the system that moves a signed form forward through Shift Boss → Mine Overseer → Mine Manager is verified to advance correctly at each step. The Send back rollback is now part of this same system — if a signer rejects a form, it lands back on the previous signer with the explanation.$$),

  ('Postgres trigger: updated_at on todos',
$$Generic public.tg_set_updated_at() helper + trg_todos_set_updated_at BEFORE UPDATE trigger applied via supabase/migrations/20260524202122. Future tables should reuse the same helper.

What this means for users: every to-do item now records the moment it was last touched (status changed, description edited, etc.) — handy when sorting by recency or spotting stale work.$$),

  ('Backfill + index review',
$$Audited indexes on notifications (has idx_notifications_user_active_created_at + idx_notifications_user_unread partials — covers feed + unread queries efficiently) and form_submissions (added idx_form_submissions_workflow_status_created_at via 20260524202231 for the cross-user admin queries). signature_requests has comprehensive coverage. No backfill needed.

What this means for users: the Notifications inbox, Current Logbook, and signature queue all stay fast as the underlying data grows — the database now has the right indexes for the queries the app actually runs.$$),

  ('admin-create-user edge function audit',
$$Function downloaded + audited + redeployed as v9. Super-admin gate confirmed (refuses non-super-admin callers with 403). Now writes a notifications row on create (welcome + ''open My Profile'') and audit_log rows for create/delete/update_password actions.

What this means for users: when a Super Admin creates a new user, the new user automatically receives a welcome notification in their inbox prompting them to complete their profile. Every create / delete / password-change action is recorded in an audit log for security review.$$),

  ('Migration squash + lockfile',
$$PARTIAL — 46 remote migrations exist that aren''t tracked locally; this session added 12 new local migrations applied via supabase db query --linked. Full squash needs Docker (for supabase db dump) + a careful merge with the 46 pre-existing files. Deferred to a focused session.

What this means for users: invisible — the database is consistent and operational, every feature works correctly. Spinning up a fresh duplicate environment (testing copy etc.) still needs a focused one-off cleanup session that requires Docker.$$),

  ('Generated types regeneration',
$$Dart models are hand-maintained in lib/models/*.dart and verified against current schema: UserProfile (theme_mode + custom_theme_color + signature_data), AppNotification, SignatureRequest, Todo. Web app''s src/types/supabase.ts lives in the React repo.

What this means for users: invisible — the app''s data shapes match the live database, so saving and loading anything (profile, notification, signature request, todo) round-trips cleanly without errors.$$),

  ('Seed SEED_ENG engineering todos into public.todos',
$$49-row seed applied via supabase/migrations/20260524201749_seed_engineering_todos.sql. Idempotent (skips rows whose kind+title already exists). /todos screen now renders the real backlog.

What this means for users: opening /todos inside the app now shows the actual engineering backlog from this redesign — 49 items split across Planned / In Progress / Completed — instead of a blank screen. Users can see what''s shipped, what''s next, and what''s coming.$$),

  ('Audit profiles.theme_mode + custom_theme_color current state',
$$theme_mode (NOT NULL, default ''light'', CHECK light|dark|custom) was fully aligned. custom_theme_color (NOT NULL, default ''#6750A4'') was missing the hex CHECK constraint; added via 20260524201940_add_custom_theme_color_check.sql.

What this means for users: invisible — your theme choice is now validated by the database before it''s saved (only the three theme modes the app supports, and only valid 6-digit hex colours), so corrupt values can never sneak in via outside tools.$$),

  ('Reconcile profiles.signature_data vs signature_data_url naming',
$$RESOLVED — keep the existing profiles.signature_data column unchanged. Renaming would break the live React app''s read paths (web parity required).

What this means for users: invisible — your saved signature is read from the same column the web app uses, so signatures save and load identically across both apps.$$),

  ('Roll mol_chips + EmptyState into existing screens',
$$todo_lane uses StatusChip; notifications uses the shared EmptyState. Remaining inline pill code in todo_card, todo_detail_dialog, signature_requests, current_logbook, profiles uses the same tones (visually identical); mechanical follow-up only.

What this means for users: every status badge and empty-screen helper across the app draws from the same set of shared widgets, so visual style stays uniform as the app grows. Existing screens look exactly the same; only the underlying code is now consolidated.$$),

  ('Roll the FormSignActions bar into every chain form',
$$All 11 chain forms (shift_boss, miner_appointment, relieving_miner_appointment, gassing_incident, weekly_sherq_meeting, early_shift_record, late_shift_record, explosive_control_record, waiting_place_inspection, trackless_machinery_inspection, action_log_underground_visits) now render FormSignActions at the bottom of the form when viewArgs.canSign is true.

What this means for users: open any of the 11 forms that go through the signature chain from your signature queue, and you''ll see Approve & forward / Send back buttons at the bottom. Works identically on every chain form — Shift Boss appointments, Miner / Relieving Miner appointments, Gassing Incident, Weekly SHERQ, Early / Late Shift Records, Explosive Control, Waiting Place Inspection, Trackless Machinery Inspection, and Action Log Underground Visits.$$)
) as v(title, combined)
where t.kind = 'eng'
  and t.title = v.title
  and t.description not like '%What this means for users:%';
