-- Org structure SP5b: shifts, gangs, and gang memberships. Builds on SP5a
-- (shafts/sections) and links members from public.profiles. Admins manage;
-- authenticated users read active rows. Archive = is_active=false.

create table if not exists public.shifts (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  start_time  text,
  end_time    text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists public.gangs (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  shaft_id    uuid references public.shafts(id) on delete set null,
  section_id  uuid references public.sections(id) on delete set null,
  shift_id    uuid references public.shifts(id) on delete set null,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists gangs_shaft_idx on public.gangs (shaft_id, is_active);

create table if not exists public.gang_memberships (
  id          uuid primary key default gen_random_uuid(),
  gang_id     uuid not null references public.gangs(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  unique (gang_id, user_id)
);
create index if not exists gang_memberships_gang_idx on public.gang_memberships (gang_id, is_active);

alter table public.shifts           enable row level security;
alter table public.gangs            enable row level security;
alter table public.gang_memberships enable row level security;

create policy "Read shifts" on public.shifts
  for select to authenticated using (is_active or public.is_admin(auth.uid()));
create policy "Admins insert shifts" on public.shifts
  for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "Admins update shifts" on public.shifts
  for update to authenticated using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));

create policy "Read gangs" on public.gangs
  for select to authenticated using (is_active or public.is_admin(auth.uid()));
create policy "Admins insert gangs" on public.gangs
  for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "Admins update gangs" on public.gangs
  for update to authenticated using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));

create policy "Read gang_memberships" on public.gang_memberships
  for select to authenticated using (true);
create policy "Admins insert gang_memberships" on public.gang_memberships
  for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "Admins update gang_memberships" on public.gang_memberships
  for update to authenticated using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));
create policy "Admins delete gang_memberships" on public.gang_memberships
  for delete to authenticated using (public.is_admin(auth.uid()));
