-- Form Builder SP2.1: dynamic, admin-authored form templates. Self-contained;
-- does not touch the existing form_templates registry or form_submissions.
-- Submissions of these forms go to form_submissions with form_type = code.

create table if not exists public.custom_form_templates (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique,
  name              text not null,
  description       text,
  category          text,
  fields            jsonb not null default '[]'::jsonb,
  audience          jsonb not null default '[]'::jsonb,
  required_signers  jsonb not null default '[]'::jsonb,
  version           integer not null default 1,
  is_active         boolean not null default true,
  created_by        uuid references public.profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists custom_form_templates_active_idx
  on public.custom_form_templates (is_active, updated_at desc);

alter table public.custom_form_templates enable row level security;

-- Any authenticated user may read active templates; admins read all.
create policy "Read active custom form templates"
  on public.custom_form_templates
  for select
  to authenticated
  using (is_active = true or public.is_admin(auth.uid()));

-- Only admins/super-admins may create/update.
create policy "Admins insert custom form templates"
  on public.custom_form_templates
  for insert
  to authenticated
  with check (public.is_admin(auth.uid()));

create policy "Admins update custom form templates"
  on public.custom_form_templates
  for update
  to authenticated
  using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));
