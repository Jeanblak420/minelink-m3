-- e-todos-5 prerequisite (also satisfies the todos portion of e-be-5).
-- Adds public.todos to the supabase_realtime publication so the Flutter
-- TodosProvider's postgres_changes subscription receives events.

alter publication supabase_realtime add table public.todos;
