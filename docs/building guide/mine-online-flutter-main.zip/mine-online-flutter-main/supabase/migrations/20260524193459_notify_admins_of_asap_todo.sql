-- e-todos-7: when a user submits an urgency='asap' request, drop a
-- notification into every admin / super-admin's inbox.
--
-- Implemented as a Postgres AFTER INSERT trigger rather than an edge function
-- call so it's atomic with the todos insert. SECURITY DEFINER is required to
-- read public.profiles and insert into public.notifications for users other
-- than the caller. EXECUTE is revoked from public/authenticated so the data
-- API can't invoke the function directly — only the trigger executor can.
--
-- The matching task in the backlog is e-be-6 ('notify-admins-on-asap-request'
-- edge function); this implementation supersedes that approach with a trigger
-- (simpler, atomic, no HTTP hop, identical effect for end users).

create or replace function public.notify_admins_of_asap_todo()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.kind = 'user' and new.urgency = 'asap' then
    insert into public.notifications
      (user_id, type, title, body, action_url, metadata)
    select
      p.id,
      'warning',
      'Urgent user request',
      coalesce(nullif(new.submitter_name, '') || ': ', '') ||
        coalesce(left(new.summary, 200), new.title),
      '/todos',
      jsonb_build_object(
        'category', 'admin',
        'todo_id', new.id::text,
        'urgency', new.urgency
      )
    from public.profiles p
    where p.id != new.submitter_id
      and (
        p.is_admin
        or coalesce(p.is_super_admin, false)
        or p.user_account_type in ('Admin', 'Super Admin')
      );
  end if;
  return new;
end;
$$;

revoke all on function public.notify_admins_of_asap_todo() from public;
revoke all on function public.notify_admins_of_asap_todo() from authenticated;
revoke all on function public.notify_admins_of_asap_todo() from anon;

drop trigger if exists trg_todos_notify_asap on public.todos;
create trigger trg_todos_notify_asap
  after insert on public.todos
  for each row
  execute function public.notify_admins_of_asap_todo();
