-- Org structure SP5a: Section + Area tables under the existing shafts table,
-- plus RLS so admins manage the Shaft → Section → Area hierarchy and any
-- authenticated user can read active rows. shafts already exists (reused).

create table if not exists public.sections (
  id          uuid primary key default gen_random_uuid(),
  shaft_id    uuid not null references public.shafts(id) on delete cascade,
  name        text not null,
  description text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists sections_shaft_idx on public.sections (shaft_id, is_active);

create table if not exists public.areas (
  id          uuid primary key default gen_random_uuid(),
  section_id  uuid not null references public.sections(id) on delete cascade,
  name        text not null,
  description text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists areas_section_idx on public.areas (section_id, is_active);

alter table public.shafts   enable row level security;
alter table public.sections enable row level security;
alter table public.areas    enable row level security;

-- shafts pre-exists; (re)create its policies idempotently.
drop policy if exists "Read shafts" on public.shafts;
drop policy if exists "Admins insert shafts" on public.shafts;
drop policy if exists "Admins update shafts" on public.shafts;
create policy "Read shafts" on public.shafts
  for select to authenticated using (is_active or public.is_admin(auth.uid()));
create policy "Admins insert shafts" on public.shafts
  for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "Admins update shafts" on public.shafts
  for update to authenticated using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));

create policy "Read sections" on public.sections
  for select to authenticated using (is_active or public.is_admin(auth.uid()));
create policy "Admins insert sections" on public.sections
  for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "Admins update sections" on public.sections
  for update to authenticated using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));

create policy "Read areas" on public.areas
  for select to authenticated using (is_active or public.is_admin(auth.uid()));
create policy "Admins insert areas" on public.areas
  for insert to authenticated with check (public.is_admin(auth.uid()));
create policy "Admins update areas" on public.areas
  for update to authenticated using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));
