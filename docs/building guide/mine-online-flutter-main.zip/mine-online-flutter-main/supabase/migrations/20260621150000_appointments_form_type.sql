-- SP4 addendum: appointments can reference a built-in appointment form (e.g.
-- shift_boss_appointment) in addition to an SP3 dynamic template. form_type holds
-- the submission/render form_type for both kinds (= template code for dynamic).

alter table public.appointments add column if not exists form_type text;
