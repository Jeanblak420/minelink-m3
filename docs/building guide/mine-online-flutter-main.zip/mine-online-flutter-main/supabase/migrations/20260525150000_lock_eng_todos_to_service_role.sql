-- Tighten the UPDATE policy on public.todos so authenticated users can
-- no longer flip status / edit kind='eng' rows. Engineering todos are
-- managed by the engineering system via service_role; users see and read
-- them, but the checkbox + status controls are intentionally read-only.
-- User-request todos (kind='user') stay collaborative: the original
-- submitter, author, or any admin can still edit them as before.
--
-- service_role bypasses RLS entirely, so this does not block the
-- engineering system from writing.

drop policy if exists "Authors and admins can update todos" on public.todos;

create policy "Update user-kind todos only"
  on public.todos
  for update
  to authenticated
  using (
    kind = 'user'
    and (author_id = auth.uid()
         or submitter_id = auth.uid()
         or public.is_admin(auth.uid()))
  )
  with check (
    kind = 'user'
    and (author_id = auth.uid()
         or submitter_id = auth.uid()
         or public.is_admin(auth.uid()))
  );
