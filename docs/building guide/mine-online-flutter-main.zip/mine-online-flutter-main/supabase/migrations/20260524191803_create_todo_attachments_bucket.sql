-- e-todos-2: todo-attachments storage bucket + RLS policies for storage.objects.
-- Public-read so a saved attachment renders via getPublicUrl() without signing.
-- Authenticated-write, scoped to the uploader's own '<userId>/...' folder.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'todo-attachments',
  'todo-attachments',
  true,
  5242880,
  array['image/png', 'image/jpeg', 'image/webp', 'image/gif']::text[]
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Authenticated can upload to todo-attachments" on storage.objects;
create policy "Authenticated can upload to todo-attachments"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'todo-attachments'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );

drop policy if exists "Authenticated can read own todo-attachments rows" on storage.objects;
create policy "Authenticated can read own todo-attachments rows"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'todo-attachments'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );

drop policy if exists "Authenticated can update own todo-attachments rows" on storage.objects;
create policy "Authenticated can update own todo-attachments rows"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'todo-attachments'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );

drop policy if exists "Authenticated can delete own todo-attachments rows" on storage.objects;
create policy "Authenticated can delete own todo-attachments rows"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'todo-attachments'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );
