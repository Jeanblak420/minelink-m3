-- SP9a: user lifecycle + audit trail.
-- 1) profiles disable flags; 2) tighten audit_log read to admins;
-- 3) audit role changes made via the profile-edit path.

alter table public.profiles
  add column if not exists disabled boolean not null default false,
  add column if not exists disabled_at timestamptz;

-- audit_log was world-readable ("Allow public read audit_log" USING true).
-- Restrict to admins. Writes remain service-role / SECURITY DEFINER only.
drop policy if exists "Allow public read audit_log" on public.audit_log;
drop policy if exists "Admins read audit_log" on public.audit_log;
create policy "Admins read audit_log" on public.audit_log
  for select to authenticated
  using (public.is_admin(auth.uid()));

create or replace function public.fn_audit_profile_role_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.user_account_type is distinct from old.user_account_type then
    insert into public.audit_log
      (user_id, action, entity_type, entity_id, old_values, new_values)
    values
      (auth.uid(), 'user.role_change', 'user', new.id,
       jsonb_build_object('user_account_type', old.user_account_type),
       jsonb_build_object('user_account_type', new.user_account_type));
  end if;
  return new;
end;
$$;

drop trigger if exists trg_profiles_audit_role on public.profiles;
create trigger trg_profiles_audit_role
  after update on public.profiles
  for each row execute function public.fn_audit_profile_role_change();
