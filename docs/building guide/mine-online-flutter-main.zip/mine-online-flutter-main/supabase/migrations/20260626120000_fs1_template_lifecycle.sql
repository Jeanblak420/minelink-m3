-- FS1: at most one ACTIVE overlay draft per base form. Originals have no active
-- draft (loadFormOverlay returns null -> the bespoke form is the fallback).
create unique index if not exists custom_form_templates_one_active_overlay
  on public.custom_form_templates (base_form_type)
  where base_form_type is not null and is_active = true;
