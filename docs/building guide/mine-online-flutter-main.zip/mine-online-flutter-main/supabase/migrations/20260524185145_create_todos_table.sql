-- e-todos-1: Create the todos table + index.
-- Shared shift-boss / mine-overseer / admin to-do list. Two kinds:
--   kind = 'eng'  -> engineering tasks (service_role inserts only)
--   kind = 'user' -> user-submitted requests (any authenticated user)
-- RLS lives in a separate migration (see e-todos-3).
-- updated_at trigger lives in a separate migration (see e-be-8).
-- Storage bucket lives in a separate migration (see e-todos-2 / e-be-4).

create table if not exists public.todos (
  id                  uuid primary key default gen_random_uuid(),
  kind                text not null check (kind in ('eng', 'user')),
  title               text not null,
  description         text,
  summary             text,
  status              text not null default 'planned' check (status in ('planned', 'doing', 'done')),
  urgency             text check (urgency in ('asap', 'whenever', 'meeting')),
  submitter_name      text,
  submitter_id        uuid references public.profiles(id) on delete set null,
  author_id           uuid references public.profiles(id) on delete set null,
  author_name         text,
  image_storage_path  text,
  image_notes         text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create index if not exists todos_kind_status_idx
  on public.todos (kind, status, created_at desc);

alter table public.todos enable row level security;
