-- e-be-8: BEFORE UPDATE trigger that keeps todos.updated_at fresh.
-- The existing form_submissions table has a bespoke update_form_submissions_updated_at()
-- function; new tables should use this generic public.tg_set_updated_at()
-- helper so we don't accrue one function per table going forward.

create or replace function public.tg_set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

revoke all on function public.tg_set_updated_at() from public;

drop trigger if exists trg_todos_set_updated_at on public.todos;
create trigger trg_todos_set_updated_at
  before update on public.todos
  for each row
  execute function public.tg_set_updated_at();
