-- Log the two follow-up changes shipped in this turn into public.todos so
-- they appear in the in-app To-Do List under Engineering / Completed.

insert into public.todos (kind, title, description, status, author_name)
values
  ('eng',
   'Show the To-Do List checklist icon on the Home screen header too',
$$home_screen.dart's custom _Header builds its own action row (it doesn't use the standard AppBar + commonAppBarActions). Added homeHeaderActions() in lib/widgets/app_bar_actions.dart that returns the same trio (checklist + bell + avatar) and rewired _Header to use it. TodosChecklistButton is now a public reusable widget. The checklist icon sits in the top-right of every screen including the Home dashboard, every role-specific dashboard, and every default landing view.

What this means for users: opening the app on Home or any dashboard now shows the checklist icon top-right alongside the notification bell and your avatar. Tapping it jumps straight to the To-Do List — no need to open another screen first.$$,
   'done',
   'Engineering'),

  ('eng',
   'Remove engineering-tooling names from app-visible data and UI',
$$supabase/migrations/20260524223550_strip_claude_mentions_from_todos.sql rewrites every row in public.todos where author_name, description, title, or summary contained the engineering-tooling name — author labels become 'Engineering' and any in-text mention is replaced with 'Engineering'. The Flutter Engineering section subtitle was changed from the old wording to 'Tasks added automatically by the engineering system as work ships. Visible to all account types.'. SEED_ENG prototype header comment scrubbed too. Memory rule feedback_no_claude_in_data added so future inserts never reintroduce the word.

What this means for users: the To-Do List now reads as if it's the project's engineering team adding the entries — no implementation details about which tooling wrote them leak into the user-facing copy.$$,
   'done',
   'Engineering');
