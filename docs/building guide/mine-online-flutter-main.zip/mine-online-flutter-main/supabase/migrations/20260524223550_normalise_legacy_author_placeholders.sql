-- Operating rule: never store the word "Claude" anywhere in public.todos.
-- Replaces 'Claude Code' author labels with 'Engineering' and strips any
-- 'Claude Code' mentions in descriptions / titles / summaries. Idempotent.

update public.todos
set author_name = 'Engineering'
where author_name ilike '%claude%';

update public.todos
set description = regexp_replace(description, 'Claude Code', 'Engineering', 'gi')
where description ilike '%claude%';

update public.todos
set title = regexp_replace(title, 'Claude Code', 'Engineering', 'gi')
where title ilike '%claude%';

update public.todos
set summary = regexp_replace(summary, 'Claude Code', 'Engineering', 'gi')
where summary ilike '%claude%';
