-- Fix: SP-created tables (created via Management-API SQL rather than the Supabase
-- dashboard) never received the table-level GRANTs that Supabase auto-applies to
-- `authenticated`/`anon`. Postgres checks table privileges BEFORE row-level
-- security, so the client (authenticated role) got "permission denied for table"
-- (SQLSTATE 42501) even though correct RLS policies exist. Surfaced via the form
-- builder reading `custom_form_templates`, but it affects every SP table.
--
-- All listed tables have RLS enabled, so granting broad privileges to
-- `authenticated` is safe — RLS still gates which rows/operations are allowed
-- (this is the standard Supabase model: grant broadly, restrict via RLS).
-- Legacy/vestigial tables (users, sessions, form_fields, form_instances,
-- form_signatures, signatures, user_roles) are intentionally NOT granted.

grant select, insert, update, delete on table
  public.appointment_roles,
  public.appointment_templates,
  public.appointments,
  public.areas,
  public.audit_log,
  public.custom_form_templates,
  public.devices,
  public.form_dropdown_sources,
  public.gang_memberships,
  public.gangs,
  public.sections,
  public.shifts
to authenticated;
