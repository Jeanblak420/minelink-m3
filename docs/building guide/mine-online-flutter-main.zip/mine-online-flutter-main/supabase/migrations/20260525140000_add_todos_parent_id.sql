-- Add self-referencing parent_id to public.todos so the /todos screen can
-- render main tasks with their phases nested underneath (and phases with
-- their own sub-tasks, recursively). Also backfill parent_id for the 29
-- '[T# · Phase X]' rows seeded in 20260525130000 so they link to their
-- 4 '[T#]' main rows.
--
-- ON DELETE CASCADE: deleting a parent removes its descendants too. This
-- matches the existing admin-only delete RLS (only admins can delete
-- anything in the first place), and it keeps the tree consistent.

alter table public.todos
  add column if not exists parent_id uuid
    references public.todos(id) on delete cascade;

create index if not exists idx_todos_parent_id
  on public.todos(parent_id);

-- Backfill: for every '[T1 · Phase 1] ...' row, set parent_id to the
-- matching '[T1] ...' row. The regex captures the digit(s) right after
-- the opening '[T'. Idempotent — only updates rows whose parent_id is
-- currently null.
with mains as (
  select id,
         substring(title from '\[T(\d+)\]') as task_number
  from public.todos
  where kind = 'eng'
    and title ~ '^\[T\d+\] '
)
update public.todos child
set parent_id = mains.id
from mains
where child.parent_id is null
  and child.kind = 'eng'
  and child.title ~ '^\[T\d+ · '
  and substring(child.title from '\[T(\d+) ') = mains.task_number;
