-- SP9c: audit appointment + device lifecycle into the existing audit_log.
-- Additive SECURITY DEFINER triggers; existing notify/guard triggers untouched.

create or replace function public.fn_audit_appointment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
  v_appointee text;
begin
  if tg_op = 'INSERT' then
    v_action := 'appointment.issued';
  elsif new.status is distinct from old.status then
    v_action := case new.status
      when 'pending_signoff' then 'appointment.accepted'
      when 'active'          then 'appointment.activated'
      when 'declined'        then 'appointment.declined'
      when 'resigned'        then 'appointment.resigned'
      else null
    end;
  else
    v_action := null;
  end if;

  if v_action is null then
    return new;
  end if;

  select full_name into v_appointee
    from public.profiles where id = new.appointee_id;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, new_values)
  values (
    coalesce(auth.uid(),
             case when tg_op = 'INSERT' then new.issued_by else null end),
    v_action, 'appointment', new.id,
    jsonb_build_object('role_code', new.role_code,
                       'appointee_name', v_appointee,
                       'status', new.status)
  );
  return new;
end;
$$;

drop trigger if exists trg_appointments_audit on public.appointments;
create trigger trg_appointments_audit
  after insert or update on public.appointments
  for each row execute function public.fn_audit_appointment();

create or replace function public.fn_audit_device()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
begin
  if new.approved = true and coalesce(old.approved, false) = false then
    v_action := 'device.approved';
  elsif new.is_active = false and coalesce(old.is_active, true) = true then
    v_action := 'device.revoked';
  elsif new.is_active = true and coalesce(old.is_active, true) = false then
    v_action := 'device.restored';
  else
    v_action := null;
  end if;

  if v_action is null then
    return new;
  end if;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, new_values)
  values (
    auth.uid(), v_action, 'device', new.id,
    jsonb_build_object('platform', new.platform,
                       'device_name', new.device_name)
  );
  return new;
end;
$$;

drop trigger if exists trg_devices_audit on public.devices;
create trigger trg_devices_audit
  after update on public.devices
  for each row execute function public.fn_audit_device();
