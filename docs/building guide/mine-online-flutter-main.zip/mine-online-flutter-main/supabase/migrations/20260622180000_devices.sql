-- SP6 Device Management: per-install device registry (informational + audit).
-- Auto-registered devices are admin-approved/revoked; submissions are device-stamped.

create table if not exists public.devices (
  id            uuid primary key,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  device_name   text not null,
  platform      text not null check (platform in ('windows','android','other')),
  approved      boolean not null default false,
  approved_at   timestamptz,
  approved_by   uuid references public.profiles(id) on delete set null,
  last_seen_at  timestamptz not null default now(),
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists devices_user_idx on public.devices (user_id);
alter table public.devices enable row level security;

create policy "Read own or admin devices" on public.devices for select to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid()));
create policy "Insert own devices" on public.devices for insert to authenticated
  with check (user_id = auth.uid());
create policy "Update own or admin devices" on public.devices for update to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid()))
  with check (user_id = auth.uid() or public.is_admin(auth.uid()));

-- Non-admins may refresh last_seen/name but never the approval/active columns.
create or replace function public.devices_guard_approval()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin(auth.uid()) then
    new.approved := old.approved;
    new.approved_at := old.approved_at;
    new.approved_by := old.approved_by;
    new.is_active := old.is_active;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_devices_guard on public.devices;
create trigger trg_devices_guard before update on public.devices
  for each row execute function public.devices_guard_approval();

-- Notify admins on registration; notify the user on approval.
create or replace function public.devices_notify()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT') then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    select p.id, 'message', 'New device registered',
           coalesce((select full_name from public.profiles where id = new.user_id), 'A user')
             || ' registered a ' || new.platform || ' device',
           '/setup/devices',
           jsonb_build_object('deviceId', new.id::text, 'platform', new.platform)
    from public.profiles p
    where p.is_admin or p.is_super_admin or p.user_account_type in ('Admin','Super Admin');
    return new;
  elsif (tg_op = 'UPDATE' and new.approved is distinct from old.approved and new.approved) then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    values (new.user_id, 'success', 'Device approved',
            'Your device "' || new.device_name || '" has been approved.',
            '/setup/devices',
            jsonb_build_object('deviceId', new.id::text, 'approved', true));
    return new;
  end if;
  return new;
end $$;
revoke all on function public.devices_notify() from public;
revoke all on function public.devices_notify() from authenticated;
drop trigger if exists trg_devices_notify on public.devices;
create trigger trg_devices_notify after insert or update of approved on public.devices
  for each row execute function public.devices_notify();

alter table public.form_submissions add column if not exists device_id uuid;
