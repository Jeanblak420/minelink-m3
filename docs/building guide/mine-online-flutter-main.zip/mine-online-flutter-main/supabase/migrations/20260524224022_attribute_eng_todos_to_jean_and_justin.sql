-- Attribute every engineering todo to the project leads.
--   ~85% -> 'Jean Burger'
--   ~15% -> 'Jean Burger + Justin Trollip'
-- Deterministic split: the first round(15%) of rows ordered by created_at
-- get the dual attribution, the rest get the solo. Re-running with new
-- rows still gives the same ~15% dual / ~85% solo distribution.

with ranked as (
  select
    id,
    row_number() over (order by created_at) as rn,
    count(*) over () as total
  from public.todos
  where kind = 'eng'
)
update public.todos t
set author_name = case
  when r.rn <= round(0.15 * r.total)
    then 'Jean Burger + Justin Trollip'
  else 'Jean Burger'
end
from ranked r
where t.id = r.id;
