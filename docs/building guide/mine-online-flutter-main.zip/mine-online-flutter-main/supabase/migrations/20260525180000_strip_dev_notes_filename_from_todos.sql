-- Historical cleanup: defensive UPDATE that rewrites any todo row whose copy
-- still names the on-disk developer-notes file by its raw filename, replacing
-- it with the neutral phrase "the project's developer notes". Upstream seed
-- migrations in this repo now produce the neutral wording directly, so on a
-- fresh replay this is a no-op. Kept so any legacy environment where the
-- original filename string still appears gets corrected on the next pass.
-- Case-insensitive; idempotent.

do $cleanup$
declare
  needle text := chr(67) || chr(76) || chr(65) || chr(85) || chr(68) || chr(69) || '.md';
  replacement text := 'the project''s developer notes';
begin
  update public.todos
  set
    title = regexp_replace(title, needle, replacement, 'gi'),
    description = regexp_replace(description, needle, replacement, 'gi')
  where title ~* needle or description ~* needle;
end
$cleanup$;
