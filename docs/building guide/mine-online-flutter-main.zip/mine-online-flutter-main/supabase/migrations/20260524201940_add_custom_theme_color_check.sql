-- e-be-14 / e-be-1 — finish the profiles theme schema.
-- theme_mode + custom_theme_color columns already exist with correct
-- defaults (light / #6750A4) and theme_mode has a check constraint.
-- The missing piece: custom_theme_color hex-format check.

alter table public.profiles
  drop constraint if exists profiles_custom_theme_color_check;

alter table public.profiles
  add constraint profiles_custom_theme_color_check
  check (custom_theme_color ~* '^#[0-9A-F]{6}$');
