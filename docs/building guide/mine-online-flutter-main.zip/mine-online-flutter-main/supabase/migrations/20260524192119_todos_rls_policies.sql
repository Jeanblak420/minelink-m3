-- e-todos-3: RLS policies for public.todos.
-- Read: any authenticated user (todo list is shared across all account types).
-- Insert kind='user': any authenticated user. Insert kind='eng' is implicitly
-- blocked (the WITH CHECK requires kind='user'); service_role bypasses RLS and
-- is the only path for eng-side inserts. Update/delete: row's author_id or
-- submitter_id matches auth.uid(), or the caller is_admin().

-- Helper: is_admin(uid uuid) returns true for admin or super-admin profiles.
-- Used by todos RLS and reusable for other tables that need the same check.
-- SECURITY INVOKER is fine because the existing profiles SELECT policy is open
-- to authenticated, so the helper can read its own table without recursion.
create or replace function public.is_admin(uid uuid)
returns boolean
language sql
stable
security invoker
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = uid
      and (
        p.is_admin
        or coalesce(p.is_super_admin, false)
        or p.user_account_type in ('Admin', 'Super Admin')
      )
  );
$$;

revoke all on function public.is_admin(uuid) from public;
grant execute on function public.is_admin(uuid) to authenticated;

-- SELECT: any authenticated user.
drop policy if exists "Authenticated can read todos" on public.todos;
create policy "Authenticated can read todos"
  on public.todos for select to authenticated
  using (true);

-- INSERT: any authenticated user, but kind must be 'user'. service_role
-- bypasses RLS and is the only path for kind='eng' inserts.
drop policy if exists "Authenticated can insert user-kind todos" on public.todos;
create policy "Authenticated can insert user-kind todos"
  on public.todos for insert to authenticated
  with check (kind = 'user');

-- UPDATE: row owner OR admin.
drop policy if exists "Authors and admins can update todos" on public.todos;
create policy "Authors and admins can update todos"
  on public.todos for update to authenticated
  using (
    author_id = auth.uid()
    or submitter_id = auth.uid()
    or public.is_admin(auth.uid())
  )
  with check (
    author_id = auth.uid()
    or submitter_id = auth.uid()
    or public.is_admin(auth.uid())
  );

-- DELETE: row owner OR admin.
drop policy if exists "Authors and admins can delete todos" on public.todos;
create policy "Authors and admins can delete todos"
  on public.todos for delete to authenticated
  using (
    author_id = auth.uid()
    or submitter_id = auth.uid()
    or public.is_admin(auth.uid())
  );
