-- Log the two follow-up fixes shipped in this turn (the GRANTS bug + the
-- back button on /todos) so they appear in the in-app To-Do List under
-- Engineering / Completed.

insert into public.todos (kind, title, description, status, author_name)
values
  ('eng',
   'Grant authenticated role base table privileges on public.todos',
$$The todos table was created with RLS enabled and the right policies, but the authenticated / anon roles never had base table grants. In Supabase you need BOTH the GRANT and the RLS policy; without the GRANT the data layer returns 0 rows to the signed-in client (no error, just empty). This is why /todos was showing "0 total" for every user even though the table held 56 rows. The new migration adds grant select, insert, update, delete on public.todos to authenticated, and grants usage on the public schema. RLS still does the row-level filtering on top.

What this means for users: the To-Do List finally renders the engineering backlog and any user-submitted requests inside the app. Open /todos and you will see every shipped item under Engineering -> Completed, every new request under User Requests, and every status badge updating live across devices.$$,
   'done',
   'Jean Burger'),

  ('eng',
   'Back arrow on the To-Do List screen',
$$lib/screens/todos_screen.dart now sets a leading IconButton(Icons.arrow_back) in its AppBar that pops the navigation stack if there's somewhere to go, otherwise returns to / (Home). Same pattern every other top-level screen in the app already uses.

What this means for users: the To-Do List no longer feels like a dead-end. The back arrow in the top-left always returns to where you came from, or to Home if you opened the To-Do List directly via the top-bar checklist icon.$$,
   'done',
   'Jean Burger + Justin Trollip');
