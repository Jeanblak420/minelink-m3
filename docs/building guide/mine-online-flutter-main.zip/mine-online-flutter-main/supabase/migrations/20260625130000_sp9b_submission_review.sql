-- SP9b: submission review queue. Review columns + an admin-gated SECURITY
-- DEFINER RPC that updates only the review fields, audits, and notifies.

alter table public.form_submissions
  add column if not exists review_status text not null default 'pending',
  add column if not exists review_note text,
  add column if not exists reviewed_by uuid references public.profiles(id),
  add column if not exists reviewed_at timestamptz;

alter table public.form_submissions
  drop constraint if exists form_submissions_review_status_chk;
alter table public.form_submissions
  add constraint form_submissions_review_status_chk
  check (review_status in ('pending','approved','rejected','flagged'));

create or replace function public.set_submission_review(
  p_submission_id uuid,
  p_status text,
  p_note text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_actor uuid := auth.uid();
  v_old text;
  v_user uuid;
  v_title text;
begin
  if not public.is_admin(v_actor) then
    raise exception 'Forbidden: admin only';
  end if;
  if p_status not in ('pending','approved','rejected','flagged') then
    raise exception 'Invalid review status: %', p_status;
  end if;

  select review_status, user_id, title
    into v_old, v_user, v_title
    from public.form_submissions
   where id = p_submission_id;
  if not found then
    raise exception 'Submission not found';
  end if;

  update public.form_submissions
     set review_status = p_status,
         review_note = p_note,
         reviewed_by = v_actor,
         reviewed_at = now()
   where id = p_submission_id;

  insert into public.audit_log
    (user_id, action, entity_type, entity_id, old_values, new_values)
  values
    (v_actor, 'submission.review', 'form_submission', p_submission_id,
     jsonb_build_object('review_status', v_old),
     jsonb_build_object('review_status', p_status, 'note', p_note,
                        'title', v_title));

  if p_status <> 'pending' and v_user is not null and v_user <> v_actor then
    insert into public.notifications
      (user_id, type, title, body, action_url, metadata)
    values (
      v_user, 'system',
      'Submission ' || p_status,
      'Your "' || coalesce(v_title, 'submission') || '" was ' || p_status ||
        case when p_note is not null and length(trim(p_note)) > 0
             then '. Note: ' || p_note else '' end,
      '/current-logbook',
      jsonb_build_object('category', 'review', 'submission_id', p_submission_id)
    );
  end if;
end;
$$;

grant execute on function
  public.set_submission_review(uuid, text, text) to authenticated;
