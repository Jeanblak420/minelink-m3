-- Intent: every user-submitted request stays on the shared To-Do List
-- permanently so we can all see what was suggested. Status changes are still
-- allowed (anyone with edit access can mark Planned → In Progress → Done),
-- but deletion is locked to admins so a user can't accidentally erase their
-- own suggestion from the shared view.
--
-- SELECT policy is unchanged: any authenticated user already sees every row
-- regardless of who created it.

drop policy if exists "Authors and admins can delete todos" on public.todos;
create policy "Only admins can delete todos"
  on public.todos for delete to authenticated
  using (public.is_admin(auth.uid()));
