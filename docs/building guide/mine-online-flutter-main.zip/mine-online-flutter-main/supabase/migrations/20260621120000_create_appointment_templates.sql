-- SP3 Appointment Builder + Letter Builder: roles catalog + appointment templates
-- (form fields + letter body). Authoring only; issuance/lifecycle is SP4.

create table if not exists public.appointment_roles (
  id            uuid primary key default gen_random_uuid(),
  code          text,
  label         text not null,
  description   text,
  is_mandatory  boolean not null default false,
  is_active     boolean not null default true,
  sort_order    integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists public.appointment_templates (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique,
  name              text not null,
  description       text,
  role_id           uuid references public.appointment_roles(id) on delete set null,
  language          text not null default 'en',
  fields            jsonb not null default '[]'::jsonb,
  letter_body       text not null default '',
  required_signers  jsonb not null default '[]'::jsonb,
  version           integer not null default 1,
  is_active         boolean not null default true,
  created_by        uuid references public.profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists appointment_roles_active_idx
  on public.appointment_roles (is_active, sort_order);
create index if not exists appointment_templates_active_idx
  on public.appointment_templates (is_active, updated_at desc);

alter table public.appointment_roles enable row level security;
alter table public.appointment_templates enable row level security;

-- appointment_roles: authenticated read active (admins read all); admin write.
create policy "Read active appointment roles"
  on public.appointment_roles for select to authenticated
  using (is_active = true or public.is_admin(auth.uid()));
create policy "Admins insert appointment roles"
  on public.appointment_roles for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admins update appointment roles"
  on public.appointment_roles for update to authenticated
  using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- appointment_templates: authenticated read active (admins read all); admin write.
create policy "Read active appointment templates"
  on public.appointment_templates for select to authenticated
  using (is_active = true or public.is_admin(auth.uid()));
create policy "Admins insert appointment templates"
  on public.appointment_templates for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admins update appointment templates"
  on public.appointment_templates for update to authenticated
  using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- Seed the statutory roles the app uses today + core MHSA roles.
insert into public.appointment_roles (code, label, description, is_mandatory, sort_order)
values
  ('2.6.1',  'Mine Manager',                  'Appointed manager responsible for the mine under MHSA 2.6.1.', true,  10),
  ('2.9.2',  'Mine Overseer',                 'Mine overseer responsible for a portion of the mine under MHSA 2.9.2.', true,  20),
  ('2.13.1', 'Shift Supervisor (Shift Boss)', 'Shift supervisor responsible for a working place during a shift under MHSA 2.13.1.', true,  30),
  ('2.13.2', 'Engineer',                      'Engineer appointed under MHSA 2.13.2.', false, 40),
  (null,     'Miner (Competent A)',           'Competent miner responsible for blasting and a working place.', false, 50),
  (null,     'Relieving Miner',               'Miner appointed to relieve a competent miner.', false, 60)
on conflict do nothing;
