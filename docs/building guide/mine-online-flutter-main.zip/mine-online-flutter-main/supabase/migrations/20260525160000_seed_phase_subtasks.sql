-- Seed sub-tasks under every phase of the 4 main feature tasks. Each
-- sub-task is its own row (kind='eng', status='planned'), parent_id
-- linked to its phase by exact phase-title match. The /todos screen
-- nests them visually under their phase, which itself nests under its
-- main task — list-within-list-within-list.
--
-- Every description carries the two required halves per the project
-- rule: a technical line and a "What this means for users:" line.
-- Author split: every 7th row is "Jean Burger + Justin Trollip" so the
-- running engineering attribution stays at ~85/15.
--
-- Idempotent: a sub-task only inserts when its exact title isn't
-- already present. Phase parent_id is resolved by joining on the phase
-- title at insert time — never hard-coded against generated IDs.

insert into public.todos
  (kind, title, description, status, urgency, author_name, parent_id, created_at)
select 'eng', v.title, v.description, 'planned', 'whenever', v.author_name,
       parent.id,
       now() - (v.offset_seconds || ' seconds')::interval
from (values

  -- ============================================================
  -- T1 · Phase 1 — Spec
  -- ============================================================
  (0,  '[T1 · P1.1] Draft the field set and ticket lifecycle spec',
   $$Document the exact captured fields (auto-pulled from profile + manual callback phone + title + description + attachments) and the three-phase lifecycle (submitted → opened → closed) including who can trigger each transition.

What this means for users: agreeing the rules now stops surprises later — once Phase 1 ships, the lifecycle behaves the way the spec says it does.$$,
   'Jean Burger',
   '[T1 · Phase 1] Specification, UX flows and decision log'),

  (1,  '[T1 · P1.2] Draft email templates + variable list',
   $$Write the four email templates (ticket submitted, ticket opened, ticket closed with summary, new chat message) with the placeholder variables they consume. Output: a template doc the function build in Phase 5 reads against.

What this means for users: ensures the emails IT and the submitter receive are well-written, consistent, and have the right info before any code is written to send them.$$,
   'Jean Burger',
   '[T1 · Phase 1] Specification, UX flows and decision log'),

  (2,  '[T1 · P1.3] Review spec with stakeholders + lock decisions',
   $$Walk the spec through with the engineering team and the eventual IT Support owner; capture decisions in the doc; lock before any code lands.

What this means for users: a reviewed spec means nothing has to be unpicked later because someone wasn't asked.$$,
   'Jean Burger',
   '[T1 · Phase 1] Specification, UX flows and decision log'),

  (3,  '[T1 · P1.4] Commit spec to docs/ and link from the project''s developer notes',
   $$Add docs/support-tickets-spec.md, link it from the project's developer-notes "Reusable widgets" section so the build phases can refer to it.

What this means for users: the agreed rules live in one durable place anyone on the project can read at any time.$$,
   'Jean Burger',
   '[T1 · Phase 1] Specification, UX flows and decision log'),

  -- ============================================================
  -- T1 · Phase 2 — Account type
  -- ============================================================
  (4,  '[T1 · P2.1] Add it_support to lib/constants/account_types.dart',
   $$Add 'it_support' to kUserAccountTypes and to kNotificationEnabledAccountTypes. Extend getAccountTypeFlags to expose isItSupport.

What this means for users: introduces the new account-type catalogue entry — invisible until Phase 7's screens use it, but the building block.$$,
   'Jean Burger',
   '[T1 · Phase 2] Add the IT Support / Development Support account type (Super Admin only)'),

  (5,  '[T1 · P2.2] Add canAccessTicketingInbox + canCreateItSupportUsers helpers',
   $$Add the two helpers to lib/utils/role_access.dart. canCreateItSupportUsers returns true only for super admin (admins must not be able to mint IT accounts).

What this means for users: the gate that keeps regular Admins out of IT Support permissions lives in one place — every screen consults it the same way.$$,
   'Jean Burger',
   '[T1 · Phase 2] Add the IT Support / Development Support account type (Super Admin only)'),

  (6,  '[T1 · P2.3] Gate the account-type option in the Profiles create/edit dialog',
   $$Inside the Profiles create / edit form, render the IT Support option only when canCreateItSupportUsers(currentUser) returns true. Otherwise omit it from the dropdown entirely.

What this means for users: Admins literally cannot see, let alone select, the IT Support account type — only Super Admins can.$$,
   'Jean Burger + Justin Trollip',
   '[T1 · Phase 2] Add the IT Support / Development Support account type (Super Admin only)'),

  (7,  '[T1 · P2.4] Mirror change to React app src/constants/accountTypes.ts',
   $$Add the same account-type entry on the web app so the two stay in parity. Use kUserAccountTypes and getAccountTypeFlags equivalents.

What this means for users: the IT Support role behaves identically on the Flutter mobile/Windows app and on the web app — same name, same permission gating.$$,
   'Jean Burger',
   '[T1 · Phase 2] Add the IT Support / Development Support account type (Super Admin only)'),

  -- ============================================================
  -- T1 · Phase 3 — DB schema
  -- ============================================================
  (8,  '[T1 · P3.1] Write the migration (4 tables + triggers + indexes)',
   $$Create supabase/migrations/<ts>_create_support_tickets.sql with support_tickets, support_ticket_messages, support_ticket_attachments, support_ticket_status_history plus BEFORE UPDATE updated_at triggers and the indexes called out in the parent phase.

What this means for users: invisible plumbing — what makes every ticket / message / attachment / status change a query-able row.$$,
   'Jean Burger',
   '[T1 · Phase 3] Database schema for tickets, messages, attachments and status history'),

  (9,  '[T1 · P3.2] Apply migration via Supabase MCP',
   $$Run mcp__plugin_supabase_supabase__apply_migration against the live project. Verify with list_tables + a count.

What this means for users: the schema actually exists in the live database, not just in a file.$$,
   'Jean Burger',
   '[T1 · Phase 3] Database schema for tickets, messages, attachments and status history'),

  (10, '[T1 · P3.3] Add tables to the realtime publication',
   $$alter publication supabase_realtime add table support_tickets, support_ticket_messages so the Phase 8 provider can subscribe.

What this means for users: lets the in-app chat and status timeline update live without a refresh once Phase 8 lands.$$,
   'Jean Burger',
   '[T1 · Phase 3] Database schema for tickets, messages, attachments and status history'),

  (11, '[T1 · P3.4] Generate Dart models for the new schema',
   $$Create lib/models/support_ticket.dart, lib/models/support_ticket_message.dart, lib/models/support_ticket_attachment.dart with fromRow / toMap. Mirror the column shape exactly.

What this means for users: gives the Flutter screens a typed shape to read and write — fewer runtime errors, better completion in the IDE.$$,
   'Jean Burger',
   '[T1 · Phase 3] Database schema for tickets, messages, attachments and status history'),

  -- ============================================================
  -- T1 · Phase 4 — RLS + storage
  -- ============================================================
  (12, '[T1 · P4.1] Write RLS policies for support_tickets (SELECT/INSERT/UPDATE)',
   $$SELECT: own rows for submitters, all rows for it_support + super_admin. INSERT: submitter inserts their own. UPDATE: status transitions restricted per the spec.

What this means for users: lock the ticket table down at the database level so no client-side bug can leak another user's ticket.$$,
   'Jean Burger',
   '[T1 · Phase 4] Row-level security policies and storage bucket for ticket attachments'),

  (13, '[T1 · P4.2] Write RLS policies for messages, attachments, status history',
   $$Same access model as the ticket — submitter sees their own ticket's children; IT sees all; admins (non-IT) do not. Status-history is read-only to anyone who can read the ticket.

What this means for users: every part of a ticket (chat, screenshots, status timeline) is protected by the same rules as the ticket itself.$$,
   'Jean Burger',
   '[T1 · Phase 4] Row-level security policies and storage bucket for ticket attachments'),

  (14, '[T1 · P4.3] Create support-ticket-attachments storage bucket + policy',
   $$createBucket(...) plus storage RLS that joins the storage path against the owning ticket so only people who can read the ticket can read its attachments.

What this means for users: an attachment URL is useless to anyone outside the ticket's read circle — the screenshot you uploaded to IT cannot be shared accidentally.$$,
   'Jean Burger + Justin Trollip',
   '[T1 · Phase 4] Row-level security policies and storage bucket for ticket attachments'),

  (15, '[T1 · P4.4] Test policies against four account types (submitter, IT, admin, super)',
   $$Sign in as each role; attempt every operation; confirm the result matches the spec (allow / deny). Capture results in the spec doc.

What this means for users: empirical proof that the security rules behave the way the spec says before any user opens a ticket in anger.$$,
   'Jean Burger',
   '[T1 · Phase 4] Row-level security policies and storage bucket for ticket attachments'),

  -- ============================================================
  -- T1 · Phase 5 — Edge function + email
  -- ============================================================
  (16, '[T1 · P5.1] Scaffold supabase/functions/support-ticket-notify (Deno)',
   $$Create the function with import map, env-var bindings (SMTP secret), service-role client, and a thin request router for the three trigger types (insert ticket, update ticket, insert message).

What this means for users: the skeleton that every email and bell-badge update will flow through — gets the function deployable before any real logic is written.$$,
   'Jean Burger',
   '[T1 · Phase 5] Edge function and email pipeline for ticket events (phase changes + chat messages)'),

  (17, '[T1 · P5.2] Implement four email templates + render helper',
   $$Per the templates locked in P1.2: ticket submitted, ticket opened, ticket closed with summary, new chat message. Render helper interpolates the variables and returns html + text.

What this means for users: the emails recipients actually receive — the wording, the deep link, the variable substitution.$$,
   'Jean Burger',
   '[T1 · Phase 5] Edge function and email pipeline for ticket events (phase changes + chat messages)'),

  (18, '[T1 · P5.3] Deploy function + wire pg_net AFTER INSERT/UPDATE triggers',
   $$supabase functions deploy support-ticket-notify; then create the three triggers (ticket insert, ticket status update, message insert) that call the function via pg_net with the row payload.

What this means for users: makes the function actually fire — without the trigger wiring, a new ticket would never produce an email.$$,
   'Jean Burger',
   '[T1 · Phase 5] Edge function and email pipeline for ticket events (phase changes + chat messages)'),

  (19, '[T1 · P5.4] Write notifications row inserts for the in-app bell badge',
   $$Inside the function, also insert a public.notifications row for the recipient on every event so the bell badge + notifications screen pick it up.

What this means for users: even with email muted, you see ticket activity inside the app via the existing bell badge — no email-only blind spot.$$,
   'Jean Burger',
   '[T1 · Phase 5] Edge function and email pipeline for ticket events (phase changes + chat messages)'),

  (20, '[T1 · P5.5] Test email delivery for all four events',
   $$Trigger each event end-to-end against a test inbox; verify subject, body, deep link, variable substitution.

What this means for users: every email a real user will receive has been seen and approved by a human before rollout.$$,
   'Jean Burger',
   '[T1 · Phase 5] Edge function and email pipeline for ticket events (phase changes + chat messages)'),

  -- ============================================================
  -- T1 · Phase 6 — User UI
  -- ============================================================
  (21, '[T1 · P6.1] Build LogTicketScreen layout',
   $$Skeleton screen with the identity panel (read-only profile fields), inputs (callback phone, title, description), attachment grid, submit button. Responsive Column → Wrap layout for narrow widths.

What this means for users: the screen the user opens when they tap "Log a Ticket" — laid out and navigable, even before submit is wired.$$,
   'Jean Burger + Justin Trollip',
   '[T1 · Phase 6] Flutter user side — Log a Ticket screen with profile pre-fill, attachments and annotator'),

  (22, '[T1 · P6.2] Wire profile pre-fill via getProfilePersonalDetails(profile)',
   $$Use the existing helper to populate the read-only identity card (name, payroll id, occupation, department, location, company contact, email).

What this means for users: the user doesn't have to re-type their name and role to log a ticket — the form already knows them.$$,
   'Jean Burger',
   '[T1 · Phase 6] Flutter user side — Log a Ticket screen with profile pre-fill, attachments and annotator'),

  (23, '[T1 · P6.3] Reuse image_painter annotator for attachment workflow',
   $$Hook the AnnotateImageDialog used by /todos into the attachments grid so a picked image opens the painter before upload.

What this means for users: lets the user draw on a screenshot to point at the exact problem before sending it to IT — same UX as the todo-list image picker.$$,
   'Jean Burger',
   '[T1 · Phase 6] Flutter user side — Log a Ticket screen with profile pre-fill, attachments and annotator'),

  (24, '[T1 · P6.4] Submit handler — upload images + insert ticket + attachments',
   $$Sequence: upload each image to support-ticket-attachments bucket, then insert the support_tickets row, then the support_ticket_attachments rows. Snapshot the submitter's profile fields into submitter_profile_snapshot at submit time.

What this means for users: a single tap actually sends the ticket — all images and metadata land in one atomic-feeling submit.$$,
   'Jean Burger',
   '[T1 · Phase 6] Flutter user side — Log a Ticket screen with profile pre-fill, attachments and annotator'),

  (25, '[T1 · P6.5] Add dashboard card + account-popover entry',
   $$"Need help? Log a ticket to IT" card on every role-specific dashboard; "Log a ticket" item inside the avatar popover.

What this means for users: the user can reach the ticket form from any screen they happen to be on without hunting through menus.$$,
   'Jean Burger',
   '[T1 · Phase 6] Flutter user side — Log a Ticket screen with profile pre-fill, attachments and annotator'),

  -- ============================================================
  -- T1 · Phase 7 — IT UI
  -- ============================================================
  (26, '[T1 · P7.1] Build TicketInboxScreen with three lanes (New / In Progress / Closed)',
   $$Reuse the tinted-card pattern from /todos. Each lane orders by ticket created_at desc. Filter at query level by status.

What this means for users: IT staff see every ticket at a glance, grouped by what stage it's at — no scrolling through a flat list.$$,
   'Jean Burger',
   '[T1 · Phase 7] Flutter IT side — inbox plus ticket detail screen with accept and close actions'),

  (27, '[T1 · P7.2] Build TicketDetailScreen layout',
   $$Submitter info card, callback phone prominent, description, attached-images carousel, status timeline, chat thread placeholder, action button row.

What this means for users: the screen where IT actually reads a ticket and decides what to do next — everything needed in one view.$$,
   'Jean Burger',
   '[T1 · Phase 7] Flutter IT side — inbox plus ticket detail screen with accept and close actions'),

  (28, '[T1 · P7.3] Wire Accept Ticket action (submitted → opened)',
   $$Button visible only when status=submitted. On tap, update support_tickets.status = opened, opened_at = now(), and insert a status_history row.

What this means for users: IT explicitly takes ownership of the ticket — the submitter sees the timeline flip and gets the "opened" email.$$,
   'Jean Burger + Justin Trollip',
   '[T1 · Phase 7] Flutter IT side — inbox plus ticket detail screen with accept and close actions'),

  (29, '[T1 · P7.4] Wire Close Ticket dialog (opened → closed + summary)',
   $$Button visible only when status=opened. Opens a dialog requiring closing_summary text; on submit, update status=closed, closed_at=now(), closing_summary=text, insert status_history row.

What this means for users: IT has to write a one-line summary of what they did — the submitter always knows why their ticket is closed, not just that it is.$$,
   'Jean Burger',
   '[T1 · Phase 7] Flutter IT side — inbox plus ticket detail screen with accept and close actions'),

  (30, '[T1 · P7.5] Gate routes via canAccessTicketingInbox()',
   $$Add the inbox + detail routes inside the protected branch of the router so non-IT roles are bounced. Add MobileBottomNav entry for IT roles.

What this means for users: only people who should see the IT queue can reach it, even by typing the URL.$$,
   'Jean Burger',
   '[T1 · Phase 7] Flutter IT side — inbox plus ticket detail screen with accept and close actions'),

  -- ============================================================
  -- T1 · Phase 8 — Realtime
  -- ============================================================
  (31, '[T1 · P8.1] Build SupportTicketProvider with per-ticket channel subscriptions',
   $$Mirror TodosProvider: subscribe to public:support_tickets (UPDATE) + public:support_ticket_messages (INSERT) filtered by ticket_id. Tear down on dispose.

What this means for users: powers the live ticket experience — every update from the other side arrives instantly without a refresh.$$,
   'Jean Burger',
   '[T1 · Phase 8] Realtime ticket chat plus live status sync (Postgres changes subscriptions)'),

  (32, '[T1 · P8.2] Implement optimistic message inserts + reconcile on event',
   $$On send, append the message locally with a temp id; on the realtime echo, swap to the persisted id. Handle network failure by marking the bubble retryable.

What this means for users: chat feels instant — your typed message shows up immediately, not after a server round-trip.$$,
   'Jean Burger',
   '[T1 · Phase 8] Realtime ticket chat plus live status sync (Postgres changes subscriptions)'),

  (33, '[T1 · P8.3] Wire status timeline auto-repaint on status_history arrival',
   $$Subscribe to status_history inserts for the open ticket; rebuild the timeline section on event.

What this means for users: the moment IT accepts or closes your ticket, you see the timeline update without doing anything.$$,
   'Jean Burger',
   '[T1 · Phase 8] Realtime ticket chat plus live status sync (Postgres changes subscriptions)'),

  (34, '[T1 · P8.4] Confirm channel cleanup on screen dispose',
   $$Unit + manual check: open a ticket, leave, open another — verify no orphan channel subscriptions accumulate (otherwise battery + bandwidth degrade).

What this means for users: the live updates don't leak resources — closing the ticket actually stops listening to it.$$,
   'Jean Burger',
   '[T1 · Phase 8] Realtime ticket chat plus live status sync (Postgres changes subscriptions)'),

  -- ============================================================
  -- T1 · Phase 9 — E2E test
  -- ============================================================
  (35, '[T1 · P9.1] Manual end-to-end on Windows (full ticket lifecycle)',
   $$Submit → IT receives → IT accepts → chat back and forth → IT closes with summary → submitter sees + email at each step. Capture screenshots in the test log.

What this means for users: confirms the entire flow really works on a Windows full-screen install before it's announced as available.$$,
   'Jean Burger + Justin Trollip',
   '[T1 · Phase 9] End-to-end testing, email rendering check, Windows + Android parity, docs'),

  (36, '[T1 · P9.2] Manual end-to-end on Android with touch annotation',
   $$Same scenario as P9.1 but on an Android phone — focus on the annotator's touch UX and the responsive layout.

What this means for users: confirms the same flow works the same way on a phone — no Windows-only blind spot.$$,
   'Jean Burger',
   '[T1 · Phase 9] End-to-end testing, email rendering check, Windows + Android parity, docs'),

  (37, '[T1 · P9.3] RLS check across four account types',
   $$Sign in as regular Admin / Shift Boss / IT Support / Super Admin; verify visibility matches the spec (only IT + Super sees the queue; regular Admin and Shift Boss do not).

What this means for users: confirms the permission rules actually hold when a real person opens the app — not just on paper.$$,
   'Jean Burger',
   '[T1 · Phase 9] End-to-end testing, email rendering check, Windows + Android parity, docs'),

  (38, '[T1 · P9.4] Run flutter analyze and fix any new warnings',
   $$Must be clean before the parent phase can be ticked.

What this means for users: keeps the codebase free of lint debt as the feature lands.$$,
   'Jean Burger',
   '[T1 · Phase 9] End-to-end testing, email rendering check, Windows + Android parity, docs'),

  (39, '[T1 · P9.5] Add "Support Tickets" section to the project''s developer notes',
   $$Document the new screens, providers, models, edge function, and the route gating so future sessions can find the feature.

What this means for users: future engineering on this app can build on the ticketing system without re-discovering how it works.$$,
   'Jean Burger',
   '[T1 · Phase 9] End-to-end testing, email rendering check, Windows + Android parity, docs'),

  -- ============================================================
  -- T2 · Phase 1 — Spec
  -- ============================================================
  (40, '[T2 · P1.1] Confirm which appointment forms can be added to a book',
   $$Decide the catalogue (likely the 11 chain forms; possibly include some non-chain). Document inclusion / exclusion criteria.

What this means for users: tells admins clearly which forms can be bundled — no guessing.$$,
   'Jean Burger',
   '[T2 · Phase 1] Specification — what a book is, which forms it can contain, completion rules'),

  (41, '[T2 · P1.2] Decide templates vs one-off, completion + reassignment rules',
   $$Template-once-assign-many vs every-assignment-is-bespoke; what happens if Admin reassigns a partially-completed book; archival rules.

What this means for users: locks down the lifecycle so Admins know what they can and can't do with a book once it's out the door.$$,
   'Jean Burger',
   '[T2 · Phase 1] Specification — what a book is, which forms it can contain, completion rules'),

  (42, '[T2 · P1.3] Commit spec to docs/ and lock decisions',
   $$Output: docs/appointment-books-spec.md.

What this means for users: the rules live in a durable doc anyone on the project can refer to.$$,
   'Jean Burger + Justin Trollip',
   '[T2 · Phase 1] Specification — what a book is, which forms it can contain, completion rules'),

  -- ============================================================
  -- T2 · Phase 2 — DB schema
  -- ============================================================
  (43, '[T2 · P2.1] Write the migration — 3 tables + completion trigger',
   $$appointment_book_templates, appointment_book_assignments, appointment_book_form_links plus the AFTER UPDATE trigger on form_submissions that flips assignment.status to completed when every link is done.

What this means for users: the data shape that makes a book "know" when all its forms are signed.$$,
   'Jean Burger',
   '[T2 · Phase 2] Database schema — book templates, assignments and form links plus completion trigger'),

  (44, '[T2 · P2.2] Apply migration via Supabase MCP',
   $$apply_migration against the live project; verify with list_tables.

What this means for users: schema actually lives in the database.$$,
   'Jean Burger',
   '[T2 · Phase 2] Database schema — book templates, assignments and form links plus completion trigger'),

  (45, '[T2 · P2.3] Add tables to the realtime publication',
   $$So admin views see new assignments live + users see their book progress update live.

What this means for users: live progress bars and inbox updates without refreshing.$$,
   'Jean Burger',
   '[T2 · Phase 2] Database schema — book templates, assignments and form links plus completion trigger'),

  (46, '[T2 · P2.4] Add Dart models (BookTemplate, BookAssignment, BookFormLink)',
   $$With fromRow / toMap mirroring the table columns.

What this means for users: typed shapes for the new screens to read and write — fewer runtime errors.$$,
   'Jean Burger',
   '[T2 · Phase 2] Database schema — book templates, assignments and form links plus completion trigger'),

  -- ============================================================
  -- T2 · Phase 3 — Admin UI
  -- ============================================================
  (47, '[T2 · P3.1] Build BookManagementScreen with Templates / Assignments tabs',
   $$Two-tab Scaffold; Templates lane shows existing templates with edit/rename/archive; Assignments lane shows existing assignments grouped by status.

What this means for users: one screen for all book admin — find a template, see who has it, hand out a new one.$$,
   'Jean Burger + Justin Trollip',
   '[T2 · Phase 3] Admin UI — create book templates and assign books to users'),

  (48, '[T2 · P3.2] Template builder — pick from the 27 appointment forms',
   $$Multi-select picker with search; saves into default_form_types text[].

What this means for users: admins build a book by ticking the forms it should contain — no manual JSON editing.$$,
   'Jean Burger',
   '[T2 · Phase 3] Admin UI — create book templates and assign books to users'),

  (49, '[T2 · P3.3] Assignment dialog — user picker + optional notes',
   $$ComboBox of users; choose a template; optional notes; insert assignment + book_form_links rows.

What this means for users: assigns a book to a specific person in one step from the admin screen.$$,
   'Jean Burger',
   '[T2 · Phase 3] Admin UI — create book templates and assign books to users'),

  (50, '[T2 · P3.4] Add canManageAppointmentBooks helper to role_access.dart',
   $$Returns true for admin + super_admin only; routes consume it.

What this means for users: only admins reach the management screen — never accidentally exposed to other roles.$$,
   'Jean Burger',
   '[T2 · Phase 3] Admin UI — create book templates and assign books to users'),

  -- ============================================================
  -- T2 · Phase 4 — User UI
  -- ============================================================
  (51, '[T2 · P4.1] Build MyAppointmentBooksScreen layout',
   $$List of assigned books for the signed-in user, each with a progress meter (X of Y forms complete).

What this means for users: the screen the user opens to see which books they have and how far through each.$$,
   'Jean Burger',
   '[T2 · Phase 4] User UI — My Appointment Books with per-form launcher and live progress'),

  (52, '[T2 · P4.2] Expandable book → form list with per-form status pills',
   $$Tap a book to expand; show each contained form with a StatusChip (Not started / Submitted / In chain / Completed).

What this means for users: at a glance you see exactly which form inside a book still needs your attention.$$,
   'Jean Burger',
   '[T2 · Phase 4] User UI — My Appointment Books with per-form launcher and live progress'),

  (53, '[T2 · P4.3] Wire form-open + auto-link form_submission_id on submit',
   $$Tap a form → open its existing screen via buildFormView; submit wrapper writes the new form_submission_id into the appointment_book_form_links row.

What this means for users: filling a form from inside a book is identical to filling it standalone — but the book quietly tracks the link.$$,
   'Jean Burger',
   '[T2 · Phase 4] User UI — My Appointment Books with per-form launcher and live progress'),

  (54, '[T2 · P4.4] Add entry on Shift Boss + role-specific dashboards',
   $$"My Appointment Books" tile on the relevant dashboards so users land on it from home.

What this means for users: discoverable from the home screen — no menu hunt.$$,
   'Jean Burger + Justin Trollip',
   '[T2 · Phase 4] User UI — My Appointment Books with per-form launcher and live progress'),

  -- ============================================================
  -- T2 · Phase 5 — Completion binding
  -- ============================================================
  (55, '[T2 · P5.1] Implement get_completed_appointment_books(user_id) RPC',
   $$Returns the assignment + ordered list of form_submission rows + PDF refs for completed books only.

What this means for users: the data feed the history viewer reads from — never includes an in-progress book.$$,
   'Jean Burger',
   '[T2 · Phase 5] Completion binding to user profile and history attachment'),

  (56, '[T2 · P5.2] Insert notification row on auto-complete',
   $$Inside the existing completion trigger, insert a notifications row for the user ("Your appointment book {name} is now complete").

What this means for users: the user gets a bell-badge ping when their book locks shut — no need to keep checking.$$,
   'Jean Burger',
   '[T2 · Phase 5] Completion binding to user profile and history attachment'),

  (57, '[T2 · P5.3] Test partial-book exclusion from the history feed',
   $$Integration test: create an assignment with 3 forms; complete only 2; verify the assignment is NOT returned by the RPC.

What this means for users: protects against a half-done book accidentally appearing in someone's history.$$,
   'Jean Burger',
   '[T2 · Phase 5] Completion binding to user profile and history attachment'),

  -- ============================================================
  -- T2 · Phase 6 — Completed-book viewer
  -- ============================================================
  (58, '[T2 · P6.1] Build CompletedBookScreen layout',
   $$Header card (book name, assignee, completed-at) + ordered list of contained forms with View + Download PDF buttons.

What this means for users: one place to walk through every form inside a completed book in order.$$,
   'Jean Burger',
   '[T2 · Phase 6] Completed-book viewer — per user, per book, read-only, scoped to authorised roles'),

  (59, '[T2 · P6.2] View-mode open via buildFormView(formType, FormViewArgs(mode: view))',
   $$Re-use the existing view-mode infrastructure so a form inside a book renders the same way it does in /signature-requests view.

What this means for users: reading a saved form inside a book uses the same UI as reading it elsewhere — consistent across the app.$$,
   'Jean Burger',
   '[T2 · Phase 6] Completed-book viewer — per user, per book, read-only, scoped to authorised roles'),

  (60, '[T2 · P6.3] Per-form Download PDF via savePdfBytes',
   $$Wire each form row's Download button to regenerate via generatePdfForFormType then save through the existing helper.

What this means for users: print or archive any individual form from inside a completed book without leaving the screen.$$,
   'Jean Burger',
   '[T2 · Phase 6] Completed-book viewer — per user, per book, read-only, scoped to authorised roles'),

  (61, '[T2 · P6.4] Surface tabs on /appointment-history-logs + /individual-completed-logbook-history',
   $$Add a "Completed Books" tab on both screens; admin variants list every user's books, user variant lists only their own.

What this means for users: completed books appear in the existing logbook history screens — no separate place to look.$$,
   'Jean Burger',
   '[T2 · Phase 6] Completed-book viewer — per user, per book, read-only, scoped to authorised roles'),

  -- ============================================================
  -- T2 · Phase 7 — E2E test
  -- ============================================================
  (62, '[T2 · P7.1] End-to-end on Windows — template, assign, fill, complete, view',
   $$Admin creates a 3-form template, assigns, user fills + signs all 3, book auto-completes, appears in admin + user history.

What this means for users: the full happy path verified on Windows before any user is asked to use it.$$,
   'Jean Burger + Justin Trollip',
   '[T2 · Phase 7] End-to-end testing across Windows + Android, plus parity check'),

  (63, '[T2 · P7.2] Same end-to-end on Android',
   $$Repeat on an Android phone to confirm the touch UI and responsive layout hold.

What this means for users: no Windows-only blind spot.$$,
   'Jean Burger',
   '[T2 · Phase 7] End-to-end testing across Windows + Android, plus parity check'),

  (64, '[T2 · P7.3] Role-matrix RLS check (Miner / Shift Boss / Admin / Manager / Overseer)',
   $$Verify each role sees only what the spec says they should — no leaks.

What this means for users: the visibility rules behave correctly when each role actually opens the app.$$,
   'Jean Burger',
   '[T2 · Phase 7] End-to-end testing across Windows + Android, plus parity check'),

  (65, '[T2 · P7.4] flutter analyze clean + Appointment Books section in the project''s developer notes',
   $$No new warnings + a section in the project's developer notes describing the new screens and provider.

What this means for users: future engineers can find and extend the appointment-book feature.$$,
   'Jean Burger',
   '[T2 · Phase 7] End-to-end testing across Windows + Android, plus parity check'),

  -- ============================================================
  -- T3 · Phase 1 — Spec
  -- ============================================================
  (66, '[T3 · P1.1] Define team fields + membership rules',
   $$name / section / shift / description / lead; primary team + optional secondaries; archive flag.

What this means for users: locks down what a "gang" actually is so the build is straightforward.$$,
   'Jean Burger',
   '[T3 · Phase 1] Specification — definition of a team, scope of scoping, edge cases'),

  (67, '[T3 · P1.2] Decide what gets scoped vs stays company-wide',
   $$Signature routing + history + dashboards = scoped; form templates + admin tools = company-wide. Document the bypass roles.

What this means for users: clear rules on what changes once gangs are turned on and what doesn't.$$,
   'Jean Burger + Justin Trollip',
   '[T3 · Phase 1] Specification — definition of a team, scope of scoping, edge cases'),

  (68, '[T3 · P1.3] Commit spec to docs/ and lock decisions',
   $$docs/teams-spec.md.

What this means for users: the rules live in a durable doc.$$,
   'Jean Burger',
   '[T3 · Phase 1] Specification — definition of a team, scope of scoping, edge cases'),

  -- ============================================================
  -- T3 · Phase 2 — DB schema
  -- ============================================================
  (69, '[T3 · P2.1] Write migration — teams + team_members + profiles.primary_team_id',
   $$Tables + indexes + the new column on profiles per the parent phase spec.

What this means for users: the data shape that holds every team.$$,
   'Jean Burger',
   '[T3 · Phase 2] Database schema — teams plus team_members plus profile primary-team column'),

  (70, '[T3 · P2.2] Apply migration via Supabase MCP',
   $$apply_migration; verify with list_tables + spot-check select.

What this means for users: tables actually exist in live DB.$$,
   'Jean Burger + Justin Trollip',
   '[T3 · Phase 2] Database schema — teams plus team_members plus profile primary-team column'),

  (71, '[T3 · P2.3] Add tables to the realtime publication',
   $$So the admin team screen sees membership changes live.

What this means for users: live admin views update without refresh.$$,
   'Jean Burger',
   '[T3 · Phase 2] Database schema — teams plus team_members plus profile primary-team column'),

  (72, '[T3 · P2.4] Add Dart models (Team, TeamMember)',
   $$fromRow / toMap mirroring columns.

What this means for users: typed shapes for the admin screens.$$,
   'Jean Burger',
   '[T3 · Phase 2] Database schema — teams plus team_members plus profile primary-team column'),

  -- ============================================================
  -- T3 · Phase 3 — Admin UI
  -- ============================================================
  (73, '[T3 · P3.1] Build TeamManagementScreen layout (list left, detail right)',
   $$Master-detail layout; teams on the left, selected team's detail on the right; responsive stack on narrow.

What this means for users: the screen admins use to build the company's gangs.$$,
   'Jean Burger',
   '[T3 · Phase 3] Admin team management UI — create, rename, archive teams and manage membership'),

  (74, '[T3 · P3.2] Add / remove members + set-as-lead toggle',
   $$ComboBox picker for adding; per-row remove button; per-row toggle to promote to lead.

What this means for users: drag a user into a team and pick the lead — gang built in seconds.$$,
   'Jean Burger',
   '[T3 · Phase 3] Admin team management UI — create, rename, archive teams and manage membership'),

  (75, '[T3 · P3.3] Rename + archive team controls',
   $$Inline rename + archive flag toggle. Archived teams hide from the day-to-day list but stay queryable.

What this means for users: gangs can evolve and retire without ever being deleted.$$,
   'Jean Burger',
   '[T3 · Phase 3] Admin team management UI — create, rename, archive teams and manage membership'),

  (76, '[T3 · P3.4] Add Team column to the /profiles list',
   $$Render each user's primary_team_id alongside their role pill.

What this means for users: the User Profiles screen also shows team at a glance — no need to open the team screen to check.$$,
   'Jean Burger',
   '[T3 · Phase 3] Admin team management UI — create, rename, archive teams and manage membership'),

  -- ============================================================
  -- T3 · Phase 4 — Workflow scoping
  -- ============================================================
  (77, '[T3 · P4.1] Update signature_workflow.dart helper to filter by primary_team_id',
   $$When computing next-signer candidates, intersect with submitter.primary_team_id (skip for company-wide roles).

What this means for users: the in-app helper that picks the next signer now respects team boundaries.$$,
   'Jean Burger + Justin Trollip',
   '[T3 · Phase 4] Scope the signature workflow to team membership (Flutter helper plus edge function)'),

  (78, '[T3 · P4.2] Update the signature-workflow edge function similarly',
   $$Mirror the same filter on the server side so direct DB-driven routing also respects teams.

What this means for users: even when the server picks the next signer, the team filter holds.$$,
   'Jean Burger',
   '[T3 · Phase 4] Scope the signature workflow to team membership (Flutter helper plus edge function)'),

  (79, '[T3 · P4.3] Update list screens for team-filtered visibility',
   $$Signature Requests + Current Logbook + Completed Logbook + Appointment History queries gain the same filter for non-company-wide roles.

What this means for users: your history pages show your team's work, not the whole mine's.$$,
   'Jean Burger',
   '[T3 · Phase 4] Scope the signature workflow to team membership (Flutter helper plus edge function)'),

  (80, '[T3 · P4.4] Handle the no-team fallback (company-wide for unassigned users)',
   $$If primary_team_id is null, treat the user as company-wide (no scoping) so existing users without a team don't lose access.

What this means for users: rolling teams out doesn't suddenly cut off anyone who hasn't been placed in one yet.$$,
   'Jean Burger',
   '[T3 · Phase 4] Scope the signature workflow to team membership (Flutter helper plus edge function)'),

  -- ============================================================
  -- T3 · Phase 5 — RLS + edge function
  -- ============================================================
  (81, '[T3 · P5.1] Update RLS on signature_requests + form_submissions',
   $$Add the same-team check to non-bypass SELECT policies.

What this means for users: the team boundary holds at the database level — no client bug can leak another team's data.$$,
   'Jean Burger',
   '[T3 · Phase 5] Row-level security and edge function updates for team-scoped reads'),

  (82, '[T3 · P5.2] Add public.same_team(uuid, uuid) helper',
   $$One DB function the policies can call to avoid duplication.

What this means for users: keeps the security rules concise and consistent across tables.$$,
   'Jean Burger',
   '[T3 · Phase 5] Row-level security and edge function updates for team-scoped reads'),

  (83, '[T3 · P5.3] Update admin-create-user to accept primary_team_id',
   $$So Admins can drop a new user straight into a team at creation time.

What this means for users: onboarding a new user takes one fewer step.$$,
   'Jean Burger',
   '[T3 · Phase 5] Row-level security and edge function updates for team-scoped reads'),

  (84, '[T3 · P5.4] Document the bypass list in the RLS comment',
   $$super_admin / admin / mine_manager / mine_overseer bypass the team filter — make this explicit at the top of the policy.

What this means for users: anyone reading the policy later sees the bypass list at a glance.$$,
   'Jean Burger + Justin Trollip',
   '[T3 · Phase 5] Row-level security and edge function updates for team-scoped reads'),

  -- ============================================================
  -- T3 · Phase 6 — E2E test
  -- ============================================================
  (85, '[T3 · P6.1] Multi-team scenario on Windows',
   $$Two teams; verify routing + visibility per the spec.

What this means for users: confirms gangs really do isolate each other on the desktop experience.$$,
   'Jean Burger',
   '[T3 · Phase 6] End-to-end testing across multi-team scenarios, Windows + Android'),

  (86, '[T3 · P6.2] Same scenario on Android',
   $$Repeat the multi-team test on a phone.

What this means for users: same behaviour on the phone — no Windows-only blind spot.$$,
   'Jean Burger',
   '[T3 · Phase 6] End-to-end testing across multi-team scenarios, Windows + Android'),

  (87, '[T3 · P6.3] Mid-chain team-move edge case',
   $$Move a user from A to B while a form is mid-signature; confirm the routing matches the spec.

What this means for users: nothing breaks when someone's gang changes during real work.$$,
   'Jean Burger',
   '[T3 · Phase 6] End-to-end testing across multi-team scenarios, Windows + Android'),

  (88, '[T3 · P6.4] flutter analyze clean + Teams section in the project''s developer notes',
   $$No new warnings + a Teams section documenting helpers, routes, RLS.

What this means for users: keeps the code reviewable and future engineering aware.$$,
   'Jean Burger',
   '[T3 · Phase 6] End-to-end testing across multi-team scenarios, Windows + Android'),

  -- ============================================================
  -- T4 · Phase 1 — Spec
  -- ============================================================
  (89, '[T4 · P1.1] Define the JSON schema shape for a form',
   $$Sections → questions / tables / images / signature blocks; per-element input type + validation; snapshot-at-submit rule.

What this means for users: locks the shape of an editable form so everything that follows fits together.$$,
   'Jean Burger',
   '[T4 · Phase 1] Specification and pick the first forms to migrate as proof'),

  (90, '[T4 · P1.2] Pick the first proof forms (Lockout Checklist + Daily Report)',
   $$Lowest-risk forms with no signature-chain dependency — ideal first migrations.

What this means for users: the proof points the rest of the build is judged against.$$,
   'Jean Burger',
   '[T4 · Phase 1] Specification and pick the first forms to migrate as proof'),

  (91, '[T4 · P1.3] Commit spec to docs/ and lock decisions',
   $$docs/form-editor-spec.md.

What this means for users: the rules live in a durable doc.$$,
   'Jean Burger + Justin Trollip',
   '[T4 · Phase 1] Specification and pick the first forms to migrate as proof'),

  -- ============================================================
  -- T4 · Phase 2 — DB schema
  -- ============================================================
  (92, '[T4 · P2.1] Write migration — form_definitions + form_versions + form_change_log',
   $$Three tables + foreign keys + indexes per parent phase spec.

What this means for users: where every form version and every edit will live.$$,
   'Jean Burger',
   '[T4 · Phase 2] Database schema — form definitions, versions and change log'),

  (93, '[T4 · P2.2] Apply migration via Supabase MCP',
   $$apply_migration; verify with list_tables.

What this means for users: tables exist live.$$,
   'Jean Burger',
   '[T4 · Phase 2] Database schema — form definitions, versions and change log'),

  (94, '[T4 · P2.3] Add schema_version_id column to form_submissions',
   $$Nullable FK so existing submissions are unaffected; populated at submit time once dynamic forms ship.

What this means for users: each submission remembers which version of the form it was filled against — so old records always render correctly.$$,
   'Jean Burger',
   '[T4 · Phase 2] Database schema — form definitions, versions and change log'),

  (95, '[T4 · P2.4] Trigger to auto-bump version_number on new schema rows',
   $$BEFORE INSERT trigger reads the max(version_number) for the definition and increments.

What this means for users: every save automatically becomes the next version — no manual numbering.$$,
   'Jean Burger',
   '[T4 · Phase 2] Database schema — form definitions, versions and change log'),

  -- ============================================================
  -- T4 · Phase 3 — Editor UI
  -- ============================================================
  (96, '[T4 · P3.1] Build FormEditorScreen layout (list + edit + preview)',
   $$Three-pane on wide, stacked on narrow: form list, edit tree, live preview.

What this means for users: the screen Admins open to make changes — everything visible at once on Windows, stackable on a phone.$$,
   'Jean Burger',
   '[T4 · Phase 3] Admin form editor UI — edit text, add/remove questions, tables, and images'),

  (97, '[T4 · P3.2] Inline-editable widgets per element type',
   $$Text block, question (text/number/date/signature/checkbox/dropdown), table, image — each editable inline.

What this means for users: change wording or settings on an element directly, no separate "edit element" dialog.$$,
   'Jean Burger',
   '[T4 · Phase 3] Admin form editor UI — edit text, add/remove questions, tables, and images'),

  (98, '[T4 · P3.3] Insert toolbar + drag-reorder',
   $$Toolbar to add elements; long-press drag to reorder; visual drop indicator.

What this means for users: composing a form feels like editing a document, not filling out a config file.$$,
   'Jean Burger + Justin Trollip',
   '[T4 · Phase 3] Admin form editor UI — edit text, add/remove questions, tables, and images'),

  (99, '[T4 · P3.4] Image upload to form-definition-images bucket',
   $$New storage bucket; image picker + upload; the schema stores the storage path.

What this means for users: drop a logo or diagram into a form without leaving the editor.$$,
   'Jean Burger',
   '[T4 · Phase 3] Admin form editor UI — edit text, add/remove questions, tables, and images'),

  (100,'[T4 · P3.5] Save-as-new-version dialog with required change summary',
   $$Modal that requires a non-empty change_summary before commit; commit inserts the new form_versions row.

What this means for users: every save asks "what changed?" so the version history is meaningful, not empty.$$,
   'Jean Burger',
   '[T4 · Phase 3] Admin form editor UI — edit text, add/remove questions, tables, and images'),

  -- ============================================================
  -- T4 · Phase 4 — Version history
  -- ============================================================
  (101,'[T4 · P4.1] Build FormVersionHistoryScreen layout',
   $$List of versions with edited-by avatar, edited-at, change_summary.

What this means for users: see every change ever made to a form, who made it, and why.$$,
   'Jean Burger',
   '[T4 · Phase 4] Version history viewer with diff and rollback'),

  (102,'[T4 · P4.2] Side-by-side diff viewer (prior vs chosen version)',
   $$Two panes with added / removed / changed highlights at the element level.

What this means for users: see exactly what's different between two versions without re-reading the whole form.$$,
   'Jean Burger',
   '[T4 · Phase 4] Version history viewer with diff and rollback'),

  (103,'[T4 · P4.3] Restore-version action (clones as a brand-new latest version)',
   $$Restoring v3 when v7 is current produces a v8 cloned from v3 — never overwrites history.

What this means for users: rolling back is one click, but the audit trail is never lost.$$,
   'Jean Burger',
   '[T4 · Phase 4] Version history viewer with diff and rollback'),

  (104,'[T4 · P4.4] Per-field change log display',
   $$Render the form_change_log entries underneath each version showing field-level adds / edits / deletes.

What this means for users: granular audit — see what specific question changed, not just that something did.$$,
   'Jean Burger',
   '[T4 · Phase 4] Version history viewer with diff and rollback'),

  -- ============================================================
  -- T4 · Phase 5 — Renderer + proof migration
  -- ============================================================
  (105,'[T4 · P5.1] Build DynamicFormRenderer widget',
   $$Takes form_version.schema jsonb; renders TextFormField / DatePickerField / SignatureCanvasField / table / image — same look as existing screens.

What this means for users: the engine that turns an editable form definition back into a real, fillable form.$$,
   'Jean Burger + Justin Trollip',
   '[T4 · Phase 5] Data-driven form renderer plus migration of the first proof forms'),

  (106,'[T4 · P5.2] Stamp schema_version_id on submit',
   $$Wrapper around saveFormSubmissionAndStartWorkflow that captures the active version at submit time.

What this means for users: each submission permanently remembers which form version it was filled against.$$,
   'Jean Burger',
   '[T4 · Phase 5] Data-driven form renderer plus migration of the first proof forms'),

  (107,'[T4 · P5.3] Migrate first proof form (Lockout Checklist) to renderer',
   $$Replace lib/screens/lockout_checklist_form_screen.dart with a thin shell that loads the definition and delegates to DynamicFormRenderer.

What this means for users: the first real form running off the new system — proof the engine works.$$,
   'Jean Burger',
   '[T4 · Phase 5] Data-driven form renderer plus migration of the first proof forms'),

  (108,'[T4 · P5.4] Migrate second proof form (Shift Boss Daily Report)',
   $$Same treatment for daily_report.

What this means for users: second proof — confirms the engine handles a second form shape without bespoke code per form.$$,
   'Jean Burger',
   '[T4 · Phase 5] Data-driven form renderer plus migration of the first proof forms'),

  -- ============================================================
  -- T4 · Phase 6 — PDF integration
  -- ============================================================
  (109,'[T4 · P6.1] Build dynamic_form_pdf.dart generator',
   $$Takes schema + payload; renders via pdf_runtime helpers in mm-letter coordinates; matches existing per-form generators visually.

What this means for users: the PDFs of dynamic forms look right — same as the existing PDFs.$$,
   'Jean Burger',
   '[T4 · Phase 6] PDF generator integration with versioned schemas'),

  (110,'[T4 · P6.2] Wire into form_registry.generatePdfForFormType routing',
   $$Dynamic forms route to the new generator; hard-coded forms keep their existing route.

What this means for users: the PDF system handles both old and new forms transparently — no separate path the user has to know about.$$,
   'Jean Burger',
   '[T4 · Phase 6] PDF generator integration with versioned schemas'),

  (111,'[T4 · P6.3] Re-test the two proof forms PDFs against originals',
   $$Visual diff — confirm the new generator produces an equivalent PDF for the proof forms.

What this means for users: a submitted form via the new engine still produces the same printable record as before.$$,
   'Jean Burger',
   '[T4 · Phase 6] PDF generator integration with versioned schemas'),

  -- ============================================================
  -- T4 · Phase 7 — E2E test
  -- ============================================================
  (112,'[T4 · P7.1] End-to-end edit / save / fill cycle on Windows',
   $$Admin edits a form, saves v2; user opens the form on another device, sees v2, submits; PDF renders v2.

What this means for users: the entire editor-to-user-submission loop verified on the desktop experience.$$,
   'Jean Burger + Justin Trollip',
   '[T4 · Phase 7] End-to-end testing, Windows + Android editor parity, rollout doc'),

  (113,'[T4 · P7.2] Test Android editor usability (or restrict to Windows)',
   $$Walk the editor on a phone; if touch UX is poor, restrict the editor route to canAccessFormEditor() guarded by platform.

What this means for users: either editing forms works on a phone, or it's intentionally Windows-only — never broken on a phone.$$,
   'Jean Burger',
   '[T4 · Phase 7] End-to-end testing, Windows + Android editor parity, rollout doc'),

  (114,'[T4 · P7.3] Verify historical v1 PDFs still render after v2 ships',
   $$Re-open an old submission stamped v1; confirm the PDF still uses v1 schema, not v2.

What this means for users: old records keep looking right even after an Admin edits the form.$$,
   'Jean Burger',
   '[T4 · Phase 7] End-to-end testing, Windows + Android editor parity, rollout doc'),

  (115,'[T4 · P7.4] flutter analyze clean + developer-notes form-engine section + per-form migration recipe',
   $$No new warnings; the project's developer notes gain a Form Engine section + a step-by-step recipe for migrating the remaining 25 forms.

What this means for users: future engineering can migrate the remaining forms one by one without re-deriving how the system works.$$,
   'Jean Burger',
   '[T4 · Phase 7] End-to-end testing, Windows + Android editor parity, rollout doc')

) as v(offset_seconds, title, description, author_name, parent_title)
join public.todos parent
  on parent.title = v.parent_title and parent.kind = 'eng'
where not exists (
  select 1 from public.todos t where t.kind = 'eng' and t.title = v.title
);
