-- SP4 Appointments lifecycle: issued appointments + accept/sign/co-sign/resign.
-- Co-signing reuses the signature-workflow edge function via form_submissions;
-- this migration adds the lifecycle record + notification/activation triggers.

create table if not exists public.appointments (
  id              uuid primary key default gen_random_uuid(),
  template_id     uuid references public.appointment_templates(id) on delete set null,
  role_id         uuid references public.appointment_roles(id) on delete set null,
  role_code       text not null,
  appointee_id    uuid not null references public.profiles(id) on delete cascade,
  issued_by       uuid references public.profiles(id) on delete set null,
  shaft_id        uuid references public.shafts(id) on delete set null,
  section         text,
  cycle           text,
  effective_date  date not null,
  period_month    date generated always as
                    (make_date(extract(year from effective_date)::int, extract(month from effective_date)::int, 1)) stored,
  status          text not null default 'pending_acceptance'
                    check (status in ('pending_acceptance','pending_signoff','active','declined','resigned')),
  payload         jsonb not null default '{}'::jsonb,
  submission_id   uuid references public.form_submissions(id) on delete set null,
  resign_reason   text,
  issued_at       timestamptz not null default now(),
  accepted_at     timestamptz,
  declined_at     timestamptz,
  activated_at    timestamptz,
  resigned_at     timestamptz,
  updated_at      timestamptz not null default now()
);

create index if not exists appointments_appointee_idx
  on public.appointments (appointee_id, status);
create index if not exists appointments_submission_idx
  on public.appointments (submission_id);
create unique index if not exists appointments_one_live_per_slot
  on public.appointments (appointee_id, role_code, shaft_id, period_month)
  where status in ('pending_acceptance','pending_signoff','active');

alter table public.appointments enable row level security;

create policy "Read own or admin appointments"
  on public.appointments for select to authenticated
  using (appointee_id = auth.uid() or public.is_admin(auth.uid()));
create policy "Admins insert appointments"
  on public.appointments for insert to authenticated
  with check (public.is_admin(auth.uid()));
create policy "Admin or appointee update appointments"
  on public.appointments for update to authenticated
  using (appointee_id = auth.uid() or public.is_admin(auth.uid()))
  with check (appointee_id = auth.uid() or public.is_admin(auth.uid()));

-- Lifecycle notifications (cross-user inserts need definer rights).
create or replace function public.appointments_notify()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT') then
    insert into public.notifications (user_id, type, title, body, action_url, metadata)
    values (new.appointee_id, 'message', 'New appointment',
            coalesce(new.role_code,'Appointment') || ' appointment pending your acceptance',
            '/my-appointments',
            jsonb_build_object('appointmentId', new.id, 'roleCode', new.role_code, 'status', new.status));
    return new;
  elsif (tg_op = 'UPDATE' and new.status is distinct from old.status) then
    if (new.status in ('pending_signoff','active') and old.status = 'pending_acceptance' and new.issued_by is not null) then
      insert into public.notifications (user_id, type, title, body, action_url, metadata)
      values (new.issued_by, 'success', 'Appointment accepted',
              'An appointee accepted their ' || coalesce(new.role_code,'') || ' appointment',
              '/setup/appointments',
              jsonb_build_object('appointmentId', new.id, 'status', new.status));
    elsif (new.status = 'declined' and new.issued_by is not null) then
      insert into public.notifications (user_id, type, title, body, action_url, metadata)
      values (new.issued_by, 'warning', 'Appointment declined',
              'An appointee declined their ' || coalesce(new.role_code,'') || ' appointment',
              '/setup/appointments',
              jsonb_build_object('appointmentId', new.id, 'status', new.status));
    elsif (new.status = 'resigned' and new.issued_by is not null) then
      insert into public.notifications (user_id, type, title, body, action_url, metadata)
      values (new.issued_by, 'warning', 'Appointment resigned',
              coalesce(new.role_code,'') || ' appointment resigned',
              '/setup/appointments',
              jsonb_build_object('appointmentId', new.id, 'status', new.status, 'reason', coalesce(new.resign_reason,'')));
    end if;
    return new;
  end if;
  return new;
end $$;

drop trigger if exists trg_appointments_notify on public.appointments;
create trigger trg_appointments_notify
  after insert or update of status on public.appointments
  for each row execute function public.appointments_notify();

-- Flip a pending_signoff appointment to active when its co-sign submission completes.
create or replace function public.appointments_activate_on_signoff()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (new.workflow_status = 'fully_signed' and old.workflow_status is distinct from 'fully_signed') then
    update public.appointments
       set status = 'active', activated_at = now(), updated_at = now()
     where submission_id = new.id and status = 'pending_signoff';
  end if;
  return new;
end $$;

drop trigger if exists trg_appointments_activate on public.form_submissions;
create trigger trg_appointments_activate
  after update of workflow_status on public.form_submissions
  for each row execute function public.appointments_activate_on_signoff();
