-- e-be-4: bring the existing 'signatures' bucket policies under version
-- control. The four policies already exist in production; this migration
-- restates them as idempotent CREATE statements (drop-if-exists first) so
-- the migration history is now the source of truth for storage RLS.
--
-- Bucket itself: signatures (private; 1 MB file_size_limit; image/png +
-- image/jpeg). No bucket-level changes here — only the RLS policies on
-- storage.objects.

drop policy if exists "Users can upload their own signatures" on storage.objects;
create policy "Users can upload their own signatures"
  on storage.objects for insert
  with check (
    bucket_id = 'signatures'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );

drop policy if exists "Users can view their own signatures" on storage.objects;
create policy "Users can view their own signatures"
  on storage.objects for select
  using (
    bucket_id = 'signatures'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );

drop policy if exists "Users can update their own signatures" on storage.objects;
create policy "Users can update their own signatures"
  on storage.objects for update
  using (
    bucket_id = 'signatures'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );

drop policy if exists "Users can delete their own signatures" on storage.objects;
create policy "Users can delete their own signatures"
  on storage.objects for delete
  using (
    bucket_id = 'signatures'
    and (storage.foldername(name))[1] = (auth.uid())::text
  );
