import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient, SupabaseClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

const compromisedPasswordMessage =
  "This password has appeared in a known data breach. Choose a different password.";

async function sha1Hex(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-1", bytes);
  return [...new Uint8Array(digest)]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

async function assertPasswordNotCompromised(password: string): Promise<void> {
  const hash = await sha1Hex(password);
  const prefix = hash.slice(0, 5);
  const suffix = hash.slice(5);
  const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
    headers: { "Add-Padding": "true" },
  });

  if (!response.ok) {
    throw new Error("Password safety check is unavailable right now. Please try again.");
  }

  const hashes = await response.text();
  const breached = hashes
    .split("\n")
    .map((line) => line.trim().split(":"))
    .some(
      ([candidate, count]) =>
        candidate === suffix && Number.parseInt(count ?? "0", 10) > 0,
    );

  if (breached) {
    throw new Error(compromisedPasswordMessage);
  }
}

// Best-effort audit + notify helpers. Both swallow errors so the user-facing
// flow never fails just because the secondary writes did. They're awaited so
// the function can't return before they finish, but their throws don't
// propagate to the caller.
async function writeAuditLog(
  client: SupabaseClient,
  callerId: string,
  payload: {
    action: string;
    entity_type?: string | null;
    entity_id?: string | null;
    new_values?: Record<string, unknown>;
    old_values?: Record<string, unknown>;
  },
): Promise<void> {
  try {
    await client.from("audit_log").insert({
      user_id: callerId,
      action: payload.action,
      entity_type: payload.entity_type ?? "user",
      entity_id: payload.entity_id ?? null,
      new_values: payload.new_values ?? null,
      old_values: payload.old_values ?? null,
    });
  } catch (_err) {
    // intentionally swallowed
  }
}

async function notifyNewUser(
  client: SupabaseClient,
  newUserId: string,
  newUserEmail: string,
): Promise<void> {
  try {
    await client.from("notifications").insert({
      user_id: newUserId,
      type: "system",
      title: "Welcome to Mine Online",
      body:
        `An administrator has created your account (${newUserEmail}). ` +
        "Open My Profile to complete your details and save a signature.",
      action_url: "/my-profile",
      metadata: { category: "admin" },
    });
  } catch (_err) {
    // intentionally swallowed
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const {
      data: { user: callerUser },
    } = await supabaseUser.auth.getUser();
    if (!callerUser) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: callerProfile } = await supabaseAdmin
      .from("profiles")
      .select("is_super_admin")
      .eq("id", callerUser.id)
      .maybeSingle();

    if (!callerProfile?.is_super_admin) {
      return new Response(
        JSON.stringify({ error: "Forbidden: Super admin only" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const body = await req.json();
    const { action, email, password, userId } = body;

    if (action === "create") {
      if (!email || !password) {
        return new Response(
          JSON.stringify({ error: "Email and password required" }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }

      await assertPasswordNotCompromised(password);

      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      });

      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const newUserId = data.user?.id;
      if (newUserId) {
        await Promise.all([
          notifyNewUser(supabaseAdmin, newUserId, email),
          writeAuditLog(supabaseAdmin, callerUser.id, {
            action: "user.create",
            entity_id: newUserId,
            new_values: { email },
          }),
        ]);
      }

      return new Response(JSON.stringify({ user: data.user }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "delete") {
      if (!userId) {
        return new Response(JSON.stringify({ error: "userId required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      await writeAuditLog(supabaseAdmin, callerUser.id, {
        action: "user.delete",
        entity_id: userId,
      });

      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "update_password") {
      if (!userId || !password) {
        return new Response(
          JSON.stringify({ error: "userId and password required" }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }

      await assertPasswordNotCompromised(password);

      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password,
      });
      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      await writeAuditLog(supabaseAdmin, callerUser.id, {
        action: "user.update_password",
        entity_id: userId,
      });

      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "set_disabled") {
      if (!userId || typeof body.disabled !== "boolean") {
        return new Response(
          JSON.stringify({ error: "userId and disabled (boolean) required" }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          },
        );
      }

      const disabled = body.disabled as boolean;

      const { error: banErr } = await supabaseAdmin.auth.admin.updateUserById(
        userId,
        { ban_duration: disabled ? "876000h" : "none" },
      );
      if (banErr) {
        return new Response(JSON.stringify({ error: banErr.message }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      await supabaseAdmin
        .from("profiles")
        .update({
          disabled,
          disabled_at: disabled ? new Date().toISOString() : null,
        })
        .eq("id", userId);

      await writeAuditLog(supabaseAdmin, callerUser.id, {
        action: disabled ? "user.disable" : "user.enable",
        entity_id: userId,
      });

      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
