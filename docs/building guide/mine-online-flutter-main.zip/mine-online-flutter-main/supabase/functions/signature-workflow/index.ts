import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import nodemailer from "npm:nodemailer@6.9.16";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

type SignatureRole = "Mine Overseer" | "Mine Manager";

type Profile = {
  id: string;
  full_name?: string | null;
  first_name?: string | null;
  email?: string | null;
  title?: string | null;
  job_title?: string | null;
  company_number?: string | null;
  company?: string | null;
  department?: string | null;
  cost_centre?: string | null;
  location?: string | null;
  phone?: string | null;
  occupation?: string | null;
  user_account_type?: string | null;
  is_admin?: boolean | null;
  is_super_admin?: boolean | null;
  signature_data?: string | null;
};

type FormSubmission = {
  id: string;
  user_id: string;
  form_type: string;
  title: string;
  payload: Record<string, unknown>;
  created_at: string;
};

type SignatureRequest = {
  id: string;
  submission_id: string;
  requested_by: string;
  requested_role: SignatureRole;
  signature_field: string;
  date_field: string | null;
  step_order: number;
  status: "pending" | "signed" | "superseded" | "cancelled";
  signed_by: string | null;
  signed_at: string | null;
  request_metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
};

// The project does not currently ship generated Supabase database types for Edge Functions.
// Keep the privileged client dynamic so Deno can type-check the function without inferring every table as `never`.
type SupabaseAdminClient = any;

type SignatureRule = {
  role: SignatureRole;
  signatureField: string;
  dateFields: string[];
  label: string;
  order: number;
};

const profileSelect = [
  "id",
  "full_name",
  "first_name",
  "email",
  "title",
  "job_title",
  "company_number",
  "company",
  "department",
  "cost_centre",
  "location",
  "phone",
  "occupation",
  "user_account_type",
  "is_admin",
  "is_super_admin",
  "signature_data",
].join(",");

const signatureRules: SignatureRule[] = [
  {
    role: "Mine Overseer",
    signatureField: "signatures.mineOverseerSignature",
    dateFields: ["signatures.mineOverseerDate"],
    label: "Mine Overseer",
    order: 10,
  },
  {
    role: "Mine Manager",
    signatureField: "signatures.mineManagerSignature",
    dateFields: ["signatures.mineManagerDate"],
    label: "Mine Manager",
    order: 20,
  },
  {
    role: "Mine Overseer",
    signatureField: "mineOverseerSignature",
    dateFields: ["mineOverseerDate", "mineOverseerSignatureDate"],
    label: "Mine Overseer",
    order: 10,
  },
  {
    role: "Mine Overseer",
    signatureField: "minerOverseerSignature",
    dateFields: ["minerOverseerSignatureDate"],
    label: "Mine Overseer",
    order: 10,
  },
  {
    role: "Mine Overseer",
    signatureField: "mineManagerOverseerSignature",
    dateFields: ["mineManagerOverseerDate"],
    label: "Mine Manager / Mine Overseer",
    order: 10,
  },
  {
    role: "Mine Overseer",
    signatureField: "managerMineOverseerSignature",
    dateFields: ["signatureDate", "managerMineOverseerDate"],
    label: "Mine Manager / Mine Overseer",
    order: 10,
  },
  {
    role: "Mine Manager",
    signatureField: "mineManagerSignature",
    dateFields: ["mineManagerDate"],
    label: "Mine Manager",
    order: 20,
  },
  {
    role: "Mine Manager",
    signatureField: "managerSignature",
    dateFields: ["managerDate"],
    label: "Manager",
    order: 20,
  },
];

const jsonResponse = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

function getServiceRoleKey() {
  const legacyKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (legacyKey) return legacyKey;

  const secretKeys = Deno.env.get("SUPABASE_SECRET_KEYS");
  if (!secretKeys) return "";

  try {
    const parsed = JSON.parse(secretKeys);
    const defaultKeyName = parsed.default || parsed.DEFAULT || Object.values(parsed)[0];
    return typeof defaultKeyName === "string" ? Deno.env.get(defaultKeyName) || defaultKeyName : "";
  } catch {
    return "";
  }
}

function displayName(profile?: Profile | null) {
  if (!profile) return "Unknown user";
  return profile.full_name || profile.first_name || profile.email || "Unknown user";
}

function normalizeProfile(profile?: Profile | null) {
  if (!profile) return null;
  return {
    id: profile.id,
    full_name: profile.full_name || "",
    first_name: profile.first_name || "",
    email: profile.email || "",
    title: profile.title || "",
    job_title: profile.job_title || "",
    company_number: profile.company_number || "",
    company: profile.company || "",
    department: profile.department || "",
    cost_centre: profile.cost_centre || "",
    location: profile.location || "",
    phone: profile.phone || "",
    occupation: profile.occupation || "",
    user_account_type: profile.user_account_type || "none of the above",
  };
}

function isAdminProfile(profile?: Profile | null) {
  return Boolean(
    profile?.is_admin ||
      profile?.is_super_admin ||
      profile?.user_account_type === "Admin" ||
      profile?.user_account_type === "Super Admin"
  );
}

function occupationContains(profile: Profile | null | undefined, words: string[]) {
  const normalized = (profile?.occupation || "").toLowerCase();
  return words.every((word) => normalized.includes(word.toLowerCase()));
}

function profileMatchesRole(profile: Profile | null | undefined, role: SignatureRole) {
  if (!profile) return false;
  if (profile.user_account_type === role) return true;
  if (role === "Mine Overseer") return occupationContains(profile, ["mine", "overseer"]);
  return occupationContains(profile, ["mine", "manager"]);
}

function getPathValue(source: unknown, path: string): unknown {
  return path.split(".").reduce<unknown>((current, part) => {
    if (current && typeof current === "object" && part in current) {
      return (current as Record<string, unknown>)[part];
    }
    return undefined;
  }, source);
}

function hasPath(source: unknown, path: string): boolean {
  return getPathValue(source, path) !== undefined;
}

function setPathValue(source: Record<string, unknown>, path: string, value: unknown) {
  const parts = path.split(".");
  let current: Record<string, unknown> = source;
  parts.slice(0, -1).forEach((part) => {
    const next = current[part];
    if (!next || typeof next !== "object" || Array.isArray(next)) {
      current[part] = {};
    }
    current = current[part] as Record<string, unknown>;
  });
  current[parts[parts.length - 1]] = value;
}

function isBlank(value: unknown) {
  return value === undefined || value === null || (typeof value === "string" && value.trim() === "");
}

function findSignatureSlots(payload: Record<string, unknown>) {
  const seen = new Set<string>();
  return signatureRules
    .filter((rule) => hasPath(payload, rule.signatureField))
    .map((rule) => ({
      ...rule,
      dateField: rule.dateFields.find((field) => hasPath(payload, field)) || rule.dateFields[0] || null,
    }))
    .filter((slot) => {
      if (seen.has(slot.signatureField)) return false;
      seen.add(slot.signatureField);
      return true;
    })
    .sort((a, b) => a.order - b.order);
}

function findNextSlot(payload: Record<string, unknown>) {
  return findSignatureSlots(payload).find((slot) => isBlank(getPathValue(payload, slot.signatureField))) || null;
}

function formatTimestamp(value: string) {
  return new Intl.DateTimeFormat("en-ZA", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Africa/Johannesburg",
  }).format(new Date(value));
}

type EmailDetails = {
  recipientRole: SignatureRole;
  documentTitle: string;
  documentType: string;
  submittedBy: string;
  submittedAt: string;
  previousSigner?: string;
  submitterProfile?: ReturnType<typeof normalizeProfile>;
  actionUrl: string;
};

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function appBaseUrl() {
  return (Deno.env.get("APP_BASE_URL") || "").replace(/\/+$/, "");
}

function buildActionLink(actionUrl: string) {
  const base = appBaseUrl();
  if (!base) return actionUrl;
  if (actionUrl.startsWith("http://") || actionUrl.startsWith("https://")) return actionUrl;
  return `${base}${actionUrl.startsWith("/") ? "" : "/"}${actionUrl}`;
}

function emailText(details: EmailDetails) {
  const previous = details.previousSigner
    ? `\nPrevious signature completed by: ${details.previousSigner}`
    : "";
  const submitterLines: string[] = [];
  if (details.submitterProfile) {
    const p = details.submitterProfile;
    if (p.job_title) submitterLines.push(`Job title: ${p.job_title}`);
    if (p.occupation) submitterLines.push(`Occupation: ${p.occupation}`);
    if (p.company) submitterLines.push(`Company: ${p.company}`);
    if (p.department) submitterLines.push(`Department: ${p.department}`);
    if (p.cost_centre) submitterLines.push(`Cost centre: ${p.cost_centre}`);
    if (p.location) submitterLines.push(`Location: ${p.location}`);
    if (p.phone) submitterLines.push(`Phone: ${p.phone}`);
  }
  return [
    `New ${details.recipientRole} signature request`,
    "",
    `Document: ${details.documentTitle}`,
    `Document type: ${details.documentType}`,
    `Submitted by: ${details.submittedBy}`,
    `Submitted at: ${details.submittedAt}`,
    `Required signature: ${details.recipientRole}`,
    ...submitterLines,
    previous,
    "",
    `Open Signature Requests: ${buildActionLink(details.actionUrl)}`,
  ].filter(Boolean).join("\n");
}

function emailHtml(details: EmailDetails) {
  const link = buildActionLink(details.actionUrl);
  const submitterRows: string[] = [];
  if (details.submitterProfile) {
    const p = details.submitterProfile;
    const row = (label: string, value?: string | null) =>
      value ? `<tr><td style="padding:4px 12px 4px 0;color:#5f6368;font-size:13px;">${escapeHtml(label)}</td><td style="padding:4px 0;color:#202124;font-size:13px;">${escapeHtml(value)}</td></tr>` : "";
    submitterRows.push(row("Submitted by", p.full_name || p.first_name || p.email || ""));
    submitterRows.push(row("Job title", p.job_title));
    submitterRows.push(row("Occupation", p.occupation));
    submitterRows.push(row("Account type", p.user_account_type));
    submitterRows.push(row("Email", p.email));
    submitterRows.push(row("Phone", p.phone));
    submitterRows.push(row("Company", p.company));
    submitterRows.push(row("Department", p.department));
    submitterRows.push(row("Cost centre", p.cost_centre));
    submitterRows.push(row("Location", p.location));
    submitterRows.push(row("Company number", p.company_number));
  }
  const previousBlock = details.previousSigner
    ? `<p style="margin:8px 0 0;color:#202124;font-size:14px;">Previously signed by: <strong>${escapeHtml(details.previousSigner)}</strong></p>`
    : "";
  return `<!doctype html>
<html><body style="margin:0;padding:0;background:#f1f3f4;font-family:Roboto,Arial,sans-serif;color:#202124;">
  <div style="max-width:600px;margin:24px auto;background:#ffffff;border-radius:16px;padding:28px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <div style="margin-bottom:12px;font-size:12px;letter-spacing:0.6px;text-transform:uppercase;color:#6750A4;font-weight:600;">Mine Online · Signature Request</div>
    <h1 style="margin:0 0 12px;font-size:22px;color:#202124;">${escapeHtml(details.recipientRole)} signature required</h1>
    <p style="margin:0 0 4px;color:#202124;font-size:15px;">Document: <strong>${escapeHtml(details.documentTitle)}</strong></p>
    <p style="margin:0 0 4px;color:#5f6368;font-size:13px;">Form type: ${escapeHtml(details.documentType)}</p>
    <p style="margin:0 0 4px;color:#5f6368;font-size:13px;">Submitted at: ${escapeHtml(details.submittedAt)}</p>
    ${previousBlock}
    <div style="margin:18px 0;border-top:1px solid #e8eaed;"></div>
    <h2 style="margin:0 0 8px;font-size:15px;color:#202124;">Submitter details</h2>
    <table cellpadding="0" cellspacing="0" style="border-collapse:collapse;">${submitterRows.join("")}</table>
    <div style="margin-top:24px;">
      <a href="${escapeHtml(link)}" style="display:inline-block;background:#6750A4;color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:24px;font-size:14px;font-weight:600;">Open Signature Requests</a>
    </div>
    <p style="margin:18px 0 0;color:#80868b;font-size:12px;">You are receiving this message because your role (${escapeHtml(details.recipientRole)}) is the next required signer on this document.</p>
  </div>
</body></html>`;
}

async function sendEmail(profile: Profile, subject: string, text: string, html: string) {
  const to = profile.email;
  const host = Deno.env.get("SMTP_HOST");
  const user = Deno.env.get("SMTP_USER");
  const pass = Deno.env.get("SMTP_PASSWORD");
  if (!to || !host || !user || !pass) return false;

  const port = Number(Deno.env.get("SMTP_PORT") || "465");
  const secure = (Deno.env.get("SMTP_SECURE") || "true").toLowerCase() === "true";
  const fromAddress = Deno.env.get("NOTIFICATION_EMAIL_ADDRESS") || user;
  const fromName = Deno.env.get("NOTIFICATION_EMAIL_FROM_NAME") || "Mine Online Notifications";

  const transport = nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user, pass },
  });

  await transport.sendMail({
    from: `"${fromName}" <${fromAddress}>`,
    to,
    subject,
    text,
    html,
  });

  return true;
}

async function getProfile(supabaseAdmin: SupabaseAdminClient, userId: string) {
  const { data, error } = await supabaseAdmin
    .from("profiles")
    .select(profileSelect)
    .eq("id", userId)
    .maybeSingle();
  if (error) throw error;
  return data as Profile | null;
}

async function listProfilesForRole(supabaseAdmin: SupabaseAdminClient, role: SignatureRole) {
  const { data, error } = await supabaseAdmin
    .from("profiles")
    .select(profileSelect)
    .not("email", "is", null);
  if (error) throw error;
  return ((data || []) as Profile[]).filter((profile) => profileMatchesRole(profile, role));
}

function signerDetailsLine(profile: Profile | null) {
  if (!profile) return "An approver";
  const first = (profile.first_name || "").trim();
  const fullName = (profile.full_name || "").trim();
  let firstName = first;
  let lastName = "";
  if (!firstName && fullName) {
    const parts = fullName.split(/\s+/);
    firstName = parts.shift() || "";
    lastName = parts.join(" ");
  } else if (fullName) {
    const parts = fullName.split(/\s+/);
    if (parts.length > 1 && (parts[0].toLowerCase() === firstName.toLowerCase() || !firstName)) {
      lastName = parts.slice(1).join(" ");
    }
  }
  const accountType = (profile.user_account_type || profile.occupation || "").trim();
  const phone = (profile.phone || "").trim();
  const email = (profile.email || "").trim();
  return [firstName, lastName, accountType, phone, email]
    .filter((part) => part.length > 0)
    .join(", ");
}

function signedEmailHtml(params: {
  signerLine: string;
  signerRole: SignatureRole;
  documentTitle: string;
  documentType: string;
  signedAtLabel: string;
  workflowComplete: boolean;
  actionUrl: string;
  signerProfile: ReturnType<typeof normalizeProfile> | null;
}) {
  const link = buildActionLink(params.actionUrl);
  const detailRow = (label: string, value?: string | null) =>
    value
      ? `<tr><td style="padding:4px 12px 4px 0;color:#5f6368;font-size:13px;">${escapeHtml(label)}</td><td style="padding:4px 0;color:#202124;font-size:13px;">${escapeHtml(value)}</td></tr>`
      : "";
  const rows: string[] = [];
  if (params.signerProfile) {
    const p = params.signerProfile;
    rows.push(detailRow("Name", p.full_name || `${p.first_name || ""}`.trim()));
    rows.push(detailRow("Account type", p.user_account_type));
    rows.push(detailRow("Occupation", p.occupation));
    rows.push(detailRow("Email", p.email));
    rows.push(detailRow("Phone", p.phone));
    rows.push(detailRow("Company", p.company));
    rows.push(detailRow("Department", p.department));
  }
  const completeBlock = params.workflowComplete
    ? `<p style="margin:8px 0 0;color:#0b8043;font-size:14px;"><strong>This document is now fully signed.</strong></p>`
    : "";
  return `<!doctype html>
<html><body style="margin:0;padding:0;background:#f1f3f4;font-family:Roboto,Arial,sans-serif;color:#202124;">
  <div style="max-width:600px;margin:24px auto;background:#ffffff;border-radius:16px;padding:28px;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
    <div style="margin-bottom:12px;font-size:12px;letter-spacing:0.6px;text-transform:uppercase;color:#6750A4;font-weight:600;">Mine Online · Signature Update</div>
    <h1 style="margin:0 0 12px;font-size:22px;color:#202124;">${escapeHtml(params.signerRole)} has signed your document</h1>
    <p style="margin:0 0 4px;color:#202124;font-size:15px;">${escapeHtml(params.signerLine)} has signed your <strong>${escapeHtml(params.documentTitle)}</strong> at <strong>${escapeHtml(params.signedAtLabel)}</strong>.</p>
    <p style="margin:0 0 4px;color:#5f6368;font-size:13px;">Form type: ${escapeHtml(params.documentType)}</p>
    ${completeBlock}
    <div style="margin:18px 0;border-top:1px solid #e8eaed;"></div>
    <h2 style="margin:0 0 8px;font-size:15px;color:#202124;">Signer details</h2>
    <table cellpadding="0" cellspacing="0" style="border-collapse:collapse;">${rows.join("")}</table>
    <div style="margin-top:24px;">
      <a href="${escapeHtml(link)}" style="display:inline-block;background:#6750A4;color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:24px;font-size:14px;font-weight:600;">Open the document</a>
    </div>
    <p style="margin:18px 0 0;color:#80868b;font-size:12px;">You are receiving this message because you submitted this document for signature approval.</p>
  </div>
</body></html>`;
}

async function notifySubmitterOfSignature(
  supabaseAdmin: SupabaseAdminClient,
  params: {
    submission: FormSubmission;
    submitterProfile: Profile | null;
    signerProfile: Profile | null;
    signerRole: SignatureRole;
    signedAt: string;
    signedAtLabel: string;
    workflowComplete: boolean;
  }
) {
  const submitter = params.submitterProfile;
  if (!submitter?.id) {
    return { notificationCount: 0, emailCount: 0 };
  }

  const signerLine = signerDetailsLine(params.signerProfile);
  const title = params.workflowComplete
    ? `Fully signed: ${params.submission.title}`
    : `${params.signerRole} signed: ${params.submission.title}`;
  const body = `${signerLine} has signed your ${params.submission.title} at ${params.signedAtLabel}.`;
  const actionUrl = `/current-logbook?submission=${params.submission.id}`;
  const metadata = {
    category: "signature_signed",
    submissionId: params.submission.id,
    documentTitle: params.submission.title,
    documentType: params.submission.form_type,
    signerRole: params.signerRole,
    signedAt: params.signedAt,
    signedAtLabel: params.signedAtLabel,
    signerProfile: normalizeProfile(params.signerProfile),
    workflowComplete: params.workflowComplete,
  };

  let notificationCount = 0;
  try {
    const { error } = await supabaseAdmin.from("notifications").insert({
      user_id: submitter.id,
      type: "message",
      title,
      body,
      action_url: actionUrl,
      metadata,
    });
    if (error) {
      console.error("notifySubmitterOfSignature notification insert failed", error);
    } else {
      notificationCount = 1;
    }
  } catch (err) {
    console.error("notifySubmitterOfSignature notification insert threw", err);
  }

  let emailCount = 0;
  try {
    const html = signedEmailHtml({
      signerLine,
      signerRole: params.signerRole,
      documentTitle: params.submission.title,
      documentType: params.submission.form_type,
      signedAtLabel: params.signedAtLabel,
      workflowComplete: params.workflowComplete,
      actionUrl,
      signerProfile: normalizeProfile(params.signerProfile),
    });
    const text = [
      title,
      "",
      body,
      params.workflowComplete ? "This document is now fully signed." : "",
      "",
      `Open the document: ${buildActionLink(actionUrl)}`,
    ]
      .filter((line) => line !== undefined && line !== null)
      .join("\n");
    const sent = await sendEmail(submitter, title, text, html);
    if (sent) emailCount = 1;
  } catch (err) {
    console.error("notifySubmitterOfSignature email send threw", err);
  }

  return { notificationCount, emailCount };
}

async function notifyRole(
  supabaseAdmin: SupabaseAdminClient,
  params: {
    request: SignatureRequest;
    submission: FormSubmission;
    role: SignatureRole;
    submitterProfile: Profile | null;
    previousSignerProfile?: Profile | null;
  }
) {
  const recipients = await listProfilesForRole(supabaseAdmin, params.role);
  const submittedAt = formatTimestamp(params.submission.created_at);
  const submitterName = displayName(params.submitterProfile);
  const previousSignerName = params.previousSignerProfile ? displayName(params.previousSignerProfile) : "";
  const actionUrl = `/signature-requests?request=${params.request.id}`;
  const title = `Signature required: ${params.submission.title}`;
  const body = previousSignerName
    ? `${submitterName} submitted ${params.submission.title}. ${previousSignerName} has signed; ${params.role} signature is now pending.`
    : `${submitterName} submitted ${params.submission.title}. ${params.role} signature is now pending.`;
  const metadata = {
    category: "signature",
    signatureRequestId: params.request.id,
    submissionId: params.submission.id,
    documentTitle: params.submission.title,
    documentType: params.submission.form_type,
    requestedRole: params.role,
    submittedAt: params.submission.created_at,
    submittedAtLabel: submittedAt,
    submitterProfile: normalizeProfile(params.submitterProfile),
    previousSignerProfile: normalizeProfile(params.previousSignerProfile),
  };

  if (recipients.length > 0) {
    const { error } = await supabaseAdmin.from("notifications").insert(
      recipients.map((recipient) => ({
        user_id: recipient.id,
        type: "message",
        title,
        body,
        action_url: actionUrl,
        metadata,
      }))
    );
    if (error) throw error;
  }

  const emailSubject = title;
  const submitterNormalized = normalizeProfile(params.submitterProfile);
  const emailDetails: EmailDetails = {
    recipientRole: params.role,
    documentTitle: params.submission.title,
    documentType: params.submission.form_type,
    submittedBy: submitterName,
    submittedAt,
    previousSigner: previousSignerName || undefined,
    submitterProfile: submitterNormalized || undefined,
    actionUrl,
  };
  const text = emailText(emailDetails);
  const html = emailHtml(emailDetails);

  const emailResults = await Promise.allSettled(
    recipients.map((recipient) => sendEmail(recipient, emailSubject, text, html))
  );
  const sentCount = emailResults.filter((result) => result.status === "fulfilled" && result.value).length;

  return { notificationCount: recipients.length, emailCount: sentCount };
}

async function createRequestForNextSlot(
  supabaseAdmin: SupabaseAdminClient,
  submission: FormSubmission,
  submitterProfile: Profile | null,
  previousSignerProfile?: Profile | null
) {
  const nextSlot = findNextSlot(submission.payload);

  if (!nextSlot) {
    const { error } = await supabaseAdmin
      .from("form_submissions")
      .update({
        workflow_status: "fully_signed",
        current_signature_role: null,
        completed_at: new Date().toISOString(),
      })
      .eq("id", submission.id);
    if (error) throw error;
    return { request: null, notifyResult: null };
  }

  const { data: existingPending, error: existingError } = await supabaseAdmin
    .from("signature_requests")
    .select("*")
    .eq("submission_id", submission.id)
    .eq("status", "pending")
    .maybeSingle();
  if (existingError) throw existingError;
  if (existingPending) {
    return { request: existingPending as SignatureRequest, notifyResult: null };
  }

  const { data, error } = await supabaseAdmin
    .from("signature_requests")
    .insert({
      submission_id: submission.id,
      requested_by: submission.user_id,
      requested_role: nextSlot.role,
      signature_field: nextSlot.signatureField,
      date_field: nextSlot.dateField,
      step_order: nextSlot.order,
      request_metadata: {
        documentTitle: submission.title,
        documentType: submission.form_type,
        signatureLabel: nextSlot.label,
        submitterProfile: normalizeProfile(submitterProfile),
        previousSignerProfile: normalizeProfile(previousSignerProfile),
      },
    })
    .select("*")
    .single();
  if (error) throw error;

  const request = data as SignatureRequest;
  const { error: updateError } = await supabaseAdmin
    .from("form_submissions")
    .update({
      workflow_status: "pending_signature",
      current_signature_role: nextSlot.role,
      completed_at: null,
    })
    .eq("id", submission.id);
  if (updateError) throw updateError;

  const notifyResult = await notifyRole(supabaseAdmin, {
    request,
    submission,
    role: nextSlot.role,
    submitterProfile,
    previousSignerProfile,
  });

  return { request, notifyResult };
}

async function loadSubmission(supabaseAdmin: SupabaseAdminClient, submissionId: string) {
  const { data, error } = await supabaseAdmin
    .from("form_submissions")
    .select("id,user_id,form_type,title,payload,created_at")
    .eq("id", submissionId)
    .single();
  if (error) throw error;
  return data as FormSubmission;
}

function canViewRequest(
  request: SignatureRequest,
  callerUserId: string,
  callerProfile: Profile | null
) {
  return (
    request.requested_by === callerUserId ||
    request.signed_by === callerUserId ||
    isAdminProfile(callerProfile) ||
    profileMatchesRole(callerProfile, request.requested_role)
  );
}

async function startWorkflow(
  supabaseAdmin: SupabaseAdminClient,
  callerUserId: string,
  callerProfile: Profile | null,
  submissionId: string
) {
  const submission = await loadSubmission(supabaseAdmin, submissionId);
  if (submission.user_id !== callerUserId && !isAdminProfile(callerProfile)) {
    return jsonResponse({ error: "You can only submit your own forms for signature." }, 403);
  }

  const submitterProfile = await getProfile(supabaseAdmin, submission.user_id);
  const result = await createRequestForNextSlot(supabaseAdmin, submission, submitterProfile);
  return jsonResponse({ success: true, ...result });
}

async function signRequest(
  supabaseAdmin: SupabaseAdminClient,
  callerUserId: string,
  callerProfile: Profile | null,
  requestId: string,
  submittedSignature?: string
) {
  const { data: requestData, error: requestError } = await supabaseAdmin
    .from("signature_requests")
    .select("*")
    .eq("id", requestId)
    .single();
  if (requestError) throw requestError;

  const request = requestData as SignatureRequest;
  if (request.status !== "pending") {
    return jsonResponse({ error: "This signature request is no longer pending." }, 409);
  }
  if (!profileMatchesRole(callerProfile, request.requested_role) && !isAdminProfile(callerProfile)) {
    return jsonResponse({ error: `Only a ${request.requested_role} can sign this request.` }, 403);
  }

  const signature = submittedSignature || callerProfile?.signature_data || "";
  if (!signature.trim()) {
    return jsonResponse({ error: "Please add a signature to your profile or draw one before submitting." }, 400);
  }

  const submission = await loadSubmission(supabaseAdmin, request.submission_id);
  const nextPayload = structuredClone(submission.payload);
  const signedAt = new Date().toISOString();
  const signedAtLabel = formatTimestamp(signedAt);

  setPathValue(nextPayload, request.signature_field, signature);
  if (request.date_field) {
    setPathValue(nextPayload, request.date_field, signedAtLabel);
  }

  const { error: submissionError } = await supabaseAdmin
    .from("form_submissions")
    .update({ payload: nextPayload })
    .eq("id", submission.id);
  if (submissionError) throw submissionError;

  const { error: signError } = await supabaseAdmin
    .from("signature_requests")
    .update({
      status: "signed",
      signed_by: callerUserId,
      signed_at: signedAt,
    })
    .eq("id", request.id);
  if (signError) throw signError;

  const submitterProfile = await getProfile(supabaseAdmin, submission.user_id);
  const updatedSubmission = { ...submission, payload: nextPayload };
  const result = await createRequestForNextSlot(
    supabaseAdmin,
    updatedSubmission,
    submitterProfile,
    callerProfile
  );

  // Tell the submitter who just signed their document. `request` was the slot
  // this signer just filled, so its `requested_role` is the signer's role for
  // display purposes (Mine Overseer / Mine Manager).
  const workflowComplete = result.request === null;
  await notifySubmitterOfSignature(supabaseAdmin, {
    submission: updatedSubmission,
    submitterProfile,
    signerProfile: callerProfile,
    signerRole: request.requested_role,
    signedAt,
    signedAtLabel,
    workflowComplete,
  });

  return jsonResponse({ success: true, signedAt, ...result });
}

async function sendBackRequest(
  supabaseAdmin: SupabaseAdminClient,
  callerUserId: string,
  callerProfile: Profile | null,
  requestId: string,
  reason: string | undefined
) {
  const { data: requestData, error: requestError } = await supabaseAdmin
    .from("signature_requests")
    .select("*")
    .eq("id", requestId)
    .single();
  if (requestError) throw requestError;

  const request = requestData as SignatureRequest;
  if (request.status !== "pending") {
    return jsonResponse({ error: "This signature request is no longer pending." }, 409);
  }
  if (
    !profileMatchesRole(callerProfile, request.requested_role) &&
    !isAdminProfile(callerProfile)
  ) {
    return jsonResponse(
      { error: `Only a ${request.requested_role} can send this back.` },
      403
    );
  }

  const submission = await loadSubmission(supabaseAdmin, request.submission_id);
  const trimmedReason = reason?.trim() ?? "";

  // Mark the current pending request as cancelled with the return metadata.
  const cancelMetadata = {
    ...(request.request_metadata ?? {}),
    returnedBy: callerUserId,
    returnedAt: new Date().toISOString(),
    returnReason: trimmedReason.length > 0 ? trimmedReason : null,
  };
  {
    const { error } = await supabaseAdmin
      .from("signature_requests")
      .update({ status: "cancelled", request_metadata: cancelMetadata })
      .eq("id", request.id);
    if (error) throw error;
  }

  // Find the most recently signed request below this step. If found, that's
  // the role that needs to re-sign — revert their signature in the payload,
  // mark the request as cancelled, and create a new pending request for that
  // role so they get notified again.
  const { data: prevSignedData } = await supabaseAdmin
    .from("signature_requests")
    .select("*")
    .eq("submission_id", submission.id)
    .eq("status", "signed")
    .lt("step_order", request.step_order)
    .order("step_order", { ascending: false })
    .limit(1)
    .maybeSingle();
  const prevSigned = (prevSignedData as SignatureRequest | null) ?? null;

  let nextPayload: Record<string, unknown> = submission.payload;
  let nextWorkflowStatus = "returned";
  let nextSignatureRole: SignatureRole | null = null;
  let newPendingRequest: SignatureRequest | null = null;

  if (prevSigned) {
    nextPayload = structuredClone(submission.payload);
    setPathValue(nextPayload, prevSigned.signature_field, "");
    if (prevSigned.date_field) {
      setPathValue(nextPayload, prevSigned.date_field, "");
    }

    {
      const { error } = await supabaseAdmin
        .from("signature_requests")
        .update({ status: "cancelled" })
        .eq("id", prevSigned.id);
      if (error) throw error;
    }

    const { data: newPending, error: insertError } = await supabaseAdmin
      .from("signature_requests")
      .insert({
        submission_id: submission.id,
        requested_by: submission.user_id,
        requested_role: prevSigned.requested_role,
        signature_field: prevSigned.signature_field,
        date_field: prevSigned.date_field,
        step_order: prevSigned.step_order,
        request_metadata: {
          ...(prevSigned.request_metadata ?? {}),
          returnedBy: callerUserId,
          returnedAt: new Date().toISOString(),
          returnReason: trimmedReason.length > 0 ? trimmedReason : null,
          returnedFromRole: request.requested_role,
        },
      })
      .select("*")
      .single();
    if (insertError) throw insertError;
    newPendingRequest = newPending as SignatureRequest;

    nextWorkflowStatus = "pending_signature";
    nextSignatureRole = prevSigned.requested_role;
  }

  {
    const { error } = await supabaseAdmin
      .from("form_submissions")
      .update({
        payload: nextPayload,
        workflow_status: nextWorkflowStatus,
        current_signature_role: nextSignatureRole,
        completed_at: null,
      })
      .eq("id", submission.id);
    if (error) throw error;
  }

  // Notify the submitter + the previous signer (if there is one). Don't
  // notify the caller themselves.
  const submitterId = submission.user_id;
  const recipientIds = new Set<string>([submitterId]);
  if (prevSigned?.signed_by) recipientIds.add(prevSigned.signed_by);
  recipientIds.delete(callerUserId);

  if (recipientIds.size > 0) {
    const callerName = displayName(callerProfile) || request.requested_role;
    const title = `${request.requested_role} returned ${submission.title}`;
    const body =
      trimmedReason.length > 0
        ? `${callerName} sent it back: "${trimmedReason}"`
        : `${callerName} sent it back for changes.`;
    const actionUrl = newPendingRequest
      ? `/signature-requests?request=${newPendingRequest.id}`
      : `/current-logbook?submitted=${submission.id}`;
    try {
      await supabaseAdmin.from("notifications").insert(
        [...recipientIds].map((id) => ({
          user_id: id,
          type: "warning",
          title,
          body,
          action_url: actionUrl,
          metadata: {
            category: "signature",
            submissionId: submission.id,
            documentTitle: submission.title,
            documentType: submission.form_type,
            returnedBy: callerUserId,
            returnedRole: request.requested_role,
            revertedToRole: nextSignatureRole,
            returnReason: trimmedReason.length > 0 ? trimmedReason : null,
          },
        }))
      );
    } catch (err) {
      console.error("send_back notification insert failed", err);
    }
  }

  return jsonResponse({
    success: true,
    workflow_status: nextWorkflowStatus,
    current_signature_role: nextSignatureRole,
    request: newPendingRequest,
  });
}

async function listRequests(
  supabaseAdmin: SupabaseAdminClient,
  callerUserId: string,
  callerProfile: Profile | null,
  status: string
) {
  const normalizedStatus = status === "signed" ? "signed" : "pending";
  const { data, error } = await supabaseAdmin
    .from("signature_requests")
    .select("*")
    .eq("status", normalizedStatus)
    .order(normalizedStatus === "signed" ? "signed_at" : "created_at", { ascending: false, nullsFirst: false })
    .limit(100);
  if (error) throw error;

  const requests = ((data || []) as SignatureRequest[]).filter((request) =>
    canViewRequest(request, callerUserId, callerProfile)
  );

  const submissionIds = [...new Set(requests.map((request) => request.submission_id))];
  const userIds = [
    ...new Set(
      requests.flatMap((request) => [request.requested_by, request.signed_by].filter(Boolean) as string[])
    ),
  ];

  const submissionsById = new Map<string, FormSubmission>();
  if (submissionIds.length > 0) {
    const { data: submissions, error: submissionsError } = await supabaseAdmin
      .from("form_submissions")
      .select("id,user_id,form_type,title,payload,created_at")
      .in("id", submissionIds);
    if (submissionsError) throw submissionsError;
    (submissions || []).forEach((submission: FormSubmission) => {
      submissionsById.set(submission.id, submission as FormSubmission);
      userIds.push(submission.user_id);
    });
  }

  const profilesById = new Map<string, Profile>();
  const uniqueUserIds = [...new Set(userIds)];
  if (uniqueUserIds.length > 0) {
    const { data: profiles, error: profilesError } = await supabaseAdmin
      .from("profiles")
      .select(profileSelect)
      .in("id", uniqueUserIds);
    if (profilesError) throw profilesError;
    (profiles || []).forEach((profile: Profile) => profilesById.set(profile.id, profile));
  }

  return jsonResponse({
    requests: requests.map((request) => {
      const submission = submissionsById.get(request.submission_id) || null;
      return {
        ...request,
        submission,
        submitterProfile: submission ? normalizeProfile(profilesById.get(submission.user_id)) : null,
        signedByProfile: request.signed_by ? normalizeProfile(profilesById.get(request.signed_by)) : null,
      };
    }),
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRoleKey = getServiceRoleKey();
    if (!serviceRoleKey) {
      return jsonResponse({ error: "Missing service role key for signature workflow." }, 500);
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);
    const supabaseUser = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user } } = await supabaseUser.auth.getUser();
    if (!user) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }

    const callerProfile = await getProfile(supabaseAdmin, user.id);
    const body = await req.json();
    const action = body.action as string | undefined;

    if (action === "start_workflow") {
      if (!body.submissionId) return jsonResponse({ error: "submissionId required" }, 400);
      return await startWorkflow(supabaseAdmin, user.id, callerProfile, body.submissionId);
    }

    if (action === "sign_request") {
      if (!body.requestId) return jsonResponse({ error: "requestId required" }, 400);
      return await signRequest(supabaseAdmin, user.id, callerProfile, body.requestId, body.signature);
    }

    if (action === "list_requests") {
      return await listRequests(supabaseAdmin, user.id, callerProfile, body.status || "pending");
    }

    if (action === "send_back") {
      if (!body.requestId) return jsonResponse({ error: "requestId required" }, 400);
      return await sendBackRequest(
        supabaseAdmin,
        user.id,
        callerProfile,
        body.requestId,
        body.reason
      );
    }

    return jsonResponse({ error: "Unknown action" }, 400);
  } catch (err) {
    console.error("signature-workflow error", err);
    return jsonResponse({ error: err instanceof Error ? err.message : String(err) }, 500);
  }
});
