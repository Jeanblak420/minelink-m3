package za.co.assmang.mine_online

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
